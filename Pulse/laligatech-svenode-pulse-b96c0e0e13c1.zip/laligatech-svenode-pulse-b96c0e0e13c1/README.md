# Pulse

This repository is being powered by:

- [Turborepo](https://turbo.build/repo) — High-performance build system for Monorepos
- [React](https://reactjs.org/) — JavaScript library for user interfaces
- [Storybook](https://storybook.js.org/) — UI component environment powered by Vite
- [Vite](https://vite.dev/)- Vite runner and bundler

As well as a few others tools :

- [TypeScript](https://www.typescriptlang.org/) for static type checking
- [ESLint](https://eslint.org/) for code linting
- [Prettier](https://prettier.io) for code formatting

## Requirements

- Node22 (currently not working with node23+)
- PNPM

---

## Commands

For daily work

- `pnpm dev` - Run all packages locally and preview with Storybook
- `pnpm test` - To run tests

For validations and formatting

- `pnpm lint` - Lint all packages
- `pnpm format` - Format all files using prettier

To test builds

- `pnpm build` - Build all packages, including the Storybook site
- `pnpm build:libs` - Build only the libraries
- `pnpm build:storybook` - Build only Storybook

For CI

- `build:nexus:ci` - Build libraries on CI
- `build:ci` - Build Storybook on CI
- `pnpm test:ci` - To run tests

Others

- `pnpm clean` - Clean up all `node_modules` and `dist` folders (runs each package's clean script)

---

## Repo organization

This monorepo includes the following packages and applications:

### Main libraries

- `libs/foundations`: Pulse tokens, themes, and base elements
- `libs/components`: Pulse components

### Storybook

- `apps/storybook`: Component documentation site with Storybook

### Shared configs

- `libs/typescript-config`: Typescript presets
- `libs/eslint-config`: ESLint preset

## Figma <-> Typescript/CSS

- `libs/tokens-builds`: To generate tokens file from figma exports

---

## Guidelines: check [GUIDELINES.md](/GUIDELINES.md)

---

## Tips!!

- Eslint can auto-fix many of the warning. If you are using VSC, you can fix many issues with the command `ESLint: fix all auto-fixable Problems`

## Recommended extensions for VSC

- ESlint: https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint
- Jest: https://marketplace.visualstudio.com/items?itemName=Orta.vscode-jest
  With this extension you can execute tests directly on VSC.
- Prettify Typescript: https://marketplace.visualstudio.com/items?itemName=MylesMurphy.prettify-ts
- Pretty Typescript Errors: https://marketplace.visualstudio.com/items?itemName=YoavBls.pretty-ts-errors

To set it up, you must create a workspace in VSC and add this code (**replace [absolutePath] with your current path to the library**):

```json
{
  ...
  "settings": {
    "jest.virtualFolders": [
      {
        "name": "foundations",
        "path": "libs/foundations",
        "rootPath": "[absolutePath]/pulse/libs/foundations",
        "jestCommandLine": "DEBUG_PRINT_LIMIT=100000 [absolutePath]/pulse/libs/foundations/node_modules/.bin/jest",
        "runMode": "on-demand",
      },
      {
        "name": "components",
        "path": "libs/components",
        "rootPath": "[absolutePath]/pulse/libs/components",
        "jestCommandLine": "DEBUG_PRINT_LIMIT=100000 [absolutePath]/pulse/libs/components/node_modules/.bin/jest",
        "runMode": "on-demand",
      },
    ],
  },
}

```

## General setup

### Important! For migration from @svenues/sv-components, check [MIGRATION.md](/MIGRATION.md)

### Consuming new library

#### Add npm registry in .npmrc

```bash
@pulse:registry=https://nexus-llt.laliga.es/repository/npm-hosted
```

#### Install packages

```bash
npm install @pulse/foundations
npm install @pulse/components
```

#### Add the link for the icon font in your document head

```html
<link
  href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
  rel="stylesheet"
/>
```

#### Add ThemeProvider

```ts
import { themes } from "@pulse/foundations";
import { ThemeProvider } from "styled-components";

<ThemeProvider theme={themes.default}>
  <App />
</ThemeProvider>;
```

#### Importing a Button

You can import components individually or from package root

Option 1 (better for three shaking)

```ts
import { Button } from "@pulse/components/button";

<Button>Test</Button>;
```

Option 2

```ts
import { Button } from "@pulse/components";

<Button>Test</Button>;
```
