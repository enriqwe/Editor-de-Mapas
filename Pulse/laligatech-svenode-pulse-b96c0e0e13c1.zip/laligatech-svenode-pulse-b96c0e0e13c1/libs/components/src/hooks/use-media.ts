/* v8 ignore start */
import { useState } from "react";
import { helpers } from "@pulse/foundations";
import type { MediaValue } from "@pulse/foundations";

import useIsomorphicLayoutEffect from "@hooks/use-isomorphic-layout-effect";

/**
 * Helper hook wrapping the window.matchMedia API. Returns wether or not the client window matches the media string provided
 */
function useMatchMedia(mediaString: string, initialValue = false) {
  const [matches, setMatches] = useState(initialValue);

  useIsomorphicLayoutEffect(() => {
    const mediaQueryList = window.matchMedia(mediaString);
    setMatches(mediaQueryList.matches);

    const controller = new AbortController();

    mediaQueryList.addEventListener(
      "change",
      event => {
        setMatches(event.matches);
      },
      { signal: controller.signal }
    );

    return () => {
      controller.abort();
    };
  }, [mediaString]);

  return matches;
}

/**
 * Returns whether or not the device window is wider than the breakpoint value
 */
export function useUp(mediaValue: MediaValue, initialValue = false) {
  return useMatchMedia(
    `(min-width: ${typeof mediaValue === "string" ? helpers.media.getSize(mediaValue) : mediaValue}px)`,
    initialValue
  );
}

/**
 * Returns whether or not the device window is narrower than the breakpoint value
 */
export function useDown(mediaValue: MediaValue, initialValue = false) {
  return useMatchMedia(
    `(max-width: ${typeof mediaValue === "string" ? helpers.media.getSize(mediaValue) : mediaValue}px)`,
    initialValue
  );
}
/* v8 ignore stop */