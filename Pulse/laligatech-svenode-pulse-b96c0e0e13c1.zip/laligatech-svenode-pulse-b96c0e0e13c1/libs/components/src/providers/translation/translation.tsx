import { createContext, useContext } from "react";
import type { /* JSX, */ PropsWithChildren } from "react";

import { translations as translationFiles } from "./translations";
import type { TranslationsKeys, Locale } from "./translations";

export type { Locale } from "./translations";

type TranslationParams = Record<string, string | number>;

const DEFAULT_LOCALE = "es-ES";

const TranslationContext = createContext(translationFiles[DEFAULT_LOCALE]);

function parametrizeString(
  input: string,
  args: Record<string, string | number>
): string {
  return Object.keys(args).reduce(
    (acum, curr) =>
      acum.replace(new RegExp(`{{${curr}}}`, "g"), `${args[curr]}`),
    input
  );
}

export function TranslationProvider({
  children,
  locale = DEFAULT_LOCALE,
}: PropsWithChildren<{ locale?: Locale }>) /* : JSX.Element */ {
  const translations = translationFiles[locale];

  return (
    <TranslationContext.Provider value={translations}>
      {children}
    </TranslationContext.Provider>
  );
}

export function useTranslation() {
  const translations = useContext(TranslationContext);

  const translate = (key: TranslationsKeys, params?: TranslationParams) => {
    const translation = translations[key] || key;
    if (!params) return translation;
    return parametrizeString(translation, params);
  };

  return translate;
}
