import { render, screen } from "@testing-library/react";

import { TranslationProvider, useTranslation } from "./translation";

describe("translation-provider", () => {
  it("should render children", () => {
    render(
      <TranslationProvider locale="es-ES">
        <div>Children</div>
      </TranslationProvider>
    );

    const div = screen.getByText("Children");

    expect(div).toBeInTheDocument();
  });

  it("should translate children", () => {
    function TestComponent() {
      const translate = useTranslation();
      return <div>{translate("paginationBar.LinesPerPage")}</div>;
    }

    render(
      <TranslationProvider locale="es-ES">
        <TestComponent />
      </TranslationProvider>
    );

    const div = screen.getByText("Lineas por página");

    expect(div).toBeInTheDocument();
  });

  it("should translate children with params", () => {
    function TestComponent() {
      const translate = useTranslation();
      return (
        <div>
          {translate("paginationBar.Description", {
            currentPage: 1,
            totalItems: 10,
          })}
        </div>
      );
    }

    render(
      <TranslationProvider locale="es-ES">
        <TestComponent />
      </TranslationProvider>
    );

    const div = screen.getByText("Mostrando 1 de 10 resultados");

    expect(div).toBeInTheDocument();
  });

  it("should translate children with only existing params", () => {
    function TestComponent() {
      const translate = useTranslation();
      return (
        <div>
          {translate("paginationBar.Description", {
            currentPage: 1,
          })}
        </div>
      );
    }

    render(
      <TranslationProvider locale="es-ES">
        <TestComponent />
      </TranslationProvider>
    );

    const div = screen.getByText("Mostrando 1 de {{totalItems}} resultados");

    expect(div).toBeInTheDocument();
  });
});
