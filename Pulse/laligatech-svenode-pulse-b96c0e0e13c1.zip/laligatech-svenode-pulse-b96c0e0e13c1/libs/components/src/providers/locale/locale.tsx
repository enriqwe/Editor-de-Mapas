import { createContext } from "react";

import type { Locale } from "@providers/translation";

export type LocaleProviderProps = {
  locale: Locale;
}

export const LocaleContext = createContext<Locale>("es-ES");

export function LocaleProvider(props: LocaleProviderProps & { children: React.ReactNode }) {
  return (
    <LocaleContext.Provider value={props.locale}>
      {props.children}
    </LocaleContext.Provider>
  );
}
