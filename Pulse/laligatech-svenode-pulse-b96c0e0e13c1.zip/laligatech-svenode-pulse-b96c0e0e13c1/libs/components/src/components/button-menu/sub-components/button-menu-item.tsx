import { mergeProps, useFocusRing, useMenuItem } from "react-aria";
import { useRef } from "react";
import type { TreeState, Node } from "react-stately";

import * as S from "../button-menu.styled";
import type { ButtonMenuItemProps } from "../button-menu.types";

export function ButtonMenuItem({
  item,
  state,
}: {
  item: Node<ButtonMenuItemProps>;
  state: TreeState<ButtonMenuItemProps>;
}) {
  const MenuItemRef = useRef(null);
  const { menuItemProps } = useMenuItem({ key: item.key }, state, MenuItemRef);
  const { focusProps, isFocusVisible } = useFocusRing();

  return (
    <S.Item
      {...mergeProps(menuItemProps, focusProps)}
      $isFocusVisible={isFocusVisible}
      ref={MenuItemRef}
    >
      {item.rendered}
    </S.Item>
  );
}
