import type { ReactElement } from "react";
import type { AriaMenuProps } from "react-aria";
import type { MenuTriggerProps } from "react-stately";

export type ButtonMenuPlacement = "left" | "right" | "stretch";
export type ButtonMenuVariant = "filled" | "outline" | "flat";

export type ButtonMenuItemProps = {
  iconLeft?: string;
  iconRight?: string;
  name: string;
  onClick?: () => void;
  textValue?: string; // Add this property for accessibility
};

export type ButtonMenuGroupProps = {
  children:
    | ReactElement<ButtonMenuItemProps>
    | ReactElement<ButtonMenuItemProps>[];
  textValue?: string; // Add this property for accessibility
  name: string;
};

export type ButtonMenuProps = {
  automationContext?: string;
  children:
    | ReactElement<ButtonMenuGroupProps | ButtonMenuItemProps>
    | ReactElement<ButtonMenuGroupProps | ButtonMenuItemProps>[];
  disabled?: boolean;
  label: string;
  placement?: ButtonMenuPlacement;
  variant?: ButtonMenuVariant;
};

export type PopoverMenuProps<T> = {
  automationClasses: string;
  disabled: boolean;
  placement: ButtonMenuPlacement;
  variant: ButtonMenuVariant;
} & Omit<
  ButtonMenuProps,
  "automationContext" | "children" | "disabled" | "placement" | "variant"
> &
  AriaMenuProps<T> &
  MenuTriggerProps;

export type ItemsCallback = Record<string, (() => void) | undefined>;
