import type { TreeState, Node } from "react-stately";
import { useMenuSection } from "react-aria";

import * as S from "../button-menu.styled";
import type { ButtonMenuItemProps } from "../button-menu.types";

import { ButtonMenuItem } from "./button-menu-item";

export function ButtonMenuSection({
  section,
  state,
}: {
  section: Node<ButtonMenuItemProps>;
  state: TreeState<ButtonMenuItemProps>;
}) {
  const { itemProps, headingProps, groupProps } = useMenuSection({
    "heading": section.rendered,
    "aria-label": section["aria-label"] ?? "",
  });

  return (
    <li {...itemProps}>
      {section.rendered ?
        <S.GroupTitle {...headingProps}>{section.rendered}</S.GroupTitle>
      : null}
      <S.Group {...groupProps}>
        {[...section.childNodes].map(node => (
          <ButtonMenuItem item={node} key={node.key} state={state} />
        ))}
      </S.Group>
    </li>
  );
}
