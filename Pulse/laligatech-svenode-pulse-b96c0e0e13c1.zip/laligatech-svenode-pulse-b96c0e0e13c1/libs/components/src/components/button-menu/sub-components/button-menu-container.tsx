import { useRef } from "react";
import { useTreeState } from "react-stately";
import { useMenu } from "react-aria";

import * as S from "../button-menu.styled";
import type {
  ButtonMenuItemProps,
  PopoverMenuProps,
} from "../button-menu.types";

import { ButtonMenuSection } from "./button-menu-section";
import { ButtonMenuItem } from "./button-menu-item";

export function ButtonMenuContainer(
  props: PopoverMenuProps<ButtonMenuItemProps>
) {
  const state = useTreeState(props);
  const MenuRef = useRef(null);
  const { menuProps } = useMenu(props, state, MenuRef);

  return (
    <S.Group {...menuProps} ref={MenuRef}>
      {[...state.collection].map(item =>
        item.type === "section" ?
          <ButtonMenuSection key={item.key} section={item} state={state} />
        : <ButtonMenuItem item={item} key={item.key} state={state} />
      )}
    </S.Group>
  );
}
