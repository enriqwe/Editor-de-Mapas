import { Item as CollectionItem, Section } from "react-stately";
import type { ReactElement } from "react";

import { PopoverMenu } from "./sub-components/popover-menu";
import * as S from "./button-menu.styled";
import type {
  ButtonMenuGroupProps,
  ButtonMenuItemProps,
  ButtonMenuProps,
  ItemsCallback,
} from "./button-menu.types";

import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";

let ITEMS_CALLBACK: ItemsCallback = {};
const setItemCallback = (
  current: ItemsCallback,
  name: string,
  callback: (() => void) | undefined
) => ({
  ...current,
  [name]: callback,
});

function Item({ iconLeft, iconRight, onClick, name }: ButtonMenuItemProps) {
  ITEMS_CALLBACK = setItemCallback(ITEMS_CALLBACK, name, onClick);

  return (
    <>
      {iconLeft && <Icon icon={iconLeft} size="s" />}
      {name}
      {iconRight && <Icon icon={iconRight} size="s" />}
    </>
  );
}

function Group({ name }: ButtonMenuGroupProps) {
  return <span>{name}</span>;
}

function Menu({
  automationContext,
  children,
  disabled = false,
  label,
  placement = "left",
  variant = "filled",
}: ButtonMenuProps) {
  const automationClasses = automationClass("button", automationContext);
  const multipleChilds = Array.isArray(children);

  let renderButton = false;
  let firstItem: ButtonMenuItemProps | undefined;

  if (!multipleChilds) {
    if (children.type === Group) {
      const group = children.props as ButtonMenuGroupProps;

      if (!Array.isArray(group.children)) {
        renderButton = true;
        firstItem = group.children.props;
      }
    } else {
      renderButton = true;
      firstItem = children.props as ButtonMenuItemProps;
    }
  }

  if (renderButton) {
    return (
      <S.Button
        $oneItem
        $placement={placement}
        $variant={variant}
        className={automationClasses}
        disabled={disabled}
        onClick={firstItem?.onClick}
      >
        {firstItem?.name}
      </S.Button>
    );
  }

  return (
    <PopoverMenu
      automationClasses={automationClasses}
      disabled={disabled}
      label={label}
      onAction={key => ITEMS_CALLBACK[key]?.()}
      placement={placement}
      variant={variant}
    >
      {multipleChilds ?
        children.map(child => {
          const isGroupChild = child.type === Group;

          if (isGroupChild) {
            const childGroup = child.props as ButtonMenuGroupProps;

            return (
              <Section key={childGroup.name} title={childGroup.name}>
                {Array.isArray(childGroup.children) ?
                  childGroup.children.map(item => (
                    <CollectionItem
                      key={item.props.name}
                      textValue={item.props.textValue || item.props.name}
                    >
                      {item}
                    </CollectionItem>
                  ))
                : <CollectionItem
                    key={childGroup.children.props.name}
                    textValue={
                      childGroup.children.props.textValue ||
                      childGroup.children.props.name
                    }
                  >
                    {childGroup.children}
                  </CollectionItem>
                }
              </Section>
            );
          }
          return (
            <CollectionItem
              key={child.props.name}
              textValue={child.props.textValue || child.props.name}
            >
              {child}
            </CollectionItem>
          );
        })
      : (() => {
          const group = children.props as ButtonMenuGroupProps;
          const groupChildren =
            group.children as ReactElement<ButtonMenuItemProps>[];

          return (
            <Section key={group.name} title={group.name}>
              {groupChildren.map(item => (
                <CollectionItem
                  key={item.props.name}
                  textValue={item.props.textValue || item.props.name}
                >
                  {item}
                </CollectionItem>
              ))}
            </Section>
          );
        })()
      }
    </PopoverMenu>
  );
}

export const ButtonMenu = {
  Group,
  Item,
  Menu,
};
