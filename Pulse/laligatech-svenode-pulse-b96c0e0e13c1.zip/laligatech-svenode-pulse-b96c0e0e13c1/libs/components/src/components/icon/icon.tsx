import type { IconProps } from "./icon.types";
import * as S from "./icon.styled";

import { automationClass } from "@utils/automation-class";
import { TooltipTrigger } from "@components/tooltip";

/**
 * See available icons at {@link https://fonts.google.com/icons}
 */
export function Icon(props: IconProps): React.JSX.Element {
  const {
    fill = false,
    size = "m",
    icon,
    color,
    hoverColor,
    onClick,
    showHoverAndActiveState = false,
    state = "default",
    tooltipContent,
    automationContext,
    tooltipPosition = "bottom",
  } = props;

  const automationClasses = automationClass("icon", automationContext);
  const tooltipAutomationClasses = automationClass("tooltip", "tooltip-icon");

  const getIcon = (): React.JSX.Element => {
    return (
      <S.Wrapper
        $color={color}
        $fill={fill}
        $hoverColor={hoverColor}
        $size={size}
        $state={state}
        aria-hidden={props["aria-hidden"] ?? "true"}
        className={`material-symbols-outlined ${automationClasses}`}
        data-hovfoc={showHoverAndActiveState}
        data-testid="icon"
        onClick={onClick} // To be removed in the future. If action is needed, use IconButton instead
      >
        {icon}
      </S.Wrapper>
    );
  };

  return (
    <>
      {tooltipContent ?
        <TooltipTrigger
          automationContext={tooltipAutomationClasses}
          position={tooltipPosition}
          tooltipContent={tooltipContent}
          triggerElement={getIcon()}
        />
      : getIcon()}
    </>
  );
}
