import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";
import type { ComponentProps } from "react";

import { CreatableDropdown } from "./creatable-dropdown";

import { render } from "@test-utils";

let options = [
  { value: "option one", label: "Option one" },
  { value: "option two", label: "Option two" },
  { value: "option three", label: "Option three", isDisabled: true },
];

let colors = [
  { value: "blue", label: "Blue" },
  { value: "red", label: "Red" },
  { value: "blue", label: "Blue" },
];

const groupedOptions = [
  { label: "Numbers", options },
  { label: "Colors", options: colors },
];

const onSelect = jest.fn();
function DefaultCreatableDropdown(
  props: Partial<ComponentProps<typeof CreatableDropdown>>
) {
  return (
    <CreatableDropdown
      additionalText="Additional text"
      closeMenuOnSelect
      disabled={false}
      error={false}
      formatCreateLabel={inputValue => `${inputValue} (New element)`}
      hideSelectedOptions={false}
      label="Label Dropdown"
      multi={false}
      noOptionsMessage="No options"
      onSelectedOption={onSelect}
      options={options}
      placeholder="Placeholder"
      required
      selectedOption={{ value: "option one", label: "Option one" }}
      {...props}
    />
  );
}

describe("creatableDropdown", () => {
  beforeEach(() => jest.resetAllMocks());

  expect.extend(toHaveNoViolations);

  it("should render properly with single select", async () => {
    const { container, user } = render(<DefaultCreatableDropdown />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    expect(screen.getByText(/option one/i)).toBeTruthy();

    const inputDropdown = screen.getByRole("combobox");
    await user.type(inputDropdown, "Option");

    expect(screen.getByText("Option (New element)")).toBeInTheDocument();

    await user.click(screen.getByText(/option two/i));
    expect(onSelect).toHaveBeenCalledTimes(1);

    expect(screen.queryByText(/option one/i)).not.toBeInTheDocument();
    expect(screen.getByText(/option two/i)).toBeInTheDocument();
  });

  it("should render properly with multi select", async () => {
    const { user } = render(<DefaultCreatableDropdown multi />);

    expect(screen.getByText(/option one/i)).toBeTruthy();

    const inputDropdown = screen.getByRole("combobox");
    await user.type(inputDropdown, "Option");

    expect(screen.getByText("Option (New element)")).toBeInTheDocument();

    await user.click(screen.getByText(/option two/i));
    expect(onSelect).toHaveBeenCalledTimes(1);

    expect(screen.getByText(/option one/i)).toBeInTheDocument();
    expect(screen.getByText(/option two/i)).toBeInTheDocument();
  });

  it("should render properly with grouped options", async () => {
    const { user } = render(
      <DefaultCreatableDropdown options={groupedOptions} />
    );

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText(/numbers/i)).toBeTruthy();
    expect(screen.getByText(/colors/i)).toBeTruthy();
  });

  it("should render properly with a multiple level options", async () => {
    const colors5 = [
      { value: "gray2", label: "gray2" },
      { value: "white2", label: "white2" },
    ];

    const colors4 = [
      { value: "1", label: "1" },
      { value: "2", label: "2" },
      { value: "colors5", label: "colors5", options: colors5 },
    ];

    const colors3 = [
      { value: "gray", label: "gray" },
      { value: "white", label: "white" },
    ];

    const colors2 = [
      { value: "blue", label: "Blue" },
      { value: "red", label: "Red" },
      { value: "Colors", label: "Colors", options: colors3 },
      { value: "colors4", label: "colors4", options: colors4 },
    ];

    const otherGroupedOptions = [
      { label: "Numbers", options, value: "numbers" },
      { label: "colors2", options: colors2, value: "colors2" },
    ];

    const { user } = render(
      <DefaultCreatableDropdown multiLevel options={otherGroupedOptions} />
    );

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText(/numbers/i)).toBeTruthy();
    expect(screen.getByText(/gray2/i)).toBeTruthy();
  });

  it("should render a multilevel dropdown properly", async () => {
    options = [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ];

    colors = [
      { label: "Red", value: "red" },
      { label: "Blue", value: "blue" },
      { label: "Green", value: "green" },
    ];

    const fruits = [
      { label: "Apple", value: "apple" },
      { label: "Banana", value: "banana" },
      { label: "Orange", value: "orange" },
    ];

    const vehicles = [
      { label: "Car", value: "car" },
      { label: "Truck", value: "truck" },
      { label: "Bike", value: "bike" },
    ];

    const otherGroupedOptions = [
      { label: "Numbers", options, value: "numbers" },
      {
        label: "AllColors",
        value: "colors",
        options: [
          {
            label: "Primary Colors",
            value: "primary",
            options: colors,
          },
          {
            label: "Secondary Colors",
            value: "secondary",
            options: [
              { label: "Yellow", value: "yellow" },
              { label: "Purple", value: "purple" },
            ],
          },
        ],
      },
      {
        label: "Fruits",
        value: "fruits",
        options: fruits,
      },
      {
        label: "Vehicles",
        value: "vehicles",
        options: [
          {
            label: "Cars",
            value: "cars",
            options: vehicles,
          },
          {
            label: "Bikes",
            value: "bikes",
            options: [
              { label: "Mountain Bike", value: "mountainBike" },
              { label: "Road Bike", value: "roadBike" },
            ],
          },
        ],
      },
    ];
    const { user } = render(
      <DefaultCreatableDropdown multiLevel options={otherGroupedOptions} />
    );

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    // Check if the options are displayed
    expect(screen.getByText("Option 1")).toBeInTheDocument();
    expect(screen.getByText("Option 2")).toBeInTheDocument();
    expect(screen.getByText("AllColors")).toBeInTheDocument();
    expect(screen.getByText("Fruits")).toBeInTheDocument();
    expect(screen.getByText("Vehicles")).toBeInTheDocument();

    // Check if Blue option is displayed
    expect(screen.getByText("Blue")).toBeInTheDocument();

    // Click on the Blue option
    await user.click(screen.getByText("Blue"));

    // Check if the onSelect function was called with the selected option
    expect(onSelect).toHaveBeenCalledTimes(1);

    // Check if the dropdown closes after an option is selected
    expect(screen.queryByText("Option 1")).toBeNull();
    expect(screen.queryByText("Option 2")).toBeNull();
    expect(screen.queryByText("Fruits")).toBeNull();
    expect(screen.queryByText("Vehicles")).toBeNull();
    expect(screen.queryByText("Primary Colors")).toBeNull();
    expect(screen.queryByText("Secondary Colors")).toBeNull();
    expect(screen.queryByText("Red")).toBeNull();
    expect(screen.queryByText("Green")).toBeNull();
    expect(screen.queryByText("Purple")).toBeNull();
  });

  it("should render a disabled creatable dropdown properly", async () => {
    const { container } = render(
      <DefaultCreatableDropdown disabled value={null} />
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const inputDropdown = screen.getByRole("combobox", { hidden: true });

    expect(inputDropdown).toBeDisabled();
  });

  it("should render additional text with error message", async () => {
    const { container } = render(
      <DefaultCreatableDropdown
        additionalText=" creatable dropdown error message text"
        error
      />
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();
    expect(
      screen.getByText(/creatable dropdown error message text/i)
    ).toBeInTheDocument();
  });
});
