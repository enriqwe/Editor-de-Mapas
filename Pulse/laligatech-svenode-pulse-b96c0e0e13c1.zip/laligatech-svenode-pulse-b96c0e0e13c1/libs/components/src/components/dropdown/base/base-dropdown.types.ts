import type { FocusEvent, ReactElement, ReactNode } from "react";
import type { GroupBase, Options, OptionsOrGroups } from "react-select";
import type Select from "react-select";
import type CreatableSelect from "react-select/creatable";

export type Option = {
  value: string;
  label: string;
  options?: Option[];
  isDisabled?: boolean;
  isFixed?: boolean;
  onSelect?: (...args: any) => void;
};

export type OptionMultiLevel = {
  level?: number;
} & Option;

export type GroupedOption = {
  label: string;
  options: Option[];
};

export type SelectedOptionType = Option | Option[];

type CommonDropdownProps = {
  label: string;
  required?: boolean;
  multi?: boolean;
  disabled?: boolean;
  additionalText?: string;
  error?: boolean;
  selectedOption?: Option | Option[];
  options: Option[] | GroupedOption[];
  maxLength?: number;
  onSelectedOption: (newValue: SelectedOptionType) => void;
  onFocus?: (e: FocusEvent) => void;
  onBlur?: (e: FocusEvent) => void;
  placeholder?: string | ReactElement;
  noOptionsMessage: string | ((obj: { inputValue: string }) => string);
  closeMenuOnSelect?: boolean;
  hideSelectedOptions?: boolean;
  value?: Option | Option[] | null | undefined;
  automationContext?: string;
  multiLevel?: boolean;
  dropdownIndicatorIcon?: ReactElement | null | undefined;
  searchable?: boolean;
  transparent?: boolean;
  /** @deprecated value should be one of the options */
  customDropdownValue?: boolean;
  dropdownInline?: boolean;
  menuPlacement?: "auto" | "bottom" | "top";
  isClearable?: boolean;
  labelTooltipContent?: ReactNode;
};

type CreatableSelectOnlyProps = {
  formatCreateLabel: (inputValue: string) => string | ReactElement;
  isValidNewOption?: (
    inputValue: string,
    value: Options<unknown>,
    options: OptionsOrGroups<unknown, GroupBase<unknown>>,
    accessors: {
      getOptionValue: (option: Option) => string;
      getOptionLabel: (option: Option) => string;
    }
  ) => boolean;
};

// Regular Dropdown
export type DropdownProps = {
  Component: Select;
  type: "regular";
} & CommonDropdownProps;

// Creatable Dropdown
export type CreatableDropdownProps = {
  Component: CreatableSelect;
  type: "creatable";
} & CommonDropdownProps &
  CreatableSelectOnlyProps;

export type BaseDropdownProps = DropdownProps | CreatableDropdownProps;
