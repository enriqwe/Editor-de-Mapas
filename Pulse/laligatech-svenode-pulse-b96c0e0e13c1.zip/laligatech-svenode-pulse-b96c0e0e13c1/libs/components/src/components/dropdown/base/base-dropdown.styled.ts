import styled, { css, useTheme } from "styled-components";
import type { StylesConfig } from "react-select";

import type { Option as IOptionTypes } from "./base-dropdown.types";

export const Wrapper = styled.div<{ $dropdownInline: boolean | undefined }>`
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-size: ${({ theme }) => theme.font.sizes.m.fontSize};
  line-height: ${({ theme }) => theme.font.sizes.m.lineHeight};
  ${props => {
    if (props.$dropdownInline) {
      return css`
        display: flex;
        gap: ${({ theme }) => theme.spacing.x12};
        align-items: center;
      `;
    }
  }};
`;

export const MultiValueLabel = styled.div<{ $isFixed: boolean }>`
  border-radius: ${({ theme }) => theme.border.radiusL};
  align-items: center;
  color: ${({ theme, $isFixed }) =>
    $isFixed ? theme.color.text.disabled : theme.color.text.tag.informative};
  font-size: ${({ theme }) => theme.font.sizes.xs.fontSize};
  display: block;
  padding: 0 0 0 ${({ theme }) => theme.spacing.x6};
`;

export const AdditionalText = styled.span`
  display: flex;
  align-items: center;
  margin: ${({ theme }) => theme.spacing.x8} 0px 0px 0px;
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  color: ${({ theme }) => theme.color.text.dropdown.additionalText};

  &.dropdown-error {
    color: ${({ theme }) => theme.color.text.dropdown.additionalTextError};
  }

  &.dropdown-disabled {
    color: ${({ theme }) => theme.color.text.disabled};
  }
`;

export const Dropdown = (
  error: boolean,
  transparent: boolean,
  disabled: boolean
): StylesConfig => {
  const theme = useTheme();
  const style: StylesConfig = {
    input: styles => {
      return {
        ...styles,
        margin: 0,
        padding: 0,
      };
    },
    multiValueRemove: base => {
      return {
        ...base,
        "display": "flex",
        ":hover": {
          backgroundColor: "inherit",
        },
      };
    },
    multiValue: (baseCSS, props) => {
      const option = props.data as IOptionTypes;
      const isDisabledOrFixed = props.isDisabled || option.isFixed;

      const hover = {
        ":hover": {
          background:
            isDisabledOrFixed ? "inherit" : theme.color.background.chip.hover,
          border:
            isDisabledOrFixed ? "1px solid inherit" : (
              `1px solid ${theme.color.background.chip.hover}`
            ),
          boxShadow:
            isDisabledOrFixed ? "inherit" : (
              `inset 0px 0px 0px 1px ${theme.color.background.chip.hover}`
            ),
        },
      };
      const baseStyle = {
        ...baseCSS,
        "borderRadius": theme.border.radiusL,
        "border":
          isDisabledOrFixed ?
            `1px solid ${theme.color.background.disabled}`
          : `1px solid ${theme.color.background.tag.informative}`,
        "background-color":
          isDisabledOrFixed ?
            theme.color.background.disabled
          : theme.color.background.tag.informative,
        "color":
          isDisabledOrFixed ?
            theme.color.text.disabled
          : theme.color.text.tag.informative,
        "height": theme.spacing.x24,
        "padding": `0 ${theme.spacing.x6} 0 0`,
        "font-weight": `${theme.font.weights.semibold}`,
        "lineHeight": "22px",
        "cursor": isDisabledOrFixed ? "not-allowed" : "inherit",
        ...hover,
      };
      return {
        ...baseStyle,
        "margin": 0,
        "& [class*=Input]": {
          padding: 0,
          margin: 0,
        },
      };
    },
    valueContainer: (styles, props) => {
      const multipleSelectProps = {
        display: "flex",
      };
      const singleSelectProps = {
        display: "grid",
        gridTemplateColumns: "1fr auto",
      };
      return {
        ...styles,
        minHeight: theme.spacing.x40,
        gap: theme.spacing.x4,
        margin: 0,
        alignItems: "center",
        padding: `${theme.spacing.x8} ${theme.spacing.x12}`,
        ...(props.isMulti ? multipleSelectProps : singleSelectProps),
      };
    },
    indicatorsContainer: styles => {
      return {
        ...styles,
        gap: theme.spacing.x4,
        margin: 0,
        display: "flex",
        alignItems: "baseline",
        padding: theme.spacing.x8,
      };
    },
    placeholder: (baseCSS, props) => {
      const { isFocused } = props;
      const transparentType = {
        color:
          isFocused ?
            "#2B58BF" // Need to add this color in color.ts (blue)
          : disabled ? theme.color.text.dropdown.disabled
          : theme.color.text.dropdown.label,
      };
      return {
        ...baseCSS,
        ...(transparent && transparentType),
        position: "absolute",
        color:
          transparent ? transparentType.color : theme.color.text.input.default,
        fontSize: theme.font.sizes.m.fontSize,
      };
    },
    control: (baseCSS, props) => {
      const { isDisabled, isFocused, menuIsOpen } = props;
      const baseStyle = {
        ...baseCSS,
        "boxShadow": "none",
        "fontSize": theme.font.sizes.m.fontSize,
        ".material-symbols-outlined, [class*=indicatorContainer]": {
          padding: 0,
          color: `${transparent && isFocused && theme.color.border.dropdown.hover}`,
        },
        "borderRadius":
          transparent ? theme.border.radiusXS : theme.border.radiusS,
        "cursor": isDisabled ? "not-allowed" : "pointer",
        "pointer-events": isDisabled && "auto",
      };

      const transparentType = {
        "border": "unset",
        "background":
          menuIsOpen ? theme.color.background.dropdown.active : "transparent",
        "fontWeight": theme.font.weights.regular,
        "fontSize": theme.font.sizes.m.fontSize,
        "lineHeight": theme.font.sizes.m.lineHeight,
        "outline-offset": isFocused && !menuIsOpen && "2px",
        "outline": `${isFocused && !menuIsOpen && "2px solid #2B58BF !important"}`, //Need to add this color (blue)
        "boxShadow": "none",
        ":hover": {
          background: `${!isDisabled && theme.color.background.default}`,
          boxShadow: "none",
        },
        ":active": {
          background: `${!isDisabled && theme.color.background.dropdown.active}`,
        },
      };

      const defaultEvent = {
        "border": `1px solid ${theme.color.border.dropdown.default}`,
        ...(isFocused && { boxShadow: "inset 0px 0px 0px 1px #2B58BF" }),
        ...(isFocused && { borderColor: "#2B58BF" }),
        "&:hover": {
          ...(isFocused && { boxShadow: "inset 0px 0px 0px 0.5px #2E6ED6" }),
          ...(isFocused && { borderColor: "#2E6ED6" }), //Need to add this color (blue)
        },
      };

      const errorEvent = {
        "boxShadow": `inset 0px 0px 0px 1px ${theme.color.border.dropdown.error}`,
        "borderColor": theme.color.border.dropdown.error,
        ":hover": {
          boxShadow: `inset 0px 0px 0px 1px ${theme.color.border.dropdown.error}`,
          borderColor: theme.color.border.dropdown.error,
        },
      };

      const disabledEvent = {
        backgroundColor: theme.color.background.disabled,
        border: `${theme.border.widthXS} solid ${theme.color.border.dropdown.disabled}`,
        color: theme.color.text.disabled,
      };

      let event;
      if (error) {
        event = errorEvent;
      } else if (isDisabled) {
        event = disabledEvent;
      } else {
        event = defaultEvent;
      }

      return {
        ...baseStyle,
        ...event,
        ...(transparent && transparentType),
      };
    },
    option: (baseCSS, props) => {
      let backgroundColor = "transparent";
      if (props.isSelected) {
        backgroundColor = theme.color.background.dropdown.active;
      } else if (props.isFocused) {
        backgroundColor = theme.color.background.dropdown.hover;
      }

      let color = theme.color.text.dropdown.default;
      if (props.isSelected) {
        color = theme.color.text.dropdown.label;
      } else if (props.isDisabled) {
        color = theme.color.text.dropdown.disabled;
      }

      return {
        ...baseCSS,
        backgroundColor,
        color,
        "cursor": props.isDisabled ? "not-allowed" : "pointer",
        "pointer-events": props.isDisabled && "auto",
        "borderRadius": theme.border.radiusXS,
      };
    },
    menu: baseCSS => ({
      ...baseCSS,
      margin: "2px",
      borderRadius: theme.border.radiusS,
      boxShadow: theme.shadow.high,
    }),
    menuList: baseCSS => ({
      ...baseCSS,
      padding: 0,
    }),
    singleValue: (baseCSS, props) => ({
      ...baseCSS,
      color:
        props.isDisabled ?
          theme.color.text.disabled
        : theme.color.text.dropdown.label,
    }),
  };
  return style;
};

export const GroupLabel = styled.div`
  color: ${({ theme }) => theme.color.text.dropdown.titleGroupOption};
  padding: ${({ theme }) => theme.spacing.x8} 0;
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  font-weight: ${({ theme }) => theme.font.weights.bold};
`;

export const DropdownWrapper = styled.div<{
  $dropdownInline: boolean | undefined;
}>`
  width: 100%;
  ${props => {
    if (props.$dropdownInline) {
      return css`
        width: auto;
        min-width: 70px;
        max-width: 90px;
      `;
    }
  }};
`;
