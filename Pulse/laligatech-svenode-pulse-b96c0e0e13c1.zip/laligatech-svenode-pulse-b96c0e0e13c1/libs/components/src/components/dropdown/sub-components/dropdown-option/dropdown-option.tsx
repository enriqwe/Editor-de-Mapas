import type { OptionProps } from "react-select";
import { components } from "react-select";

import type { OptionMultiLevel } from "../../base/base-dropdown.types";

import * as S from "./dropdown-option.styled";

export function Option(props: OptionProps) {
  const { label, data } = props;
  const { level = 0 } = data as OptionMultiLevel;
  return (
    <S.WrapperOption>
      <components.Option {...props}>
        {level > 0 ?
          <S.SpacingOption level={level}>{label}</S.SpacingOption>
        : label}
      </components.Option>
    </S.WrapperOption>
  );
}
