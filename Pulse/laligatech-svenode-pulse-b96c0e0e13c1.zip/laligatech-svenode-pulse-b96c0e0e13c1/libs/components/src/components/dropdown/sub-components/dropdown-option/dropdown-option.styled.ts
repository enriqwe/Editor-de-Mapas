import styled from "styled-components";

export const WrapperOption = styled.div`
  display: flex;
  align-items: center;
  .customCheck {
    pointer-events: none;
  }
`;

export const SpacingOption = styled.div<{ level: number }>`
  padding-left: ${({ level }) => level * 16}px;
`;
