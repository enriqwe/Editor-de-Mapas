import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const StyledTooltipContainer = styled.div`
  display: inline-block;
  position: relative;
`;

export const StyledPopoverWrapper = styled.div`
  max-width: 200px;
  color: ${cssVars.color.textInverse};
  background: ${cssVars.color.bgInverse};
  border-radius: ${cssVars.border.radiusS};
  padding: ${cssVars.spacing.x12};

  font: ${cssVars.text.bodyMediumSemiBold};

  word-break: break-word;
`;

export const StyledArrow = styled.svg`
  position: absolute;
  fill: ${cssVars.color.bgInverse};
  stroke: ${cssVars.color.bgInverse};
  stroke-width: 1px;
  width: 20px;
  height: 12px;

  &[data-placement="top"] {
    top: 97.9%;
    transform: translateX(-30%);
  }

  &[data-placement="bottom"] {
    bottom: 97.9%;
    transform: translateX(-70%) rotate(180deg);
  }

  &[data-placement="left"] {
    left: 97.9%;
    transform: translateY(-80%) rotate(-90deg);
  }

  &[data-placement="right"] {
    right: 97.9%;
    transform: translateY(-20%) rotate(90deg);
  }
`;

export const StyledTooltipTrigger = styled.div`
  display: flex;
`;
