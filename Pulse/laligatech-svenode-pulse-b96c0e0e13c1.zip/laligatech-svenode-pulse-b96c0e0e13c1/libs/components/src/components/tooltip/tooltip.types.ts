import type { AriaPopoverProps } from "react-aria";
import type { OverlayTriggerState } from "react-stately";

export type Position =
  | "bottom"
  | "bottom left"
  | "bottom right"
  | "top"
  | "top left"
  | "top right"
  | "left"
  | "left top"
  | "left bottom"
  | "right"
  | "right top"
  | "right bottom";

export type TooltipProps = Omit<AriaPopoverProps, "popoverRef"> & {
  children: React.ReactNode;
  id?: string;
  state: OverlayTriggerState;
  automationContext?: string;
};

export type TooltipTriggerProps = {
  triggerElement: React.ReactNode;
  tooltipContent?: React.ReactNode;
  automationContext?: string;
  position?: Position;
};
