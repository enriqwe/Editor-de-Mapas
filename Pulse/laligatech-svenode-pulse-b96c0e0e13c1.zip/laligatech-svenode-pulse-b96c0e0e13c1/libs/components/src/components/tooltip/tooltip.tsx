import { useRef } from "react";
import { DismissButton, Overlay, usePopover } from "react-aria";

import { StyledPopoverWrapper, StyledArrow } from "./tooltip.styled";
import type { TooltipProps } from "./tooltip.types";

export function Tooltip({
  automationContext,
  children,
  offset = 8,
  placement = "bottom",
  state: { close, open, setOpen, toggle, isOpen },
  triggerRef,
}: TooltipProps) {
  const popoverRef = useRef(null);
  const {
    arrowProps,
    placement: arrowPlacement,
    popoverProps,
    underlayProps,
  } = usePopover(
    {
      offset,
      popoverRef,
      placement,
      triggerRef,
    },
    {
      isOpen,
      open,
      close,
      setOpen,
      toggle,
    }
  );
  const { style, onKeyDown, onBlur, onFocus } = popoverProps;
  return (
    <Overlay>
      <div onPointerDown={underlayProps.onPointerDown} />
      <StyledPopoverWrapper
        className={automationContext}
        onBlur={onBlur}
        onFocus={onFocus}
        onKeyDown={onKeyDown}
        ref={popoverRef}
        style={style}
      >
        <StyledArrow data-placement={arrowPlacement} style={arrowProps.style}>
          <path d="M0 0,L6 6,L12 0" />
        </StyledArrow>
        <DismissButton onDismiss={close} />
        {children}
        <DismissButton onDismiss={close} />
      </StyledPopoverWrapper>
    </Overlay>
  );
}
