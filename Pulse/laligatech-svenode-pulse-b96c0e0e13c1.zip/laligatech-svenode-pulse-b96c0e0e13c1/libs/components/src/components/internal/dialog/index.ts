export { Dialog } from "./dialog";
export type { DialogProps } from "./dialog";
