import { useRef } from "react";
import { usePopover, DismissButton, Overlay } from "react-aria";

import * as S from "./popover.styled";
import type { PopoverProps } from "./popover.types";

import { automationClass } from "@utils/automation-class";

export function Popover({
  automationContext,
  children,
  crossOffset = 0,
  hasBorder = false,
  offset = 4,
  showArrow = false,
  state,
  ...props
}: Readonly<PopoverProps>) {
  const popoverRef = useRef(null);

  const { arrowProps, placement, popoverProps, underlayProps } = usePopover(
    {
      ...props,
      crossOffset,
      offset,
      popoverRef,
    },
    state
  );
  const automationClasses = automationClass("popover", automationContext);

  return (
    <Overlay>
      <S.UnderLay {...underlayProps} />
      <S.Popover
        {...popoverProps}
        $hasBorder={hasBorder}
        className={automationClasses}
        ref={popoverRef}
      >
        {showArrow ?
          <S.Arrow
            {...arrowProps}
            data-placement={placement}
            viewBox="0 0 12 12"
          >
            <path d="M0 0,L6 6,L12 0" />
          </S.Arrow>
        : null}
        <DismissButton
          onDismiss={() => {
            state.close();
          }}
        />
        {children}
        <DismissButton
          onDismiss={() => {
            state.close();
          }}
        />
      </S.Popover>
    </Overlay>
  );
}
