import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: ${({ theme }) => theme.spacing.x4};
  margin-bottom: 8px;
`;

export const Label = styled.label<{ $isDisabled?: boolean }>`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x4};
  color: ${({ theme, $isDisabled }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.textLabel};
  ${({ theme }) => theme.text.bodyMediumSemiBold}
`;

export const RequiredIcon = styled.div`
  ${({ theme }) => theme.text.bodyMediumSemiBold}
  font-size: 20px;
  color: ${({ theme }) => theme.color.textRequired};
`;

export const TooltipIconWrapper = styled.div`
  color: ${({ theme }) => theme.color.iconInfo};
`;
