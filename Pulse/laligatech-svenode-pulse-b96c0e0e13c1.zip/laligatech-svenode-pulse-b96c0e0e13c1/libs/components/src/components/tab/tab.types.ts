import type { ReactNode } from "react";
import type { TabListProps, TabListState } from "react-stately";
import type { AriaTabProps, AriaTabPanelProps } from "react-aria";

export type TabGroupProps = TabListProps<TabItemProps> & {
  automationContext?: string;
};

export type TabListStateProps = {
  state: TabListState<TabItemProps>;
} & AriaTabPanelProps;

export type TabItemProps = AriaTabProps &
  TabListStateProps & {
    item: Pick<AriaTabProps, "key"> & { rendered: ReactNode };
  };
