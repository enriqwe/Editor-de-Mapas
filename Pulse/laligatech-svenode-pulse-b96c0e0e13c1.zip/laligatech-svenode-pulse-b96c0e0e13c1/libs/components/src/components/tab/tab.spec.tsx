import "@testing-library/jest-dom";
import { screen } from "@testing-library/react";

import { Tab } from "./tab";

import { render } from "@test-utils";

describe("tab", () => {
  it("should render properly with state default", () => {
    render(
      <Tab.Group>
        <Tab.Item title="Tab 1">Tab Content 1</Tab.Item>
        <Tab.Item title="Tab 2">Tab Content 2</Tab.Item>
      </Tab.Group>
    );
    const tab1 = screen.getByText(/Tab 1/i);
    const tab2 = screen.getByText(/Tab 2/i);

    expect(tab1).toBeInTheDocument();
    expect(screen.getByText(/Tab Content 1/i)).toBeInTheDocument();
    expect(tab2).toBeInTheDocument();
  });

  it("should render properly when tab is selected", async () => {
    const { user } = render(
      <Tab.Group>
        <Tab.Item title="Tab 1">Tab Content 1</Tab.Item>
        <Tab.Item title="Tab 2">Tab Content 2</Tab.Item>
      </Tab.Group>
    );
    const tab1 = screen.getByText(/Tab 1/i);
    const tab2 = screen.getByText(/Tab 2/i);

    await user.click(tab2);

    expect(tab1).toBeInTheDocument();
    expect(tab2).toBeInTheDocument();
    expect(screen.getByText(/Tab Content 2/i)).toBeInTheDocument();
  });
});
