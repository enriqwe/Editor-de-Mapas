import { styled } from "styled-components";

type SpinnerProps = {
  size: number;
};

export const Spinner = styled.svg<SpinnerProps>`
  @keyframes rotate {
    from {
      transform: rotate(0deg)
    }
    to {
      transform: rotate(359deg);
    }
  }

  width: ${({ size }) => size}px;
  height: ${({ size }) => size}px;
  animation: rotate 1s linear infinite;
`;
