import * as S from "./spinner-icon.styled";
import { SpinnerDark } from "./assets/spinner-dark";
import { SpinnerLight } from "./assets/spinner-light";

export const SpinnerSizes = {
  sm: 16,
  md: 24,
  lg: 32,
  xl: 60,
  xxl: 90,
};

export function SpinnerIcon({
  size: sizeProp,
  variant = "dark",
}: {
  size: keyof typeof SpinnerSizes;
  variant?: "dark" | "light";
}) {
  const size = SpinnerSizes[sizeProp];
  return (
    <S.Spinner size={size} viewBox="0 0 32 32">
      {variant === "dark" ?
        <SpinnerDark />
      : <SpinnerLight />}
    </S.Spinner>
  );
}
