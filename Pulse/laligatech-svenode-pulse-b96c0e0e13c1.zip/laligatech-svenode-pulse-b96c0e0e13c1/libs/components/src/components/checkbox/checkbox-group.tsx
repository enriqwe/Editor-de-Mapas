import type { JSX, PropsWithChildren } from "react";
import { createContext, useContext, useRef } from "react";
import type { CheckboxGroupProps, CheckboxGroupState } from "react-stately";
import { useCheckboxGroupState } from "react-stately";
import type { AriaCheckboxGroupItemProps } from "react-aria";
import {
  useCheckboxGroup,
  useFocusRing,
  VisuallyHidden,
  useCheckboxGroupItem,
} from "react-aria";

import { BaseCheckbox } from "./sub-components/base-checkbox";
import * as S from "./checkbox-group.styled";

import { automationClass } from "@utils/automation-class";

type GroupProps = PropsWithChildren<CheckboxGroupProps> & {
  orientation?: "horizontal" | "vertical";
  hasError?: boolean;
  automationContext?: string;
  description?: JSX.Element | string;
  errorMessage?: JSX.Element | string;
};

const CheckboxGroupContext = createContext<CheckboxGroupState | null>(null);

function Group(props: GroupProps) {
  const { children, orientation = "vertical", automationContext } = props;
  const state = useCheckboxGroupState(props);
  const { labelProps, groupProps, descriptionProps, errorMessageProps } =
    useCheckboxGroup(props, state);

  const automationClasses = automationClass("checkboxGroup", automationContext);

  return (
    <S.CheckboxGroup {...groupProps} className={automationClasses}>
      <span {...labelProps}>{props.label}</span>
      {props.isRequired && <S.TextRequired>*</S.TextRequired>}
      <S.CheckboxGroupContainer $isHorizontal={orientation === "horizontal"}>
        <CheckboxGroupContext.Provider value={state}>
          {children}
        </CheckboxGroupContext.Provider>
      </S.CheckboxGroupContainer>
      {props.description && (
        <S.CheckboxGroupDescription {...descriptionProps}>
          {props.description}
        </S.CheckboxGroupDescription>
      )}
      {props.errorMessage && (
        <S.CheckboxErrorMessage {...errorMessageProps}>
          {props.errorMessage}
        </S.CheckboxErrorMessage>
      )}
    </S.CheckboxGroup>
  );
}

type ItemProps = {
  align?: "right" | "left";
  children: JSX.Element | string;
  automationContext?: string;
} & AriaCheckboxGroupItemProps;

function Item(props: ItemProps) {
  const { automationContext, ...commonProps } = props;

  const inputRef = useRef<HTMLInputElement>(null);

  const state = useContext(CheckboxGroupContext);

  const { isFocusVisible, focusProps } = useFocusRing();

  const automationClasses = automationClass("checkboxItem", automationContext);

  if (!state) {
    throw new Error("Checkbox.Item should be used within a Checkbox.Group");
  }

  const { inputProps } = useCheckboxGroupItem(commonProps, state, inputRef);

  const { onChange, onClick, onMouseDown, onPointerDown, onPointerUp } =
    inputProps;

  const isDisabled = state.isDisabled || props.isDisabled;
  const isSelected = state.isSelected(props.value);

  return (
    <S.Label
      $align={props.align === "right"}
      $isDisabled={Boolean(props.isDisabled)}
      className={automationClasses}
    >
      <VisuallyHidden>
        <input {...inputProps} {...focusProps} ref={inputRef} />
      </VisuallyHidden>
      <BaseCheckbox
        isDisabled={Boolean(isDisabled)}
        isFocusVisible={isFocusVisible}
        isIndeterminate={props.isIndeterminate}
        isSelected={isSelected}
        onChange={onChange}
        onClick={onClick}
        onMouseDown={onMouseDown}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
      />
      <S.ItemText $isDisabled={Boolean(props.isDisabled)}>
        {props.children}
      </S.ItemText>
    </S.Label>
  );
}

export const CheckboxGroup = { Group, Item };
