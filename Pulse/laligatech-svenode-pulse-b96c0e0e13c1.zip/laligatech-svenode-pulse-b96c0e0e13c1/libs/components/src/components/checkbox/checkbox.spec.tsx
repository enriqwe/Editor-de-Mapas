import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import { Checkbox } from "./checkbox";

import { render } from "@test-utils";

describe("checkbox", () => {
  expect.extend(toHaveNoViolations);
  it("should render properly [default state]", async () => {
    const { container } = render(
      <Checkbox>
        <span>checkbox 1</span>
      </Checkbox>
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    expect(screen.getByText("checkbox 1")).toBeTruthy();
  });

  it("should uncheck when click on the checkbox", async () => {
    const { user } = render(
      <Checkbox>
        <span>checkbox 3</span>
      </Checkbox>
    );
    const checkbox = screen.getByRole("checkbox", { checked: false });

    await user.click(checkbox);
    expect(checkbox).toBeChecked();

    await user.click(checkbox);
    expect(checkbox).not.toBeChecked();
  });

  it("should uncheck when click on the checkboxlabel", async () => {
    const { user } = render(<Checkbox>checkbox 3</Checkbox>);
    const checkbox = screen.getByRole("checkbox", { checked: false });
    const checkboxLabel = screen.getByText("checkbox 3");

    await user.click(checkboxLabel);
    expect(checkbox).toBeChecked();

    await user.click(checkbox);
    expect(checkbox).not.toBeChecked();
  });
  it("should check when checkbox is disabled", () => {
    render(<Checkbox isDisabled>checkbox 4</Checkbox>);
    const checkbox = screen.getByRole("checkbox", { checked: false });
    expect(screen.getByText("checkbox 4")).toBeTruthy();
    expect(checkbox).toBeDisabled();
  });

  it("should render indeterminate checkbox with required state", () => {
    render(
      <Checkbox isIndeterminate isRequired>
        checkbox 1
      </Checkbox>
    );
    expect(screen.getByText("checkbox 1")).toBeTruthy();
    expect(screen.getByText(/\*/i)).toBeTruthy();
    expect(screen.getByText(/check_indeterminate_small/i)).toBeTruthy();
  });

  it("should render indeterminate checkbox with disabled state", () => {
    render(
      <Checkbox isDisabled isIndeterminate>
        checkbox 1
      </Checkbox>
    );
    expect(screen.getByText("checkbox 1")).toBeTruthy();
    expect(screen.getByText(/check_indeterminate_small/i)).toBeTruthy();
    const checkbox = screen.getByRole("checkbox");
    expect(checkbox).toBeDisabled();
  });

  it("should render checkbox is selected with disabled state", () => {
    render(
      <Checkbox align="right" isDisabled isSelected>
        checkbox 1
      </Checkbox>
    );
    expect(screen.getByText("checkbox 1")).toBeTruthy();
    expect(screen.getByText("check_small")).toBeTruthy();
    const checkbox = screen.getByRole("checkbox");
    expect(checkbox).toBeDisabled();
  });
});
