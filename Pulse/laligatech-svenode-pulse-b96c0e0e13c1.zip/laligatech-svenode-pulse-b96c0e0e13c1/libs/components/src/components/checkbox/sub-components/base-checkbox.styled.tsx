import styled, { css } from "styled-components";

export const CheckBoxIcon = styled.span<{
  $isDisabled?: boolean;
  $isSelected: boolean;
  $hasError: boolean;
  $isFocusVisible: boolean;
  $isIndeterminate: boolean;
}>`
  border-style: solid;
  border-width: 2px;
  border-radius: ${({ theme }) => theme.border.radiusXS};

  color: ${({ theme, $isDisabled }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.textOnBrand};

  width: 24px;
  height: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
  box-sizing: border-box;

  ${({ $hasError, $isSelected, $isDisabled, $isIndeterminate, theme }) => {
    let borderColor = theme.color.borderFormControlDefault;
    let backgroundColor = theme.color.surfacePrimary;

    if ($isDisabled) {
      borderColor = theme.color.borderDisabled;
    } else if ($hasError) {
      borderColor = theme.color.borderError;
    }

    if ($isSelected || $isIndeterminate) {
      backgroundColor = theme.color.bgFormControlActive;
      if ($isDisabled) {
        backgroundColor = theme.color.bgDisabled;
      } else if ($hasError) {
        backgroundColor = theme.color.bgFormControlActiveError;
      }
    }

    return css`
      background-color: ${backgroundColor};
      border-color: ${borderColor};
    `;
  }}

  &:hover {
    outline-offset: 0;
    outline: ${({ $isDisabled, $hasError, theme }) => {
      if (!$isDisabled) {
        if ($hasError) {
          return css`solid 6px ${theme.color.bgFormControlActiveHoverError}`;
        }
        return css`solid 6px ${theme.color.bgFormControlActiveHover}`;
      }
    }};
  }

  ${({ $isFocusVisible, theme }) => {
    if ($isFocusVisible) {
      return css`
        outline-offset: 3px;
        outline: ${theme.border.widthS} solid ${theme.color.borderFocus};
      `;
    }
  }}
`;
