import styled from "styled-components";

export const Label = styled.label<{
  $align: boolean;
  $isDisabled: boolean;
}>`
  display: inline-flex;
  align-items: center;
  margin-top: ${({ theme }) => theme.spacing.x8};
  margin-bottom: ${({ theme }) => theme.spacing.x8};
  gap: ${({ theme }) => theme.spacing.x8};
  word-break: break-word;
  flex-direction: ${({ $align }) => $align && "row-reverse"};
  ${({ $isDisabled }) => !$isDisabled && `&:hover { cursor: pointer }`}
`;

export const Text = styled.span<{
  $isDisabled?: boolean;
}>`
  color: ${({ theme, $isDisabled }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.text.checkbox.default};

  ${({ theme }) => theme.text.bodyBaseRegular};
`;

export const TextRequired = styled.span`
  margin-left: ${({ theme }) => theme.spacing.x8};
  color: ${({ theme }) => theme.color.iconError};
`;
