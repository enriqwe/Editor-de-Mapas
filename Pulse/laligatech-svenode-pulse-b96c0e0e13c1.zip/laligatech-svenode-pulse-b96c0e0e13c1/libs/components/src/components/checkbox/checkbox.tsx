import type { ForwardedRef } from "react";
import { forwardRef, useRef } from "react";
import { useToggleState } from "react-stately";
import {
  mergeProps,
  useCheckbox,
  useFocusRing,
  VisuallyHidden,
} from "react-aria";
import type { AriaCheckboxProps } from "react-aria";

import { BaseCheckbox } from "./sub-components/base-checkbox";
import * as S from "./checkbox.styled";

import { automationClass } from "@utils/automation-class";

export type CheckboxProps = {
  align?: "right" | "left";
  hasError?: boolean;
  automationContext?: string;
} & AriaCheckboxProps;

function CheckboxComponent(
  props: CheckboxProps,
  baseRef: ForwardedRef<HTMLInputElement>
) {
  const { hasError = false, automationContext, ...checkboxProps } = props;
  const inputRef = useRef<HTMLInputElement>(null);

  const state = useToggleState(checkboxProps);

  const { isFocusVisible, focusProps } = useFocusRing();

  const automationClasses = automationClass("checkboxItem", automationContext);

  const { inputProps } = useCheckbox(checkboxProps, state, inputRef);

  const { onChange, onClick, onMouseDown, onPointerDown, onPointerUp } =
    inputProps;

  return (
    <div className="checkbox">
      <S.Label
        $align={props.align === "right"}
        $isDisabled={Boolean(props.isDisabled)}
        className={automationClasses}
      >
        <VisuallyHidden>
          <input
            {...mergeProps(inputProps, focusProps)}
            ref={baseRef ?? inputRef}
          />
        </VisuallyHidden>
        <BaseCheckbox
          hasError={hasError}
          isDisabled={Boolean(props.isDisabled)}
          isFocusVisible={isFocusVisible}
          isIndeterminate={props.isIndeterminate}
          isSelected={state.isSelected}
          onChange={onChange}
          onClick={onClick}
          onMouseDown={onMouseDown}
          onPointerDown={onPointerDown}
          onPointerUp={onPointerUp}
        />

        <S.Text $isDisabled={Boolean(props.isDisabled)}>
          {props.children}
          {props.isRequired && <S.TextRequired>*</S.TextRequired>}
        </S.Text>
      </S.Label>
    </div>
  );
}

export const Checkbox = forwardRef(CheckboxComponent);
