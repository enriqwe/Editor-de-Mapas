import styled from "styled-components";

export const CheckboxGroup = styled.div`
  ${({ theme }) => theme.text.bodyBaseSemiBold};
`;

export const TextRequired = styled.span`
  margin-left: ${({ theme }) => theme.spacing.x8};
  color: ${({ theme }) => theme.color.iconError};
`;

export const CheckboxGroupContainer = styled.div<{
  $isHorizontal: boolean;
}>`
  display: flex;
  margin-top: 8px;
  flex-direction: ${({ $isHorizontal }) => ($isHorizontal ? "row" : "column")};
  ${({ $isHorizontal }) => $isHorizontal && { flexWrap: "wrap" }}
  gap: 16px;
`;

export const Column = styled.div`
  margin-right: ${({ theme }) => theme.spacing.x32};
`;

export const CheckboxGroupDescription = styled.div`
  ${({ theme }) => theme.text.bodyMediumRegular};
  color: ${({ theme }) => theme.color.textHelpertext};
  margin-top: ${({ theme }) => theme.spacing.x8};
`;

export const CheckboxErrorMessage = styled.div`
  ${({ theme }) => theme.text.bodyMediumRegular};
  color: ${({ theme }) => theme.color.iconError};
`;

export const Label = styled.label<{
  $align: boolean;
  $isDisabled: boolean;
}>`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x8};
  word-break: break-word;
  width: fit-content;
  flex-direction: ${({ $align }) => $align && "row-reverse"};
  ${({ $isDisabled }) => !$isDisabled && `&:hover { cursor: pointer }`}
`;

export const ItemText = styled.span<{
  $isDisabled?: boolean;
}>`
  color: ${({ theme, $isDisabled }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.text.checkbox.default};

  ${({ theme }) => theme.text.bodyBaseRegular};
`;
