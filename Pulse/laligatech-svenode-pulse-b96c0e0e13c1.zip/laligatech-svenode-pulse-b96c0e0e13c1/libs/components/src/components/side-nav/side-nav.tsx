import { Collection, DisclosureGroup } from "react-aria-components";
import { useState } from "react";
import { /* FocusScope, */ useFocusWithin, useHover } from "react-aria";

import type { SideNavProps, TreeItem } from "./side-nav.types";
import { getItemParents } from "./side-nav.utils";
import { SideNavContextProvider } from "./sub-components/side-nav-context";
import { NavItem } from "./sub-components/nav-item";
import * as S from "./side-nav.styled";

import useEvent from "@hooks/use-event";
import { useUp } from "@hooks/use-media";

export function SideNav(props: SideNavProps) {
  const {
    isExpanded: isSidebarExpanded,
    isOpen: isSidebarOpen,
    items,
    activeItemId,
    onClose,
  } = props;

  const [expandedKeys, setExpandedKeys] = useState<Set<string | number>>(
    new Set(getItemParents(items, activeItemId).map(item => item.id))
  );

  const isDesktop = useUp("desktop");
  const [isFocused, setIsFocused] = useState(false);
  const { hoverProps, isHovered } = useHover({
    onHoverEnd: () => {
      setIsFocused(false);
    },
    isDisabled: !isDesktop,
  });
  const { focusWithinProps } = useFocusWithin({
    onFocusWithinChange: setIsFocused,
    onFocusWithin: () => {
      setIsFocused(true);
    },
    isDisabled: !isDesktop,
  });

  const onExpandedChange = useEvent(
    (key: string | undefined, treeLevelItems: TreeItem[]) => {
      setExpandedKeys(currentExpandedKeys => {
        let newExpandedKeys = new Set(currentExpandedKeys);
        newExpandedKeys = newExpandedKeys.difference(
          new Set(treeLevelItems.map(item => item.id))
        );

        if (key) {
          newExpandedKeys.add(key);
        }

        return newExpandedKeys;
      });
    }
  );

  /* A bit cumbersome, but we want to avoid rogue properties on the elements like a data-expanded="false" on the container in mobile, where it makes no sense to have it. We keep properties as undefined whenever possible in this object to not pass them to the DOM elements. */
  const flags: {
    isMobileOpen?: boolean;
    isDesktopExpanded?: boolean;
    isDesktopOpen?: boolean;
  } = {};

  if (isDesktop) {
    flags.isDesktopExpanded = isSidebarExpanded;

    if (!flags.isDesktopExpanded) {
      flags.isDesktopOpen = isHovered || isFocused;
    }
  } else {
    flags.isMobileOpen = isSidebarOpen;
  }

  const finalExpandedKeys =
    flags.isDesktopExpanded === false && flags.isDesktopOpen === false ?
      new Set<string | number>()
    : expandedKeys;

  const Navigation = (
    <S.NavContainer
      aria-hidden={flags.isMobileOpen === false || undefined}
      data-expanded={flags.isDesktopExpanded}
    >
      <S.Overlay data-open={flags.isMobileOpen} onClick={onClose} />
      <S.ScrollContainer
        data-expanded={flags.isDesktopExpanded}
        data-open={flags.isMobileOpen || flags.isDesktopOpen}
      >
        <S.Nav {...hoverProps} {...focusWithinProps}>
          <DisclosureGroup expandedKeys={finalExpandedKeys}>
            <S.List>
              <Collection items={items}>
                {item => {
                  return <NavItem item={item} treeLevelItems={items} />;
                }}
              </Collection>
            </S.List>
          </DisclosureGroup>
        </S.Nav>
      </S.ScrollContainer>
    </S.NavContainer>
  );

  return (
    <SideNavContextProvider
      activeItemId={activeItemId}
      expandedKeys={finalExpandedKeys}
      isExpanded={Boolean(
        !isDesktop || flags.isDesktopExpanded || flags.isDesktopOpen
      )}
      onExpandedChange={onExpandedChange}
      tree={items}
    >
      {/* TODO: Enable <FocusScope /> once we handle closing the modal with ESC and a react-aria's <DismissButton /> for assistive technology */}
      {/* {(!isDesktop && isOpen) ? (
        <FocusScope
          autoFocus
          contain
          restoreFocus
        >
          {Navigation}
        </FocusScope>
      ) : Navigation} */}
      {Navigation}
    </SideNavContextProvider>
  );
}
