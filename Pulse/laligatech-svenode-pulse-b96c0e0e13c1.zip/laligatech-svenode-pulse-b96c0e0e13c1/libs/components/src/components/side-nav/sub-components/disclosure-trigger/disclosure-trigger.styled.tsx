import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";
import { Button } from "react-aria-components";

export const DisclosureTrigger = styled(Button)`
  width: 100%;

  display: flex;
  align-items: center;
  justify-content: space-between;
  text-align: left;

  gap: ${cssVars.spacing.x8};
  padding: ${cssVars.spacing.x8};

  border: none;
  border-radius: ${cssVars.border.radiusM};

  font: ${cssVars.text.bodyBaseRegular};

  color: ${cssVars.color.textSidebarDefault};
  background-color: transparent;

  &[data-hovered="true"] {
    color: ${cssVars.color.textSidebarItemHover};
  }

  &[data-focused="true"]:focus-visible {
    outline: 2px solid ${cssVars.color.borderFocus};
    outline-offset: 2px;
    color: ${cssVars.color.textSidebarItemHover};
  }

  @supports not selector(:focus-visible) {
    &[data-focused="true"] {
      outline: 2px solid ${cssVars.color.borderFocus};
      outline-offset: 2px;
      color: ${cssVars.color.textSidebarItemHover};
    }
  }

  /* Force increase specificity 1 level to easily override focused styles */
  &&[data-highlighted="true"] {
    color: ${cssVars.color.textSidebarItemActive};
  }

  > *:last-child {
    margin-left: auto;
  }

  > *:first-child {
    margin-left: revert;
  }
`;

export const DefaultIcon = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: flex-start;
  flex-shrink: 0;

  width: 12px;
  height: 24px;

  &::after {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: currentColor;
  }
`;

export const DefaultIconInner = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: flex-start;
  flex-shrink: 0;

  width: 12px;
  height: 24px;

  &::after {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    border: 1px solid currentColor;
  }
`;

export const IconWrapper = styled.span`
  display: flex;
  align-self: flex-start;
`;
