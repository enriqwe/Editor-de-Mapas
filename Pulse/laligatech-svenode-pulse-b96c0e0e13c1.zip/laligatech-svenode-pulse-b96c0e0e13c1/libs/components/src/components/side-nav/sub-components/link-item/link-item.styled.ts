import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";
import { Link } from "react-aria-components";

export const LinkItem = styled(Link)`
  width: 100%;

  display: flex;
  align-items: center;

  gap: ${cssVars.spacing.x8};
  padding: ${cssVars.spacing.x8};

  border: none;
  border-radius: ${cssVars.border.radiusM};

  font: ${cssVars.text.bodyBaseRegular};
  text-decoration: none;

  color: ${cssVars.color.textSidebarDefault};

  &[data-hovered="true"] {
    color: ${cssVars.color.textSidebarItemHover};
  }

  &[data-focused="true"]:focus-visible {
    outline: 2px solid ${cssVars.color.borderFocus};
    outline-offset: 2px;
    color: ${cssVars.color.textSidebarItemHover};
  }

  @supports not selector(:focus-visible) {
    &[data-focused="true"] {
      outline: 2px solid ${cssVars.color.borderFocus};
      outline-offset: 2px;
      color: ${cssVars.color.textSidebarItemHover};
    }
  }

  &[data-active="true"] {
    color: ${cssVars.color.textSidebarItemActive};
    background-color: ${cssVars.color.bgSidebarItemActive};
  }
`;

export const DefaultIcon = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: flex-start;
  flex-shrink: 0;

  width: 12px;
  height: 24px;

  &::after {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: currentColor;
  }
`;

export const DefaultIconInner = styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: flex-start;
  flex-shrink: 0;

  width: 12px;
  height: 24px;

  &::after {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    border: 1px solid currentColor;
  }
`;

export const IconWrapper = styled.span`
  display: flex;
  align-self: flex-start;
`;
