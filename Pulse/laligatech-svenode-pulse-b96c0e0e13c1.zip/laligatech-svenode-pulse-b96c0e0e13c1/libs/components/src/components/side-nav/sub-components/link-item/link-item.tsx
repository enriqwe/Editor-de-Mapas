import { useSideNavContext } from "../side-nav-context";

import * as S from "./link-item.styled";

import { Icon, type IconProps } from "@components/icon";

type LinkItemComponentProps = {
  href: string;
  label: string;
  icon?: IconProps["icon"];
  inner?: boolean;
  isActive: boolean;
  testId: string;
};

export function LinkItem(props: LinkItemComponentProps) {
  const { href, label, inner, icon, isActive, testId } = props;

  const { isExpanded } = useSideNavContext();

  const DefaultIcon = inner ? <S.DefaultIconInner /> : <S.DefaultIcon />;

  return (
    <S.LinkItem
      data-active={isActive ? true : undefined}
      data-testid={`nav-item-${testId}`}
      href={href}
    >
      {icon ?
        <S.IconWrapper>
          <Icon color="inherit" icon={icon} size="m" />
        </S.IconWrapper>
      : DefaultIcon}
      {isExpanded && <span>{label}</span>}
    </S.LinkItem>
  );
}
