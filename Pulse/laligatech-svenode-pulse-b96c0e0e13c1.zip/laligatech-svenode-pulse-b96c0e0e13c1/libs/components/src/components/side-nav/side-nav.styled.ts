import { styled } from "@linaria/react";
import { cssVars, helpers } from "@pulse/foundations";

export const NavContainer = styled.div`
  ${helpers.media.down("desktop")} {
    width: 0;
    position: relative;
  }

  ${helpers.media.up("desktop")} {
    &[data-expanded="false"] {
      width: 72px;
    }
  }

  z-index: ${cssVars.zIndex.stickied};

  &[aria-hidden="true"] {
    visibility: hidden;
  }

  box-sizing: border-box;
  * {
    box-sizing: border-box;
  }
  *::before,
  *::after {
    box-sizing: inherit;
  }
`;

export const Overlay = styled.div`
  position: absolute;
  width: 0;
  top: 0;
  left: 0;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);

  &[data-open="true"] {
    width: 100vw;
  }

  ${helpers.media.up("desktop")} {
    display: none;
  }
`;

export const ScrollContainer = styled.div`
  overflow: auto;
  height: 100%;

  ${helpers.media.down("desktop")} {
    width: 240px;
    max-width: 100vw;
    transform: translateX(-100%);

    &[data-open="true"] {
      transform: translateX(0%);
    }
  }

  ${helpers.media.down("tablet")} {
    width: 100vw;
  }

  ${helpers.media.up("desktop")} {
    &[data-expanded="true"],
    &[data-open="true"] {
      width: 240px;
    }
  }
`;

export const Nav = styled.nav`
  position: relative; /* If not present, useHover breaks, idk why */
  min-height: 100%;
  color: ${cssVars.color.textSidebarDefault};
  background-color: ${cssVars.color.bgSidebarDefault};
  padding: ${cssVars.spacing.x40} ${cssVars.spacing.x16};
`;

export const List = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;

  display: grid;
  grid-template-columns: minmax(0px, 1fr);
  gap: ${cssVars.spacing.x4};
`;
