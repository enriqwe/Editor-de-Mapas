import type { IconProps } from "@components/icon";

type Link = {
  href: string;
};

export type SubNavItem = {
  id: string;
  label: string;
} & (
  | {
      link: Link;
      items?: never;
    }
  | {
      link?: never;
      items: SubNavItem[];
    }
);

export type NavItem = {
  id: string;
  label: string;
  icon: IconProps["icon"];
} & (
  | {
      link: Link;
      items?: never;
    }
  | {
      link?: never;
      items: SubNavItem[];
    }
);

export type SideNavProps = {
  /** In desktop, whether or not the sidenav is expanded. This prop is ignored in mobile. */
  isExpanded: boolean;
  /** In mobile, whether or not the sidenav is open. This prop is ignored in desktop. */
  isOpen: boolean;
  /** In mobile, Callback to close the sidenav. This prop is ignored in desktop. */
  onClose: () => void;
  items: NavItem[];
  activeItemId: string;
};


export type TreeItem = {
  id: string;
  items?: TreeItem[];
};