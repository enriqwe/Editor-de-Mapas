import { styled } from "@linaria/react"
import { cssVars } from "@pulse/foundations"

export const List = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;

  display: grid;
  grid-template-columns: minmax(0px, 1fr);
  gap: ${cssVars.spacing.x4};

  padding-left: ${cssVars.spacing.x12};
`

export const ListItem = styled.li`
`
