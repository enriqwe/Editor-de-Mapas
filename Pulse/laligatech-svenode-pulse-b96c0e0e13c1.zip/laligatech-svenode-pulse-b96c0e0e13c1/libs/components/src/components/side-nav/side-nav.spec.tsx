import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import type { SideNavProps } from "./side-nav.types";
import { SideNav } from "./side-nav";

import { render } from "@test-utils";
import { useUp } from "@hooks/use-media";

jest.mock("@hooks/use-media");

Object.defineProperty(window, "matchMedia", {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment -- stop copmlaining please
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

describe("side-nav", () => {
  expect.extend(toHaveNoViolations);

  const mockProps: SideNavProps = {
    isExpanded: true,
    isOpen: false,
    onClose: jest.fn(),
    activeItemId: "1",
    items: [
      {
        id: "1",
        label: "Dashboard (1)",
        icon: "monitoring",
        link: {
          href: "#",
        },
      },
      {
        id: "2",
        label: "Contenido (2)",
        icon: "folder",
        items: [
          {
            id: "3",
            label: "Noticias (3)",
            link: {
              href: "#",
            },
          },
          {
            id: "4",
            label: "Galerías (4)",
            link: {
              href: "#",
            },
          },
          {
            id: "5",
            label: "Multimedia (5)",
            items: [
              {
                id: "6",
                label: "Imágenes (6)",
                link: {
                  href: "#",
                },
              },
              {
                id: "7",
                label: "Vídeos (7)",
                link: {
                  href: "#",
                },
              },
              {
                id: "8",
                label: "Documentos (8)",
                link: {
                  href: "#",
                },
              },
            ],
          },
        ],
      },
      {
        id: "9",
        label: "Interacciones (9)",
        icon: "waving_hand",
        items: [
          {
            id: "10",
            label: "Formularios (10)",
            items: [
              {
                id: "11",
                label: "Recibidos (11)",
                link: {
                  href: "#",
                },
              },
              {
                id: "12",
                label: "Pendientes (12)",
                link: {
                  href: "#",
                },
              },
            ],
          },
          {
            id: "13",
            label: "Votaciones (13)",
            items: [
              {
                id: "14",
                label: "Recibidas (14)",
                link: {
                  href: "#",
                },
              },
              {
                id: "15",
                label: "Resultados (15)",
                link: {
                  href: "#",
                },
              },
            ],
          },
        ],
      },
      {
        id: "16",
        label: "Organización (16)",
        icon: "domain",
        items: [
          {
            id: "17",
            label: "Permisos (17)",
            link: {
              href: "#",
            },
          },
          {
            id: "18",
            label: "Usuarios (18)",
            link: {
              href: "#",
            },
          },
        ],
      },
    ],
  };

  beforeEach(() => {
    jest.mocked(useUp).mockImplementation(() => true);
  });

  it("renders the component without accesibility issues", async () => {
    const { container } = render(<SideNav {...mockProps} />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
  });

  it("starts with active item visible", () => {
    render(<SideNav {...mockProps} activeItemId="7" />);
    const lvl1 = screen.getByTestId("nav-trigger-2");
    const lvl2 = screen.getByTestId("nav-trigger-5");
    const activeItem = screen.getByTestId("nav-item-7");
    expect(lvl1).toHaveAttribute("data-highlighted", "true");
    expect(lvl2).toHaveAttribute("data-highlighted", "true");
    expect(activeItem).toHaveAttribute("data-active", "true");
  });

  it("collapses all items when it's collapsed", () => {
    render(<SideNav {...mockProps} activeItemId="7" isExpanded={false} />);
    const lvl1 = screen.getByTestId("nav-disclosure-2");
    const lvl2 = screen.getByTestId("nav-disclosure-5");
    expect(lvl1).not.toHaveAttribute("data-expanded", "true");
    expect(lvl2).not.toHaveAttribute("data-expanded", "true");
  });
});
