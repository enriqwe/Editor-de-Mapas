import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const UserTriggerContent = styled.div`
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
`

export const UserDisplay = styled.div`
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
  color: ${cssVars.color.textLabel};
  font: ${cssVars.text.bodyBaseRegular};
  padding: ${cssVars.spacing.x8};
`