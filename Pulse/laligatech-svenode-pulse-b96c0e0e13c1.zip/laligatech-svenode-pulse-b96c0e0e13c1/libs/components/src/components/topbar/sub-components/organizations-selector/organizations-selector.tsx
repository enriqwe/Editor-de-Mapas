import { MenuTrigger } from "react-aria-components";

import { Menu, MenuItem, OrganizationMenuTriggerButton, Popover } from "../menu";

import * as S from "./organizations-selector.styled";

import type { Organizations } from "@components/topbar/topbar.types";
import { Icon } from "@components/icon";
import { useTranslation } from "@providers/translation";

export function OrganizationsSelector(props: { organizations: Organizations }) {
  const { organizations } = props;

  const t = useTranslation();

  return (
    <MenuTrigger>
      <OrganizationMenuTriggerButton
        aria-label={t("topbar.a11y.orgsMenu.label")}
        data-testid="org-trigger"
      >
        {state => {
          return (
            <>
              {organizations.current.logoSrc && (
                <S.OrganizationLogo
                  alt="Organization logo"
                  src={organizations.current.logoSrc}
                />
              )}
              <S.CurrentOrganization>
                {organizations.current.label}
              </S.CurrentOrganization>
              {state.isPressed ?
                <Icon icon="expand_less" />
              : <Icon icon="expand_more" />}
            </>
          );
        }}
      </OrganizationMenuTriggerButton>
      <Popover placement="bottom left">
        <Menu data-testid="org-menu">
          {organizations.items.map(item => {
            return (
              <MenuItem
                data-testid={`org-${item.id}`}
                key={item.id}
                onAction={() => {
                  if (item.id !== organizations.current.id) {
                    organizations.onChange(item);
                  }
                }}
              >
                {item.logoSrc && (
                  <S.OrganizationLogo
                    alt="Organization logo"
                    src={organizations.current.logoSrc}
                  />
                )}
                {item.label}
              </MenuItem>
            );
          })}
        </Menu>
      </Popover>
    </MenuTrigger>
  );
}
