import { useEffect } from "react";
import { Form, MenuTrigger } from "react-aria-components";
import {
  useOverlayTriggerState,
  type OverlayTriggerState,
} from "react-stately";

import { Menu, MenuItem, TriggerButton, Popover } from "../menu";

import * as S from "./user-profile.styled";

import { type Locale, useTranslation } from "@providers/translation";
import { useUp } from "@hooks/use-media";
import { Avatar } from "@components/avatar";
import { Icon } from "@components/icon";
import { Modal, ModalWithSection } from "@components/modal";
import { Radio } from "@components/radio";
import type { Languages, UserProfile } from "@components/topbar/topbar.types";

function LanguagesModal(props: {
  languages: Languages;
  state: OverlayTriggerState;
  locale: Locale;
}) {
  const { languages, state, locale } = props;

  const t = useTranslation();

  const intlLanguages = new Intl.DisplayNames(locale, {
    type: "language",
    languageDisplay: "standard",
  });

  return (
    <Modal isDismissable state={state} type="medium">
      <Form
        data-testid="lang-form"
        onSubmit={e => {
          e.preventDefault();
          const formData = Object.fromEntries(
            new FormData(e.currentTarget)
          ) as { language: Locale };
          if (formData.language !== languages.current) {
            languages.onChange(formData.language);
          }
          state.close();
        }}
      >
        <ModalWithSection.Header
          closeHandler={() => {
            state.close();
          }}
          description="Choose a languge"
          title="Language"
        />
        <ModalWithSection.Body>
          <Radio.Group
            aria-label={t("topbar.a11y.langsModal.input.label")}
            automationContext="lang"
            column
            defaultValue={languages.current}
            name="language"
          >
            {languages.items.map(item => {
              return (
                <Radio.Item key={item} value={item}>
                  <span style={{ textTransform: "capitalize" }}>
                    {intlLanguages.of(item.split("-")[0] ?? "")}
                  </span>
                </Radio.Item>
              );
            })}
          </Radio.Group>
          {}
        </ModalWithSection.Body>
        <ModalWithSection.Footer
          actions={[
            {
              buttonVariant: "primary",
              buttonLabel: "Submit",
              buttonType: "submit",
              // eslint-disable-next-line @typescript-eslint/no-empty-function -- A button type="submit" already submits the form. clickHandler is required but not needed
              clickHandler: () => {},
            },
            {
              buttonVariant: "secondary",
              buttonLabel: "Cancel",
              clickHandler: () => {
                state.close();
              },
            },
          ]}
        />
      </Form>
    </Modal>
  );
}

export function UserProfile(props: {
  userProfile: UserProfile;
  languages?: Languages;
  locale: Locale;
}) {
  const { userProfile, languages, locale } = props;

  const t = useTranslation();
  const isDesktop = useUp("desktop");

  const modalState = useOverlayTriggerState({});

  useEffect(() => {
    /* Close the modal if it's open and the languages are not passed in (== change from mobile to tablet) */
    if (!languages) {
      modalState.close();
    }
  }, [languages, modalState]);

  if (!languages && userProfile.items.length === 0) {
    return (
      <S.UserDisplay>
        <Avatar name={userProfile.name} size="s" variant="topbar" />
        {isDesktop && (
          <span>{userProfile.name}</span>
        )}
      </S.UserDisplay>
    )
  }

  return (
    <>
      <MenuTrigger>
        <TriggerButton
          aria-label={t("topbar.a11y.userMenu.label")}
          data-testid="user-trigger"
        >
          {state => {
            return (
              <S.UserTriggerContent>
                <Avatar name={userProfile.name} size="s" variant="topbar" />
                {isDesktop && (
                  <>
                    <span>{userProfile.name}</span>
                    {state.isPressed ?
                      <Icon icon="expand_less" />
                    : <Icon icon="expand_more" />}
                  </>
                )}
              </S.UserTriggerContent>
            );
          }}
        </TriggerButton>
        <Popover placement="bottom right">
          <Menu data-testid="user-menu">
            {Boolean(languages) && (
              <MenuItem
                data-testid="user-lang-trigger"
                key="languages"
                onAction={() => {
                  modalState.open();
                }}
              >
                {t("topbar.userMenu.items.lang.label")}
              </MenuItem>
            )}
            {userProfile.items.map(item => {
              return (
                <MenuItem
                  data-testid={`user-${item.id}`}
                  key={item.id}
                  onAction={item.onPress}
                >
                  {item.icon && <Icon icon={item.icon} />}
                  {item.label}
                </MenuItem>
              );
            })}
          </Menu>
        </Popover>
      </MenuTrigger>
      {languages && modalState.isOpen ?
        <LanguagesModal
          languages={languages}
          locale={locale}
          state={modalState}
        />
      : undefined}
    </>
  );
}
