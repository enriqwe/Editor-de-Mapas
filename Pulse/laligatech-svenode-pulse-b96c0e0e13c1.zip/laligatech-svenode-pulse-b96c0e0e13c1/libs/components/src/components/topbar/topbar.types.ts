import type { IconProps } from "@components/icon";
import type { Locale } from "@providers/translation";

export type OrganizationItem = {
  id: string;
  label: string;
  logoSrc?: string;
};

export type Organizations = {
  current: OrganizationItem;
  items: OrganizationItem[];
  onChange: (value: OrganizationItem) => void;
};

export type Languages = {
  current: Locale;
  items: Locale[];
  onChange: (value: Locale) => void;
};

export type UserProfileItem = {
  id: string;
  label: string;
  icon?: IconProps["icon"];
  onPress: () => void;
};

export type UserProfile = {
  name: string;
  items: UserProfileItem[];
};

export type TopbarProps = {
  locale?: Locale;
  onHamburguerPress?: () => void;
  logo: {
    href?: string;
  } & (
    | {
        src: { mobile: string; desktop: string };
        element?: React.ReactNode;
      }
    | {
        src?: { mobile: string; desktop: string };
        element: React.ReactNode;
      }
  );
  organizations?: Organizations;
  languages?: Languages;
  userProfile: UserProfile;
};
