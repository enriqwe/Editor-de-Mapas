import { styled } from "@linaria/react";

export const OrganizationLogo = styled.img`
  width: 24px;
  height: 24px;
  object-fit: contain;
  object-position: center;
`

export const CurrentOrganization = styled.span`
  min-width: 7ch;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`