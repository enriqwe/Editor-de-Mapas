import { MenuTrigger } from "react-aria-components";

import { Menu, MenuItem, TriggerButton, Popover } from "../menu";

import { useUp } from "@hooks/use-media";
import { Icon } from "@components/icon";
import type { Languages } from "@components/topbar/topbar.types";
import { useTranslation, type Locale } from "@providers/translation";

export function LanguagesSelector(props: {
  languages: Languages;
  locale: Locale;
}) {
  const { languages, locale } = props;

  const t = useTranslation();
  const isDesktop = useUp("desktop");

  const intlLanguages = new Intl.DisplayNames(locale, {
    type: "language",
    languageDisplay: "standard",
  });

  return (
    <MenuTrigger>
      <TriggerButton
        aria-label={t("topbar.a11y.langsMenu.label")}
        data-testid="lang-trigger"
      >
        {state => {
          return (
            <>
              <Icon icon="language" />
              {isDesktop && (
                <>
                  <span style={{ textTransform: "uppercase" }}>
                    {intlLanguages
                      .of(languages.current.split("-")[0] ?? "")
                      ?.slice(0, 3)}
                  </span>
                  {state.isPressed ?
                    <Icon icon="expand_less" />
                  : <Icon icon="expand_more" />}
                </>
              )}
            </>
          );
        }}
      </TriggerButton>
      <Popover placement="bottom right">
        <Menu data-testid="lang-menu">
          {languages.items.map(item => {
            return (
              <MenuItem
                data-testid={`lang-${item}`}
                key={item}
                onAction={() => {
                  if (item !== languages.current) {
                    languages.onChange(item);
                  }
                }}
              >
                <span style={{ textTransform: "capitalize" }}>
                  {intlLanguages.of(item.split("-")[0] ?? "")}
                </span>
              </MenuItem>
            );
          })}
        </Menu>
      </Popover>
    </MenuTrigger>
  );
}
