import type {
  Button as RAButton,
  MenuItem as RAMenuItem,
  Menu as RAMenu,
  Popover as RAPopover,
} from "react-aria-components";
import type { ComponentPropsWithRef } from "react";

import * as S from "./menu.styled";

export function TriggerButton(props: ComponentPropsWithRef<typeof RAButton>) {
  return (
    <S.TriggerButton {...props} />
  );
}

export function OrganizationMenuTriggerButton(props: ComponentPropsWithRef<typeof RAButton>) {
  return (
    <S.OrganizationMenuTriggerButton {...props} />
  );
}

export function Menu(props: ComponentPropsWithRef<typeof RAMenu>) {
  return <S.Menu {...props} />;
}

export function MenuItem(props: ComponentPropsWithRef<typeof RAMenuItem>) {
  return <S.MenuItem {...props} />;
}

export function Popover(props: ComponentPropsWithRef<typeof RAPopover>) {
  return <S.Popover {...props} />;
}