import { styled } from "@linaria/react"
import { cssVars } from "@pulse/foundations"
import {
  Menu as RAMenu,
  MenuItem as RAMenuItem,
  Button as RAButton,
  Popover as RAPopover,
} from "react-aria-components"

export const TriggerButton = styled(RAButton)`
  background: transparent;
  border: none;
  border-radius: ${cssVars.border.radiusS};
  color: ${cssVars.color.textLabel};
  font: ${cssVars.text.bodyBaseRegular};
  padding: ${cssVars.spacing.x8};
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};

  &[data-hovered="true"] {
    background: ${cssVars.color.bgNavbarDropdownHover};
  }

  &[data-disabled="true"] {
    background: ${cssVars.color.bgDisabled};
    color: ${cssVars.color.textDisabled};
  }

  &[data-focused="true"]:focus-visible {
    outline: ${cssVars.color.borderFocus} solid 2px;
    outline-offset: 2px;
    background: ${cssVars.color.bgNavbarDropdownHover};
  }

  @supports not selector(:focus-visible) {
    &[data-focused="true"] {
      outline: ${cssVars.color.borderFocus} solid 2px;
      outline-offset: 2px;
      background: ${cssVars.color.bgNavbarDropdownHover};
    }
  }

  &[aria-expanded="true"] {
    background: ${cssVars.color.bgItemSelected};
    color: ${cssVars.color.textBrandActive};
  }
`

export const OrganizationMenuTriggerButton = styled(TriggerButton)`
  min-width: 0;
`

export const Popover = styled(RAPopover)`
  overflow: auto;
  background-color: ${cssVars.color.surfacePrimary};
  border-radius: ${cssVars.border.radiusS};
  box-shadow: ${cssVars.shadow.break};
`

export const Menu = styled(RAMenu)`
  padding: ${cssVars.spacing.x8};
  font: ${cssVars.text.bodyBaseRegular};
  min-width: 150px;
`

export const MenuItem = styled(RAMenuItem)`
  cursor: default;
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
  padding: ${cssVars.spacing.x8};
  border-radius: ${cssVars.border.radiusXS};

  &[data-hovered="true"] {
    background: ${cssVars.color.bgItemHover};
  }

  &[data-disabled="true"] {
    background: ${cssVars.color.bgItemDisabled};
    color: ${cssVars.color.textDisabled};
  }

  &[data-focused="true"]:focus-visible {
    outline: ${cssVars.color.borderFocus} solid 2px;
    background: ${cssVars.color.bgItemHover};
  }

  @supports not selector(:focus-visible) {
    &[data-focused="true"] {
      outline: ${cssVars.color.borderFocus} solid 2px;
      background: ${cssVars.color.bgItemHover};
    }
  }
`
