import styled from "styled-components";

export const Breadcrumb = styled.div`
  display: flex;
  background-color: ${({ theme }) => theme.color.background.breadcrumb};
`;

export const LastItem = styled.span`
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-style: normal;
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.semibold)};
  letter-spacing: 0.02em;
  /* padding: ${({ theme }) => `0 0 0 ${theme.spacing.x4}`}; */

  color: ${({ theme }) => theme.color.text.link.active};
`;

export const ContainerIcon = styled.div`
  padding: ${({ theme }) => `${theme.spacing.x2} 0`};
  display: flex;
  align-items: center;
`;
