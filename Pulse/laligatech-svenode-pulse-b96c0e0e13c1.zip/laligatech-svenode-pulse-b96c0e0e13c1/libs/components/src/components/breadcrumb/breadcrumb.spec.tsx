import { screen } from "@testing-library/react";

import { Breadcrumb } from "./breadcrumb";

import { render } from "@test-utils";

describe("breadcrumb", () => {
  it("should render successfully and property", () => {
    render(
      // <MemoryRouter>
      <Breadcrumb
        // routerLink={Link}
        to={[
          { to: "", label: "Test" },
          { to: "", label: "Create" },
          { to: "", label: "Actions" },
        ]}
      />
      // </MemoryRouter>
    );

    expect(screen.getByText(/Test/)).toBeInTheDocument();

    expect(screen.getByText(/Create/)).toBeInTheDocument();

    expect(screen.getByText(/Actions/)).toBeInTheDocument();
  });
});
