import { useEffect, useRef, useState } from "react";

import type {
  UseVisibilityStateProps,
  UseVisibilityStateReturnData,
} from "./use-visibility-state.types";

const MAX_HEIGHT = 42;

export const useVisibilityState = ({
  items,
}: UseVisibilityStateProps): UseVisibilityStateReturnData => {
  const [visibleItems, setVisibleItems] = useState<
    UseVisibilityStateProps["items"]
  >([]);
  const [isShowMoreButtonDisplayed, setIsShowMoreButtonDisplayed] =
    useState(false);
  const [areItemsHidden, setAreItemsHidden] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);

  const handleShowMoreChange = () => {
    setAreItemsHidden(previousState => {
      if (!previousState) {
        setVisibleItems(items.slice(0, 1));
        setIsShowMoreButtonDisplayed(false);
      } else {
        setVisibleItems(items);
      }

      return !previousState;
    });
  };

  useEffect(() => {
    setVisibleItems(items.slice(0, 1));
    setIsShowMoreButtonDisplayed(false);
  }, [items]);

  useEffect(() => {
    if (containerRef.current) {
      const currentHeight = containerRef.current.clientHeight;

      if (
        currentHeight <= MAX_HEIGHT &&
        visibleItems.length < items.length &&
        !isShowMoreButtonDisplayed
      ) {
        setVisibleItems(prevItems => items.slice(0, prevItems.length + 1));
      }

      if (
        currentHeight >= MAX_HEIGHT &&
        areItemsHidden &&
        visibleItems.length <= items.length
      ) {
        setVisibleItems(prevItems => items.slice(0, prevItems.length - 1));
        setIsShowMoreButtonDisplayed(true);
      }
    }
  }, [
    items,
    isShowMoreButtonDisplayed,
    areItemsHidden,
    visibleItems,
    containerRef,
  ]);

  return {
    handleShowMoreChange,
    visibleItems,
    isShowMoreButtonDisplayed,
    areItemsHidden,
    containerRef,
  };
};
