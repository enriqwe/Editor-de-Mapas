export { Legend } from "./legend";
export type { LegendProps } from "./legend.types";
