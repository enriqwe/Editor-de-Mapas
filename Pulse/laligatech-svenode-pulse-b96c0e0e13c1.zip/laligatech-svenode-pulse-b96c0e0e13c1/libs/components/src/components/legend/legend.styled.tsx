import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x8};
  overflow: hidden;
`;

export const Item = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x4};
`;

export const ItemColor = styled.div<{
  $background: string;
}>`
  background-color: ${({ $background }) => $background};
  border-radius: ${({ theme }) => theme.border.radiusM};
  height: ${({ theme }) => theme.spacing.x8};
  width: ${({ theme }) => theme.spacing.x12};
`;

export const ItemLabel = styled.span`
  ${({ theme }) => theme.text.bodyMediumRegular}
  color: ${({ theme }) => theme.color.textLabel};
`;
