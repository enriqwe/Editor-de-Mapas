type LegendItem = {
  color: string;
  label: string;
};

export type LegendProps = {
  items: LegendItem[];
  automationContext?: string;
};
