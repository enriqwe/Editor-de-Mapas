import { createRef } from "react";
import { screen } from "@testing-library/react";

import { Legend } from "./legend";
import { useVisibilityState } from "./hooks";
import type { LegendProps } from "./legend.types";
import type { UseVisibilityStateReturnData } from "./hooks";

import { render } from "@test-utils";

jest.mock("./hooks", () => ({
  ...jest.requireActual("./hooks"),
  useVisibilityState: jest.fn(),
}));

describe("legend", () => {
  let minProps: LegendProps;
  let useVisibilityStateReturnData: UseVisibilityStateReturnData;

  beforeEach(() => {
    minProps = {
      items: [
        {
          color: "#2E6ED6",
          label: "First Item",
        },
        {
          color: "#EAF1FB",
          label: "Second Item",
        },
        { color: "#09A57F", label: "Third Item" },
        { color: "#09A57F", label: "Fourth Item" },
        { color: "#09A57F", label: "Fifth Item" },
      ],
    };

    useVisibilityStateReturnData = {
      visibleItems: minProps.items,
      isShowMoreButtonDisplayed: true,
      areItemsHidden: true,
      handleShowMoreChange: jest.fn(),
      containerRef: createRef(),
    };

    jest
      .mocked(useVisibilityState)
      .mockReturnValue(useVisibilityStateReturnData);
  });

  it("should render properly the visible items", () => {
    render(<Legend {...minProps} />);

    expect(screen.getByText("First Item")).toBeInTheDocument();
    expect(screen.getByText("Second Item")).toBeInTheDocument();
    expect(screen.getByText("Third Item")).toBeInTheDocument();
    expect(screen.getByText("Fourth Item")).toBeInTheDocument();
    expect(screen.getByText("Fifth Item")).toBeInTheDocument();
  });

  describe("show more button", () => {
    it("should render the button if they are hidden items", () => {
      jest.mocked(useVisibilityState).mockReturnValueOnce({
        ...useVisibilityStateReturnData,
        isShowMoreButtonDisplayed: true,
      });

      render(<Legend {...minProps} />);

      expect(screen.getByText("Ver mas")).toBeInTheDocument();
    });

    it("should not render the button if there is no hidden item", () => {
      jest.mocked(useVisibilityState).mockReturnValueOnce({
        ...useVisibilityStateReturnData,
        isShowMoreButtonDisplayed: false,
      });

      render(<Legend {...minProps} />);

      expect(screen.queryByText("Ver mas")).not.toBeInTheDocument();
    });

    it("should call the handleShowMoreChange method if the button is clicked", async () => {
      const { user } = render(<Legend {...minProps} />);

      await user.click(screen.getByText("Ver mas"));

      expect(
        useVisibilityStateReturnData.handleShowMoreChange
      ).toHaveBeenCalled();
    });

    describe("label", () => {
      it("should display show more label if the areItemsHidden data is true", () => {
        jest.mocked(useVisibilityState).mockReturnValueOnce({
          ...useVisibilityStateReturnData,
          areItemsHidden: true,
        });

        render(<Legend {...minProps} />);

        expect(screen.getByText("Ver mas")).toBeInTheDocument();
        expect(screen.queryByText("Ver menos")).not.toBeInTheDocument();
      });

      it("should display show less label if the areItemsHidden data is false", () => {
        jest.mocked(useVisibilityState).mockReturnValueOnce({
          ...useVisibilityStateReturnData,
          areItemsHidden: false,
        });

        render(<Legend {...minProps} />);

        expect(screen.queryByText("Ver mas")).not.toBeInTheDocument();
        expect(screen.getByText("Ver menos")).toBeInTheDocument();
      });
    });
  });
});
