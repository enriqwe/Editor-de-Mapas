import type { CSSProperties } from "react";
import type { ClearIndicatorProps } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import { Icon } from "@components/icon";

export function ClearIndicator(props: ClearIndicatorProps<Option>) {
  const {
    getStyles,
    innerProps: { ref, ...restInnerProps },
    selectProps: { inputValue },
  } = props;

  return !inputValue.length ?
      <div
        {...restInnerProps}
        ref={ref}
        style={getStyles("clearIndicator", props) as CSSProperties}
      >
        <Icon icon="clear" size="s" />
      </div>
    : null;
}
