import { Spinner } from "@components/spinner";

export function LoadingIndicator() {
  return <Spinner size="sm" />;
}
