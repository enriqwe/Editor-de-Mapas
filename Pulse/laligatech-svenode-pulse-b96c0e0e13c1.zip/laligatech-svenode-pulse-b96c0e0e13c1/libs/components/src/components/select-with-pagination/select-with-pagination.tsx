import {
  forwardRef,
  useCallback,
  useImperativeHandle,
  useRef,
  useMemo,
} from "react";
import type { ForwardedRef } from "react";
import type {
  InputActionMeta,
  SelectInstance,
  MenuProps,
  GroupBase,
} from "react-select";
import Select from "react-select";

import type {
  OptionValue,
  SelectWithPaginationProps,
  Option,
  SelectWithPaginationRef,
} from "./select-with-pagination.types";
import * as S from "./select-with-pagination.styled";
import {
  DropdownIndicator,
  LoadingIndicator,
  MultiValueRemove,
  SelectMenu,
  MenuOptions,
  ClearInputIndicator,
  ClearIndicator,
  MultiValueLabel,
  SingleValue,
} from "./sub-components";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

const debounce = (func: (val: string) => void, delay = 300) => {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: [val: string]) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      func(...args);
    }, delay);
  };
};

export enum SelectActions {
  InputChange = "input-change",
  SetValue = "set-value",
  MenuClose = "menu-close",
}

function SelectWithPaginationComponent(
  props: SelectWithPaginationProps,
  selectRef: ForwardedRef<SelectWithPaginationRef>
) {
  const {
    isMulti,
    isLoading,
    options,
    totalOptions,
    onInputChange,
    onChange,
    onPageEndReached,
    initialValue,
    name,
    isClearable = true,
    noOptionsMessage = "No Options",
    label,
    dropdownInline,
    required,
    disabled,
    pageSize,
    tooltipContent,
    helperText,
    errorMessage,
    minInputLength,
    placeholder,
    automationContext,
    menuPlacement = "auto",
    clearInputOnChange = false,
    allowedCharRegExp,
  } = props;
  const thisRef = useRef<SelectInstance<Option> | null>(null);
  const automationClasses = automationClass(
    "selectWithPagination",
    automationContext
  );
  const onValueChange = (value: OptionValue) => {
    onChange(value);

    if (clearInputOnChange) {
      clearInput();
    }
    return value;
  };

  const clearInput = () => {
    thisRef.current?.onInputChange("", {
      action: "input-change",
      prevInputValue: "",
    });
  };

  const clearSelectedOptions = () => {
    thisRef.current?.setValue(null, "deselect-option");
  };

  useImperativeHandle(selectRef, () => ({
    clearInput,
    clearSelectedOptions,
  }));

  const debouncedInputChange = useMemo(
    () => debounce(onInputChange, 300),
    [onInputChange]
  );

  const onInput = (inputValue: string) => {
    if (minInputLength) {
      inputValue.length >= minInputLength && debouncedInputChange(inputValue);
    } else {
      debouncedInputChange(inputValue);
    }
  };

  const onInputSelectChange = (
    inputValue: string,
    { action, prevInputValue }: InputActionMeta
  ) => {
    if (allowedCharRegExp && !allowedCharRegExp.test(inputValue)) {
      return prevInputValue;
    }

    if (
      isMulti &&
      (action === SelectActions.SetValue || action === SelectActions.MenuClose)
    ) {
      if (prevInputValue) {
        onInputChange(prevInputValue);
      }
      return prevInputValue;
    }

    onInput(inputValue);
    return inputValue;
  };

  const Menu = useCallback(
    (menuProps: MenuProps<Option, boolean, GroupBase<Option>>) => {
      return (
        <SelectMenu
          {...menuProps}
          data-testid="select-menu-component"
          pageSize={pageSize}
          totalOptions={totalOptions}
        />
      );
    },
    [pageSize, totalOptions]
  );

  return (
    <S.Wrapper
      className={automationClasses}
      data-testid="select-component"
      dropdownInline={dropdownInline}
    >
      {label && (
        <S.Label $disabled={disabled} $dropdownInline={dropdownInline}>
          {label}
          {required && <S.RequiredField />}
          {tooltipContent && (
            <Icon
              fill
              icon="info"
              size="s"
              state="informative"
              tooltipContent={tooltipContent}
            />
          )}
        </S.Label>
      )}
      <S.SelectContainer>
        <Select
          isLoading={isLoading}
          isMulti={isMulti}
          options={options ?? []}
          ref={thisRef}
          {...(initialValue && { defaultValue: initialValue })}
          isDisabled={disabled}
          {...(name && { name })}
          {...(errorMessage && { menuIsOpen: false })}
          closeMenuOnSelect={!isMulti}
          components={{
            Menu,
            Option: MenuOptions,
            DropdownIndicator,
            MultiValueRemove,
            LoadingIndicator,
            IndicatorSeparator: ClearInputIndicator, // using indicator separator space to add custom input clear indicator.
            ClearIndicator,
            MultiValueLabel,
            SingleValue,
          }}
          escapeClearsValue
          filterOption={() => true}
          getOptionValue={option => {
            return option.label;
          }}
          hideSelectedOptions
          isClearable={isClearable}
          loadingMessage={() => "Cargando opciones..."}
          menuPlacement={menuPlacement}
          menuPosition="fixed"
          menuShouldScrollIntoView={false}
          noOptionsMessage={() => noOptionsMessage}
          onChange={onValueChange}
          onInputChange={onInputSelectChange}
          onMenuScrollToBottom={() => {
            onPageEndReached();
          }}
          openMenuOnFocus
          placeholder={placeholder}
          styles={S.Select(errorMessage, disabled)}
        />
      </S.SelectContainer>
      {(errorMessage || helperText) && (
        <S.Label
          $disabled={disabled}
          $dropdownInline={dropdownInline}
          $isError={Boolean(errorMessage)}
          $isSubLabel
        >
          {errorMessage || helperText}
        </S.Label>
      )}
    </S.Wrapper>
  );
}

export const SelectWithPagination = forwardRef(SelectWithPaginationComponent);
