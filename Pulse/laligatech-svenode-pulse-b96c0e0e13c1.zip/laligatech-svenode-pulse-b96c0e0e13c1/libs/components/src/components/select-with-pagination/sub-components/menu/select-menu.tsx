import { useEffect, useRef } from "react";
import { components } from "react-select";

import type { SelectMenuProps } from "../../select-with-pagination.types";

import { MenuListFooter } from "./menu-list-footer";

export function SelectMenu(props: SelectMenuProps) {
  const menu = useRef<HTMLDivElement>(null);
  const handleScroll = () => {
    const { children } = menu.current?.children.item(0) || {};
    if (children) {
      const total = children.length;
      if (total > props.pageSize) {
        children[children.length - (props.pageSize + 1)]?.scrollIntoView({
          inline: "nearest",
        });
      }
    }
  };

  useEffect(() => {
    handleScroll();
  }, []);

  return (
    <components.Menu {...props} innerRef={menu}>
      <>
        {props.children}
        {props.options.length ?
          <MenuListFooter
            actualNumber={props.options.length}
            total={props.totalOptions}
          />
        : null}
      </>
    </components.Menu>
  );
}
