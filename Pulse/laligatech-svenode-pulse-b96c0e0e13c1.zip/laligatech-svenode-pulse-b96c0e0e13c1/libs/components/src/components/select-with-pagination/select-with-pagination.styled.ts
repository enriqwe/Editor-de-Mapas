import type { StylesConfig } from "react-select";
import styled, { css, useTheme } from "styled-components";

import type { Option } from "./select-with-pagination.types";

export const Wrapper = styled.div<{
  dropdownInline: boolean | undefined;
}>`
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-size: ${({ theme }) => theme.font.sizes.m.fontSize};
  line-height: ${({ theme }) => theme.font.sizes.m.lineHeight};
  ${props => {
    if (props.dropdownInline) {
      return css`
        display: flex;
      `;
    }
  }};
`;

export const RequiredField = styled.span`
  color: ${({ theme }) => theme.color.icon.error};
  margin-left: ${({ theme }) => theme.spacing.x4};
  &::before {
    content: "*";
  }
`;

export const Label = styled.label<{
  $dropdownInline?: boolean;
  $isError?: boolean;
  $disabled?: boolean;
  $isSubLabel?: boolean;
}>`
  display: flex;
  gap: ${({ theme }) => theme.spacing.x4};
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-weight: ${({ theme, $isSubLabel }) =>
    $isSubLabel ? theme.font.weights.regular : theme.font.weights.semibold};
  font-size: ${({ theme, $isSubLabel }) =>
    $isSubLabel ? theme.font.sizes.xs.fontSize : theme.font.sizes.sm.fontSize};
  line-height: ${({ theme, $isSubLabel }) =>
    $isSubLabel ?
      theme.font.sizes.xs.lineHeight
    : theme.font.sizes.sm.lineHeight};
  color: ${({ theme, $isError, $disabled }) => {
    if ($disabled) {
      return theme.color.text.disabled;
    }
    if ($isError) {
      return theme.color.text.helperTextError;
    }
    return theme.color.text.body;
  }};

  ${({ $dropdownInline }) => {
    if ($dropdownInline) {
      return css`
        margin-top: ${({ theme }) => theme.spacing.x8};
      `;
    }
  }};
`;

export const SelectContainer = styled.div`
  padding: ${({ theme }) => theme.spacing.x8} 0px;
`;

export const Select = (
  errorMessage: string | undefined,
  disabled: boolean | undefined
): StylesConfig<Option> => {
  const theme = useTheme();
  return {
    menu: baseStyles => ({
      ...baseStyles,
      borderRadius: theme.spacing.x8,
      boxShadow: theme.shadow.high,
      padding: theme.spacing.x8,
    }),
    control: (baseStyles, state) => {
      const { isFocused } = state;

      const baseStyle = {
        ...baseStyles,
        "boxShadow": "none",
        "fontSize": theme.font.sizes.m.fontSize,
        "border-radius": theme.border.radiusS,
        "cursor": disabled ? "not-allowed" : "pointer",
        "pointer-events": disabled && "auto",
      };

      const defaultEvent = {
        "border": `1px solid ${theme.color.border.dropdown.default}`,
        "box-shadow":
          isFocused && `inset 0px 0px 0px 1px ${theme.color.border.tab.active}`,
        "border-color": isFocused && theme.color.border.tab.active,
        "&:hover": {
          "box-shadow":
            !isFocused &&
            `inset 0px 0px 0px 0.5px ${theme.color.border.button.secondary}`,
          "border-color": !isFocused && theme.color.border.button.secondary,
        },
      };

      const errorEvent = {
        "box-shadow": `inset 0px 0px 0px 1px ${theme.color.border.dropdown.error}`,
        "border-color": theme.color.border.dropdown.error,
        ":hover": {
          "box-shadow": `inset 0px 0px 0px 1px ${theme.color.border.dropdown.error}`,
          "border-color": theme.color.border.dropdown.error,
        },
      };

      const disabledEvent = {
        backgroundColor: theme.color.background.disabled,
        border: `${theme.border.widthXS} solid ${theme.color.border.dropdown.disabled}`,
        color: theme.color.text.disabled,
      };

      let event;
      if (errorMessage) {
        event = errorEvent;
      } else if (disabled) {
        event = disabledEvent;
      } else {
        event = defaultEvent;
      }

      return {
        ...baseStyle,
        ...event,
      };
    },
    multiValue: baseStyles => ({
      ...baseStyles,
      borderRadius: theme.spacing.x16,
      background:
        disabled ?
          theme.color.background.dropdown.disabled
        : theme.color.background.dropdown.active,
      color: theme.color.text.chip.active,
      justifyContent: "space-evenly",
      alignItems: "center",
      padding: `3px ${theme.spacing.x6} 3px ${theme.spacing.x12}`,
      gap: theme.spacing.x4,
    }),
    multiValueLabel: baseStyles => ({
      ...baseStyles,
      color:
        disabled ?
          theme.color.text.dropdown.disabled
        : theme.color.text.chip.active,
      fontSize: theme.font.sizes.xs.fontSize,
      fontWeight: theme.font.weights.semibold,
      lineHeight: theme.font.sizes.xs.lineHeight,
    }),
    valueContainer: baseStyles => ({
      ...baseStyles,
      maxHeight: "82px",
      overflow: "auto",
    }),
    option: baseStyles => ({
      ...baseStyles,
      "color": theme.color.text.body,
      "fontFamily": theme.font.fontFamily,
      "fontSize": theme.font.sizes.m.fontSize,
      "fontWeight": theme.font.weights.regular,
      "lineHeight": theme.font.sizes.m.lineHeight,
      "borderRadius": theme.spacing.x4,
      "&:hover": {
        background: theme.color.background.dropdown.active,
      },
      '&[aria-disabled="true"]': {
        color: theme.color.text.dropdown.disabled,
      },
    }),
  };
};
