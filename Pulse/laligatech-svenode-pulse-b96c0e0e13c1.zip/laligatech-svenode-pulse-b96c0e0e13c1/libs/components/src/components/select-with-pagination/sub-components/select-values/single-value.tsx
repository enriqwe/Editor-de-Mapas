import type { CSSProperties } from "react";
import type { SingleValueProps } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import { TextTooltip } from "@components/text-tooltip";

export function SingleValue(props: SingleValueProps<Option>) {
  const { getStyles } = props;
  return (
    <div style={getStyles("singleValue", props) as CSSProperties}>
      <TextTooltip tooltipText={props.data.label}>
        {props.data.label}
      </TextTooltip>
    </div>
  );
}
