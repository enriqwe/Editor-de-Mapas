import type { MultiValueRemoveProps } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import * as S from "./multi-value-remove.styled";

import { Icon } from "@components/icon";

export function MultiValueRemove(props: MultiValueRemoveProps<Option>) {
  return (
    <S.MultiValueRemove
      $disabled={props.selectProps.isDisabled}
      onClick={event => {
        props.innerProps.onClick && props.innerProps.onClick(event);
      }}
    >
      <Icon
        icon="close"
        size="xs"
        state={props.selectProps.isDisabled ? "disabled" : "informative"}
      />
    </S.MultiValueRemove>
  );
}
