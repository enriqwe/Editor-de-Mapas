import styled from "styled-components";

export const MultiValueRemove = styled.div<{ $disabled?: boolean }>`
  display: flex;
  pointer-events: ${({ $disabled }) => ($disabled ? "none" : "auto")};

  &:hover {
    .material-symbols-outlined {
      color: ${({ theme }) => theme.color.border.dropdown.error};
    }
  }
`;
