import type { DropdownIndicatorProps } from "react-select";
import { components } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import { Icon } from "@components/icon";

export function DropdownIndicator(props: DropdownIndicatorProps<Option>) {
  return (
    <components.DropdownIndicator {...props}>
      {props.selectProps.menuIsOpen ?
        <Icon icon="keyboard_arrow_up" />
      : <Icon icon="keyboard_arrow_down" />}
    </components.DropdownIndicator>
  );
}
