import styled from "styled-components";

export const MultiValueLabel = styled.div`
  color: ${({ theme }) => theme.color.text.chip.active};
  font-size: ${({ theme }) => theme.font.sizes.xs.fontSize};
  font-weight: ${({ theme }) => theme.font.weights.semibold};
  line-height: ${({ theme }) => theme.font.sizes.xs.lineHeight};
  width: 95%;
`;
