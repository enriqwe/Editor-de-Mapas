import type { OptionProps } from "react-select";
import { components } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import * as S from "./menu-options.styled";

const getHighlightedText = (text?: string, highlight?: string) => {
  if (!text || !highlight) return;
  const validatedString = highlight.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const parts = text.split(new RegExp(`(${validatedString})`, "gi"));
  return (
    <span>
      {parts.map((part, i) => (
        <S.Option
          $isBold={part.toLowerCase() === highlight.toLowerCase()}
          key={i}
        >
          {part}
        </S.Option>
      ))}
    </span>
  );
};

export function MenuOptions(props: OptionProps<Option>) {
  const {
    selectProps: { inputValue },
  } = props;
  return (
    <components.Option {...props}>
      {inputValue ?
        getHighlightedText(props.children?.toString(), inputValue)
      : props.children}
    </components.Option>
  );
}
