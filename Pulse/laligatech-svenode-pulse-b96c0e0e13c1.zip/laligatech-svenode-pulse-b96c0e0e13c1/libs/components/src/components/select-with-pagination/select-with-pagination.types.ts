import type {
  GroupBase,
  MenuProps,
  MultiValue,
  SingleValue,
} from "react-select";

export type Option = {
  isDisabled?: boolean;
  label: string;
  value: string | number;
};

type Single = SingleValue<Option>;
type Multi = MultiValue<Option>;

export type OptionValue = Single | Multi;

export type SelectWithPaginationProps = {
  onInputChange: (value: string) => void;
  onChange: (value: OptionValue) => void;
  onPageEndReached: () => void;
  pageSize: number;
  name?: string | undefined;
  disabled?: boolean;
  options?: Option[];
  isMulti?: boolean | undefined;
  isLoading?: boolean | undefined;
  initialValue?: Option | Option[] | undefined | null;
  isClearable?: boolean | undefined;
  noOptionsMessage?: string | React.ReactElement | undefined;
  automationContext?: string;
  label?: string | undefined;
  required?: boolean | undefined;
  dropdownInline?: boolean | undefined;
  totalOptions?: number;
  tooltipContent?: string;
  helperText?: string;
  errorMessage?: string;
  minInputLength?: number;
  placeholder?: string;
  clearInputOnChange?: boolean;
  menuPlacement?: "auto" | "bottom" | "top";
  allowedCharRegExp?: RegExp;
};

export type SelectMenuProps = {
  totalOptions?: number | undefined;
  pageSize: number;
} & MenuProps<Option, boolean, GroupBase<Option>>;

export type SelectWithPaginationRef = {
  clearInput: VoidFunction;
  clearSelectedOptions: VoidFunction;
};
