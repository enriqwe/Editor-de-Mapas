import type { MultiValueGenericProps } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import * as S from "./multi-value.styled";

import { TextTooltip } from "@components/text-tooltip";

export function MultiValueLabel(props: MultiValueGenericProps<Option>) {
  const label = props.data.label as string;
  return (
    <S.MultiValueLabel>
      <TextTooltip tooltipText={label}>{label}</TextTooltip>
    </S.MultiValueLabel>
  );
}
