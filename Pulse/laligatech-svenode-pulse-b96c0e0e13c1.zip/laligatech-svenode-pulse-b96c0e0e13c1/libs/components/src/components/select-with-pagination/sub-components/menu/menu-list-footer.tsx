import * as S from "./menu-list-footer.styled";

export function MenuListFooter({
  total,
  actualNumber,
}: {
  total: number | undefined;
  actualNumber: number;
}) {
  return (
    <S.Footer>
      Mostrando <span>{actualNumber}</span> de <span>{total || 0}</span>{" "}
      resultados
    </S.Footer>
  );
}
