import styled from "styled-components";

export const Footer = styled.div`
  display: flex;
  align-items: center;
  justify-content: left;
  padding: ${({ theme }) => theme.spacing.x8};
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  font-weight: ${({ theme }) => theme.font.weights.regular};
  line-height: ${({ theme }) => theme.font.sizes.sm.lineHeight};
  letter-spacing: 0.28px;
  color: ${({ theme }) => theme.color.text.disabled};

  span {
    font-weight: ${({ theme }) => theme.font.weights.bold};
    padding: 0px ${({ theme }) => theme.spacing.x4};
  }
`;
