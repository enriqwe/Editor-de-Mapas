import styled from "styled-components";

export const Option = styled.span<{ $isBold?: boolean }>`
  font-weight: ${({ theme, $isBold }) =>
    $isBold ? theme.font.weights.bold : theme.font.weights.regular};
`;
