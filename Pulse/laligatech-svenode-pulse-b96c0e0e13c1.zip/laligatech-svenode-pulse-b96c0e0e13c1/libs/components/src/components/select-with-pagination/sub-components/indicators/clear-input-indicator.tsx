import type { IndicatorSeparatorProps } from "react-select";

import type { Option } from "../../select-with-pagination.types";

import { Icon } from "@components/icon";

export function ClearInputIndicator(props: IndicatorSeparatorProps<Option>) {
  const {
    selectProps: { inputValue, onInputChange, isLoading },
  } = props;

  if (inputValue && !isLoading) {
    return (
      <Icon
        icon="clear"
        onClick={() => {
          onInputChange("", {
            action: "input-change",
            prevInputValue: "",
          });
        }}
        size="s"
      />
    );
  }
  return null;
}
