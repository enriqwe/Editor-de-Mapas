import styled from "styled-components";

export const TimeField = styled.div`
  display: inline-flex;
  position: relative;
  text-align: left;
  flex-direction: column;
`;

export const Dropdown = styled.div`
  label {
    padding: ${({ theme }) => `0px 0px ${theme.spacing.x8}`};
  }
`;
