import * as S from "./time-picker.styled";
import { generateTimeOptions } from "./time-picker.utils";

import { Time } from "@utils/date";
import { Dropdown } from "@components/dropdown";
import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";

export type TimePickerProps = {
  label: string;
  intervalTime?: number;
  required?: boolean;
  withHelper?: string;
  disabled?: boolean;
  error: boolean;
  invalidTime?: Time;
  automationContext?: string;
  onTimeSelected: (params: Time) => void;
  /** @deprecated use value prop instead */
  time?: Time;
  value?: Time;
};

const timeToSimpleString = (time: Time) => {
  return time.toString().slice(0, 5);
};

const simpleStringToTime = (string: string) => {
  return new Time(Number(string.split(":")[0]), Number(string.split(":")[1]));
};

export function TimePicker(props: TimePickerProps) {
  const {
    label,
    intervalTime = 30,
    required = false,
    withHelper = "",
    disabled = false,
    error,
    invalidTime,
    automationContext,
    onTimeSelected,
    time,
    value,
  } = props;
  const automationClasses = automationClass("timepicker", automationContext);
  const options = generateTimeOptions(intervalTime);
  let timeValidationError = false;

  let finalValue = value;
  if (time && !value) {
    finalValue = time;
  }

  if (invalidTime && finalValue) {
    if (finalValue.compare(invalidTime) === 0) {
      timeValidationError = true;
    }

    const valueInString = timeToSimpleString(finalValue);

    const isManualTimeValid = options.some(option => {
      return option.value === valueInString;
    });

    if (!isManualTimeValid) {
      timeValidationError = true;
    }
  }

  const finalValueOption = finalValue && {
    value: timeToSimpleString(finalValue),
    label: timeToSimpleString(finalValue),
  };

  return (
    <S.Dropdown className={automationClasses}>
      <Dropdown
        additionalText={withHelper}
        closeMenuOnSelect
        disabled={disabled}
        dropdownIndicatorIcon={
          <Icon
            icon="schedule"
            size="s"
            state={disabled ? "disabled" : "default"}
          />
        }
        error={error || timeValidationError}
        label={label}
        noOptionsMessage="No options"
        onSelectedOption={event => {
          if (Array.isArray(event)) {
            /** This assertion is here because the type of the event is not exposed correctly on dropdown
             * If multi is false, the event should not be an array
             */
            throw new Error("this should not be an array ");
          }
          const selectedValue = event.value;

          onTimeSelected(simpleStringToTime(selectedValue));
        }}
        options={options}
        placeholder="00:00"
        required={required}
        {...(finalValue && {
          value: finalValueOption,
        })}
      />
    </S.Dropdown>
  );
}
