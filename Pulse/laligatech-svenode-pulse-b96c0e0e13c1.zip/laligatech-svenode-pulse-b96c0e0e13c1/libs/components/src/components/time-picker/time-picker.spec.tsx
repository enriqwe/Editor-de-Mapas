import { screen } from "@testing-library/react";

import { TimePicker } from "./time-picker";

import { Time } from "@utils/date";
import { render } from "@test-utils";

describe("timePicker", () => {
  it("should render properly with options", () => {
    const { baseElement } = render(
      <TimePicker
        error={false}
        label="TimePicker"
        onTimeSelected={() => null}
        value={new Time(12, 45)}
        withHelper="Tristique senectus et netus et"
      />
    );

    expect(baseElement).toBeTruthy();
    expect(screen.getByText("TimePicker")).toBeInTheDocument();
    expect(screen.getByText(/12:45/i)).toBeInTheDocument();
    expect(
      screen.getByText("Tristique senectus et netus et")
    ).toBeInTheDocument();
  });

  it("should render properly with invalid time options", () => {
    const { baseElement } = render(
      <TimePicker
        error
        intervalTime={30}
        invalidTime={new Time(12, 30)}
        label="TimePicker"
        onTimeSelected={() => null}
        value={new Time(12, 30)}
        withHelper="Tristique senectus et netus et"
      />
    );

    expect(baseElement).toBeTruthy();
    expect(screen.getByText("TimePicker")).toBeInTheDocument();
    expect(screen.getByText(/12:30/i)).toBeInTheDocument();
    expect(
      screen.getByText("Tristique senectus et netus et")
    ).toBeInTheDocument();
  });
});
