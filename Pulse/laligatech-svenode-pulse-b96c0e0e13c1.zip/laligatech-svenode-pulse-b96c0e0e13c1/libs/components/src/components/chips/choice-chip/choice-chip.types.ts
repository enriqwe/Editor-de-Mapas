import type { ToggleButtonProps } from "react-aria-components";

type DeprecatedProps = {
  /** @deprecated use `text` instead */
  label?: string;
  /** @deprecated use `onPress` instead */
  onClick?: () => void;
  /** @deprecated use `isDisabled` instead */
  disabled?: boolean;
  /** @deprecated use `isSelected` instead */
  selected?: boolean;
};

export type ChoiceChipProps = {
  text: string;
  iconLeft?: string;
  iconRight?: string;
  variant?: "outlined" | "filled";
  automationContext?: string;
  size?: "s" | "m" | "l";
} & DeprecatedProps &
  Omit<ToggleButtonProps, "children">;
