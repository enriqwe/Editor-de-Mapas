import styled, { css } from "styled-components";

import type { ActionChipProps } from "./action-chip.types";

const styledOutline = css`
  outline-offset: 2px;
  outline: ${({ theme }) =>
    `${theme.border.widthS} solid ${theme.color.borderFocus}`};
`;

const ActionChip = styled.button<{
  disabled: boolean;
  $size: NonNullable<ActionChipProps["size"]>;
  $iconLeft: boolean;
  $iconRight: boolean;
}>`
  display: flex;
  align-items: center;
  justify-content: center;

  ${({ theme }) => theme.text.bodySmallSemiBold};

  background: none;
  border-width: ${({ theme }) => theme.border.widthXS};
  border-radius: ${({ theme }) => theme.border.radiusL};

  cursor: pointer;

  padding-top: ${({ theme, $size }) =>
    $size === "s" ? theme.spacing.x2 : theme.spacing.x4};
  padding-bottom: ${({ theme, $size }) =>
    $size === "s" ? theme.spacing.x2 : theme.spacing.x4};
  padding-left: ${({ theme, $iconLeft }) =>
    $iconLeft ? theme.spacing.x6 : theme.spacing.x12};
  padding-right: ${({ theme, $iconRight }) =>
    $iconRight ? theme.spacing.x6 : theme.spacing.x12};

  gap: ${({ theme }) => theme.spacing.x4};

  color: ${({ theme, disabled }) =>
    disabled ? theme.color.textDisabled : theme.color.textBody};

  & > span {
    color: ${({ theme, disabled }) =>
      disabled ? theme.color.textDisabled : theme.color.textBody};
  }
`;

export const ActionChipOutlined = styled(ActionChip)<{
  disabled: boolean;
}>`
  border: ${({ theme, disabled }) =>
    `${theme.border.widthXS} solid ${disabled ? theme.color.borderDisabled : theme.color.borderChipDefault}`};

  &:hover,
  :focus {
    border-color: ${({ theme }) => theme.color.borderChipHover};
  }

  &:focus-visible {
    ${styledOutline}
  }
`;

export const ActionChipFilled = styled(ActionChip)<{
  disabled: boolean;
}>`
  border-color: transparent;
  background: ${({ theme, disabled }) =>
    disabled ? theme.color.bgDisabled : theme.color.bgChipDefault};

  &:hover,
  :focus {
    background-color: ${({ theme }) => theme.color.bgChipHover};
  }

  &:focus-visible {
    ${styledOutline}
  }
`;
