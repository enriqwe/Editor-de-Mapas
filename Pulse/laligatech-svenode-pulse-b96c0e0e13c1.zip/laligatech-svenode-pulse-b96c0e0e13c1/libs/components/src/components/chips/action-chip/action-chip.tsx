import * as S from "./action-chip.styled";
import type { ActionChipProps } from "./action-chip.types";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

export function ActionChip(props: ActionChipProps) {
  const {
    label,
    iconLeft = "",
    iconRight = "",
    disabled = false,
    onClick,
    automationContext,
    variant = "outlined",
    size = "s",
  } = props;
  const automationClasses = automationClass("actionChip", automationContext);

  const Action =
    variant === "outlined" ? S.ActionChipOutlined : S.ActionChipFilled;
  return (
    <Action
      $iconLeft={Boolean(iconLeft)}
      $iconRight={Boolean(iconRight)}
      $size={size}
      aria-label={props["aria-label"]}
      className={automationClasses}
      disabled={disabled}
      onClick={onClick}
      type="button"
    >
      {iconLeft && <Icon icon={iconLeft} size="xs" />}
      {label}
      {iconRight && <Icon icon={iconRight} size="xs" />}
    </Action>
  );
}
