import * as S from "./choice-chip.styled";
import type { ChoiceChipProps } from "./choice-chip.types";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

export function ChoiceChip(props: ChoiceChipProps) {
  const {
    label,
    text,
    iconLeft = "",
    iconRight = "",
    isDisabled,
    disabled = false,
    onClick,
    automationContext,
    variant = "outlined",
    size = "s",
    selected,
    isSelected,
  } = props;
  const handleClick = () => onClick?.();

  const automationClasses = automationClass("choiceChip", automationContext);
  const Choice =
    variant === "outlined" ? S.ChoiceChipOutlined : S.ChoiceChipFilled;
  return (
    <Choice
      {...props}
      $iconLeft={Boolean(iconLeft)}
      $iconRight={Boolean(iconRight)}
      $size={size}
      aria-label={props["aria-label"]}
      aria-pressed={selected}
      className={automationClasses}
      isDisabled={isDisabled || disabled}
      isSelected={Boolean(isSelected || selected)}
      onClick={handleClick}
      type="button"
    >
      {iconLeft && <Icon icon={iconLeft} size="xs" />}
      {text || label}
      {iconRight && <Icon icon={iconRight} size="xs" />}
    </Choice>
  );
}
