export type ActionChipProps = {
  "label": string;
  "iconLeft"?: string;
  "iconRight"?: string;
  "variant"?: "outlined" | "filled";
  "onClick"?: () => void;
  "disabled"?: boolean;
  "automationContext"?: string;
  "size"?: "s" | "m";
  "aria-label"?: string;
};
