import { screen } from "@testing-library/react";

import { TextTooltip } from "./text-tooltip";

import { render } from "@test-utils";

describe("textTooltip", () => {
  it("should render properly", async () => {
    const { user } = render(
      <TextTooltip alwaysShow>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua
      </TextTooltip>
    );
    const text = screen.getByText(/Lorem ipsum dolor sit amet/i);

    await user.hover(text);

    expect(screen.getAllByText(/Lorem ipsum dolor sit amet/i)).toHaveLength(2);
  });

  it("should render properly with tooltipText", async () => {
    const { user } = render(
      <TextTooltip alwaysShow tooltipText="Testing text tooltip content">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua
      </TextTooltip>
    );
    const text = screen.getByText(/Lorem ipsum dolor sit amet/i);

    await user.hover(text);

    expect(
      screen.getByText(/Testing text tooltip content/i)
    ).toBeInTheDocument();
  });

  //TODO: add test to check that tooltip is displayed when container is hovered and is smaller than the content
});
