export { TextTooltip } from "./text-tooltip";
export type { TextToolTipProps } from "./text-tooltip";
