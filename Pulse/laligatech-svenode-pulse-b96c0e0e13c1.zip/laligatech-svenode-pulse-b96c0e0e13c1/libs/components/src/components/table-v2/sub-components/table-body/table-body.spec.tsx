import {
  createColumnHelper,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { screen } from "@testing-library/react";

import { TableBody } from "./table-body";

import { render } from "@test-utils";

// Mock data
type Person = {
  firstName: string;
  lastName: string;
  age: number;
};

const defaultData: Person[] = [
  {
    firstName: "John",
    lastName: "Doe",
    age: 30,
  },
  {
    firstName: "Jane",
    lastName: "Smith",
    age: 25,
  },
];

const columnHelper = createColumnHelper<Person>();

const columns = [
  columnHelper.accessor("firstName", {
    cell: info => info.getValue(),
  }),
  columnHelper.accessor("lastName", {
    cell: info => info.getValue(),
  }),
  columnHelper.accessor("age", {
    cell: info => info.getValue(),
  }),
];

describe("tableBody", () => {
  function TableWrapper() {
    const table = useReactTable({
      data: defaultData,
      columns,
      getCoreRowModel: getCoreRowModel(),
    });

    return (
      <table>
        <TableBody table={table} />
      </table>
    );
  }

  it("should render table body with data", () => {
    render(<TableWrapper />);

    // Check if tbody exists
    const tbody = screen.getByRole("rowgroup");
    expect(tbody).toBeInTheDocument();

    // Check if all rows are rendered
    const rows = screen.getAllByRole("row");
    expect(rows).toHaveLength(defaultData.length);
  });

  it("should render correct cell values", () => {
    render(<TableWrapper />);

    // Check if all data is rendered correctly
    defaultData.forEach(person => {
      expect(screen.getByText(person.firstName)).toBeInTheDocument();
      expect(screen.getByText(person.lastName)).toBeInTheDocument();
      expect(screen.getByText(person.age.toString())).toBeInTheDocument();
    });
  });
});
