import type { Header, Column } from "@tanstack/react-table";
import { flexRender } from "@tanstack/react-table";
import { useEffect } from "react";

import { ResizeSeparator } from "..";

import * as S from "./table-header-cell.styled";

import { Icon } from "@components/icon";
import { IconButton } from "@components/icon-button";

type TableHeaderCellProps<T> = {
  header: Header<T, unknown>;
  enableColumnResizing: boolean;
  enableColumnPinning: boolean;
  enableColumnSorting: boolean;
};

export function TableHeaderCell<T>({
  header,
  enableColumnResizing,
  enableColumnPinning,
  enableColumnSorting,
}: TableHeaderCellProps<T>) {
  useEffect(() => {
    if (header.column.columnDef.meta?.pinned) {
      header.column.pin(header.column.columnDef.meta.pinned);
    }
  }, [header.column]);

  const pinned = header.column.getIsPinned();
  const isPinnedFixed = pinned && header.column.columnDef.meta?.pinned;

  const pinningHandler = () => {
    header.column.pin(pinned === "left" ? false : "left");
  };

  const canSort = header.column.getCanSort();

  const getSortingIconProps = () => {
    if (header.column.getIsSorted() === "asc") {
      return { icon: "arrow_upward" };
    } else if (header.column.getIsSorted() === "desc") {
      return { icon: "arrow_downward" };
    }
    return { icon: "sync_alt", rotate: 90 };
  };

  const headerText = flexRender(
    header.column.columnDef.header,
    header.getContext()
  );

  const sortClickZone =
    enableColumnSorting && canSort ?
      <S.SortButton
        data-testid="sort-button"
        onClick={header.column.getToggleSortingHandler()}
      >
        {headerText}
        <Icon {...getSortingIconProps()} size="xs" />
      </S.SortButton>
    : headerText;
  return (
    <S.HeaderCell
      $column={header.column as Column<unknown>}
      $width={header.getSize()}
      colSpan={header.colSpan}
      data-testid="table-header-cell"
    >
      {header.isPlaceholder ? null : sortClickZone}
      {enableColumnPinning && !isPinnedFixed && (
        <IconButton
          iconName={pinned ? "keep_off" : "keep"}
          iconSize="xs"
          onPress={pinningHandler}
        />
      )}
      {enableColumnResizing && (
        <ResizeSeparator
          isResizing={header.column.getIsResizing()}
          resetSize={header.column.resetSize}
          resizeHandler={header.getResizeHandler()}
        />
      )}
    </S.HeaderCell>
  );
}
