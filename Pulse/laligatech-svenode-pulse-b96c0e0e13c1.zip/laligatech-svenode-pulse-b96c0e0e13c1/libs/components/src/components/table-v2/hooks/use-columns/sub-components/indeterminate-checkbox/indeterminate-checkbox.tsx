import type { HTMLProps } from "react";
import { useEffect, useRef } from "react";

import * as S from "./indeterminate-checkbox.styled";

export function IndeterminateCheckbox({
  indeterminate,
  className = "",
  checked,
  onChange,
  disabled,
}: { indeterminate: boolean } & HTMLProps<HTMLInputElement>) {
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (ref.current) {
      ref.current.indeterminate = !checked && indeterminate;
    }
  }, [ref, indeterminate, checked]);

  return (
    <S.Checkbox
      aria-label="select row"
      className={`${className} cursor-pointer`}
      disabled={disabled}
      onChange={onChange}
      ref={ref}
      type="checkbox"
    />
  );
}
