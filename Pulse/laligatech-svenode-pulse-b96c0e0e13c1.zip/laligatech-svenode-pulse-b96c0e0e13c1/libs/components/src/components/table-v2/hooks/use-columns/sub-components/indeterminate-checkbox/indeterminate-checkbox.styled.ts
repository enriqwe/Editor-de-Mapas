import styled from "styled-components";

export const Checkbox = styled.input`
  width: 16px;
  height: 16px;
  margin: 0;
`;
