import type { JSX } from "react";
import type { ColumnDef, SortingState } from "@tanstack/react-table";

import type { Locale } from "@providers/translation";

export type { ColumnDef } from "@tanstack/react-table";

export type ExposedToolbarProps = {
  massiveActions?:
    | {
        options: {
          text: string;
          onSelect: (selectedKeys?: (string | number)[]) => void;
        }[];
      }
    | undefined;
  items?: JSX.Element[] | undefined;
  filters?:
    | {
        count: number;
        onClick: () => void;
      }
    | undefined;
};

// Sorting should call backend
type ControlledProps = {
  controlled: {
    currentPage: number;
    totalRows: number;
    pageSize: number;
    onPageChange: (pageNumber: number) => void;
    onPageSizeChange: (pageSize: number) => void;
    sortingState?: SortingState;
    onSortChange: (sortingState: SortingState) => void;
  };
  defaultPageSize?: never;
};

// Sorting should be done by table
type UncontrolledProps = {
  controlled?: never;
  defaultPageSize?: number;
};

export type TableV2Props<T> = (ControlledProps | UncontrolledProps) & {
  automationContext?: string;
  data: T[];
  columns: ColumnDef<T>[];
  label?: string;
  ariaLabel?: string;
  loading?: boolean;
  /** Locale for all texts on the component */
  locale?: Locale;
  /** List of possible page sizes */
  pageSizes?: number[];

  /** If true, shows all records. Only useful if pagination is client-side */
  disablePagination?: boolean;
  enableColumnResizing?: boolean;
  enableColumnPinning?: boolean;
  enableColumnSorting?: boolean;

  enableRowSelection?: boolean;

  /** Pending implementation */
  enableHideColumns?: boolean;
  toolbar?: ExposedToolbarProps;
};

// export type Column<T> = Pick<ColumnDef<T>, 'id' | 'cell' | 'header' | 'accessorKey' | 'accesorFn'>;
