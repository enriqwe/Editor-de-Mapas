import type { Table } from "@tanstack/react-table";

import { TableHeaderCell } from "..";

export type TableHeaderProps<T> = {
  enableColumnResizing: boolean;
  enableColumnPinning: boolean;
  enableColumnSorting: boolean;
  table: Table<T>;
};

export function TableHeader<T>({
  enableColumnResizing,
  enableColumnSorting,
  enableColumnPinning,
  table,
}: // columnOrder,
TableHeaderProps<T>) {
  return (
    <thead>
      {table.getHeaderGroups().map(headerGroup => (
        <tr key={headerGroup.id}>
          {headerGroup.headers.map(header => {
            return (
              <TableHeaderCell
                enableColumnPinning={enableColumnPinning}
                enableColumnResizing={enableColumnResizing}
                enableColumnSorting={enableColumnSorting}
                header={header}
                key={header.id}
              />
            );
          })}
        </tr>
      ))}
    </thead>
  );
}
