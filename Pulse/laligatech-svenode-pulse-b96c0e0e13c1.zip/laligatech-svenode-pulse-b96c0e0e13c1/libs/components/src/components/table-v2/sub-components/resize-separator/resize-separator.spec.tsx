import { screen } from "@testing-library/react";

import { ResizeSeparator } from "./resize-separator";

import { render } from "@test-utils";

describe("resizeSeparator", () => {
  const resetSizeMock = jest.fn();
  const resizeHandlerMock = jest.fn();

  it("should have the correct class", () => {
    render(
      <ResizeSeparator
        isResizing={false}
        resetSize={resetSizeMock}
        resizeHandler={resizeHandlerMock}
      />
    );

    const separator = screen.getByTestId("resize-separator");

    expect(separator.classList.contains("resizer")).toBe(true);
    expect(separator.classList.contains("isResizing")).toBe(false);
  });

  it("should call resetSize when double-clicked", async () => {
    const { user } = render(
      <ResizeSeparator
        isResizing={false}
        resetSize={resetSizeMock}
        resizeHandler={resizeHandlerMock}
      />
    );

    const separator = screen.getByTestId("resize-separator");
    await user.dblClick(separator);

    expect(resetSizeMock).toHaveBeenCalled();
  });

  it("should call resizeHandler when mouse down", async () => {
    const { user } = render(
      <ResizeSeparator
        isResizing={false}
        resetSize={resetSizeMock}
        resizeHandler={resizeHandlerMock}
      />
    );

    const separator = screen.getByTestId("resize-separator");
    await user.pointer({ keys: "[MouseLeft]", target: separator });

    expect(resizeHandlerMock).toHaveBeenCalled();
  });

  it("should have the correct initial state", () => {
    render(
      <ResizeSeparator
        isResizing
        resetSize={resetSizeMock}
        resizeHandler={resizeHandlerMock}
      />
    );

    const separator = screen.getByTestId("resize-separator");
    expect(separator.classList.contains("isResizing")).toBe(true);
  });
});
