import { flexRender } from "@tanstack/react-table";
import type { Cell, Column, Row } from "@tanstack/react-table";

import * as S from "./table-body-cell.styled";

type TableBodyCellProps<T> = {
  cell: Cell<T, unknown>;
  row: Row<T>;
};

export function TableBodyCell<T>({ cell, row }: TableBodyCellProps<T>) {
  const isExpandCell = cell.column.id === "expand";
  const isExpanded = row.getIsExpanded();
  const isParentExpanded = row.getParentRow()?.getIsExpanded() ?? false;

  return (
    <S.BodyCell
      $column={cell.column as Column<unknown>}
      $expanded={isExpandCell && (isExpanded || isParentExpanded)}
      $isExpandCell={isExpandCell}
      $width={cell.column.getSize()}
      key={cell.id}
    >
      {flexRender(cell.column.columnDef.cell, cell.getContext())}
    </S.BodyCell>
  );
}
