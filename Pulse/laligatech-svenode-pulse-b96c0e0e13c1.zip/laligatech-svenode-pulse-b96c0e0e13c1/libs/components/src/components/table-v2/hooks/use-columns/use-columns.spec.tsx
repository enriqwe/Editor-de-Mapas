import { renderHook } from "@testing-library/react";

import { useColumns } from "./use-columns";

const defaultColumns = [
  { id: "column1", accessor: "column1" },
  { id: "column2", accessor: "column2" },
];
const enableRowSelection = true;
const hasSubRows = false;

// Test useColumns hook
describe("useColumns", () => {
  it("should return columns with row selection enabled", () => {
    const { result } = renderHook(() =>
      useColumns(defaultColumns, enableRowSelection, hasSubRows)
    );
    expect(result.current).toHaveLength(3);
  });

  it("should return columns without row selection", () => {
    const { result } = renderHook(() =>
      useColumns(defaultColumns, false, hasSubRows)
    );
    expect(result.current).toHaveLength(2);
  });

  it("should return columns with sub rows", () => {
    const { result } = renderHook(() =>
      useColumns(defaultColumns, false, true)
    );
    expect(result.current).toHaveLength(3);
  });

  it("should return columns with row selection and sub rows", () => {
    const { result } = renderHook(() => useColumns(defaultColumns, true, true));
    expect(result.current).toHaveLength(4);
  });
});
