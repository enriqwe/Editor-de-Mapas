import { screen } from "@testing-library/react";
import type { Cell, Row, CellContext } from "@tanstack/react-table";

import { TableBodyCell } from "./table-body-cell";

import { render } from "@test-utils";

describe("tableBodyCell", () => {
  const mockCell: Partial<Cell<any, unknown>> = {
    id: "test-cell",
    column: {
      id: "test-column",
      getSize: () => 50,
      columnDef: {
        cell: () => "Test Content",
      },
      getIsPinned: () => false,
    } as any,
    getContext: () =>
      ({
        cell: mockCell as Cell<any, unknown>,
        column: mockCell.column!,
        getValue: () => "",
        renderValue: () => "",
        row: mockRow as Row<any>,
      }) as CellContext<any, unknown>,
  };

  const mockRow: Partial<Row<any>> = {
    id: "test-row",
    getIsExpanded: () => false,
    getParentRow: () => {
      return {
        id: "test-parent-row",
        getIsExpanded: () => false,
      } as Row<any>;
    },
  };

  let container: HTMLElement;
  beforeEach(() => {
    const table = document.createElement("table");
    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");
    container = document.body
      .appendChild(table)
      .appendChild(tbody)
      .appendChild(tr);
  });

  it("should render cell content", () => {
    render(
      <TableBodyCell
        cell={mockCell as Cell<any, unknown>}
        row={mockRow as Row<any>}
      />,
      {
        container,
      }
    );

    const Cell = screen.getByText("Test Content");
    expect(Cell).toBeInTheDocument();
  });

  it("should adjust width to auto if isExpandCell", () => {
    const expandCell = {
      ...mockCell,
      column: {
        ...mockCell.column,
        id: "expand",
      },
    };

    render(
      <TableBodyCell
        cell={expandCell as Cell<any, unknown>}
        row={mockRow as Row<any>}
      />,
      {
        container,
      }
    );

    const Cell = screen.getByText("Test Content");

    expect(Cell).toHaveStyle("width: auto");
  });

  it("should adjust width to 100% if isExpandCell is false", () => {
    const expandCell = {
      ...mockCell,
      column: {
        ...mockCell.column,
        getSize: () => 50,
        id: "not-expand",
      },
    };

    render(
      <TableBodyCell
        cell={expandCell as Cell<any, unknown>}
        row={mockRow as Row<any>}
      />,
      {
        container,
      }
    );

    const Cell = screen.getByText("Test Content");

    expect(Cell).toHaveStyle("width: 50px");
  });
});
