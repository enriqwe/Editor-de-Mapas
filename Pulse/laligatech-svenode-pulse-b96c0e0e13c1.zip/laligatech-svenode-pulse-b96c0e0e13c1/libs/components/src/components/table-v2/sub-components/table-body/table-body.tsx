import type { Table } from "@tanstack/react-table";

import { TableBodyCell } from "..";

type TableBodyProps<T> = {
  table: Table<T>;
};

export function TableBody<T>({ table }: TableBodyProps<T>) {
  return (
    <tbody>
      {table.getRowModel().rows.map(row => (
        <tr key={row.id}>
          {row.getVisibleCells().map(cell => (
            <TableBodyCell cell={cell} key={cell.id} row={row} />
          ))}
        </tr>
      ))}
    </tbody>
  );
}
