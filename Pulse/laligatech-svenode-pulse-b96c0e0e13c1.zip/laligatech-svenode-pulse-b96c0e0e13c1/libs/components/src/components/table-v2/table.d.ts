import "@tanstack/react-table";

declare module "@tanstack/react-table" {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars, @typescript-eslint/consistent-type-definitions -- needed to extend the interface
  interface ColumnMeta<TData, TValue> {
    pinned?: "left" | "right";
  }
}
