import {
  createColumnHelper,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { screen } from "@testing-library/react";

import { TableHeader } from "./table-header";

import { render } from "@test-utils";

// Mock data
type Person = {
  firstName: string;
  lastName: string;
  age: number;
};

const defaultData: Person[] = [
  {
    firstName: "John",
    lastName: "Doe",
    age: 30,
  },
  {
    firstName: "Jane",
    lastName: "Smith",
    age: 25,
  },
];

const columnHelper = createColumnHelper<Person>();

const columns = [
  columnHelper.accessor("firstName", {
    header: "First Name",
  }),
  columnHelper.accessor("lastName", {
    header: "Last Name",
  }),
  columnHelper.accessor("age", {
    header: "Age",
  }),
];

describe("tableHeader", () => {
  function TableWrapper({
    enableColumnResizing = false,
    enableColumnPinning = false,
    enableColumnSorting = false,
  }) {
    const table = useReactTable({
      data: defaultData,
      columns,
      getCoreRowModel: getCoreRowModel(),
    });

    return (
      <table>
        <TableHeader
          enableColumnPinning={enableColumnPinning}
          enableColumnResizing={enableColumnResizing}
          enableColumnSorting={enableColumnSorting}
          table={table}
        />
      </table>
    );
  }

  it("should render table header with column titles", () => {
    render(<TableWrapper />);

    expect(screen.getByText("First Name")).toBeInTheDocument();
    expect(screen.getByText("Last Name")).toBeInTheDocument();
    expect(screen.getByText("Age")).toBeInTheDocument();
  });

  it("should render thead element", () => {
    render(<TableWrapper />);

    const thead = screen.getByRole("rowgroup");
    expect(thead).toBeInTheDocument();
  });

  it("should render header cells with sorting enabled", () => {
    render(<TableWrapper enableColumnSorting />);

    const headerCells = screen.getAllByRole("columnheader");
    expect(headerCells).toHaveLength(3);
    headerCells.forEach(cell => {
      expect(cell).toBeInTheDocument();
    });
  });

  it("should render header cells with resizing enabled", () => {
    render(<TableWrapper enableColumnResizing />);

    const resizeHandles = screen.getAllByTestId("resize-separator");
    expect(resizeHandles).toHaveLength(3);
    resizeHandles.forEach(handle => {
      expect(handle).toBeInTheDocument();
    });
  });

  it("should render header cells with pinning enabled", () => {
    render(<TableWrapper enableColumnPinning />);

    const pinButtons = screen.getAllByRole("button");
    expect(pinButtons.length).toBeGreaterThan(0);
    pinButtons.forEach(button => {
      expect(button).toBeInTheDocument();
    });
  });
});
