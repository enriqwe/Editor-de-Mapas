import { screen } from "@testing-library/react";

import { Toolbar } from "./toolbar";

import { render } from "@test-utils";
import type { Locale } from "@providers/translation";
import { TranslationProvider } from "@providers/translation";

const locale = "es-ES" as Locale;

const mockProps = {
  massiveActions: {
    options: [
      { text: "Action 1", onSelect: jest.fn() },
      { text: "Action 2", onSelect: jest.fn() },
    ],
  },
  filters: {
    onClick: jest.fn(),
    count: 2,
  },
  selectedRows: ["row1", "row2"],
  locale,
  automationContext: "test-context",
};

describe("table Toolbar", () => {
  it("renders massive actions button menu when options are provided", () => {
    render(
      <TranslationProvider locale={mockProps.locale}>
        <Toolbar {...mockProps} />
      </TranslationProvider>
    );

    expect(screen.getByText("Selecciona una opción")).toBeInTheDocument();
  });

  it("renders filters button with count", () => {
    render(
      <TranslationProvider locale={mockProps.locale}>
        <Toolbar {...mockProps} />
      </TranslationProvider>
    );

    expect(screen.getByText("Filtros (2)")).toBeInTheDocument();
  });

  it("calls onClick when filters button is clicked", async () => {
    const { user } = render(
      <TranslationProvider locale={mockProps.locale}>
        <Toolbar {...mockProps} />
      </TranslationProvider>
    );

    await user.click(screen.getByText("Filtros (2)"));
    expect(mockProps.filters.onClick).toHaveBeenCalled();
  });

  it("disables massive actions button menu when no rows are selected", () => {
    const props = { ...mockProps, selectedRows: [] };
    render(
      <TranslationProvider locale={props.locale}>
        <Toolbar {...props} />
      </TranslationProvider>
    );

    expect(
      screen.getByText("Selecciona una opción").closest("button")
    ).toBeDisabled();
  });

  it("calls onSelect with selected rows when massive action is clicked", async () => {
    const { user } = render(
      <TranslationProvider locale={mockProps.locale}>
        <Toolbar {...mockProps} />
      </TranslationProvider>
    );

    await user.click(screen.getByText("Selecciona una opción"));
    await user.click(screen.getByText("Action 1"));

    const firstItemOnSelect = mockProps.massiveActions.options[0]?.onSelect;
    expect(firstItemOnSelect).toHaveBeenCalledWith(mockProps.selectedRows);
  });

  it("renders correct number of massive actions in the menu", async () => {
    const { user } = render(
      <TranslationProvider locale={mockProps.locale}>
        <Toolbar {...mockProps} />
      </TranslationProvider>
    );

    await user.click(screen.getByText("Selecciona una opción"));
    const items = screen.getAllByRole("menuitem");

    expect(items).toHaveLength(mockProps.massiveActions.options.length);
  });

  it("does not render filters button when filters are not provided", () => {
    const props = { ...mockProps, filters: undefined };
    render(
      <TranslationProvider locale={props.locale}>
        <Toolbar {...props} />
      </TranslationProvider>
    );

    expect(screen.queryByText("Filtros")).not.toBeInTheDocument();
  });
});
