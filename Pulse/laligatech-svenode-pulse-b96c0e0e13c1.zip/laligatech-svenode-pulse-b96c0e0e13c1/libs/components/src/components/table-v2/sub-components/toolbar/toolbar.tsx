import type { ExposedToolbarProps } from "../../table-v2.types";

import * as S from "./toolbar.styled";

import { Button } from "@components/button";
import { ButtonMenu } from "@components/button-menu";
import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";
import { TranslationProvider } from "@providers/translation";
import type { Locale } from "@providers/translation";

type ToolbarProps = ExposedToolbarProps & {
  selectedRows: string[];
  locale: Locale;
  automationContext: string;
};

export function Toolbar(props: ToolbarProps) {
  const {
    massiveActions,
    filters,
    selectedRows,
    automationContext,
    locale /* items */,
  } = props;
  // TODO: add support for custom items
  // TODO: add support for locale (e)

  const automationClasses = automationClass("toolbar", automationContext);

  return (
    <div>
      <TranslationProvider locale={locale}>
        <S.ToolBar className={automationClasses}>
          {massiveActions?.options.length && (
            <S.ButtonMenuContainer>
              <ButtonMenu.Menu
                automationContext="massive actions"
                disabled={selectedRows.length === 0}
                label="Selecciona una opción"
                placement="left"
                variant="outline"
              >
                {massiveActions.options.map(({ text, onSelect }) => (
                  <ButtonMenu.Item
                    key={`item-${text}`}
                    name={text}
                    onClick={() => {
                      onSelect(selectedRows);
                    }}
                  />
                ))}
              </ButtonMenu.Menu>
              <Icon
                fill
                icon="info"
                state="informative"
                tooltipContent="Solamente verás acciones compatibles con los ítems seleccionados"
                tooltipPosition="right"
              />
            </S.ButtonMenuContainer>
          )}
          <S.InputFilterWrapper>
            {filters?.onClick && (
              <Button onPress={filters.onClick} variant="tertiary">
                {`Filtros (${filters.count})`}
              </Button>
            )}
          </S.InputFilterWrapper>
        </S.ToolBar>
      </TranslationProvider>
    </div>
  );
}
