import { useState } from "react";
import type { ExpandedState, PaginationState } from "@tanstack/react-table";
import {
  useReactTable,
  getCoreRowModel,
  getExpandedRowModel,
  getGroupedRowModel,
  getSortedRowModel,
  getPaginationRowModel,
} from "@tanstack/react-table";

import { useColumns } from "./hooks";
import type { TableV2Props } from "./table-v2.types";
import * as S from "./table-v2.styled";
import { TableHeader, TableBody, Toolbar } from "./sub-components";

import { PaginationBar } from "@components/pagination-bar";
import { automationClass } from "@utils/automation-class";

const INFINITE_PAGE_SIZE = 9999;
const DEFAULT_PAGE_SIZE = 10;
const DEFAULT_PAGE_SIZES = [10, 20, 50];

export function TableV2<T extends { subRows?: T[] }>(props: TableV2Props<T>) {
  const {
    automationContext = "",
    data,
    columns: defaultColumns,
    enableColumnSorting = false,
    enableColumnResizing = false,
    enableRowSelection = false,
    enableColumnPinning = false,
    locale = "es-ES",
    disablePagination = false,
    toolbar = {},
    controlled,
    defaultPageSize = DEFAULT_PAGE_SIZE,
    pageSizes = DEFAULT_PAGE_SIZES,
  } = props;

  const hasSubRows = data.some(row => row.subRows);

  const automationClasses = automationClass("table", automationContext);

  const columns = useColumns(defaultColumns, enableRowSelection, hasSubRows);

  // ROW SELECTION
  const [rowSelection, setRowSelection] = useState({});

  // ROW EXPANSION
  const [expanded, setExpanded] = useState<ExpandedState>({});

  // PAGINATION
  const [paginationState, setPaginationState] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: disablePagination ? INFINITE_PAGE_SIZE : defaultPageSize,
  });

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    state: {
      expanded,
      ...(!controlled && { pagination: paginationState }),
      ...(controlled &&
        enableColumnSorting && { sorting: controlled.sortingState }),
      rowSelection,
    },
    getPaginationRowModel: getPaginationRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onExpandedChange: setExpanded,
    getGroupedRowModel: getGroupedRowModel(),
    enableColumnPinning,
    ...(enableColumnResizing && {
      enableColumnResizing,
      columnResizeMode: "onChange",
      columnResizeDirection: "ltr",
    }),
    ...(enableRowSelection && {
      enableRowSelection,
      onRowSelectionChange: setRowSelection,
    }),
    ...(controlled && {
      manualSorting: true,
      onSortingChange: updater => {
        const newSortingState =
          updater instanceof Function ?
            updater(controlled.sortingState ?? [])
          : updater;
        controlled.onSortChange(newSortingState);
      },
      manualPagination: true,
      rowCount: controlled.totalRows,
    }),

    // Row Expansion
    getSubRows: row => {
      const { subRows } = row as T & { subRows: T[] };
      return subRows;
    },
    // debugTable: true,
    // debugHeaders: true,
    // debugColumns: true,
  });

  // Props for toolbar
  const selectedRows = table.getSelectedRowModel().rows.map(row => row.id);
  const showToolbar =
    /* toolbar.items || */ toolbar.filters || toolbar.massiveActions;

  // Pagination props for pagination bar
  const currentPage =
    controlled ?
      props.controlled.currentPage
    : table.getState().pagination.pageIndex + 1;

  const totalItems =
    controlled ? props.controlled.totalRows : table.getRowCount();

  const currentPageSize =
    controlled ?
      props.controlled.pageSize
    : table.getState().pagination.pageSize;

  const onPageChange =
    controlled ?
      props.controlled.onPageChange
    : (pageNumber: number) => {
        setPaginationState(prop => ({ ...prop, pageIndex: pageNumber - 1 }));
      };

  const onPageSizeChange =
    controlled ?
      props.controlled.onPageSizeChange
    : (pageSize: number) => {
        setPaginationState(() => ({ pageSize, pageIndex: 0 }));
      };

  return (
    <S.Table>
      {showToolbar && (
        <S.ToolbarContainer>
          <Toolbar
            automationContext={automationContext}
            filters={toolbar.filters}
            locale={locale}
            massiveActions={toolbar.massiveActions}
            selectedRows={selectedRows}
            // items={toolbar.items}  Pending to implement
          />
        </S.ToolbarContainer>
      )}

      <S.TableBodyContainer>
        <S.TableBody
          $width={table.getCenterTotalSize()}
          className={automationClasses}
        >
          <TableHeader
            enableColumnPinning={enableColumnPinning}
            enableColumnResizing={enableColumnResizing}
            enableColumnSorting={enableColumnSorting}
            table={table}
          />
          <TableBody table={table} />
        </S.TableBody>
      </S.TableBodyContainer>

      {!disablePagination && (
        <S.PaginationContainer>
          <PaginationBar
            automationContext={automationContext}
            currentPage={currentPage}
            currentPageSize={currentPageSize}
            locale={locale}
            onPageChange={onPageChange}
            onPageSizeChange={onPageSizeChange}
            pageSizesList={pageSizes}
            totalItems={totalItems}
          />
        </S.PaginationContainer>
      )}
    </S.Table>
  );
}
