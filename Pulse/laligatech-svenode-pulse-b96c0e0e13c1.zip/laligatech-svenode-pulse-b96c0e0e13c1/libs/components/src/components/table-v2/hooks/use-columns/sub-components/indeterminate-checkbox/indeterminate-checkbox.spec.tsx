import { screen } from "@testing-library/react";

import { IndeterminateCheckbox } from "./indeterminate-checkbox";

import { render } from "@test-utils";

describe("indeterminateCheckbox", () => {
  it("should render properly [default state]", () => {
    render(
      <IndeterminateCheckbox
        checked={false}
        indeterminate={false}
        onChange={jest.fn()}
      />,
      {}
    );
    const checkbox = screen.getByRole("checkbox");
    expect(checkbox).toBeInTheDocument();
    expect(checkbox).not.toBeChecked();
  });

  it("should render as indeterminate when indeterminate prop is true", () => {
    render(
      <IndeterminateCheckbox
        checked={false}
        indeterminate
        onChange={jest.fn()}
      />,
      {}
    );

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion -- needed to access the indeterminate property
    const checkbox = screen.getByRole("checkbox") as HTMLInputElement;
    expect(checkbox).toBeInTheDocument();
    expect(checkbox.indeterminate).toBe(true);
  });

  it("should call onChange when clicked", async () => {
    const handleChange = jest.fn();
    const { user } = render(
      <IndeterminateCheckbox
        checked={false}
        indeterminate={false}
        onChange={handleChange}
      />,
      {}
    );
    const checkbox = screen.getByRole("checkbox");
    await user.click(checkbox);
    expect(handleChange).toHaveBeenCalledTimes(1);
  });

  it("should be disabled when disabled prop is true", () => {
    render(
      <IndeterminateCheckbox
        checked={false}
        disabled
        indeterminate={false}
        onChange={jest.fn()}
      />,
      {}
    );
    const checkbox = screen.getByRole("checkbox");
    expect(checkbox).toBeDisabled();
  });
});
