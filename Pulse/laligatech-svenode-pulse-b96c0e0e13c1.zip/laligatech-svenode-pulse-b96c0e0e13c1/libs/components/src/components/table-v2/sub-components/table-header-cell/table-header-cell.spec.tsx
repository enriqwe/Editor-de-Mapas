import { screen } from "@testing-library/react";
import type {
  ColumnPinningPosition,
  Header,
  SortDirection,
} from "@tanstack/react-table";

import { TableHeaderCell } from "./table-header-cell";

import { render } from "@test-utils";

jest.mock("..", () => ({
  ResizeSeparator: () => <div data-testid="resize-handle" />,
}));

describe("tableHeaderCell", () => {
  let container: HTMLElement;

  beforeEach(() => {
    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const tr = document.createElement("tr");
    container = document.body
      .appendChild(table)
      .appendChild(thead)
      .appendChild(tr);
  });

  const mockHeader = {
    getSize: () => 100,
    column: {
      columnDef: {
        header: "Column1",
        meta: {},
      },
      getCanSort: () => false,
      getIsSorted: () => false,
      getIsPinned: () => false,
      getIsResizing: () => false,
      pin: jest.fn(),
      resetSize: jest.fn(),
    },
    getContext: () => ({}),
    isPlaceholder: false,
    colSpan: 1,
    getResizeHandler: () => jest.fn(),
  } as unknown as Header<{ someProp: string }, unknown>;

  it("should render the table header cell with text", () => {
    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeader}
      />,
      { container }
    );

    const cell = screen.getByTestId("table-header-cell");
    expect(cell).toBeInTheDocument();
  });

  it("should render the table header cell with sorting icon ascending", () => {
    const mockHeaderWithSorting = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getCanSort: () => true,
        getIsSorted: () => "asc" as SortDirection,
        getToggleSortingHandler: () => jest.fn(),
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting
        header={mockHeaderWithSorting}
      />,
      { container }
    );

    const button = screen.getByTestId("sort-button");
    expect(button).toBeInTheDocument();

    const icon = screen.getByText("arrow_upward");
    expect(icon).toBeInTheDocument();
  });

  it("should render the table header cell with sorting icon descending", () => {
    const mockHeaderWithSorting = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getCanSort: () => true,
        getIsSorted: () => "desc" as SortDirection,
        getToggleSortingHandler: () => jest.fn(),
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting
        header={mockHeaderWithSorting}
      />,
      { container }
    );

    const button = screen.getByTestId("sort-button");
    expect(button).toBeInTheDocument();

    const icon = screen.getByText("arrow_downward");
    expect(icon).toBeInTheDocument();
  });

  it("should render the table header cell with sorting icon not sorted", () => {
    const mockHeaderWithSorting = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getCanSort: () => true,
        // getIsSorted: () => false as false,
        getToggleSortingHandler: () => jest.fn(),
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting
        header={mockHeaderWithSorting}
      />,
      { container }
    );

    const button = screen.getByTestId("sort-button");
    expect(button).toBeInTheDocument();

    const icon = screen.getByText("sync_alt");
    expect(icon).toBeInTheDocument();
  });

  it("should not render sorting click zone when placeholder is enabled", () => {
    const mockHeaderWithSorting = {
      ...mockHeader,
      isPlaceholder: true,
      column: {
        ...mockHeader.column,
        getCanSort: () => true,
        getToggleSortingHandler: () => jest.fn(),
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithSorting}
      />,
      { container }
    );

    const button = screen.queryByText("Column1");
    expect(button).not.toBeInTheDocument();
  });

  it("should not render sorting button, just text, when sorting is disabled", () => {
    const mockHeaderWithSorting = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getCanSort: () => false,
        getToggleSortingHandler: () => jest.fn(),
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithSorting}
      />,
      { container }
    );

    const button = screen.queryByTestId("sort-button");
    expect(button).not.toBeInTheDocument();

    const text = screen.getByText("Column1");
    expect(text).toBeInTheDocument();
  });

  it("should render the table header cell with pinning button", () => {
    const mockHeaderWithPinning = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsPinned: () => false as ColumnPinningPosition,
        columnDef: {
          accessorFn: jest.fn(),
          id: "test-column",
        },
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithPinning}
      />,
      { container }
    );

    const pinningButton = screen.getByText("keep");
    expect(pinningButton).toBeInTheDocument();
  });

  it("should render the table header cell with pinning button active", () => {
    const mockHeaderWithPinning = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsPinned: () => "left" as ColumnPinningPosition,
        getStart: () => 10,
        getIsLastColumn: () => false,
        columnDef: {
          accessorFn: jest.fn(),
          id: "test-column",
        },
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithPinning}
      />,
      { container }
    );

    const pinningButton = screen.getByText("keep_off");
    expect(pinningButton).toBeInTheDocument();
  });

  it("should not render pinning button when pinning is disabled", () => {
    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeader}
      />,
      { container }
    );

    const pinningButton = screen.queryByText("keep");
    expect(pinningButton).not.toBeInTheDocument();
  });

  it("should not render pinning button when pinning is fixed", () => {
    const mockHeaderWithPinning = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsPinned: () => "left" as ColumnPinningPosition,
        getStart: () => 10,
        getIsLastColumn: () => false,
        columnDef: {
          meta: { pinned: "left" as "left" | "right" },
          accessorFn: jest.fn(),
          id: "test-column",
        },
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithPinning}
      />,
      { container }
    );

    const pinningButtonActive = screen.queryByText("keep");
    expect(pinningButtonActive).not.toBeInTheDocument();

    const pinningButtonInactive = screen.queryByText("keep_off");
    expect(pinningButtonInactive).not.toBeInTheDocument();
  });

  it("should render the table header cell with resizing button", () => {
    const mockHeaderWithResizing = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsResizing: () => false,
      },
    };

    render(
      <TableHeaderCell
        enableColumnPinning={false}
        enableColumnResizing
        enableColumnSorting={false}
        header={mockHeaderWithResizing}
      />,
      { container }
    );

    const resizingButton = screen.getByTestId("resize-handle");
    expect(resizingButton).toBeInTheDocument();
  });

  it("should call pin method when pinning button is clicked and column is not pinned", async () => {
    const mockHeaderWithPinning = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsPinned: () => false as ColumnPinningPosition,
        columnDef: {
          accessorFn: jest.fn(),
          id: "test-column",
        },
        pin: jest.fn(),
      },
    };

    const { user } = render(
      <TableHeaderCell
        enableColumnPinning
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithPinning}
      />,
      { container }
    );

    const pinningButton = screen.getByText("keep");
    await user.click(pinningButton);

    expect(mockHeaderWithPinning.column.pin).toHaveBeenCalledWith("left");
  });

  it("should call pin method when pinning button is clicked and column is pinned", async () => {
    const mockHeaderWithPinning = {
      ...mockHeader,
      column: {
        ...mockHeader.column,
        getIsLastColumn: () => false,
        getIsFirstColumn: () => false,
        getAfter: () => 0,
        getStart: () => 0,
        getIsPinned: () => "left" as ColumnPinningPosition,
        columnDef: {
          accessorFn: jest.fn(),
          id: "test-column",
        },
        pin: jest.fn(),
      },
    };

    const { user } = render(
      <TableHeaderCell
        enableColumnPinning
        enableColumnResizing={false}
        enableColumnSorting={false}
        header={mockHeaderWithPinning}
      />,
      { container }
    );

    const pinningButton = screen.getByText("keep_off");
    await user.click(pinningButton);

    expect(mockHeaderWithPinning.column.pin).toHaveBeenCalledWith(false);
  });
});
