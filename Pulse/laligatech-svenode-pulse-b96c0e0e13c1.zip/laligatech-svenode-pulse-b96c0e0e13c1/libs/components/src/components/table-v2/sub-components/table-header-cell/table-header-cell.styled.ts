import styled from "styled-components";
import type { Column } from "@tanstack/react-table";

import { commonPinningStyles } from "../../table-v2.styled";

export const HeaderCell = styled.th<{
  $width?: number;
  $column: Column<unknown>;
}>`
  padding: ${({ theme }) => theme.spacing.x12};
  height: 30px;
  background: ${({ theme }) => theme.color.bgTableThead};
  position: relative;
  white-space: nowrap;
  width: ${({ $width }) => `${$width}px`};
  ${({ $column }) => commonPinningStyles($column)}
`;

export const SortButton = styled.button`
  background: none;
  color: inherit;
  border: none;
  padding: 0;
  font: inherit;
  cursor: pointer;
  outline: inherit;
`;
