import { useState, useEffect } from "react";
import type { ColumnDef } from "@tanstack/react-table";

import { IndeterminateCheckbox } from "./sub-components/indeterminate-checkbox";

import { IconButton } from "@components/icon-button";

export function useColumns<T, K>(
  defaultColumns: ColumnDef<T, K>[],
  enableRowSelection: boolean,
  hasSubRows: boolean
) {
  const [columns, setColumns] = useState(defaultColumns);

  useEffect(() => {
    const newColumns: ColumnDef<T, K>[] = [];
    if (hasSubRows) {
      newColumns.push({
        id: "expand",
        header: () => null,
        cell: ({ row }) => {
          return row.getCanExpand() ?
              <div style={{ paddingLeft: `${row.depth * 2}rem` }}>
                <IconButton
                  iconName={row.getIsExpanded() ? "expand_less" : "expand_more"}
                  onPress={row.getToggleExpandedHandler()}
                />
              </div>
            : "";
        },
      });
    }
    if (enableRowSelection) {
      newColumns.push({
        id: "select",
        header: ({ table }) => (
          <IndeterminateCheckbox
            checked={table.getIsAllRowsSelected()}
            indeterminate={table.getIsSomeRowsSelected()}
            onChange={table.getToggleAllRowsSelectedHandler()}
          />
        ),
        cell: ({ row }) => (
          <IndeterminateCheckbox
            checked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            indeterminate={row.getIsSomeSelected()}
            onChange={row.getToggleSelectedHandler()}
          />
        ),
      });
    }
    setColumns([...newColumns, ...defaultColumns]);
  }, [defaultColumns, enableRowSelection, hasSubRows]);

  return columns;
}
