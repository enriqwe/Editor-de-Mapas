import styled from "styled-components";
import type { Column } from "@tanstack/react-table";

import { commonPinningStyles } from "../../table-v2.styled";

export const BodyCell = styled.td<{
  $width: number;
  $column: Column<unknown>;
  $isExpandCell: boolean;
  $expanded: boolean;
}>`
  position: relative;
  border-bottom: 1px solid ${({ theme }) => theme.color.border.box};
  padding: ${({ theme }) => theme.spacing.x12};
  background: ${({ theme }) => theme.color.bgTableTbody};
  /* border-left: ${({ $expanded, theme }) =>
    $expanded ?
      `4px solid ${theme.color.borderDefault}`
    : "4px solid white"}; */
  width: ${({ $width, $isExpandCell }) =>
    $isExpandCell ? "auto" : `${$width}px`};
  ${({ $column }) => commonPinningStyles($column)}
`;
