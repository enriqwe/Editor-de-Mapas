import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

import type { AvatarVariant, AvatarSize } from "./avatar.types";

const sizeValues = { s: 24, m: 32, l: 44 };

export const Avatar = styled.div<{
  size: AvatarSize;
  $variant: AvatarVariant;
  src?: string | undefined;
}>`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: ${cssVars.border.radiusCircle};
  overflow: hidden;
  user-select: none;
  height: ${({ size }) => sizeValues[size]}px;
  width: ${({ size }) => sizeValues[size]}px;
  font: ${({ size }) => {
    switch (size) {
      case "s":
        return cssVars.text.bodySmallBold;
      case "m":
        return cssVars.text.bodyMediumBold;
      case "l":
        return cssVars.text.heading6Bold;
    }
  }};
  background-color: ${({ $variant }) =>
    $variant === "topbar" ?
      cssVars.color.bgNavbarAvatarDefault
    : cssVars.color.bgPrimary};
  text-align: center;
  color: ${cssVars.color.textBody};

  svg {
    & path {
      fill: ${cssVars.color.iconDefault};
    }
  }
`;
