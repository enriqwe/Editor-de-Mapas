import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import { PublicAvatar as Avatar } from "./avatar";

import { render } from "@test-utils";

describe("avatar", () => {
  expect.extend(toHaveNoViolations);
  it("should render successfully", async () => {
    const { container } = render(<Avatar />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    expect(container).toBeTruthy();
  });

  it("should render the image when an image is passed in", async () => {
    const imageSrc = "https://example.com/avatar.jpg";
    const { container } = render(<Avatar src={imageSrc} />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    const image = screen.getByAltText("Avatar");
    expect(image).toHaveAttribute("src");
    expect(image.getAttribute("src")).toEqual(imageSrc);
  });

  it("should render one letter when a name is passed in", () => {
    const userName = "user name";
    render(<Avatar name={userName} />);
    const avatarLetter = screen.getByText("U");
    expect(avatarLetter).toHaveTextContent(/^.$/);
    expect(avatarLetter.textContent).toHaveLength(1);
  });

  it("should render user icon when name and url are not passed in", () => {
    render(<Avatar />);
    const avatar = screen.getByTestId("icon");
    expect(avatar).toContainHTML("<svg");
  });
});
