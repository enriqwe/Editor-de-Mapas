import styled from "styled-components";

export const Root = styled.div`
  display: flex;
  flex-direction: column;

  input::placeholder {
    color: ${({ theme }) => theme.color.textPlaceholder};
  }
`;

export const InputContainer = styled.div<{ width?: string }>`
  position: relative;
  width: 100%;
  box-sizing: border-box;
  & * {
    box-sizing: border-box;
  }
`;

export const Input = styled.input<{
  $isError?: boolean;
  disabled?: boolean;
}>`
  width: 100%;
  height: 44px;
  border-radius: ${({ theme }) => theme.border.radiusS};
  padding: ${({ theme }) => `${theme.spacing.x8} ${theme.spacing.x12}`};
  ${({ theme }) => theme.text.bodyBaseRegular};

  color: ${({ theme }) => theme.color.textBody};
  background: ${({ theme }) => theme.color.surfacePrimary};

  border-style: solid;
  border-width: ${({ theme }) => theme.border.widthXS};
  border-color: ${({ theme }) => theme.color.borderFormControlDefault};

  &:hover:not(:disabled) {
    border-color: ${({ theme }) => theme.color.borderFormControlHover};
    box-shadow: inset 0 0 0 1px
      ${({ theme }) => theme.color.borderFormControlHover};
  }

  &:focus:not(:disabled) {
    border-color: ${({ theme }) => theme.color.borderFocus};
    box-shadow: inset 0 0 0 1px ${({ theme }) => theme.color.borderFocus};
  }

  &:disabled {
    cursor: not-allowed;
    color: ${({ theme }) => theme.color.textDisabled};
    border-color: ${({ theme }) => theme.color.borderDisabled};
    background: ${({ theme }) => theme.color.bgDisabled};
  }

  ${({ $isError, disabled, theme }) =>
    $isError &&
    !disabled && {
      borderColor: theme.color.borderError,
      boxShadow: `inset 0 0 0 1px ${theme.color.borderError}`,
    }}
`;

export const InputIconContainer = styled.div`
  position: absolute;
  top: ${({ theme }) => theme.spacing.x6};
  right: ${({ theme }) => theme.spacing.x12};
  cursor: pointer;
`;

export const HelperText = styled.p<{ $isError?: boolean; $disabled?: boolean }>`
  display: flex;
  align-items: center;

  box-sizing: border-box;

  gap: ${({ theme }) => theme.spacing.x4};

  ${({ theme }) => theme.text.bodySmallRegular};

  margin-top: ${({ theme }) => theme.spacing.x8};
  color: ${({ $isError, $disabled, theme }) => {
    if ($disabled) {
      return theme.color.textDisabled;
    } else if ($isError) {
      return theme.color.textError;
    }
    return theme.color.textHelpertext;
  }};
`;
