import type { ReactNode } from "react";
import { useRef } from "react";
import type { AriaModalOverlayProps } from "react-aria";
import { Overlay, useModalOverlay } from "react-aria";
import type { OverlayTriggerState } from "react-stately";

import * as S from "./modal.styled";

import { automationClass } from "@utils/automation-class";

export type ModalProps = {
  state: OverlayTriggerState;
  children: ReactNode;
  automationContext?: string;
  type?: "short" | "medium" | "large";
} & AriaModalOverlayProps;

export function Modal({
  state,
  children,
  automationContext,
  type = "short",
  isDismissable = false,
  isKeyboardDismissDisabled = false,
  shouldCloseOnInteractOutside,
}: ModalProps) {
  const modalRef = useRef(null);
  const { modalProps, underlayProps } = useModalOverlay(
    { isDismissable, isKeyboardDismissDisabled, shouldCloseOnInteractOutside },
    state,
    modalRef
  );

  const automationClasses = automationClass("modal", automationContext);

  return (
    <Overlay>
      <S.Underlay {...underlayProps}>
        <S.Modal
          className={automationClasses}
          {...modalProps}
          ref={modalRef}
          type={type}
        >
          {children}
        </S.Modal>
      </S.Underlay>
    </Overlay>
  );
}
