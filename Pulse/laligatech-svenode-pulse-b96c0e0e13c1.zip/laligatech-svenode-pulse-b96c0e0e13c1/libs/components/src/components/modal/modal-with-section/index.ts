import type {
  BodyProps,
  FooterProps,
  HeaderProps,
} from "./modal-with-section.types";

export type ModalWithSectionProps = {
  Body: BodyProps;
  Footer: FooterProps;
  Header: HeaderProps;
};

export { ModalWithSection } from "./modal-with-section";
