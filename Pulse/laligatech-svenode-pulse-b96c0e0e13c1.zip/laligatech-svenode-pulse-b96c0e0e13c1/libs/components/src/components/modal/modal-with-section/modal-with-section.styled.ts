import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const ModalFooter = styled.footer`
  display: flex;
  justify-content: flex-start;
  flex-direction: row-reverse;
  gap: ${cssVars.spacing.x16};
  padding-top: ${cssVars.spacing.x24};
`;

export const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  border: none;
`;

export const Title = styled.h1`
  font: ${cssVars.text.heading6Bold};
  color: ${cssVars.color.textHeading};
  margin: 0;
`;

export const ModalBody = styled.div`
  overflow: auto;
  margin: ${cssVars.spacing.x12} 0;
`;
export const ModalDescription = styled.p`
  margin: ${cssVars.spacing.x12} 0 0;
  font: ${cssVars.text.bodyMediumRegular};
  color: ${cssVars.color.textSubheading};
`;
