export { ModalTrigger } from "./modal-trigger";
export type { ModalTriggerProps } from "./modal-trigger";
