import * as S from "./modal-with-section.styled";
import type {
  BodyProps,
  FooterProps,
  HeaderProps,
} from "./modal-with-section.types";

import { Button } from "@components/button";
import { IconButton } from "@components/icon-button";

function Header({ title, closeHandler, description }: HeaderProps) {
  return (
    <>
      <S.ModalHeader>
        <S.Title aria-label={title}>{title}</S.Title>
        {closeHandler && (
          <IconButton
            data-testid="close"
            iconName="close"
            onPress={closeHandler}
          />
        )}
      </S.ModalHeader>
      {description && <S.ModalDescription>{description}</S.ModalDescription>}
    </>
  );
}

function Footer({ actions }: FooterProps) {
  return (
    <S.ModalFooter>
      {actions.map(action => {
        return (
          <Button
            isDisabled={action.buttonDisabled}
            key={`btn_${action.buttonLabel}`}
            onPress={action.clickHandler}
            type={action.buttonType ?? "button"}
            variant={action.buttonVariant}
          >
            {action.buttonLabel}
          </Button>
        );
      })}
    </S.ModalFooter>
  );
}

function Body({ children }: BodyProps) {
  return <S.ModalBody>{children}</S.ModalBody>;
}

export const ModalWithSection = {
  Header,
  Body,
  Footer,
};
