import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const RadioItem = styled.label<{
  $disabled: boolean;
  $iconLeftAlign: boolean;
}>`
  word-break: break-word;
  display: inline-flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
  color: ${({ $disabled }) =>
    $disabled ?
      cssVars.color.textDisabled
    : cssVars.color.textLabel};
  flex-direction: ${({ $iconLeftAlign }) => $iconLeftAlign ? "row" : "row-reverse"};
  font: ${cssVars.text.bodyBaseRegular};
  letter-spacing: 0.02em;
  cursor: ${({$disabled}) => $disabled ? "revert" : "pointer"};
`;

export const RadioGroupTitle = styled.label`
  display: flex;
  align-items: center;
  margin-top: ${cssVars.spacing.x8};
  margin-bottom: ${cssVars.spacing.x8};
  word-break: break-word;
  user-select: none;
  color: ${cssVars.color.textBody};
  gap: ${cssVars.spacing.x4};
  font: ${cssVars.text.bodyBaseSemiBold};
  font-style: normal;
`;

export const RadioGroup = styled.div`
  display: flex;
  flex-direction: column;
  user-select: none;
`;

export const RadioItemContainer = styled.div<{ $column: boolean }>`
  display: flex;
  flex-direction: ${({ $column }) => ($column ? "column" : "row")};
  gap: ${({ $column }) => $column ? cssVars.spacing.x8 : cssVars.spacing.x16};
`;
