import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import { Radio } from "./radio";

import { render } from "@test-utils";

function RenderRadioGroupTest({ isDisabled }: { isDisabled?: boolean }) {
  return (
    <Radio.Group isDisabled={isDisabled} label="Favorite sports">
      <Radio.Item value="soccer">Soccer</Radio.Item>
      <Radio.Item value="baseball">Baseball</Radio.Item>
      <Radio.Item isDisabled={isDisabled} value="basketball">
        Basketball
      </Radio.Item>
    </Radio.Group>
  );
}

describe("radio", () => {
  expect.extend(toHaveNoViolations);
  it("should render properly [default state]", async () => {
    const { container } = render(<RenderRadioGroupTest />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    expect(screen.getByText("Soccer")).toBeTruthy();
    expect(screen.getByText("Baseball")).toBeTruthy();
    expect(screen.getByText("Basketball")).toBeTruthy();
  });

  it("should mark has checked the correct radio", async () => {
    const { user } = render(<RenderRadioGroupTest />);
    const radio = screen.getByRole("radio", { name: "Baseball" });

    await user.click(radio);
    expect(radio).toBeChecked();
  });

  it("should not check when checkbox is disabled", async () => {
    const { user } = render(<RenderRadioGroupTest isDisabled />);
    const radio = screen.getByRole("radio", { name: "Basketball" });

    await user.click(radio);
    expect(radio).not.toBeChecked();

    expect(radio).toBeDisabled();
  });
});
