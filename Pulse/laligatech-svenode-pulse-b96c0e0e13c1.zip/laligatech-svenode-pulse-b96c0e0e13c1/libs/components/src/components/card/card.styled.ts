import styled from "styled-components";

export const Card = styled.div`
  padding: 20px;
  border: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.borderDefault}`};
  border-radius: ${({ theme }) => theme.border.radiusM};
  box-sizing: border-box;
  background-color: ${({ theme }) => theme.color.surfacePrimary};
`;

export const Header = styled.div`
  display: flex;
  flex-direction: row;
  align-items: start;
  gap: 8px;
`;

export const TextContainer = styled.div`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`;

export const Title = styled.p`
  color: ${({ theme }) => theme.color.textHeading};
  ${({ theme }) => theme.text.heading6Bold};
  margin: 0;
`;

export const Description = styled.p`
  color: ${({ theme }) => theme.color.textSubheading};
  ${({ theme }) => theme.text.bodyMediumRegular};
  margin: 0;
`;

export const Actions = styled.div`
  display: flex;
  flex-direction: row;
  gap: 8px;
  margin-top: -4px;
  margin-left: 8px;
`;

export const Content = styled.div`
  margin-top: 16px;
`;
