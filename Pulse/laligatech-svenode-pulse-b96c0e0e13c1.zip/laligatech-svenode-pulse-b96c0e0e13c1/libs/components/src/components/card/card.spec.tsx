import { screen } from "@testing-library/react";

import { Card } from "./card";
import type { CardProps } from "./card.types";

import { render } from "@test-utils";

const actions = [
  {
    iconName: "house",
    tooltipContent: "tooltip text",
    onClick: jest.fn(),
    disabled: false,
    automationContext: "house-icon-button",
  },
  {
    iconName: "settings",
    tooltipContent: "tooltip text",
    onClick: jest.fn(),
    disabled: false,
    automationContext: "settings-icon-button",
  },
];

describe("card", () => {
  const tag = {
    label: "STATE",
    variant: "informative",
    automationContext: "informative",
  } as CardProps["tag"];

  it("should render successfully with required props only", () => {
    const { container } = render(
      <Card actions={actions} tag={tag} title="title" />
    );

    expect(container).toBeTruthy();

    expect(screen.getByText(/title/i)).toBeInTheDocument(); // title

    const actionsContainer = screen.getByTestId("actions-container");

    expect(screen.queryAllByRole("button").length).toEqual(2); // icons (buttons)
    expect(actionsContainer.querySelectorAll("button")[0]).toHaveTextContent(
      "house"
    );
    expect(screen.getByText(/settings/i)).toBeInTheDocument();
  });

  it("should render successfully with optional props", () => {
    render(
      <Card
        actions={actions}
        description="description"
        icon="edit"
        tag={{
          label: "STATE",
          variant: "informative",
          automationContext: "informative",
        }}
        title="title"
      >
        <p>Test content</p>
      </Card>
    );

    expect(screen.getByText(/description/i)).toBeInTheDocument(); // description
    expect(screen.getByText(/edit/i)).toBeInTheDocument(); // icon
  });

  it("should not render tag if not set", () => {
    render(
      <Card
        actions={actions}
        description="description"
        icon="edit"
        title="title"
      >
        <p>Test content</p>
      </Card>
    );

    const tagElement = screen.queryByTestId("static-tag");

    expect(tagElement).toBeNull();
  });

  it("should not render actions if not set", () => {
    render(
      <Card
        description="description"
        icon="edit"
        tag={{
          label: "STATE",
          variant: "informative",
          automationContext: "informative",
        }}
        title="title"
      >
        <p>Test content</p>
      </Card>
    );

    const actionsElement = screen.queryByTestId("actions-container");

    expect(actionsElement).toBeNull();
  });
});
