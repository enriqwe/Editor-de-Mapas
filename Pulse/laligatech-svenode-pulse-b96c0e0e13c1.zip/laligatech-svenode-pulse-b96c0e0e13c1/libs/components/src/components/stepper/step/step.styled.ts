import styled, { css } from "styled-components";

import type { StepperContainerProps } from "../stepper.types";

export const WrapperStep = styled.div<{
  $selected?: boolean;
  $isLastItem?: boolean;
  $error?: boolean;
  $orientation: StepperContainerProps["orientation"];
}>`
  ${({ $orientation }) =>
    $orientation === "horizontal" ?
      css`
        display: grid;
        grid-template-columns: max-content auto;
        grid-template-rows: auto;
        align-items: center;
      `
    : css`
        display: flex;
        flex-direction: column;
        align-items: flex-start;
      `}

  font-family: ${({ theme }) => theme.font.fontFamily};
  flex: ${({ $isLastItem }) => (!$isLastItem ? "1" : "0")};
  color: ${({ theme }) => theme.color.text.stepper.inactive};

  ${({ theme, $selected }) =>
    $selected &&
    css`
      color: ${theme.color.text.stepper.active};
    `}

  ${({ theme, $error }) =>
    $error &&
    css`
      color: ${theme.color.text.stepper.error};
    `}
`;

export const StepContent = styled.div<{
  $selected: boolean;
  $error: boolean;
  $completed: boolean;
}>`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x8};
  padding: ${({ theme }) => theme.spacing.x8};
  border-radius: ${({ theme }) => theme.border.radiusS};

  ${({ $selected, $error, $completed }) =>
    ($selected || $error || $completed) &&
    css`
      &:hover {
        background: ${({ theme }) => theme.color.background.stepper.hover};
      }
    `}
`;

export const StepIndicator = styled.div<{
  $selected: boolean;
  $error: boolean;
  $completed: boolean;
}>`
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: ${({ theme }) => theme.font.weights.bold};
  height: ${({ theme }) => theme.spacing.x32};
  width: ${({ theme }) => theme.spacing.x32};
  box-sizing: border-box;
  border-radius: ${({ theme }) => theme.border.radiusCircle};
  color: ${({ theme }) => theme.color.text.stepper.indicator.inactive};
  background: ${({ theme }) =>
    theme.color.background.stepper.indicator.inactive};
  ${({ theme }) => theme.font.sizes.xl};

  ${({ theme, $selected }) =>
    $selected &&
    css`
      background: ${theme.color.background.stepper.indicator.active};
      color: ${theme.color.text.stepper.indicator.active};
    `}

  ${({ theme, $completed }) =>
    $completed &&
    css`
      background: ${theme.color.background.stepper.indicator.completed};
      color: ${theme.color.text.stepper.indicator.completed};
    `}

  ${({ theme, $error }) =>
    $error &&
    css`
      background: ${theme.color.background.stepper.indicator.error};
      color: ${theme.color.text.stepper.indicator.error};
    `}
`;

export const WrapperText = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

export const StepperLabel = styled.label<{
  $completed: boolean;
  $error: boolean;
  $editable: boolean;
}>`
  font-weight: ${({ theme }) => theme.font.weights.bold};
  ${({ theme }) => theme.font.sizes.sm};

  ${({ theme, $completed }) =>
    $completed &&
    css`
      color: ${theme.color.text.stepper.completed};
    `}
  ${({ theme, $completed, $editable }) =>
    $completed &&
    $editable &&
    css`
      color: ${theme.color.text.stepper.editable};
    `}
  ${({ theme, $error }) =>
    $error &&
    css`
      color: ${theme.color.text.stepper.error};
    `}
`;

export const HelperText = styled.span`
  ${({ theme }) => theme.font.sizes.xs};
`;

export const DividingLine = styled.div<{
  $completed: boolean;
  $error: boolean;
  $orientation: StepperContainerProps["orientation"];
}>`
  ${({ $orientation }) =>
    $orientation === "horizontal" ?
      css`
        height: 1px;
        width: auto;
        margin-left: ${({ theme }) => theme.spacing.x8};
        margin-right: ${({ theme }) => theme.spacing.x8};
      `
    : css`
        height: auto;
        width: 1px;
        margin: 0 auto;
      `}

  background: ${({ theme }) =>
    theme.color.background.stepper.dividingLine.default};
  ${({ theme, $completed }) =>
    $completed &&
    css`
      background: ${theme.color.background.stepper.dividingLine.completed};
    `}
  ${({ theme, $completed, $error }) =>
    $completed &&
    $error &&
    css`
      background: ${theme.color.background.stepper.dividingLine.error};
    `}
`;

export const ContentPanel = styled.div`
  display: grid;
  grid-template-columns: ${({ theme }) => theme.spacing.x32} auto;
  padding: ${({ theme }) => theme.spacing.x8};
`;
