import { screen } from "@testing-library/react";

import { Stepper } from "./stepper";

import { render } from "@test-utils";

const { Container, Step } = Stepper;
describe("stepper", () => {
  it("should render horizontal orientation properly", () => {
    render(
      <Container orientation="horizontal" selectedKey="step1">
        <Step key="step1" title="Stepper label 1">
          Step content 1
        </Step>
        <Step key="step2" title="Stepper label 2">
          Step content 2
        </Step>
        <Step key="step3" title="Stepper label 3">
          Step content 3
        </Step>
      </Container>
    );

    const step1 = screen.getByText(/Stepper label 1/i);
    const step1Content = screen.getByText(/Stepper label 1/i);
    const step2 = screen.getByText(/Stepper label 2/i);
    const step3 = screen.getByText(/Stepper label 3/i);

    expect(step1).toBeInTheDocument();
    expect(step1Content).toBeInTheDocument();
    expect(step2).toBeInTheDocument();
    expect(step3).toBeInTheDocument();
  });

  it("should render vertical orientation properly", () => {
    render(
      <Container orientation="vertical">
        <Step key="step1" title="Stepper label 1">
          Step content 1
        </Step>
        <Step key="step2" title="Stepper label 2">
          Step content 2
        </Step>
        <Step key="step3" title="Stepper label 3">
          Step content 3
        </Step>
      </Container>
    );

    const step1 = screen.getByText(/Stepper label 1/i);
    const step1Content = screen.getByText(/Stepper label 1/i);
    const step2 = screen.getByText(/Stepper label 2/i);
    const step3 = screen.getByText(/Stepper label 3/i);

    expect(step1).toBeInTheDocument();
    expect(step1Content).toBeInTheDocument();
    expect(step2).toBeInTheDocument();
    expect(step3).toBeInTheDocument();
  });

  it("should render helper text when is passed", () => {
    render(
      <Container orientation="horizontal">
        <Step key="step1" title="Stepper label 1">
          Step content 1
        </Step>
        <Step helperText="Optional" key="step2" title="Stepper label 2">
          Step 2 with helper text
        </Step>
        <Step key="step3" title="Stepper label 3">
          Step content 3
        </Step>
      </Container>
    );

    const step2 = screen.getByText(/Stepper label 2/i);
    const step2Optional = screen.getByText(/Optional/i);

    expect(step2).toBeInTheDocument();
    expect(step2Optional).toBeInTheDocument();
  });

  it("should render the content of the selected element", () => {
    render(
      <Container orientation="vertical" selectedKey="step2">
        <Step key="step1" title="Stepper label 1">
          Step content 1
        </Step>
        <Step key="step2" title="Stepper label 2">
          Step selected
        </Step>
        <Step key="step3" title="Stepper label 3">
          Step content 3
        </Step>
      </Container>
    );

    const step1 = screen.getByText(/Stepper label 1/i);
    const step2 = screen.getByText(/Stepper label 2/i);
    const step2Content = screen.getByText(/Step selected/i);
    const step3 = screen.getByText(/Stepper label 3/i);

    expect(step1).toBeInTheDocument();
    expect(step2).toBeInTheDocument();
    expect(step2Content).toBeInTheDocument();
    expect(step3).toBeInTheDocument();
  });
});
