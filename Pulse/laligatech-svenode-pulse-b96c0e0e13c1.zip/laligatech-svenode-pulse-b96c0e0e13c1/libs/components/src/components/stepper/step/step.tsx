import { useTab } from "react-aria";
import { useRef } from "react";
import type { JSX } from "react";

import { StepContentPanel } from "../step-content-panel";
import type { StepperItemProps } from "../stepper.types";

import * as S from "./step.styled";

import { Icon } from "@components/icon";

export function Step(props: StepperItemProps) {
  const {
    item,
    stepListState,
    selected = false,
    helperText,
    indicator,
    isLastItem,
    completed,
    editable = false,
    error = false,
    orientation = "horizontal",
  } = props;
  const { key, rendered } = item;
  const ref = useRef(null);

  const { tabProps } = useTab({ key }, stepListState, ref);

  let indicatorIcon: number | JSX.Element = indicator;
  if (error) {
    indicatorIcon = <Icon color="inherit" icon="error" size="s" />;
  } else if (completed) {
    indicatorIcon = <Icon color="inherit" icon="check" size="s" />;
  }

  return (
    <S.WrapperStep
      $error={error}
      $isLastItem={isLastItem}
      $orientation={orientation}
      $selected={selected}
      ref={ref}
      {...tabProps}
    >
      <S.StepContent $completed={completed} $error={error} $selected={selected}>
        <S.StepIndicator
          $completed={completed}
          $error={error}
          $selected={selected}
        >
          {indicatorIcon}
        </S.StepIndicator>
        <S.WrapperText>
          <S.StepperLabel
            $completed={completed}
            $editable={editable}
            $error={error}
          >
            {rendered}
          </S.StepperLabel>
          {helperText && <S.HelperText>{helperText}</S.HelperText>}
        </S.WrapperText>
      </S.StepContent>
      {orientation === "horizontal" ?
        <S.DividingLine
          $completed={completed}
          $error={error}
          $orientation={orientation}
        />
      : <S.ContentPanel>
          <S.DividingLine
            $completed={completed}
            $error={error}
            $orientation={orientation}
          />
          {selected && (
            <StepContentPanel
              key={stepListState.selectedItem?.key}
              stepListState={stepListState}
            />
          )}
        </S.ContentPanel>
      }
    </S.WrapperStep>
  );
}
