import type { AriaTabListProps, AriaTabProps } from "react-aria";
import type { TabListState, Node } from "react-stately";

export type Orientation = "horizontal" | "vertical";

export type StepperContainerProps = AriaTabListProps<AriaTabProps> & {
  /** @deprecated use selectedKey instead, with the corresponding key value (not step number) */
  stepSelected?: number;
  orientation?: Orientation;
  automationContext?: string;
};

export type StepListStateProps = {
  stepListState: TabListState<AriaTabProps>;
};

export type StepperItemProps = AriaTabProps &
  StepListStateProps & {
    completed: boolean;
    indicator: number;
    item: Node<AriaTabProps>;
    orientation: Orientation;
    selected: boolean;
    isLastItem: boolean;
    /** A boolean that indicates whether an error has occurred in the current step. */
    error?: boolean;
    /** A boolean that indicates whether current step can be edited. */
    editable?: boolean;
    /** A string that will provide additional information to the Stepper label. */
    helperText?: string;
  };
