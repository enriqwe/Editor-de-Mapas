import { lazy, Suspense } from "react";

import * as S from "./empty-state.styled";
import type { EmptyStateProps } from "./empty-state.types";

import { automationClass } from "@utils/automation-class";
import { Button } from "@components/button";

const illustrationMap = {
  Bank: () => import("./assets/bank"),
  Beach: () => import("./assets/beach"),
  BillBoard: () => import("./assets/bill-board"),
  Calendar: () => import("./assets/calendar"),
  Computer: () => import("./assets/computer"),
  Crane: () => import("./assets/crane"),
  Date: () => import("./assets/date"),
  Document: () => import("./assets/document"),
  Dollar: () => import("./assets/dollar"),
  Drink: () => import("./assets/drink"),
  Home: () => import("./assets/home"),
  Home2: () => import("./assets/home2"),
  Image: () => import("./assets/image"),
  Mountain: () => import("./assets/mountain"),
  NoResultsFound: () => import("./assets/no-results-found"),
  NothingHere: () => import("./assets/nothing-here"),
  PiggyBank: () => import("./assets/piggy-bank"),
  PlayVideo: () => import("./assets/play-video"),
  Search: () => import("./assets/search"),
  SearchError: () => import("./assets/search-error"),
  Shopping: () => import("./assets/shopping"),
  Stadium: () => import("./assets/stadium"),
  Stand: () => import("./assets/stand"),
  Tags: () => import("./assets/tags"),
  ToDo: () => import("./assets/to-do"),
  Welcome: () => import("./assets/welcome"),
};

export function EmptyState({
  title,
  subTitle,
  illustrationName,
  automationContext,
  actionLabel,
  actionType = "secondary",
  actionHandler,
  size = "l",
}: EmptyStateProps) {
  const automationClasses = automationClass("emptyState", automationContext);

  const LazyIllustration =
    illustrationName ? lazy(illustrationMap[illustrationName]) : null;

  return (
    <S.EmptyState $size={size} className={automationClasses}>
      {LazyIllustration && (
        <S.ImageWrapper $size={size} aria-hidden="true">
          <Suspense>
            <S.IllustrationWrapper $size={size}>
              <LazyIllustration />
            </S.IllustrationWrapper>
          </Suspense>
        </S.ImageWrapper>
      )}
      <S.TitleWrapper $size={size}>
        <S.Title $size={size}>{title}</S.Title>
        {subTitle && <S.SubTitle $size={size}>{subTitle}</S.SubTitle>}
      </S.TitleWrapper>
      {actionLabel && (
        <S.ActionButtonWrapper $size={size}>
          <Button onPress={actionHandler} variant={actionType}>
            {actionLabel}
          </Button>
        </S.ActionButtonWrapper>
      )}
    </S.EmptyState>
  );
}
