import { screen } from "@testing-library/react";

import { EmptyState } from "./empty-state";

import { render } from "@test-utils";

describe("emptyState", () => {
  it("should render successfully", async () => {
    render(
      <EmptyState
        illustrationName="Bank"
        subTitle="Proin dictum dolor vitae enim venenatis gravida"
        title="Lorem ipsum dolor sit amet"
      />
    );

    expect(
      await screen.findByText("Lorem ipsum dolor sit amet")
    ).toBeInTheDocument();

    expect(
      screen.getByText("Proin dictum dolor vitae enim venenatis gravida")
    ).toBeInTheDocument();
  });

  it("should render successfully with action button", async () => {
    const handleClick = jest.fn();
    const { user } = render(
      <EmptyState
        actionHandler={handleClick}
        actionLabel="Add Record"
        actionType="primary"
        illustrationName="Bank"
        subTitle="Proin dictum dolor vitae enim venenatis gravida"
        title="Lorem ipsum dolor sit amet"
      />
    );

    expect(
      await screen.findByText("Lorem ipsum dolor sit amet")
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", { name: "Add Record" })
    ).toBeInTheDocument();

    await user.click(screen.getByText(/Add Record/i));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("should render successfully all illustration images", async () => {
    render(
      <>
        <EmptyState illustrationName="Bank" title="Title" />
        <EmptyState illustrationName="Beach" title="Title" />
        <EmptyState illustrationName="BillBoard" title="Title" />
        <EmptyState illustrationName="Calendar" title="Title" />
        <EmptyState illustrationName="Computer" title="Title" />
        <EmptyState illustrationName="Crane" title="Title" />
        <EmptyState illustrationName="Date" title="Title" />
        <EmptyState illustrationName="Document" title="Title" />
        <EmptyState illustrationName="Dollar" title="Title" />
        <EmptyState illustrationName="Drink" title="Title" />
        <EmptyState illustrationName="Home" title="Title" />
        <EmptyState illustrationName="Home2" title="Title" />
        <EmptyState illustrationName="Image" title="Title" />
        <EmptyState illustrationName="Mountain" title="Title" />
        <EmptyState illustrationName="NoResultsFound" title="Title" />
        <EmptyState illustrationName="NothingHere" title="Title" />
        <EmptyState illustrationName="PiggyBank" title="Title" />
        <EmptyState illustrationName="PlayVideo" title="Title" />
        <EmptyState illustrationName="Search" title="Title" />
        <EmptyState illustrationName="SearchError" title="Title" />
        <EmptyState illustrationName="Shopping" title="Title" />
        <EmptyState illustrationName="Stadium" title="Title" />
        <EmptyState illustrationName="Stand" title="Title" />
        <EmptyState illustrationName="Tags" title="Title" />
        <EmptyState illustrationName="ToDo" title="Title" />
        <EmptyState illustrationName="Welcome" title="Title" />
      </>
    );

    expect(await screen.findAllByText("Title")).toHaveLength(26);

    expect(true).toBeTruthy();
  });
});
