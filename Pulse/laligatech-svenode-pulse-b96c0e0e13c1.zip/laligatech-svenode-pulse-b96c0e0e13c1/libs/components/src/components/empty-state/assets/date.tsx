export default function Date() {
  return (
    <svg
      fill="none"
      height="119"
      viewBox="0 0 116 119"
      width="116"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M24.0098 102H91.9887C93.8571 102.005 95.6582 101.298 97.0309 100.023C102.757 94.6895 107.339 88.2333 110.493 81.052C113.647 73.8707 115.308 66.1161 115.373 58.2652C115.666 26.3423 89.8714 0.0755024 58.1384 0.000164309C26.3875 30.0752164 0.625038 25.7961 0.625038 57.7209C0.615971 65.6667 2.24227 73.5283 5.40153 80.8107C8.5608 88.0932 13.1846 94.6387 18.9818 100.035C20.3516 101.304 22.1475 102.006 24.0098 102Z"
        fill="url(#paint0_linear_13833_65036)"
      />
      <g filter="url(#filter0_dd_13833_65036)">
        <path
          d="M20.2812 17.7969C20.2812 15.4497 22.184 13.5469 24.5312 13.5469H91.2031C93.5503 13.5469 95.4531 15.4497 95.4531 17.7969V98.8125C95.4531 101.16 93.5503 103.062 91.2031 103.062H24.5312C22.184 103.062 20.2812 101.16 20.2812 98.8125V17.7969Z"
          fill="white"
        />
      </g>
      <path
        d="M20.2812 17.7969C20.2812 15.4497 22.184 13.5469 24.5312 13.5469H91.2031C93.5503 13.5469 95.4531 15.4497 95.4531 17.7969V33.2217H20.2812V17.7969Z"
        fill="#2B58BF"
      />
      <mask
        height="21"
        id="mask0_13833_65036"
        maskUnits="userSpaceOnUse"
        width="76"
        x="20"
        y="13"
      >
        <path
          d="M20.2812 17.7969C20.2812 15.4497 22.184 13.5469 24.5312 13.5469H91.2031C93.5503 13.5469 95.4531 15.4497 95.4531 17.7969V33.2031H20.2812V17.7969Z"
          fill="white"
        />
      </mask>
      <g mask="url(#mask0_13833_65036)">
        <path
          d="M89.3438 12.75L29.8241 33.2031H19.4844V12.75H89.3438Z"
          fill="#2E6ED6"
        />
      </g>
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(26.3906 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(37.5488 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(48.707 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(59.8652 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(71.0234 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(82.1816 52.5938)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(26.3906 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(37.5488 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(48.707 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(59.8652 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(71.0234 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(82.1816 64.3398)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(26.3906 76.085)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(37.5488 76.085)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(48.707 76.085)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(59.8652 76.085)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(71.0234 76.085)"
        width="7.63464"
      />
      <rect
        fill="#CDD3DD"
        height="7.63464"
        transform="translate(82.1816 76.085)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(26.3906 87.8301)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(37.5488 87.8301)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(48.707 87.8301)"
        width="7.63464"
      />
      <rect
        fill="#EEF1F6"
        height="7.63464"
        transform="translate(59.8652 87.8301)"
        width="7.63464"
      />
      <rect
        fill="white"
        height="7.63464"
        transform="translate(71.0234 87.8301)"
        width="7.63464"
      />
      <rect
        fill="white"
        height="7.63464"
        transform="translate(82.1816 87.8301)"
        width="7.63464"
      />
      <path
        d="M80.5943 40.375H35.3523C34.2171 40.375 33.2969 41.2952 33.2969 42.4304V42.4304C33.2969 43.5655 34.2171 44.4858 35.3523 44.4858H80.5943C81.7295 44.4858 82.6497 43.5655 82.6497 42.4304C82.6497 41.2952 81.7295 40.375 80.5943 40.375Z"
        fill="#E4E8EE"
      />
      <defs>
        <filter
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
          height="111.516"
          id="filter0_dd_13833_65036"
          width="97.1719"
          x="9.28125"
          y="6.54688"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="4.5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.341176 0 0 0 0 0.4 0 0 0 0 0.458824 0 0 0 0.05 0"
          />
          <feBlend
            in2="BackgroundImageFix"
            mode="normal"
            result="effect1_dropShadow_13833_65036"
          />
          <feColorMatrix
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="5.5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
          />
          <feBlend
            in2="effect1_dropShadow_13833_65036"
            mode="normal"
            result="effect2_dropShadow_13833_65036"
          />
          <feBlend
            in="SourceGraphic"
            in2="effect2_dropShadow_13833_65036"
            mode="normal"
            result="shape"
          />
        </filter>
        <linearGradient
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_13833_65036"
          x1="58"
          x2="58"
          y1="0"
          y2="102"
        >
          <stop stopColor="#EAF1FB" stopOpacity="0.1" />
          <stop offset="1" stopColor="#EAF1FB" />
        </linearGradient>
      </defs>
    </svg>
  );
}
