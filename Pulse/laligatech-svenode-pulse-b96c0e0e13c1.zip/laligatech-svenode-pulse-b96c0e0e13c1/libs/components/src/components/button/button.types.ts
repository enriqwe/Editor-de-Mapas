import type { AriaButtonOptions } from "react-aria";

export type ButtonVariant =
  | "primary"
  | "secondary"
  | "tertiary"
  | "destructive"
  | "ghost";
export type ButtonType = "button" | "submit" | "reset";

type LoadingStateVariants = {
  variant?: "primary" | "destructive";
  isLoading?: boolean;
  loadingText?: string;
};

type NonLoadingStateVariants = {
  variant?: "secondary" | "tertiary" | "ghost";
};

export type ButtonProps = {
  type?: ButtonType;
  children?: React.ReactNode;
  IconLeft?: string | React.ReactNode;
  IconRight?: string | React.ReactNode;
  formId?: string;
  automationContext?: string;
  tooltipContent?: React.ReactNode;
} & (LoadingStateVariants | NonLoadingStateVariants) &
  Omit<AriaButtonOptions<"button">, "onClick">;
