import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

import type { ButtonVariant } from "./button.types";

const Button = styled.button<{
  $variant: ButtonVariant;
  $isLoading?: boolean | undefined;
}>`
  display: flex;
  gap: ${cssVars.spacing.x8};
  align-items: center;
  justify-content: space-around;
  height: 40px;
  border: none;
  background: none;
  border-radius: ${cssVars.border.radiusM};
  padding: ${cssVars.spacing.x8} ${cssVars.spacing.x16};

  cursor: ${({ $isLoading }) => ($isLoading ? "not-allowed" : "default")};

  &:disabled {
    cursor: not-allowed;
    color: ${cssVars.color.textDisabled} !important;
    border: ${cssVars.border.widthXS} solid ${cssVars.color.borderDisabled} !important;
  }

  &:focus {
    outline-offset: 2px;
    outline: ${cssVars.border.widthS} solid ${cssVars.color.borderFocus};
  }
`;

const PrimaryButton = styled(Button)`
  background: ${cssVars.color.bgButtonPrimary};
  color: ${cssVars.color.textOnBrand};

  &:hover:not(:disabled) {
    background: ${cssVars.color.bgButtonPrimaryHover};
  }
  &:focus {
    background: ${cssVars.color.bgButtonPrimaryHover};
  }
  &:active:not(:disabled) {
    background: ${cssVars.color.bgButtonPrimaryPressed};
  }
  &:disabled {
    background: ${cssVars.color.bgDisabled};
  }
`;

const PrimaryButtonLoading = styled(PrimaryButton)`
  background: ${cssVars.color.bgButtonPrimaryPressed};
  &:hover:not(:disabled),
  &:active:not(:disabled),
  &:focus {
    background: ${cssVars.color.bgButtonPrimaryPressed};
  }
`;

const SecondaryButton = styled(Button)`
  background: ${cssVars.color.surfacePrimary};
  color: ${cssVars.color.textBrandDefault};
  border: ${cssVars.border.widthXS} solid
    ${cssVars.color.borderButtonSecondaryDefault};

  &:hover:not(:disabled) {
    background: ${cssVars.color.bgButtonSecondaryHover};
    color: ${cssVars.color.textBrandHover};
    border: ${cssVars.border.widthXS} solid
      ${cssVars.color.borderButtonSecondaryDefault};
  }

  &:focus {
    background: ${cssVars.color.bgButtonSecondaryHover};
    color: ${cssVars.color.textBrandHover};
    border: ${cssVars.border.widthXS} solid
      ${cssVars.color.borderButtonSecondaryDefault};
  }

  &:active:not(:disabled) {
    color: ${cssVars.color.textBrandPressed};
    border: ${cssVars.border.widthXS} solid ${cssVars.color.borderBrandPressed};
  }

  &:disabled {
    border: ${cssVars.border.widthXS} solid ${cssVars.color.borderDisabled};
  }
`;

const TertiaryButton = styled(Button)`
  background: ${cssVars.color.surfacePrimary};
  color: ${cssVars.color.textBrandDefault};

  &:hover:not(:disabled) {
    background: ${cssVars.color.bgButtonTertiaryHover};
    color: ${cssVars.color.textBrandHover};
  }

  &:focus {
    background: ${cssVars.color.bgButtonTertiaryHover};
    color: ${cssVars.color.textBrandHover};
  }

  &:active:not(:disabled) {
    color: ${cssVars.color.textBrandPressed};
  }

  &:disabled {
    background: ${cssVars.color.bgDisabled};
    border: none;
  }
`;

const DestructiveButton = styled(Button)`
  background: ${cssVars.color.bgButtonDestructive};
  color: ${cssVars.color.textInverse};

  &:hover:not(:disabled) {
    background: ${cssVars.color.bgButtonDestructiveHover};
  }

  &:focus {
    background: ${cssVars.color.bgButtonDestructiveHover};
  }

  &:active:not(:disabled) {
    background: ${cssVars.color.bgButtonDestructivePressed};
  }

  &:disabled {
    background: ${cssVars.color.bgDisabled};
  }
`;

const DestructiveButtonLoading = styled(DestructiveButton)`
  background: ${cssVars.color.bgButtonDestructivePressed};
  &:hover:not(:disabled),
  &:active,
  &:focus {
    background: ${cssVars.color.bgButtonDestructivePressed};
  }
`;

const GhostButton = styled(Button)`
  padding: 0 2px;
  color: ${cssVars.color.textBrandDefault};

  &:hover:not(:disabled) {
    color: ${cssVars.color.textBrandHover};
  }

  &:focus {
    color: ${cssVars.color.textBrandHover};
  }

  &:active:not(:disabled) {
    color: ${cssVars.color.textBrandPressed};
  }

  &:disabled {
    border: none;
  }
`;

export function getButton(variant: ButtonVariant, isLoading: boolean) {
  switch (variant) {
    case "primary":
      return isLoading ? PrimaryButtonLoading : PrimaryButton;
    case "secondary":
      return SecondaryButton;
    case "tertiary":
      return TertiaryButton;
    case "destructive":
      return isLoading ? DestructiveButtonLoading : DestructiveButton;
    case "ghost":
      return GhostButton;
    default:
      return Button;
  }
}

export const IconContainer = styled.span<{
  $disabled: boolean;
  $variant: ButtonVariant;
}>`
  color: ${cssVars.color.textDisabled};

  span {
    color: ${({ $variant, $disabled }) => {
      if ($disabled) {
        return cssVars.color.textDisabled;
      }

      switch ($variant) {
        case "primary":
          return cssVars.color.iconOnBrand;
        case "secondary":
          return cssVars.color.iconBrand;
        case "tertiary":
          return cssVars.color.iconBrand;
        case "destructive":
          return cssVars.color.iconInverse;
        case "ghost":
          return cssVars.color.iconBrand;
      }
    }};
  }
`;

export const ButtonText = styled.span`
  font: ${cssVars.text.bodyBaseSemiBold};
`;
