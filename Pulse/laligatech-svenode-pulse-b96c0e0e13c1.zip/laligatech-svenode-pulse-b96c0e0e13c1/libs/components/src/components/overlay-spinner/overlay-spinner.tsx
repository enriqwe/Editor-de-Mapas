import type { JSX } from "react";

import { Overlay } from "./overlay-spinner.styled";

import { Spinner } from "@components/spinner";

export type OverlaySpinnerProps = {
  text: string;
  overlay?: "dark" | "light";
};

export function OverlaySpinner({
  text,
  overlay = "light",
}: OverlaySpinnerProps): JSX.Element {
  return (
    <Overlay $variant={overlay}>
      <Spinner
        helperText={text}
        size="xl"
        variant={overlay === "dark" ? "light" : "dark"}
      />
    </Overlay>
  );
}
