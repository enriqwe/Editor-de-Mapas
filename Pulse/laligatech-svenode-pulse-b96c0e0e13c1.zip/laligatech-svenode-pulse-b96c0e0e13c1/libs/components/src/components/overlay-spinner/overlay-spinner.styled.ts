import styled from "styled-components";

export const Overlay = styled.div<{ $variant: "light" | "dark" }>`
  background-color: ${({ $variant }) =>
    $variant === "light" ? "#fff" : "#012134"}; // TODO: use theme colors
  opacity: 0.8;
  display: flex;
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-size: ${({ theme }) => theme.font.sizes.xl};
  font-weight: ${({ theme }) => theme.font.weights.bold};
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  width: 100%;
  z-index: ${({ theme }) => theme.zIndex.x99999};
  justify-content: center;
  align-items: center;
`;
