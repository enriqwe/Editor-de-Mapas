import styled from "styled-components";

export const TableHeaderRow = styled.tr`
  border-bottom: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.border.accordion.default}`};
  margin-bottom: ${({ theme }) => theme.spacing.x4};
  background: ${({ theme }) => theme.color.background.box};
  font-family: ${({ theme }) => theme.font.fontFamily};
`;
