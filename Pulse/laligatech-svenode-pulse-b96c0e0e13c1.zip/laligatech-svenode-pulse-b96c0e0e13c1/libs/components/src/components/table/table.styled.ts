import styled from "styled-components";

export const TableWrapper = styled.div`
  overflow-x: auto;
`;

export const Table = styled.table`
  border-collapse: collapse;
  position: relative;
  font-family: ${({ theme }) => theme.font.fontFamily};
  width: 100%;
  table-layout: fixed;
  overflow: scroll;
`;

export const PaginationBarContainer = styled.div`
  margin-top: ${({ theme }) => theme.spacing.x12};
`;

export const EmptyStateWrapper = styled.div`
  margin-top: ${({ theme }) => theme.spacing.x64};
  margin-bottom: ${({ theme }) => theme.spacing.x64};
`;

export const Loader = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;

  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;

  @-webkit-keyframes spin {
    0% {
      -webkit-transform: rotate(360deg);
    }
    100% {
      -webkit-transform: rotate(0deg);
    }
  }

  @keyframes spin {
    0% {
      transform: rotate(360deg);
    }
    100% {
      transform: rotate(0deg);
    }
  }
`;
