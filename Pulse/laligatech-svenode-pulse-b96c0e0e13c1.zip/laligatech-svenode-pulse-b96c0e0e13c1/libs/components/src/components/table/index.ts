export { Table } from "./table";
export type { TableProps } from "./table.types";
