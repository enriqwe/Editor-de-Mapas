import * as S from "./toolbar.styled";

import { Link } from "@components/link";
import { ButtonMenu } from "@components/button-menu";
import { Icon } from "@components/icon";

type ToolbarProps = {
  onFilterClick: (() => void) | undefined;
  buttonMenuItems:
    | {
        name: string;
        onClick: () => void;
      }[]
    | undefined;
  filtersCount?: number;
};

export function Toolbar(props: ToolbarProps) {
  const { onFilterClick, buttonMenuItems, filtersCount } = props;

  return (
    <S.ToolBar>
      {buttonMenuItems ?
        <S.ButtonMenuContainer>
          <ButtonMenu.Menu
            automationContext="massive actions"
            disabled={buttonMenuItems.length === 0}
            label="Selecciona una opción"
            placement="left"
            variant="outline"
          >
            {buttonMenuItems.map(({ name, onClick }) => (
              <ButtonMenu.Item
                key={`item-${name}`}
                name={name}
                onClick={onClick}
              />
            ))}
          </ButtonMenu.Menu>
          <Icon
            fill
            icon="info"
            state="informative"
            tooltipContent="Solamente verás acciones compatibles con los ítems seleccionados"
            tooltipPosition="right"
          />
        </S.ButtonMenuContainer>
      : null}
      <S.InputFilterWrapper>
        {onFilterClick ?
          <Link
            automationContext="filter"
            fontWeight="bold"
            iconRight="filter_alt"
            onPress={onFilterClick}
            size="sm"
          >
            {`Filtros ${filtersCount ? `(${filtersCount})` : ""}`}
          </Link>
        : null}
      </S.InputFilterWrapper>
    </S.ToolBar>
  );
}
