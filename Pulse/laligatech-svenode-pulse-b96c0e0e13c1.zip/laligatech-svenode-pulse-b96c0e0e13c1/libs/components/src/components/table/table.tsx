import { useEffect, useState } from "react";
import type { Selection } from "react-stately";

import { TableFELogic, sortTableData } from "./table-fe-logic";
import { TableBELogic } from "./table-be-logic";
import { TableContent } from "./table-content";
import { Toolbar } from "./sub-components";
import type { TableProps } from "./table.types";
import * as S from "./table.styled";
import { DataHandling } from "./table.constant";

import { TranslationProvider } from "@providers/translation";
import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";
import { PaginationBar } from "@components/pagination-bar";

export function Table(props: TableProps) {
  const {
    dataHandling = DataHandling.BACKEND,
    disablePagination = false,
    paginationProps = {},
    initialSort = { columnKey: "", order: "ascending" },
    ariaLabel = "",
    tableData,
    automationContext = "",
    sortHandler = () => null,
    loading = false,
    massiveActions,
    showSelectAll = false,
    selectedRows = () => null,
    filtersCount = 0,
    onFilterClick,
    locale = "es-ES",
  } = props;

  const { data, headers } = tableData;
  const {
    totalRecords = data.length,
    activePageNo = 1,
    pageSizeList = [],
    defaultPageSize = 10,
    onPageChange = () => null,
    onPageSizeChange = () => null,
  } = paginationProps;

  const [activePage, setActivePage] = useState(activePageNo);
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const [rowsData, setRowsData] = useState<any[]>([]);
  const [sortDescriptor, setSortDescriptor] = useState(initialSort);
  const [disabledKeys, setDisabledKeys] = useState<any[]>([]);

  // selected rows/keys can be retrieved from selectedkeys to perform bulk actions
  const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set());

  const automationClasses = automationClass("table", automationContext);

  // Updates the current page whenever the activePageNo prop changes
  // This is useful for server-side pagination where the activePageNo is controlled by the server
  // and the component needs to reflect that change in the UI.
  useEffect(() => {
    setActivePage(activePageNo); //to update the value in pagination input
  }, [activePageNo]);

  const getPageData = (
    newData: any[],
    newPageNumber: number,
    newPageSize: number
  ) => {
    const firstPageIndex = (newPageNumber - 1) * newPageSize;
    const lastPageIndex = firstPageIndex + newPageSize;
    return newData.slice(firstPageIndex, lastPageIndex);
  };

  // Update table data when data changes
  useEffect(() => {
    let updatedRows = data;

    /** Retrieve disabled keys from the table data */
    const disabledRows = data.reduce((disabledIds, currentRow) => {
      if (currentRow.disabled) {
        disabledIds.push(currentRow.id);
      }
      return disabledIds;
    }, []);
    setDisabledKeys(disabledRows);

    /** Get active page table data if pagination is present in FE */
    if (dataHandling === DataHandling.FRONTEND && initialSort.columnKey) {
      updatedRows = sortTableData(updatedRows, initialSort);
    }

    if (!disablePagination && dataHandling === DataHandling.FRONTEND) {
      updatedRows = getPageData(updatedRows, activePage, pageSize);
    }

    setRowsData(updatedRows);
  }, [data]);

  const getTableProps = () => {
    if (dataHandling === DataHandling.FRONTEND) {
      return TableFELogic({
        pageSize,
        totalData: data,
        updatePageSize: setPageSize,
        updateActivePage: setActivePage,
        updateRowsData: setRowsData,
        updateSortDescriptor: setSortDescriptor,
        getPageData,
      });
    }
    return TableBELogic({
      sortHandler,
      pageSize,
      onPageChange,
      onPageSizeChange,
      updatePageSize: setPageSize,
      updateActivePage: setActivePage,
      updateSortDescriptor: setSortDescriptor,
    });
  };

  //replace this loader with actual loader once developed
  if (loading) {
    return (
      <S.Loader>
        <Icon icon="restart_alt" size="xl" />
      </S.Loader>
    );
  }

  const tableProps = getTableProps();

  const updateSelectedKeys = (key: Selection) => {
    /* callback function to perform any action on selected rows */
    selectedRows([...key]);
    setSelectedKeys(key);
  };

  const buttonMenuItems = massiveActions?.options.map(({ onSelect, text }) => ({
    name: text,
    onClick: () => {
      onSelect(Array.from(selectedKeys));
    },
  }));

  return (
    <TranslationProvider locale={locale}>
      <S.TableWrapper className={automationClasses}>
        {(massiveActions || onFilterClick) && (
          <Toolbar
            buttonMenuItems={buttonMenuItems}
            filtersCount={filtersCount}
            onFilterClick={onFilterClick}
          />
        )}
        <TableContent
          appliedFilters={filtersCount > 0}
          ariaLabel={ariaLabel}
          disabledKeys={disabledKeys}
          headers={headers}
          onSort={newSortDescriptor => {
            tableProps.sort(newSortDescriptor);
            setSelectedKeys(new Set());
          }}
          rowsData={rowsData}
          selectedKeys={selectedKeys}
          setSelectedKeys={updateSelectedKeys}
          showSelectAll={showSelectAll}
          sortDescriptor={sortDescriptor}
        />
        {!disablePagination && totalRecords > 0 && (
          <S.PaginationBarContainer>
            <PaginationBar
              currentPage={activePage}
              currentPageSize={pageSize}
              locale={locale}
              onPageChange={pageNumber => {
                tableProps.onPageChange(pageNumber);
                if (dataHandling === DataHandling.FRONTEND) {
                  setActivePage(pageNumber);
                }
                setSelectedKeys(new Set());
              }}
              onPageSizeChange={tableProps.onPageSizeChange}
              pageSizesList={pageSizeList}
              totalItems={totalRecords}
            />
          </S.PaginationBarContainer>
        )}
      </S.TableWrapper>
    </TranslationProvider>
  );
}
