import { useRef } from "react";
import type { GridRowProps } from "react-aria";
import { useTableHeaderRow } from "react-aria";
import type { TableState } from "react-stately";

import * as S from "./table-header-row.styled";

type TableHeaderRowProps<T> = {
  item: GridRowProps<T>["node"];
  state: TableState<T>;
  children: React.ReactNode;
};

export function TableHeaderRow<T>(props: TableHeaderRowProps<T>) {
  const { item, state, children } = props;
  const ref = useRef<HTMLTableRowElement>(null);
  const { rowProps } = useTableHeaderRow({ node: item }, state, ref);

  return (
    <S.TableHeaderRow {...rowProps} ref={ref}>
      {children}
    </S.TableHeaderRow>
  );
}
