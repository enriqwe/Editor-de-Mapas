import styled, { css } from "styled-components";

export const TableRowGroup = styled.tbody<{
  $isRowHeader: boolean;
}>`
  background: ${({ theme }) => theme.color.background.box};
  overflow: auto;

  ${({ $isRowHeader }) => {
    if ($isRowHeader) {
      return css`
        position: sticky;
        top: 0px;
      `;
    }
  }}
`;
