import { useRef } from "react";
// import type { GridNode } from '@react-types/grid';
import type { AriaTableColumnHeaderProps } from "react-aria";
import {
  mergeProps,
  useHover,
  useFocusRing,
  useTableColumnHeader,
} from "react-aria";
import type { TableState } from "react-stately";
import { useTheme } from "styled-components";

import { SortDirection } from "../../table.constant";

import * as S from "./table-column-header.styled";

import { Icon } from "@components/icon";

export type TableColumnHeaderProps<T> = {
  column: AriaTableColumnHeaderProps<T>["node"];
  state: TableState<T>;
};

export function TableColumnHeader<T>({
  column,
  state,
}: TableColumnHeaderProps<T>) {
  const theme = useTheme();
  const ref = useRef<HTMLTableCellElement | null>(null);

  const { columnHeaderProps } = useTableColumnHeader(
    { node: column },
    state,
    ref
  );

  const { isFocusVisible, focusProps } = useFocusRing();
  const { hoverProps, isHovered } = useHover({});

  const allowsSorting = Boolean(column.props?.allowsSorting);

  let iconColor = theme.color.text.stepper.inactive; // default color
  if (state.sortDescriptor && column.key === state.sortDescriptor.column) {
    iconColor = "#1F2329"; // color constant not available in theme
  }

  let arrowIcon = "arrow_downward"; //default sort icon value
  /** only change the sort icon for currently sorted column */
  if (
    state.sortDescriptor &&
    column.key === state.sortDescriptor.column &&
    state.sortDescriptor.direction === SortDirection.ASCENDING
  )
    arrowIcon = "arrow_upward";

  // Casting due to wrong typing in react-aria
  const columnValue = column.value as
    | {
        align?: "left" | "center" | "right";
        isSelectionCell?: boolean;
      }
    | undefined;
  const align = columnValue?.align;

  return (
    <S.TableColumnHeader
      {...mergeProps(columnHeaderProps, focusProps, hoverProps)}
      $isColumnSorted={
        column.key === state.sortDescriptor?.column && allowsSorting
      }
      $isFocusVisible={isFocusVisible}
      $isHover={isHovered && allowsSorting}
      {...(align && { $textAlignValue: align })}
      ref={ref}
    >
      <S.TableColumnHeaderContent
        $allowsSorting={allowsSorting}
        {...(align && { $textAlignValue: align })}
      >
        {column.rendered}
        {allowsSorting && (
          <S.TableColumnHeaderIcon aria-hidden>
            <Icon color={iconColor} icon={arrowIcon} size="xs" />
          </S.TableColumnHeaderIcon>
        )}
      </S.TableColumnHeaderContent>
    </S.TableColumnHeader>
  );
}
