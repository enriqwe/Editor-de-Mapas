import styled, { css } from "styled-components";

export const TableRow = styled.tr<{
  $isFocusVisible: boolean;
  $isHover: boolean;
  $isDisabled?: boolean;
}>`
  ${({ $isHover, theme }) =>
    $isHover &&
    css`
      background: ${theme.color.background.default};
    `}
  :active {
    background: ${({ theme }) => theme.color.background.accordion.hover};
    .material-symbols-outlined {
      color: ${({ theme }) => theme.color.background.accordion.focus};
    }
  }

  &[aria-selected="true"] {
    background: ${({ theme }) => theme.color.background.accordion.hover};
  }

  ${({ theme, $isDisabled }) =>
    $isDisabled && `background-color: ${theme.color.background.disabled}`};
  border-bottom: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.border.box}`};
  outline: 2px solid transparent;
  outline-offset: 2px;

  ${({ $isFocusVisible }) => {
    if ($isFocusVisible) {
      return css`
        outline-color: ${({ theme }) => theme.color.background.button.primary};
        outline-style: solid;
        outline-offset: ${({ theme }) => theme.spacing.x4};
      `;
    }
  }}
`;
