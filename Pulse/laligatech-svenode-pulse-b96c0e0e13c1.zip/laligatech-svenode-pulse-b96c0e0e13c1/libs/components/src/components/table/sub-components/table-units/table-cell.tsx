import { useRef } from "react";
// import type { GridNode, AriaTableCellProps } from '@react-types/grid';
import { mergeProps, useFocusRing, useTableCell } from "react-aria";
import type { AriaTableCellProps } from "react-aria";
import type { TableState } from "react-stately";

import * as S from "./table-cell.styled";

type TableCellProps<T> = {
  cell: AriaTableCellProps["node"];
  state: TableState<T>;
  isDisabled?: boolean;
};

export function TableCell<T>(props: TableCellProps<T>) {
  const { cell, state, isDisabled = false } = props;
  const ref = useRef<HTMLTableCellElement | null>(null);
  const { gridCellProps } = useTableCell({ node: cell }, state, ref);
  const { isFocusVisible, focusProps } = useFocusRing();

  const cellContent =
    typeof cell.rendered === "string" && cell.rendered.length <= 0 ?
      "-"
    : cell.rendered;

  const cellColumn = cell.column as { value: { align?: string } } | undefined;
  const textAlign = cellColumn?.value.align ?? "left";

  return (
    <S.TableCell
      {...mergeProps(gridCellProps, focusProps)}
      $isDisabled={isDisabled}
      $isFocusVisible={isFocusVisible}
      $textAlign={textAlign}
      ref={ref}
    >
      {/*       <S.TableCellBox
        onMouseDown={e => {
          e.stopPropagation();
        }}
        onPointerDown={e => {
          e.stopPropagation();
        }}
      > */}
      {cellContent}
      {/* </S.TableCellBox> */}
    </S.TableCell>
  );
}
