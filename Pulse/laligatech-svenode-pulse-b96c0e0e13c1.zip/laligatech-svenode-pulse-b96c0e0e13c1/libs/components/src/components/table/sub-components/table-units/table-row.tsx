import { useRef } from "react";
import { mergeProps, useFocusRing, useHover, useTableRow } from "react-aria";
import type { GridRowProps } from "react-aria";
import type { TableState } from "react-stately";

import * as S from "./table-row.styled";

type TableRowProps<T> = {
  item: GridRowProps<T>["node"];
  state: TableState<T>;
  children: React.ReactNode;
};

export function TableRow<T>({ item, state, children }: TableRowProps<T>) {
  const ref = useRef<HTMLTableRowElement | null>(null);
  const { hoverProps, isHovered } = useHover({});
  const { rowProps } = useTableRow(
    {
      node: item,
    },
    state,
    ref
  );
  const { isFocusVisible, focusProps } = useFocusRing();

  const itemValue = item.value as { disabled?: boolean };

  return (
    <S.TableRow
      $isDisabled={itemValue.disabled}
      $isFocusVisible={isFocusVisible}
      $isHover={isHovered}
      {...mergeProps(rowProps, focusProps, hoverProps)}
      onPointerDown={e => {
        if ((e.target as HTMLElement).tagName === "INPUT") return;
        rowProps.onPointerDown?.(e);
      }}
      ref={ref}
    >
      {/* {[...item.childNodes].map(cell => {
        return cell.props.isSelectionCell ?
            <TableCheckboxCell cell={cell} key={cell.key} state={state} />
          : <TableCell
              cell={cell}
              column={cell.column}
              isDisabled={item.value?.disabled}
              key={cell.key}
              state={state}
            />;
      })} */}
      {children}
    </S.TableRow>
  );
}
