import styled, { css } from "styled-components";

export const TableCell = styled.td<{
  $isFocusVisible: boolean;
  $textAlign?: string;
  $isDisabled: boolean;
}>`
  box-sizing: border-box;
  font-family: ${({ theme }) => theme.font.fontFamily};
  text-align: ${props => props.$textAlign};
  padding: ${({ theme }) => theme.spacing.x16};
  cursor: default;
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.regular)};
  outline: 2px solid transparent;
  outline-offset: 2px;
  color: ${({ theme, $isDisabled }) =>
    $isDisabled ? theme.color.text.disabled : theme.color.text.pending};

  ${({ $isFocusVisible }) => {
    if ($isFocusVisible) {
      return css`
        outline-color: ${({ theme }) => theme.color.background.button.primary};
        outline-style: solid;
        outline-offset: ${({ theme }) => theme.spacing.x4};
      `;
    }
  }}
`;

export const TableCellBox = styled.span`
  cursor: text;
  user-select: text;
  &:first-letter {
    text-transform: capitalize;
  }
`;
