import styled, { css } from "styled-components";

export const TableColumnHeader = styled.th<{
  $textAlignValue?: string;
  $isFocusVisible: boolean;
  $isHover: boolean;
  $isColumnSorted: boolean;
}>`
  box-sizing: border-box;
  ${({ $textAlignValue }) =>
    $textAlignValue && `text-align: ${$textAlignValue};`}
  cursor: default;
  padding: ${({ theme }) => theme.spacing.x16};
  outline: 2px solid transparent;
  outline-offset: 2px;
  ${({ $isColumnSorted, theme }) =>
    $isColumnSorted && `background: ${theme.color.background.accordion.hover}`};

  ${props =>
    props.$isHover &&
    css`
      background: ${({ theme }) => theme.color.background.layout.body};
    `}

  :active {
    ${({ $isHover }) =>
      $isHover &&
      css`
        background: ${({ theme }) => theme.color.background.accordion.hover};
        .material-symbols-outlined {
          color: ${({ theme }) => theme.color.background.accordion.focus};
        }
      `}
  }

  ${props => {
    if (props.$isFocusVisible) {
      return css`
        outline-color: ${({ theme }) => theme.color.background.button.primary};
        outline-style: solid;
        outline-offset: ${({ theme }) => theme.spacing.x4};
      `;
    }
  }}
`;
export const TableColumnHeaderContent = styled.div<{
  $textAlignValue?: string;
  $allowsSorting: boolean;
}>`
  float: ${props => props.$textAlignValue};
  height: 28px;
  display: flex;
  align-items: center;
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.bold)};
  letter-spacing: 0.02em;
  ${({ $allowsSorting }) => $allowsSorting && `cursor: pointer`};
  color: ${({ theme }) => theme.color.text.body};
  text-align: left;
  &:first-letter {
    text-transform: capitalize;
  }
`;

export const TableColumnHeaderIcon = styled.span`
  margin-left: ${({ theme }) => theme.spacing.x8};
  align-self: self-end;
`;
