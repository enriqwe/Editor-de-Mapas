import styled from "styled-components";

export const TableCheckbox = styled.td`
  padding-left: 18px;
  width: 30px;
`;

export const TableCheckboxHeader = styled.th`
  padding-left: 18px;
  width: 30px;
`;
