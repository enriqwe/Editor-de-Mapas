import { useRef } from "react";
import {
  useTableCell,
  useTableColumnHeader,
  useTableSelectAllCheckbox,
  useTableSelectionCheckbox,
  VisuallyHidden,
} from "react-aria";
import type { TableState } from "react-stately";
import type { AriaTableCellProps } from "react-aria";

import * as S from "./table-checkbox.styled";

import { Checkbox } from "@components/checkbox";

type TableCheckboxCellProps<T> = {
  cell: AriaTableCellProps["node"];
  state: TableState<T>;
};

type TableSelectAllCellProps<T> = {
  column: AriaTableCellProps["node"];
  state: TableState<T>;
};

export function TableCheckboxCell<T>(props: TableCheckboxCellProps<T>) {
  const { cell, state } = props;

  const ref = useRef(null);

  const { gridCellProps } = useTableCell({ node: cell }, state, ref);
  const { checkboxProps } = useTableSelectionCheckbox(
    { key: cell.parentKey ?? "" },
    state
  );

  return (
    <S.TableCheckbox {...gridCellProps} ref={ref}>
      <Checkbox {...checkboxProps} aria-label="select row" />
    </S.TableCheckbox>
  );
}

export function TableSelectAllCell<T>(props: TableSelectAllCellProps<T>) {
  const { column, state } = props;
  const ref = useRef<HTMLTableCellElement | null>(null);
  const { columnHeaderProps } = useTableColumnHeader(
    { node: column },
    state,
    ref
  );
  const { checkboxProps } = useTableSelectAllCheckbox(state);

  return (
    <S.TableCheckboxHeader
      aria-label="selection-column"
      {...columnHeaderProps}
      ref={ref}
    >
      {state.selectionManager.selectionMode === "single" ?
        <VisuallyHidden>{checkboxProps["aria-label"]}</VisuallyHidden>
      : <Checkbox {...checkboxProps} aria-label="select all" />}
    </S.TableCheckboxHeader>
  );
}
