import type { ReactNode } from "react";
import { useTableRowGroup } from "react-aria";

import * as S from "./table-row-group.styled";

type TableRowGroupProps = {
  children: ReactNode;
  type: string;
};

export function TableRowGroup(props: TableRowGroupProps) {
  const { children, type = "tbody" } = props;
  const { rowGroupProps } = useTableRowGroup();

  return (
    <S.TableRowGroup
      $isRowHeader={type === "thead"}
      as={type}
      {...rowGroupProps}
    >
      {children}
    </S.TableRowGroup>
  );
}
