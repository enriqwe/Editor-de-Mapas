import type { ReactNode } from "react";
import type { AriaButtonProps } from "react-aria";

import type { IconProps } from "@components/icon";

export type IconButtonProps = {
  iconName: string;
  /** @deprecated use isDisabled instead */
  disabled?: boolean;
  automationContext?: string;
  tooltipContent?: ReactNode;
  /** @deprecated this is no longer aligned with Figma's designs. Use prop `size` instead */
  iconSize?: IconProps["size"];
  size?: "default" | "medium" | "small";
} & Omit<AriaButtonProps, "onClick">;
