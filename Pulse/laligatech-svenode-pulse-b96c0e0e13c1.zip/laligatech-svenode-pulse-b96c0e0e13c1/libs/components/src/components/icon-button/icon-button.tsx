import React, { useRef } from "react";
import { useButton } from "react-aria";

import * as S from "./icon-button.styled";
import type { IconButtonProps } from "./icon-button.types";

import { Icon } from "@components/icon";
import { TooltipTrigger } from "@components/tooltip";
import { automationClass } from "@utils/automation-class";

const iconSizeForSize = {
  default: "m",
  medium: "s",
  small: "s",
} as const

export function IconButton(props: IconButtonProps) {
  const {
    automationContext,
    iconName,
    iconSize = "m",
    tooltipContent,
    size,
  } = props;
  const ref = useRef<HTMLButtonElement>(null);

  // TODO: evaluate if one of aria-label or aria-labelledby should be mandatory

  const { buttonProps } = useButton(props, ref);

  const automationClasses = automationClass("iconButton", automationContext);

  const tooltipAutomationClasses = automationClass(
    "tooltip",
    "tooltip-iconButton"
  );

  const finalIconSize = size ? iconSizeForSize[size] : iconSize;

  const getIconButton = () => {
    return (
      <S.IconButton
        {...buttonProps}
        $size={size}
        className={automationClasses}
        ref={ref}
      >
        <Icon
          color="inherit"
          icon={iconName}
          size={finalIconSize}
          state={buttonProps.disabled ? "disabled" : "default"}
        />
      </S.IconButton>
    );
  };

  return (
    <>
      {tooltipContent ?
        <TooltipTrigger
          automationContext={tooltipAutomationClasses}
          tooltipContent={tooltipContent}
          triggerElement={getIconButton()}
        />
      : getIconButton()}
    </>
  );
}
