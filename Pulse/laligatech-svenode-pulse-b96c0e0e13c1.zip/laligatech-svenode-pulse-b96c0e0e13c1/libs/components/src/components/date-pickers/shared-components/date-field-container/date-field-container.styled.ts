import styled, { css } from "styled-components";

export const DateFieldContainer = styled.div<{
  $isError: boolean;
  $disabled?: boolean;
}>`
  height: 44px;
  box-sizing: border-box;
  padding: ${({ theme }) => `${theme.spacing.x8} ${theme.spacing.x12}`};

  border-radius: ${({ theme }) => theme.border.radiusS};
  border-style: solid;
  border-width: ${({ theme }) => theme.border.widthXS};
  border-color: ${({ theme }) => theme.color.borderFormControlDefault};

  display: flex;
  align-items: center;
  justify-content: space-between;

  ${({ theme }) => theme.text.bodyBaseRegular};
  color: ${({ theme }) => theme.color.textBody};

  &:hover {
    ${({ theme, $isError, $disabled }) =>
      !$isError &&
      !$disabled &&
      css`
        border-color: ${theme.color.borderFormControlHover};
        box-shadow: inset 0 0 0 1px ${theme.color.borderFormControlHover};
      `};
  }

  &:focus-visible {
    ${({ theme, $isError, $disabled }) =>
      !$isError &&
      !$disabled &&
      css`
        border-color: ${theme.color.borderFocus};
        box-shadow: inset 0 0 0 1px ${theme.color.borderFocus};
      `};
  }

  ${({ $disabled, theme }) =>
    $disabled &&
    css`
      cursor: not-allowed;
      color: ${theme.color.textDisabled};
      border-color: ${theme.color.borderDisabled};
      background: ${theme.color.bgDisabled};
    `}

  ${({ $isError, $disabled, theme }) =>
    $isError &&
    !$disabled && {
      borderColor: theme.color.borderError,
      boxShadow: `inset 0 0 0 1px ${theme.color.borderError}`,
    }}
`;
