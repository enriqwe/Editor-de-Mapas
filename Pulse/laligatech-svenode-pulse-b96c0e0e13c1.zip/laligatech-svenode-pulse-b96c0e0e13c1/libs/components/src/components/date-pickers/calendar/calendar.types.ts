import type { ReactElement } from "react";

export type IDate = {
  year: number;
  month: number;
  day: number;
};

export type CalendarDataProps = {
  title?: ReactElement;
  nextButton?: ReactElement;
  prevButton?: ReactElement;
  calendarGrid?: ReactElement;
};
