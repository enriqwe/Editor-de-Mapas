import styled from "styled-components";

export const DateField = styled.div`
  display: flex;
  align-items: center;
`;

export const Segment = styled.div<{
  $isPlaceholderText?: boolean;
  $disabled?: boolean;
}>`
  box-sizing: content-box;
  padding-left: 2px;
  padding-right: 2px;
  color: ${({ theme, $isPlaceholderText, $disabled }) => {
    if ($disabled) {
      return theme.color.textDisabled;
    }

    if ($isPlaceholderText) {
      return theme.color.textPlaceholder;
    }

    return theme.color.textBody;
  }};

  ${({ theme }) => theme.text.bodyBaseRegular};
`;

export const Placeholder = styled.span<{ $isPlaceholder: boolean }>`
  display: ${({ $isPlaceholder }) => ($isPlaceholder ? "block" : "none")};

  text-align: center;
  width: 100%;
  height: ${({ $isPlaceholder }) => ($isPlaceholder ? "" : 0)};
  pointer-events: none;
`;
