import type { JSX } from "react";
import { useDateFormatter } from "react-aria";
import type { CalendarState, RangeCalendarState } from "react-stately";

import * as S from "./year-calendar.styled";

type YearCalendarProps = {
  state: CalendarState | RangeCalendarState;
  onMonthSelected: () => void;
};

export function YearCalendar({ state, onMonthSelected }: YearCalendarProps) {
  const months: string[] = [];
  const formatter = useDateFormatter({
    month: "short",
    timeZone: state.timeZone,
  });

  const numMonths = state.focusedDate.calendar.getMonthsInYear(
    state.focusedDate
  );
  for (let monthCount = 1; monthCount <= numMonths; monthCount++) {
    const date = state.focusedDate.set({ month: monthCount });
    months.push(formatter.format(date.toDate(state.timeZone)));
  }

  const setMonth = (month: number) => {
    const date = state.focusedDate.set({ month });
    state.setFocusedDate(date);
  };

  const minMonthSelection = (month: number) => {
    if (
      state.minValue &&
      state.minValue.year >= state.focusedDate.year &&
      state.minValue.month > month
    )
      return true;
    return false;
  };

  const monthsTableData = months.map((data, index) => (
    <S.Cell
      $disabled={minMonthSelection(index + 1)}
      $selected={state.focusedDate.month === index + 1}
      key={data}
    >
      <S.CellButton
        $selected={state.focusedDate.month === index + 1}
        disabled={minMonthSelection(index + 1)}
        onClick={() => {
          setMonth(index + 1);
          onMonthSelected();
        }}
        type="button"
      >
        <span>{data}</span>
      </S.CellButton>
    </S.Cell>
  ));

  const rows: JSX.Element[][] = [];
  let cells: JSX.Element[] = [];

  monthsTableData.forEach((row, index) => {
    if (index % 4 !== 0 || index === 0) {
      cells.push(row);
    } else {
      rows.push(cells);
      cells = [];
      cells.push(row);
    }
  });
  rows.push(cells);

  const monthlist = rows.map((cell, index) => {
    // eslint-disable-next-line react/no-array-index-key -- index is unique
    return <S.Row key={index}>{cell}</S.Row>;
  });

  return (
    <S.Table aria-label={`${state.focusedDate.year}`} role="grid">
      <S.Body>{monthlist}</S.Body>
    </S.Table>
  );
}
