import { screen } from "@testing-library/react";

import { DateFieldContainer } from "./date-field-container";

import { render } from "@test-utils";

describe("dateFieldContainer", () => {
  it("should render successfully", () => {
    const onClickMock = jest.fn();

    render(
      <DateFieldContainer
        groupProps={{
          onClick: onClickMock,
        }}
        isError={false}
      >
        <div>Test Children</div>
      </DateFieldContainer>
    );

    expect(screen.getByText(/test children/i)).toBeTruthy();
  });
});
