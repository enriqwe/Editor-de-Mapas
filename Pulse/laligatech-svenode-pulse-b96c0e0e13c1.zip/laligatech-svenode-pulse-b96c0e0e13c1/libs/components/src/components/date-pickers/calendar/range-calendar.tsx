import { useRef } from "react";
import type { AriaRangeCalendarProps, DateValue } from "react-aria";
import { useRangeCalendar, useLocale } from "react-aria";
import { useRangeCalendarState } from "react-stately";

import * as S from "./calendar.styled";
import { CalendarContent } from "./sub-components/calendar-content";

import { createCalendar } from "@utils/date";
import { automationClass } from "@utils/automation-class";

export function RangeCalendar(
  props: AriaRangeCalendarProps<DateValue> & {
    automationContext?: string;
  }
) {
  const { locale } = useLocale();
  const state = useRangeCalendarState({
    ...props,
    locale,
    createCalendar,
  });

  const ref = useRef(null);
  const { calendarProps, prevButtonProps, nextButtonProps, title } =
    useRangeCalendar(props, state, ref);

  const automationClasses = automationClass(
    "rangeCalendar",
    props.automationContext
  );

  return (
    <S.CalendarRoot {...calendarProps} className={automationClasses} ref={ref}>
      <CalendarContent
        nextButtonProps={nextButtonProps}
        prevButtonProps={prevButtonProps}
        state={state}
        title={title}
      />
    </S.CalendarRoot>
  );
}
