import { useCalendarGrid, useLocale } from "react-aria";
import type { CalendarState, RangeCalendarState } from "react-stately";

import { CalendarCell } from "./calendar-cell";
import * as S from "./calendar-grid.styled";

import { getWeeksInMonth } from "@utils/date";
import type { CalendarDate } from "@utils/date";

export function CalendarGrid({
  state,
  ...props
}: {
  state: CalendarState | RangeCalendarState;
}) {
  const { locale } = useLocale();
  const { gridProps, headerProps, weekDays } = useCalendarGrid(props, state);

  // Get the number of weeks in the month so we can render the proper number of rows.
  const weeksInMonth = getWeeksInMonth(state.visibleRange.start, locale);

  return (
    <S.CalendarGridTable {...gridProps} cellPadding="0">
      <S.CalendarGridTableHeader {...headerProps}>
        <tr>
          {weekDays.map((day, index) => (
            // eslint-disable-next-line react/no-array-index-key -- day letter is not unique
            <S.CalendarGridTableHeaderText key={index}>
              {day}
            </S.CalendarGridTableHeaderText>
          ))}
        </tr>
      </S.CalendarGridTableHeader>
      <tbody>
        {[...new Array(weeksInMonth).keys()].map(weekIndex => (
          <tr key={weekIndex}>
            {state
              .getDatesInWeek(weekIndex)
              .map((date: CalendarDate | null, i: number) =>
                date ?
                  <CalendarCell
                    date={date}
                    key={date.toString()}
                    state={state}
                  />
                  // eslint-disable-next-line react/no-array-index-key -- date can be null
                : <td key={i} />
              )}
          </tr>
        ))}
      </tbody>
    </S.CalendarGridTable>
  );
}
