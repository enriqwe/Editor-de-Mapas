import type { AriaDateRangePickerProps } from "react-aria";
import type { ReactNode } from "react";
import { useRef } from "react";
import { I18nProvider, useDateRangePicker } from "react-aria";
import { useDateRangePickerState } from "react-stately";
import { useTheme } from "styled-components";

import { RangeCalendar } from "../calendar";
import { CalendarButton } from "../shared-components/calendar-button";
import { DateField } from "../shared-components/date-field";
import { DateFieldContainer } from "../shared-components/date-field-container";

import * as S from "./date-range-picker.styled";

import { Label } from "@components/internal";
import type { DateValue } from "@utils/date";
import { Dialog } from "@components/internal/dialog";
import { Popover } from "@components/internal/popover";
import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";
import type { Locale } from "@providers/translation";

export type DateRangePickerProps = {
  /** @deprecated use isDisabled instead */
  disabled?: boolean;
  errorMessage?: JSX.Element | string;
  automationContext?: string;
  locale?: Locale;
  labelTooltipContent?: ReactNode;
} & Omit<AriaDateRangePickerProps<DateValue>, "errorMessage">;

export function DateRangePicker(props: DateRangePickerProps) {
  const {
    description,
    locale = "es-ES",
    isRequired = false,
    automationContext,
    errorMessage,
    labelTooltipContent,
  } = props;

  const isDisabled = props.isDisabled ?? props.disabled ?? false;

  const state = useDateRangePickerState({
    ...props,
    isDisabled,
  });

  const ref = useRef(null);
  const theme = useTheme();
  const {
    groupProps,
    labelProps,
    startFieldProps,
    endFieldProps,
    buttonProps,
    dialogProps,
    calendarProps,
    descriptionProps,
    errorMessageProps,
  } = useDateRangePicker(props, state, ref);

  const { isInvalid, isOpen } = state;

  const automationClasses = automationClass(
    "dateRangePicker",
    automationContext
  );

  const getDescriptionAndErrorSection = () => {
    if (description && !isInvalid)
      return (
        <S.Description {...descriptionProps} $isDisabled={isDisabled}>
          {description}
        </S.Description>
      );
    else if (isInvalid && errorMessage)
      return (
        <S.ErrorSubText {...errorMessageProps}>{errorMessage}</S.ErrorSubText>
      );
  };

  return (
    <I18nProvider locale={locale}>
      <S.Container className={automationClasses}>
        {props.label && (
          <Label
            {...labelProps}
            infoTooltipContent={labelTooltipContent}
            isDisabled={isDisabled}
            isRequired={isRequired}
            label={props.label}
          />
        )}
        <DateFieldContainer
          disabled={isDisabled}
          groupProps={groupProps}
          isError={isInvalid}
          ref={ref}
        >
          <S.MultipleDateFieldContainer>
            <DateField {...startFieldProps} isDisabled={isDisabled} />
            <Icon color={theme.color.icon.default} icon="remove" size="s" />
            <DateField {...endFieldProps} isDisabled={isDisabled} />
          </S.MultipleDateFieldContainer>
          <CalendarButton {...buttonProps} />{" "}
          {/* TODO: replace with iconButton */}
        </DateFieldContainer>
        {!isOpen && getDescriptionAndErrorSection()}
        {isOpen && (
          <Popover placement="bottom end" state={state} triggerRef={ref}>
            <Dialog {...dialogProps}>
              <S.CalendarSection>
                <RangeCalendar {...calendarProps} />
              </S.CalendarSection>
            </Dialog>
          </Popover>
        )}
      </S.Container>
    </I18nProvider>
  );
}
