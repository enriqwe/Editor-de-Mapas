import { useRef } from "react";
import type {
  DateFieldState,
  DateSegment as DateSegmentType,
} from "react-stately";
import { useDateFieldState } from "react-stately";
import type { AriaDateFieldProps } from "react-aria";
import { useDateField, useDateSegment, useLocale } from "react-aria";

import * as S from "./date-field.styled";

import type { DateValue } from "@utils/date";
import { createCalendar } from "@utils/date";
import { automationClass } from "@utils/automation-class";

export type DateFieldProps = {
  automationContext?: string;
} & AriaDateFieldProps<DateValue>;

export function DateField(props: DateFieldProps) {
  const { locale } = useLocale();

  const state = useDateFieldState({
    ...props,
    locale,
    createCalendar,
  });
  const automationClasses = automationClass(
    "dateField",
    props.automationContext
  );

  const ref = useRef(null);
  const { fieldProps } = useDateField(props, state, ref);
  return (
    <S.DateField {...fieldProps} className={automationClasses} ref={ref}>
      {state.segments.map((segment, i) => (
        <DateSegment
          disabled={state.isDisabled}
          key={i}
          segment={segment}
          state={state}
        />
      ))}
    </S.DateField>
  );
}

type DateSegmentProps = {
  segment: DateSegmentType;
  state: DateFieldState;
  disabled: boolean;
};

function DateSegment(props: DateSegmentProps) {
  const { segment, state, disabled } = props;
  const ref = useRef(null);
  const { segmentProps } = useDateSegment(segment, state, ref);

  return (
    <S.Segment
      {...segmentProps}
      $disabled={disabled}
      $isPlaceholderText={segment.isPlaceholder}
      ref={ref}
    >
      {/* Always reserve space for the placeholder, to prevent layout shift when editing. */}
      <S.Placeholder $isPlaceholder={segment.isPlaceholder} aria-hidden="true">
        {segment.placeholder}
      </S.Placeholder>
      {segment.isPlaceholder ? "" : segment.text}
    </S.Segment>
  );
}
