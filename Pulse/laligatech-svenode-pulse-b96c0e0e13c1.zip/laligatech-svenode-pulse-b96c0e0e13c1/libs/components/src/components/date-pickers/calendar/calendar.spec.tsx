import { screen } from "@testing-library/react";

import { Calendar } from "./calendar";

import { render } from "@test-utils";
import { CalendarDate } from "@utils/date";

const getDate = (date: Date = new Date()) => {
  return {
    day: date.getDate(),
    month: date.getMonth() + 1,
    year: date.getFullYear(),
  };
};

describe("calendar", () => {
  it("should render successfully (date + buttons)", () => {
    const date = new CalendarDate(2022, 2, 3);
    render(<Calendar locale="en-US" value={date} />);

    const PrevButton = screen.getByRole("button", { name: "Previous" });
    const Next = screen.getByRole("button", { name: "Next" });
    const MonthText = screen.getByText("February 2022");

    expect(PrevButton).toBeInTheDocument();
    expect(Next).toBeInTheDocument();
    expect(MonthText).toBeInTheDocument();
  });

  it("select date should work properly", async () => {
    const date = new CalendarDate(2022, 2, 3);
    const { user } = render(<Calendar locale="en-US" value={date} />);

    const DayButton = screen.getByText("15");

    await user.click(DayButton);

    const selectedDay = screen.getByRole("gridcell", { selected: true });
    expect(selectedDay).toBeInTheDocument();
  });

  it("should show current month and year when displaying calendar", async () => {
    const date = new CalendarDate(2022, 2, 3);
    const { user } = render(<Calendar locale="en-US" value={date} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    const selectedMonth = screen.getByRole("application", {
      name: "February 2022",
    });
    expect(selectedMonth).toBeInTheDocument();
  });

  it("should increase month when clicking next button without month selector open", async () => {
    const date = new CalendarDate(2023, 2, 3);

    const { user } = render(<Calendar locale="en-US" value={date} />);

    let selectedYear = screen.getByText("February 2023");
    expect(selectedYear).toBeInTheDocument();

    const nextBtn = screen.getByRole("button", { name: "Next" });
    await user.click(nextBtn);

    selectedYear = screen.getByText("March 2023");
    expect(selectedYear).toBeInTheDocument();
  });

  it("should increase year when clicking next button with month selector open", async () => {
    const date = new CalendarDate(2023, 2, 3);

    const { user } = render(<Calendar locale="en-US" value={date} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    let selectedYear = screen.getByText("2023");
    expect(selectedYear).toBeInTheDocument();

    const nextBtn = screen.getByRole("button", { name: "Next" });
    await user.click(nextBtn);

    selectedYear = screen.getByText("2024");
    expect(selectedYear).toBeInTheDocument();
  });

  it("select month should work properly", async () => {
    const date = new CalendarDate(2023, 2, 3);
    const { user } = render(<Calendar locale="en-US" value={date} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    const selectedMonth = screen.getByRole("button", { name: "Apr" });
    await user.click(selectedMonth);

    const updatedMonth = screen.getByText("April 2023");

    expect(updatedMonth).toBeInTheDocument();
  });

  it("should check next and prev button disabled state)", () => {
    const { day, month, year } = getDate();
    const minDate = new CalendarDate(year, month, day).subtract({ days: 0 });
    const maxDate = new CalendarDate(year, month, day).add({ days: 0 });

    render(<Calendar locale="en-US" maxValue={maxDate} minValue={minDate} />);

    const PrevButton = screen.getByRole("button", { name: "Previous" });
    expect(PrevButton).toHaveAttribute("disabled");

    const Next = screen.getByRole("button", { name: "Next" });
    expect(Next).toHaveAttribute("disabled");
  });

  it("check current and previous year", async () => {
    const date = new CalendarDate(2024, 3, 3);
    const { user } = render(<Calendar locale="en-US" value={date} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    expect(screen.getByRole("heading", { name: "2024" })).toBeInTheDocument();

    const PrevButton = screen.getByRole("button", { name: "Previous" });
    await user.click(PrevButton);
    expect(screen.getByRole("heading", { name: "2023" })).toBeInTheDocument();
  });

  it("check previous year to be disabled", async () => {
    const currentYear = new Date().getFullYear();
    const date = new CalendarDate(currentYear + 1, 3, 3);

    const { day, month, year } = getDate();
    const minDate = new CalendarDate(year, month, day).subtract({ months: 1 });

    const { user } = render(
      <Calendar locale="en-US" minValue={minDate} value={date} />
    );

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    expect(
      screen.getByRole("heading", { name: `${currentYear + 1}` })
    ).toBeInTheDocument();

    const PrevButton = screen.getByRole("button", { name: "Previous" });
    await user.click(PrevButton);

    const prevYear = screen.queryByText(currentYear - 1);
    expect(prevYear).not.toBeInTheDocument();
  });
});
