import { screen } from "@testing-library/react";

import { DatePicker } from "./date-picker";

import { getLocalTimeZone, today } from "@utils/date";
import type { Locale } from "@providers/translation";
import { render } from "@test-utils";

describe("datePicker", () => {
  it("should render successfully with placeholder", () => {
    const onClickMock = jest.fn();
    const onBlurMock = jest.fn();

    const { baseElement } = render(
      <DatePicker
        automationContext="date-of-birth"
        description="Tristique senectus et netus et"
        errorMessage="You have an error"
        isDisabled={false}
        isRequired
        label="Example Label"
        minValue={today(getLocalTimeZone())}
        onBlur={onBlurMock}
        onChange={onClickMock}
      />
    );
    expect(baseElement).toBeTruthy();
    expect(screen.getByText("Example Label")).toBeTruthy();
    expect(screen.getByText("Tristique senectus et netus et")).toBeTruthy();
  });

  it("should render successfully with datepicker with error state", () => {
    const onClickMock = jest.fn();
    const onBlurMock = jest.fn();

    render(
      <DatePicker
        automationContext="date-of-birth"
        errorMessage="You have an error"
        isInvalid
        isRequired={false}
        label="Example Label"
        locale="en-US"
        minValue={today(getLocalTimeZone())}
        onBlur={onBlurMock}
        onChange={onClickMock}
      />
    );
    expect(screen.getByText("You have an error")).toBeTruthy();
  });

  it("should render successfully calender on click on calender icon", async () => {
    const onClickMock = jest.fn();
    const onBlurMock = jest.fn();

    const { user } = render(
      <DatePicker
        automationContext="date-of-birth"
        description="Tristique senectus et netus et"
        errorMessage="You have an error"
        isRequired
        label="Example Label"
        locale="en-US"
        minValue={today(getLocalTimeZone())}
        onBlur={onBlurMock}
        onChange={onClickMock}
      />
    );

    await user.click(screen.getByRole("button"));

    const PrevButton = screen.getByRole("button", { name: "Previous" });

    const Next = screen.getByRole("button", { name: "Next" });
    expect(PrevButton).toBeTruthy();
    expect(Next).toBeTruthy();
  });

  it.each`
    locale     | expected
    ${"en-US"} | ${"mm/dd/yyyy"}
    ${"en-GB"} | ${"dd/mm/yyyy"}
  `(
    "returns a date in format $expected when locales is $locale",
    ({ locale, expected }: { locale: Locale; expected: string }) => {
      const onClickMock = jest.fn();

      render(
        <DatePicker
          automationContext="date-of-birth"
          description="Tristique senectus et netus et"
          errorMessage="You have an error"
          isRequired
          label="Example Label"
          locale={locale}
          minValue={today(getLocalTimeZone())}
          onChange={onClickMock}
        />
      );

      expect(screen.getByRole("presentation").textContent).toEqual(expected);
    }
  );

  it("should render text tooltip on mouse over if set", async () => {
    const onClickMock = jest.fn();
    const onBlurMock = jest.fn();
    const { baseElement, container, user } = render(
      <DatePicker
        automationContext="date-of-birth"
        description="Tristique senectus et netus et"
        errorMessage="You have an error"
        isRequired
        label="Example Label"
        labelTooltipContent="Tooltip Text"
        minValue={today(getLocalTimeZone())}
        onBlur={onBlurMock}
        onChange={onClickMock}
      />
    );
    expect(baseElement).toBeTruthy();
    expect(screen.getByText("Example Label")).toBeTruthy();
    expect(screen.getByText("Tristique senectus et netus et")).toBeTruthy();
    const button = screen.getByText("info");
    await user.hover(button);
    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });
});
