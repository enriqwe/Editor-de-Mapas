export type VariantStaticProps =
  | "success"
  | "error"
  | "informative"
  | "pending"
  | "warning"
  | "tip";

export type StaticSizeProps = "large" | "small";

export type VariantDynamicProps = "default" | "deleted";

type TagProps = {
  label: string;
  automationContext?: string;
};

export type StaticTagProps = TagProps & {
  variant: VariantStaticProps;
  size: StaticSizeProps;
  tooltip?: boolean;
};

export type DynamicTagProps = TagProps & {
  variant: VariantDynamicProps;
  onClick: () => void;
  disabled?: boolean;
};
