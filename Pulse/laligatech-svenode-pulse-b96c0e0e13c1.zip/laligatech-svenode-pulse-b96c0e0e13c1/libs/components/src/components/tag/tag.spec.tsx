import { screen } from "@testing-library/react";

import { StaticTag, DynamicTag } from "./tag";

import { render } from "@test-utils";

describe("staticTag", () => {
  it("should render static tag successfully", () => {
    render(<StaticTag label="test" size="small" variant="informative" />);
    expect(screen.getByText("test")).toBeInTheDocument();
  });
});

describe("dynamicTag", () => {
  const onClickMock = jest.fn();

  beforeEach(() => {
    jest.resetAllMocks();
  });
  it("should render dynamic tag successfully", () => {
    render(<DynamicTag label="test" onClick={onClickMock} variant="default" />);

    expect(screen.getByText("test")).toBeInTheDocument();
  });

  it("should execute callback when clicking", async () => {
    const { user } = render(
      <DynamicTag label="test" onClick={onClickMock} variant="default" />
    );

    const tag = screen.getByText("test");
    await user.click(tag);

    expect(onClickMock).toHaveBeenCalledTimes(1);
  });
});
