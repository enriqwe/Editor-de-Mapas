import styled from "styled-components";

export const TextareaRoot = styled.div<{ $width: string }>`
  display: flex;
  flex-direction: column;
  width: ${({ $width }) => $width};
  margin-bottom: ${({ theme }) => theme.spacing.x20};
  font-family: ${({ theme }) => theme.font.fontFamily};
  & * {
    box-sizing: border-box;
  }
`;

export const TextareaLabelContainer = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x4};
  padding: ${({ theme }) => theme.spacing.x4};
  margin-bottom: 2px;
`;

export const TextareaLabel = styled.label`
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  font-weight: ${({ theme }) => theme.font.weights.bold};
  color: ${({ theme }) => theme.color.text.label};
  letter-spacing: 0.02em;
`;

export const TextareaText = styled.p<{ $isError: boolean }>`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x4};
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  font-weight: ${({ theme }) => theme.font.weights.regular};
  letter-spacing: 0.02em;
  margin: ${({ theme }) => theme.spacing.x8} 0 0
    ${({ theme }) => theme.spacing.x4};
  color: ${({ $isError, theme }) =>
    $isError ?
      theme.color.text.error
    : `#575C64`}; //Need to add this color in color.ts
`;

export const Textarea = styled.textarea<{
  $isError: boolean;
  $width: string;
  $height: string;
  disabled: boolean;
}>`
  height: ${({ $height }) => $height};
  width: ${({ $width }) => $width};
  background: ${({ theme }) => theme.color.background.form};
  border-radius: ${({ theme }) => theme.border.radiusS};
  padding: ${({ theme }) => theme.spacing.x8};
  border: ${({ $isError, theme }) =>
    `${theme.border.widthXS} solid ${
      $isError ? theme.color.border.form.error : "#858585"
    }`}; //Need to add this color in color.ts
  font-family: ${({ theme }) => theme.font.fontFamily};
  resize: none;
  font-size: ${({ theme }) => theme.font.sizes.m.fontSize};

  &:hover {
    border: ${({ theme, $isError }) =>
      `${theme.border.widthXS} solid ${!$isError && theme.color.border.chip.hover}`};
    box-shadow: ${({ $isError, theme, disabled }) => {
      if ($isError) {
        return `inset 0px 0px 0px 2px ${theme.color.border.form.error}`;
      } else if (disabled) {
        return `none`;
      }
      return `inset 0px 0px 0px 1.5px ${theme.color.border.chip.hover}`;
    }};
  }

  &:focus {
    box-shadow: inset 0px 0px 0px 2px
      ${({ theme }) => theme.color.border.chip.active};
    border: ${({ theme }) =>
      `${theme.border.widthXS} solid ${theme.color.border.chip.active}`};
  }

  &:disabled {
    border: ${({ theme }) => `${theme.border.widthXS} solid #b8b8b8`};
    background: #f3f3f3; //Need to add this color in color.ts
  }

  &::placeholder {
    color: ${({ theme, disabled }) =>
      disabled ?
        theme.color.border.form.default
      : `#7f858f`}; //Need to add this color in color.ts
  }

  ${({ $isError, theme }) =>
    $isError &&
    ` box-shadow: inset 0px 0px 0px 2px ${theme.color.border.form.error};`}
`;

export const LabelCounter = styled.span`
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.xs, theme.font.weights.semibold)};
  color: ${({ theme }) => theme.color.text.pending};
`;

export const TextboxLabel = styled.label<{ $disabled?: boolean }>`
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.semibold)};
  color: ${({ theme }) => theme.color.text.label};
  letter-spacing: 0.02em;
  color: ${({ $disabled }) =>
    $disabled ? "#858585" : `#303030`}; //Need to add this color in color.ts
`;
export const LabelContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: ${({ theme }) => theme.spacing.x4};
  padding: ${({ theme }) => theme.spacing.x4} 0;
  margin-bottom: 2px;
`;

export const MandatoryLabel = styled.span`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x4};
`;
