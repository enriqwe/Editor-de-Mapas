export { Textarea } from "./textarea";
export type { TextareaProps } from "./textarea";
