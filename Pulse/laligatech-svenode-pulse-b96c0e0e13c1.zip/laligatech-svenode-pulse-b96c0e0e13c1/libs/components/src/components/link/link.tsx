import { useRef } from "react";
import { useLink, mergeProps, useFocusRing } from "react-aria";

import * as S from "./link.styled";
import type { LinkProps } from "./link.types";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

export function Link(props: LinkProps) {
  const {
    children,
    // customElement,
    to,
    iconLeft,
    iconRight,
    fontWeight = "semibold",
    size = "sm",
    automationContext,
    isDisabled,
    variant = "standalone",
  } = props;

  const automationClasses = automationClass("externalLink", automationContext);
  const ref = useRef(null);
  const { linkProps } = useLink(props, ref);
  const { focusProps } = useFocusRing();

  // const Component = customElement || "a";

  return (
    <S.Anchor
      // as={Component}
      {...mergeProps(linkProps, focusProps)}
      $fontWeight={fontWeight}
      $isDisabled={isDisabled}
      $size={size}
      className={automationClasses}
      ref={ref}
      {...(to && { to })}
    >
      {iconLeft && (
        <Icon
          icon={iconLeft}
          size="s"
          {...(props.isDisabled ? { state: "disabled" } : { color: "inherit" })}
        />
      )}
      <S.LabelContainer
        $iconLeft={iconLeft}
        $iconRight={iconRight}
        $variant={variant}
      >
        {children}
      </S.LabelContainer>
      {iconRight && (
        <Icon
          icon={iconRight}
          size="s"
          {...(props.isDisabled ? { state: "disabled" } : { color: "inherit" })}
        />
      )}
    </S.Anchor>
  );
}
