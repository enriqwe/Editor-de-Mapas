export { Link } from "./link";
export type { LinkProps } from "./link.types";
