export { ProgressBar } from "./progress-bar";

// For retrocompatibility
export { ProgressBar as Loader } from "./progress-bar";
