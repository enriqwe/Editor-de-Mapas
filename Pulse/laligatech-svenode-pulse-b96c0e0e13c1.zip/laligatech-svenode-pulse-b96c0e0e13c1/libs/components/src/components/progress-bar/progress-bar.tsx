import { useProgressBar } from "react-aria";

import * as S from "./progress-bar.styled";
import type { ProgressBarProps } from "./progress-bar.types";

import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";

export function ProgressBar({
  value,
  label,
  status = "normal",
  helperText,
  errorText,
  successText,
  automationContext,
}: ProgressBarProps) {
  const Text = {
    normal: helperText,
    error: errorText,
    success: successText,
  }[status];

  const Icons = {
    normal: null,
    error: <Icon fill icon="cancel" size="xs" state="error" />,
    success: <Icon fill icon="check_circle" size="xs" state="success" />,
  }[status];

  const { progressBarProps, labelProps } = useProgressBar({
    minValue: 0,
    maxValue: 100,
    value,
    label,
  });
  const automationClasses = automationClass("progressBar", automationContext);

  const barWidth = `${value}%`;

  return (
    <S.Root className={automationClasses} {...progressBarProps}>
      {label && <S.Label {...labelProps}>{label}</S.Label>}
      <S.ProgressBarBackground>
        <S.ProgressBar $status={status} $width={barWidth} />
      </S.ProgressBarBackground>
      {Text && (
        <S.Text $status={status} {...labelProps}>
          {Icons}
          {Text}
        </S.Text>
      )}
    </S.Root>
  );
}
