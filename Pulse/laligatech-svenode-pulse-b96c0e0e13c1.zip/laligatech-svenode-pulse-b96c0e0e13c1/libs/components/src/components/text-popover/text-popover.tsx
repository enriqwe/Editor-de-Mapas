import { useEffect, useRef } from "react";
import { useOverlayTriggerState } from "react-stately";
import { useButton, useOverlayTrigger } from "react-aria";

import * as S from "./text-popover.styled";
import type { TextPopoverProps } from "./text-popover.types";

import { IconButton } from "@components/icon-button";
import { Popover } from "@components/internal/popover";

const POPOVER_VERTICAL_PADDING = 24;
const CONTENT_TOP_MARGIN = 12;

export function TextPopover({
  automationContext = "",
  placement = "top",
  popoverContent,
  popoverTitle,
  text,
}: Readonly<TextPopoverProps>) {
  const triggerRef = useRef<HTMLButtonElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const state = useOverlayTriggerState({});
  const { triggerProps, overlayProps } = useOverlayTrigger(
    { type: "dialog" },
    state,
    triggerRef
  );
  const { buttonProps } = useButton(triggerProps, triggerRef);

  const offsetWith = triggerRef.current?.offsetWidth ?? 0;

  let crossOffset: number;

  switch (placement) {
    case "bottom left":
    case "top left":
      crossOffset = offsetWith / 3;
      break;
    case "bottom right":
    case "top right":
      crossOffset = -(offsetWith / 3);
      break;
    default:
      crossOffset = 0;
  }

  useEffect(() => {
    // TODO: review how to avoid this querySelector
    // TODO: review if this useEffect is necessary at all
    const popoverContainer = document.querySelector<HTMLDivElement>(".popover");
    const popoverHeight = popoverContainer?.getBoundingClientRect().height ?? 0;
    const titleHeight = titleRef.current?.getBoundingClientRect().height ?? 0;

    if (contentRef.current) {
      contentRef.current.style.maxHeight = `${
        popoverHeight -
        titleHeight -
        POPOVER_VERTICAL_PADDING -
        CONTENT_TOP_MARGIN
      }px`;
    }
  }, [state.isOpen]);

  return (
    <>
      <S.Button {...buttonProps} ref={triggerRef}>
        {text}
      </S.Button>
      {state.isOpen ?
        <Popover
          automationContext={automationContext}
          crossOffset={crossOffset}
          hasBorder
          offset={8}
          placement={placement}
          showArrow
          state={state}
          triggerRef={triggerRef}
        >
          <S.Overlay {...overlayProps}>
            <S.Title ref={titleRef}>
              {popoverTitle}
              <IconButton
                iconName="close"
                iconSize="xs"
                onPress={triggerProps.onPress}
              />
            </S.Title>
            <S.Content ref={contentRef}>{popoverContent}</S.Content>
          </S.Overlay>
        </Popover>
      : null}
    </>
  );
}
