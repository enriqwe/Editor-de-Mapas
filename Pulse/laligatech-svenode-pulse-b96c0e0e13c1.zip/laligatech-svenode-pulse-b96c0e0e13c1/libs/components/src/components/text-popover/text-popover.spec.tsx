import { axe, toHaveNoViolations } from "jest-axe";
import { screen } from "@testing-library/react";

import { TextPopover } from "./text-popover";
import type { TextPopoverProps } from "./text-popover.types";

import { render } from "@test-utils";

const defaultProps: TextPopoverProps = {
  text: "Link Popover",
  popoverContent: <span>Popover content</span>,
  popoverTitle: "Header Popover",
};

function DefaultTextPopover(props: Partial<TextPopoverProps>) {
  return <TextPopover {...defaultProps} {...props} />;
}

describe("defaultTextPopover test suit", () => {
  expect.extend(toHaveNoViolations);

  it("should render component correctly", async () => {
    const { container } = render(<DefaultTextPopover />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
  });

  it("should render button with the text correctly", async () => {
    const { container } = render(<DefaultTextPopover />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
    expect(
      screen.getByRole("button", { name: defaultProps.text as string })
    ).toBeInTheDocument();
  });

  it("should render popover content when click on triger button and placement is buttom left", async () => {
    const { container, user } = render(
      <DefaultTextPopover placement="bottom left" />
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button", {
      name: defaultProps.text as string,
    });

    await user.click(triggerButton);

    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });

  it("should render popover content when click on triger button and placement is top left", async () => {
    const { container, user } = render(
      <DefaultTextPopover placement="top left" />
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button", {
      name: defaultProps.text as string,
    });

    await user.click(triggerButton);

    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });

  it("should render popover content when click on triger button and placement is bottom right", async () => {
    const { container, user } = render(
      <DefaultTextPopover placement="bottom right" />
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button", {
      name: defaultProps.text as string,
    });

    await user.click(triggerButton);

    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });

  it("should render popover content when click on triger button and placement is top right", async () => {
    const { container, user } = render(
      <DefaultTextPopover placement="top right" />
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button", {
      name: defaultProps.text as string,
    });

    await user.click(triggerButton);

    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });
});
