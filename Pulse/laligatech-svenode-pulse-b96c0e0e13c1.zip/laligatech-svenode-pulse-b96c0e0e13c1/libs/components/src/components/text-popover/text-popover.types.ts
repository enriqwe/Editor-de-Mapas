type Placement =
  | "bottom"
  | "bottom left"
  | "bottom right"
  | "top"
  | "top left"
  | "top right"
  | "left"
  | "left top"
  | "left bottom"
  | "right"
  | "right top"
  | "right bottom";

export type TextPopoverProps = {
  automationContext?: string;
  placement?: Placement;
  popoverContent: React.ReactElement;
  popoverTitle: string;
  text: string | React.ReactElement;
};
