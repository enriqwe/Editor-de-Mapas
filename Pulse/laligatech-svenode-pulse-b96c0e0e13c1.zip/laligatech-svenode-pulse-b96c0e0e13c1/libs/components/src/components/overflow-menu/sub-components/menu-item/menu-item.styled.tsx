import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const MenuItemContainer = styled.div`
  padding: ${cssVars.spacing.x4};
`;

export const MenuItem = styled.li`
  display: flex;
  gap: ${cssVars.spacing.x8};
  padding: ${cssVars.spacing.x8};
  font: ${cssVars.text.bodyBaseRegular};
  color: ${cssVars.color.textBody};
  border-radius: ${cssVars.border.radiusS};
  box-sizing: border-box;

  cursor: pointer;

  &:hover:not(:disabled),
  &:focus-visible {
    background-color: ${cssVars.color.bgItemHover};
  }

  &:focus {
    outline-offset: 2px;
    outline: ${cssVars.border.widthS} solid ${cssVars.color.borderFocus};
  }
`;
