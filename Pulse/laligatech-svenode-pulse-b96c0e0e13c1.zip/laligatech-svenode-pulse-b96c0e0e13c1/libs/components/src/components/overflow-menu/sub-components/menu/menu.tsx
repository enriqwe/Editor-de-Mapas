import type { Key } from "react";
import { useRef } from "react";
import type { AriaMenuProps } from "react-aria";
import { useMenu } from "react-aria";
import { useTreeState } from "react-stately";

import { MenuItem } from "../menu-item/menu-item";

import * as S from "./menu.styled";

type MenuProps<T> = AriaMenuProps<T>;

export function Menu<T extends object>(props: MenuProps<T>) {
  const state = useTreeState(props);

  const menuContainerRef = useRef(null);
  const { menuProps } = useMenu(props, state, menuContainerRef);

  return (
    <S.MenuContainer {...menuProps} ref={menuContainerRef}>
      {[...state.collection].map(item => (
        <MenuItem
          item={item}
          key={item.key as Key}
          // onAction={props.onAction}
          // onClose={props.onClose}
          state={state}
        />
      ))}
    </S.MenuContainer>
  );
}
