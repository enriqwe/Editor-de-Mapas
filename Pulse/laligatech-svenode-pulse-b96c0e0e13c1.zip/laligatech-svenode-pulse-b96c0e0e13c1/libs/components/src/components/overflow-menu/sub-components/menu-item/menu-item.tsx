import { useRef } from "react";
import { mergeProps, useMenuItem } from "react-aria";
import type { Node, TreeState } from "react-stately";

import * as S from "./menu-item.styled";

type MenuItemProps<T> = {
  item: Node<T>;
  state: TreeState<T>;
};

export function MenuItem<T>({ item, state }: MenuItemProps<T>) {
  const MenuItemRef = useRef(null);
  const { menuItemProps } = useMenuItem(
    {
      key: item.key,
    },
    state,
    MenuItemRef
  );

  return (
    <S.MenuItemContainer>
      <S.MenuItem {...mergeProps(menuItemProps)} ref={MenuItemRef}>
        {item.rendered}
      </S.MenuItem>
    </S.MenuItemContainer>
  );
}
