import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const MenuContainer = styled.ul`
  background: ${cssVars.color.surfacePrimary};
  border-radius: ${cssVars.border.radiusS};
  min-width: 177px;
  overflow: auto;
  list-style: none;
  padding: 0;
  margin: 0;
  padding: ${cssVars.spacing.x8};
`;
