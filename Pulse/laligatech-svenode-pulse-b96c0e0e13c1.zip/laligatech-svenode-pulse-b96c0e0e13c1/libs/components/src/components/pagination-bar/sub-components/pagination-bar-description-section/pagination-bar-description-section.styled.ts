import styled from "styled-components";

export const PaginationBarDescriptionSection = styled.div`
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.regular)};
  font-family: ${({ theme }) => theme.font.fontFamily};
  color: ${({ theme }) => theme.color.text.body};
`;
