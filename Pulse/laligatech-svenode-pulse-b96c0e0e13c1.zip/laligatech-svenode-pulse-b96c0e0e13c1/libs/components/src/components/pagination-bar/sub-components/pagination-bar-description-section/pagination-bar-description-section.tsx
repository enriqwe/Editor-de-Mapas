import * as S from "./pagination-bar-description-section.styled";

import { useTranslation } from "@providers/translation";

type PaginationBarDescriptionSectionProps = {
  currentPage: number;
  lastPage: number;
  totalItems: number;
  currentPageSize: number;
};

export function PaginationBarDescriptionSection(
  props: PaginationBarDescriptionSectionProps
) {
  const translate = useTranslation();
  const { currentPage, lastPage, totalItems, currentPageSize } = props;

  return (
    <S.PaginationBarDescriptionSection data-testid="pagination-bar-description">
      {translate("paginationBar.Description", {
        currentPage:
          currentPage === lastPage ? totalItems : currentPageSize * currentPage,
        totalItems,
      })}
    </S.PaginationBarDescriptionSection>
  );
}
