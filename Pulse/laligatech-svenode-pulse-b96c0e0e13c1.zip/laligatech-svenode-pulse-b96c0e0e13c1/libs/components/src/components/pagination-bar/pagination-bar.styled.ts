import styled from "styled-components";

export const PaginationBarContainer = styled.div`
  display: flex;
  align-items: center;

  justify-content: space-between;
  background: ${({ theme }) => theme.color.background.paginationBar};
  border-radius: ${({ theme }) => theme.border.radiusS};
  height: 40px;
  padding: ${({ theme }) => `${theme.spacing.x8} ${theme.spacing.x16}`};
`;

export const PaginationBarPageSize = styled.span`
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.bold)};
`;
