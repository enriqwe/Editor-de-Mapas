import styled from "styled-components";

export const PaginationBarInput = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x8};
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.regular)};
  font-family: ${({ theme }) => theme.font.fontFamily};
  color: ${({ theme }) => theme.color.text.card.subHeader};

  input {
    border: ${({ theme }) => `${theme.border.widthXS} solid #858585`};
    text-align: center;
  }
`;

export const PaginationBarLastPage = styled.span`
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.sm, theme.font.weights.bold)};
  color: ${({ theme }) => theme.color.text.accordion.subLabel};
`;

export const PaginationBarOfLabel = styled.span`
  color: ${({ theme }) => theme.color.text.accordion.subLabel};
`;

export const PaginationBarButtonSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x16};

  button:disabled {
    background: transparent;
  }
`;
