import { screen } from "@testing-library/react";

import { PaginationBar } from "./pagination-bar";

import { render } from "@test-utils";

describe("paginationBar", () => {
  it("should render successfully", () => {
    const onPageChange = jest.fn();
    const { baseElement } = render(
      <PaginationBar
        currentPage={2}
        currentPageSize={10}
        onPageChange={onPageChange}
        onPageSizeChange={onPageChange}
        pageSizesList={[]}
        totalItems={11}
      />
    );
    expect(baseElement).toBeTruthy();
  });

  it("should change the page number by input successfully", () => {
    const onPageChange = jest.fn();
    render(
      <PaginationBar
        onPageChange={onPageChange}
        onPageSizeChange={onPageChange}
        pageSizesList={[]}
        totalItems={100}
      />
    );
    const input = screen.getByRole("textbox");
    expect(input.getAttribute("value")).toBe("1");

    const nextButton = screen.getByTestId("pagination-bar-next-button");
    const prevButton = screen.getByTestId("pagination-bar-previous-button");
    expect(prevButton.getAttribute("disabled")).toBe("");
    expect(nextButton.getAttribute("disabled")).toBe(null);
  });

  it("should change the data per page by dropdown", () => {
    const onPageChange = jest.fn();
    render(
      <PaginationBar
        currentPageSize={15}
        onPageChange={onPageChange}
        onPageSizeChange={onPageChange}
        pageSizesList={[15, 30]}
        totalItems={40}
      />
    );

    expect(screen.getByText("15")).toBeInTheDocument();
    expect(screen.queryByText("30")).not.toBeInTheDocument();
  });
});

describe("paginationBar - i18n", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should render with translated text (locale "es")', async () => {
    const onPageChange = jest.fn();

    render(
      <PaginationBar
        currentPage={2}
        currentPageSize={10}
        onPageChange={onPageChange}
        onPageSizeChange={onPageChange}
        pageSizesList={[]}
        totalItems={11}
      />
    );

    const descriptionElement = await screen.findByTestId(
      "pagination-bar-description"
    );
    expect(descriptionElement.textContent).toEqual(
      "Mostrando 11 de 11 resultados"
    );
  });

  it('should render with translated text (locale "en")', async () => {
    const onPageChange = jest.fn();

    render(
      <PaginationBar
        currentPage={2}
        currentPageSize={10}
        locale="en-US"
        onPageChange={onPageChange}
        onPageSizeChange={onPageChange}
        pageSizesList={[]}
        totalItems={11}
      />
    );

    const descriptionElement = await screen.findByTestId(
      "pagination-bar-description"
    );
    expect(descriptionElement.textContent).toEqual("Showing 11 of 11 results");
  });
});
