import { useEffect, useState } from "react";

import * as S from "./pagination-bar-button-section.styled";

import { useTranslation } from "@providers/translation";
import { IconButton } from "@components/icon-button";
import { Input } from "@components/input";

export type PaginationBarButtonSectionProps = {
  previousPage: () => void;
  lastPage: number;
  nextPage: () => void;
  currentPage: number;
  onPageChange: (input: number) => void;
};

export function PaginationBarButtonSection({
  previousPage,
  lastPage,
  nextPage,
  currentPage,
  onPageChange,
}: PaginationBarButtonSectionProps) {
  const translate = useTranslation();

  const [inputValue, setInputValue] = useState<string>(currentPage.toString());

  useEffect(() => {
    setInputValue(String(currentPage));
  }, [currentPage, setInputValue]);

  return (
    <S.PaginationBarButtonSection>
      <IconButton
        data-testid="pagination-bar-previous-button"
        iconName="chevron_left"
        isDisabled={currentPage === 1}
        onPress={previousPage}
      />
      <S.PaginationBarInput>
        <Input
          aria-label="Page Number"
          inputSize={currentPage.toString().length}
          label=""
          onBlur={() => {
            const value = Number(inputValue);
            if (!isNaN(value) && value > 0 && value <= lastPage) {
              onPageChange(value);
            } else {
              setInputValue(String(currentPage));
            }
          }}
          onChange={setInputValue}
          onKeyDown={event => {
            const intInputValue = parseInt(inputValue);
            event.key === "Enter" &&
              onPageChange(intInputValue > lastPage ? lastPage : intInputValue);
          }}
          value={inputValue}
        />
        <S.PaginationBarOfLabel>
          {translate("paginationBar.PagesSeparator")}
        </S.PaginationBarOfLabel>
        <S.PaginationBarLastPage>{lastPage}</S.PaginationBarLastPage>
      </S.PaginationBarInput>
      <IconButton
        data-testid="pagination-bar-next-button"
        iconName="chevron_right"
        isDisabled={currentPage === lastPage}
        onPress={nextPage}
      />
    </S.PaginationBarButtonSection>
  );
}
