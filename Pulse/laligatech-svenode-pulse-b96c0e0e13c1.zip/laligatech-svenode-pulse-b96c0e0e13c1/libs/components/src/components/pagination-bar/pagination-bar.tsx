import * as S from "./pagination-bar.styled";
import {
  PaginationBarDropdown,
  PaginationBarDescriptionSection,
  PaginationBarButtonSection,
} from "./sub-components";

import { TranslationProvider } from "@providers/translation";
import type { Locale } from "@providers/translation";
import { automationClass } from "@utils/automation-class";

export type PaginationBarProps = {
  /** @deprecated Use currentPageSize instead */
  defaultPageSize?: number;
  /** @deprecated Use pageSizesList instead */
  dataPerPagesOption?: number[];
  /** @deprecated Use onPageSizeChange instead */
  setPageSize?: (pageSize: number) => void;
  automationContext?: string;
  currentPage?: number;
  onPageChange: (pageNum: number) => void;
  /** List of possible items per page */
  pageSizesList?: number[];
  currentPageSize?: number;
  onPageSizeChange: (pageNum: number) => void;
  /** @deprecated use totalItems instead */
  totalDataCount?: number;
  totalItems: number;
  locale?: Locale;
};

export function PaginationBar(props: PaginationBarProps) {
  const {
    automationContext = "",
    currentPage = 1,
    currentPageSize = 10,
    // defaultPageSize = 10,
    pageSizesList = [10, 20, 50],
    // currentPageSize = 10,
    locale = "es-ES",
    onPageChange,
    onPageSizeChange,
    totalItems,
  } = props;

  // const [currentPageSize, setCurrentPageSize] = useState<number>(defaultPageSize);
  const automationClasses = automationClass("paginationBar", automationContext);

  const previousPage = () => {
    onPageChange(currentPage - 1);
  };

  const nextPage = () => {
    onPageChange(currentPage + 1);
  };

  const lastPage = Math.ceil(totalItems / currentPageSize);

  return (
    <TranslationProvider locale={locale}>
      <S.PaginationBarContainer
        className={automationClasses}
        data-testid="pagination-bar"
      >
        <PaginationBarDescriptionSection
          currentPage={currentPage}
          currentPageSize={currentPageSize}
          lastPage={lastPage}
          totalItems={totalItems}
        />

        <PaginationBarButtonSection
          currentPage={currentPage}
          lastPage={lastPage}
          nextPage={nextPage}
          onPageChange={onPageChange}
          previousPage={previousPage}
        />
        <PaginationBarDropdown
          currentPageSize={currentPageSize}
          onPageSizeChange={onPageSizeChange}
          pageSizesList={pageSizesList}
        />
      </S.PaginationBarContainer>
    </TranslationProvider>
  );
}
