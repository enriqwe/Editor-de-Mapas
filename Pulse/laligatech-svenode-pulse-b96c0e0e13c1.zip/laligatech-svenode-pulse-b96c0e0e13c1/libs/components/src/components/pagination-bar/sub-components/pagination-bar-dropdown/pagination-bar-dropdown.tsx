import { useTranslation } from "@providers/translation";
import { Dropdown } from "@components/dropdown";

type PaginationBarDropdownProps = {
  currentPageSize: number;
  pageSizesList: number[];
  onPageSizeChange: (pageSize: number) => void;
};

export function PaginationBarDropdown({
  currentPageSize,
  pageSizesList,
  onPageSizeChange,
}: PaginationBarDropdownProps) {
  const translate = useTranslation();

  const pagesList = pageSizesList.map(pageSize => ({
    value: String(pageSize),
    label: String(pageSize),
  }));

  return (
    <Dropdown
      dropdownInline
      label={translate("paginationBar.LinesPerPage")}
      menuPlacement="top"
      noOptionsMessage=""
      onSelectedOption={optionEvents => {
        // Checking that is not an array is just a workaround to avoid the error on type on dropdown
        !Array.isArray(optionEvents) &&
          onPageSizeChange(Number(optionEvents.value));
      }}
      options={pagesList}
      placeholder=""
      selectedOption={{
        value: String(currentPageSize),
        label: String(currentPageSize),
      }}
    />
  );
}
