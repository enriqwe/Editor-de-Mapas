import { dirname, join } from "path";

const config = {
  staticDir: "../public",
  stories: [
    {
      directory: '../stories/documentation',
      titlePrefix: 'Documentation',
    },
    {
      directory: '../stories/foundations',
      titlePrefix: 'Foundations',
    },
    {
      directory: '../stories/components',
      titlePrefix: 'Components',
    },
  ],
  addons: [
    "@storybook/addon-links",
    "@storybook/addon-a11y",
    "@storybook/addon-designs",
    "@storybook/addon-docs"
  ],
  framework: {
    name: "@storybook/react-vite",
    options: {},
  },

  core: {
    disableTelemetry: true, // 👈 Disables telemetry
  },

  async viteFinal(config, { configType }) {
    // customize the Vite config here
    return {
      ...config,
      define: { "process.env": {} },
      resolve: {
      },
    };
  },
};

export default config;
