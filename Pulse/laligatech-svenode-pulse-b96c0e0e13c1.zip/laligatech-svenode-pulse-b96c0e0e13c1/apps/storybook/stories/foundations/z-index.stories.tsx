import type { StoryObj, Meta } from "@storybook/react-vite";
import styled, { useTheme } from "styled-components";

import { StoryContainer } from "../utils/components";

// import { zIndex, ZIndexProp } from "./zIndex";

const StyledZIndexBox = styled.div<{ $zIndexValue: number; $margin: number }>`
  display: flex;
  justify-content: space-between;
  background: rgba(111, 161, 263, 0.65);
  z-index: ${props => props.$zIndexValue};
  position: absolute;
  color: #fff;
  box-shadow: -7px -7px 16px 0px rgba(41, 39, 39, 0.75);
  -webkit-box-shadow: -7px -7px 16px 0px rgba(41, 39, 39, 0.75);
  -moz-box-shadow: -7px -7px 16px 0px rgba(41, 39, 39, 0.75);
  font-weight: 700;
  font-size: 1.5rem;
  padding: 0px 20px 0px 20px;
  border: 2px solid gray;
  border-radius: 0.25rem;
  height: 200px;
  width: 400px;
  left: ${props => props.$margin * 2}px;
  top: ${props => props.$margin}px;
`;

const RelativeContainer = styled.div`
  position: relative;
`;

function ZIndexBox({
  zIndexVal,
  zIndexName,
  margin,
}: {
  zIndexVal: number;
  zIndexName: string;
  margin: number;
}) {
  return (
    <StyledZIndexBox $margin={margin} $zIndexValue={zIndexVal}>
      <span>{zIndexName}</span>
      <span>{zIndexVal}</span>
    </StyledZIndexBox>
  );
}

function ZIndex() {
  const { zIndex } = useTheme();
  const zIndexKeys = Object.keys(zIndex) as (keyof typeof zIndex)[];
  return (
    <RelativeContainer>
      {zIndexKeys
        .sort((a, b) => zIndex[a] - zIndex[b])
        .map((zIndexName, i) => (
          <ZIndexBox
            key={zIndexName}
            margin={i * 40}
            zIndexName={zIndexName}
            zIndexVal={zIndex[zIndexName]}
          />
        ))}
    </RelativeContainer>
  );
}

const meta: Meta<typeof ZIndex> = {
  title: "ZIndex",
  component: ZIndex,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof ZIndex>;

export const ZIndexTokens: Story = {
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1504%3A8835&t=QyZVTdPW266KGihs-0",
    },
  },
  render: () => <ZIndex />,
};
