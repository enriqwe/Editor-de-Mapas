import styled from "styled-components";

export const StoryContainer = styled.div`
  ${({ theme }) => theme.text.bodyBaseRegular};
`;
