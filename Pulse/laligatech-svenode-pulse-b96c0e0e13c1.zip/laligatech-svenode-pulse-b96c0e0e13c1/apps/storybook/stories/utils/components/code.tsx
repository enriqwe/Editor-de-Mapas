import styled from "styled-components";

type CodeProps = {
  children: React.ReactNode;
};

const StyledPre = styled.pre`
  clear: both;
  color: #fff;
  background: #1b1b1b;
  padding: 0;
  tab-size: 2;
  word-break: normal;
  hyphens: none;
  position: relative;
  line-height: 28px;
  border-radius: 8px;

  code {
    background: none;
    white-space: pre;
    display: block;
    max-width: 100%;
    min-width: 100px;
    font-size: 14px;
    padding: ${({ theme }) =>
      `${theme.spacing.x16} ${theme.spacing.x20} ${theme.spacing.x12} ${theme.spacing.x20}`};
    line-height: 1.75;

    strong {
      color: red;
    }
  }
`;

export function Code({ children }: CodeProps) {
  return (
    <StyledPre>
      <code>{children}</code>
    </StyledPre>
  );
}
