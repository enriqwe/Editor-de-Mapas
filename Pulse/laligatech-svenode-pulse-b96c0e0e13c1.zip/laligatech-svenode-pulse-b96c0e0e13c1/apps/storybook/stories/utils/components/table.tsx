import styled from "styled-components";

type TableProps = {
  headers: string[];
  children: React.ReactNode;
};

export function Table({ headers = [], children }: TableProps) {
  return (
    <StyledTable>
      <thead>
        <tr>
          {headers.map(header => (
            <th key={header}>{header}</th>
          ))}
        </tr>
      </thead>
      <tbody>{children}</tbody>
    </StyledTable>
  );
}

const StyledTable = styled.table`
  text-align: left;

  ${({ theme }) => theme.text.bodyBaseRegular};

  td {
    padding: 4px 8px;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  tbody {
    border: 1px solid #e5e7eb;
  }
`;
