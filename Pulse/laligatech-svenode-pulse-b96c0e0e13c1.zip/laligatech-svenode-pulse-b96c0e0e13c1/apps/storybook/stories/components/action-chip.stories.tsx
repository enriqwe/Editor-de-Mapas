import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { ActionChip as ActionComponent } from "@pulse/components/action-chip";

// @ts-expect-error - Fix for storybook issue with names in code
ActionComponent.displayName = "ActionChip";

const meta: Meta<typeof ActionComponent> = {
  component: ActionComponent,
  title: "Chips/ActionChip",
  args: {
    onClick: fn(),
  },
  argTypes: {
    variant: {
      options: ["outlined", "filled"],
      control: "select",
      table: {
        defaultValue: { summary: "outlined" },
      },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1245%3A8503&t=TEaz5CNnWWADmSnA-0",
    },
  },
};
export default meta;

type Story = StoryObj<typeof ActionComponent>;

export const Simple: Story = {
  args: {
    label: "Label 1",
    disabled: false,
    automationContext: "add-item",
    variant: "outlined",
  },
};

export const WithIcons: Story = {
  args: {
    label: "Label 1",
    iconLeft: "add_circle",
    iconRight: "delete",
    disabled: false,
    automationContext: "add-item",
    variant: "outlined",
  },
};
