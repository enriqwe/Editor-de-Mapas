import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Icon } from "@pulse/components/icon";

// @ts-expect-error - Fix for storybook issue with names in code
Icon.displayName = "Icon";

const meta: Meta<typeof Icon> = {
  component: Icon,
  title: "Icon",
  args: {
    onClick: fn(),
  },
  argTypes: {
    size: {
      control: "select",
      options: ["xs", "s", "m", "l", "xl"],
    },
    color: {
      control: "color",
    },
    hoverColor: {
      control: "color",
    },
  },
  // color: { control: "color" },
  /*
  hoverColor: { control: "color" },
  showHoverAndActiveState: {
    defaultValue: {
      summary: false,
    },
  }, */
};
export default meta;

type Story = StoryObj<typeof Icon>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1973-18965&t=LuLq6SjSbNJJm8Gc-0",
  },
  layout: "centered",
};

export const Default: Story = {
  args: {
    icon: "settings",
    state: "default",
    fill: false,
    size: "m",
    showHoverAndActiveState: false,
    automationContext: "settings",
    tooltipContent: "tooltip text",
    color: "#FF0000",
    hoverColor: "#0000FF",
  },
  parameters: defaultParams,
};
