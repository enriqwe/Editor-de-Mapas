import type { Meta, StoryObj } from "@storybook/react-vite";
import { Dropdown } from "@pulse/components/dropdown";
import { Avatar } from "@pulse/components/avatar";
import { action } from "storybook/actions";

import {
  options,
  groupedOptions,
  numberOptions,
  otherGroupedOptions,
} from "../sampleData/dropdown";

// @ts-expect-error - Fix for storybook issue with names in code
Dropdown.displayName = "Dropdown";

const meta: Meta<typeof Dropdown> = {
  component: Dropdown,
  title: "form/Dropdown",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1540%3A9379&t=3squNbLOqUnEHeP7-0",
    },
  },
  decorators: [
    Story => (
      <div style={{ width: "400px" }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;

type Story = StoryObj<typeof Dropdown>;

export const SingleSelect: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    selectedOption: { value: "value two", label: "Option two" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
  },
};

// export const SingleSelectControlled: Story = {
//   args: {
//     label: "Label Dropdown",
//     options: options,
//     additionalText: "Additional text",
//     onSelectedOption: e => !Array.isArray(e) && action(e?.value),
//     onBlur: () => action("onBlur"),
//     placeholder: "Choose an option",
//     noOptionsMessage: "No options",
//     required: true,
//     disabled: false,
//     multi: false,
//     error: false,
//     closeMenuOnSelect: true,
//     hideSelectedOptions: false,
//     automationContext: "select-size",
//     isClearable: true,
//     value: { value: "value four", label: "Option four" },
//   },
// };

export const MultiSelect: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    selectedOption: { value: "value one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Choose an option",
    noOptionsMessage: "NO RESULTS",
    required: true,
    disabled: false,
    multi: true,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: true,
    automationContext: "select-city",
  },
};

export const MultiSelectWithFixedItems: Story = {
  args: {
    label: "Label Dropdown",
    options: [
      { value: "value one", label: "Option one" },
      { value: "value two", label: "Option two", isFixed: true },
      { value: "value three", label: "Option three", isDisabled: true },
      { value: "value four", label: "Option four" },
      { value: "value five", label: "Option five", isFixed: true },
      { value: "value six", label: "Option six" },
      { value: "value seven", label: "Option seven" },
      { value: "value eight", label: "Option eight" },
      { value: "value nine", label: "Option nine" },
    ],
    additionalText: "Additional text",
    selectedOption: { value: "value one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Choose an option",
    noOptionsMessage: "NO RESULTS",
    required: true,
    disabled: false,
    multi: true,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
  },
};

export const GroupedOptions: Story = {
  args: {
    label: "Label Dropdown",
    options: groupedOptions,
    additionalText: "Additional text",
    selectedOption: { value: "value one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    automationContext: "select-size",
  },
};

export const MultilevelOptions: Story = {
  args: {
    label: "Label Dropdown",
    options: otherGroupedOptions,
    additionalText: "Additional text",
    selectedOption: { value: "value one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    multiLevel: true,
  },
};

function AvatarComponent({ label }: { label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <Avatar name={label} size="s" />
      {label}
    </div>
  );
}

export const Transparent: Story = {
  args: {
    label: "Label Dropdown",
    placeholder: "Select..",
    options,
    noOptionsMessage: "No options",
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    required: false,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    transparent: true,
    searchable: false,
    customDropdownValue: false,
  },
};

export const TransparentCustomValue: Story = {
  args: {
    label: "Label Dropdown",
    placeholder: <AvatarComponent label="User name" />,
    options,
    noOptionsMessage: "No options",
    required: false,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    transparent: true,
    searchable: false,
    customDropdownValue: true,
  },
};

export const DropdownInline: Story = {
  args: {
    label: "Label",
    options: numberOptions,
    selectedOption: { value: "15", label: "15" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
    dropdownInline: true,
  },
};

export const WithLabelTooltipContent: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    selectedOption: { value: "value two", label: "Option two" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
    labelTooltipContent: "Text Tooltip",
  },
};

export const InlineWithTooltip: Story = {
  args: {
    label: "Label",
    options: numberOptions,
    selectedOption: { value: "15", label: "15" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Choose an option",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
    dropdownInline: true,
    labelTooltipContent: "Text Tooltip",
  },
};
