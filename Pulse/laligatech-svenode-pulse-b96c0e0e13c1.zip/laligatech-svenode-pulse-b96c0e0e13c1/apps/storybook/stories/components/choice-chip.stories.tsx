import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { ChoiceChip as ChoiceComponent } from "@pulse/components/choice-chip";

// @ts-expect-error - Fix for storybook issue with names in code
ChoiceComponent.displayName = "ChoiceChip";

const meta: Meta<typeof ChoiceComponent> = {
  component: ChoiceComponent,
  title: "Chip",
  args: {
    onClick: fn(),
  },
  argTypes: {
    variant: {
      options: ["outlined", "filled"],
      control: "select",
      table: {
        defaultValue: { summary: "outlined" },
      },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1245%3A8503&t=TEaz5CNnWWADmSnA-0",
    },
  },
};
export default meta;

type Story = StoryObj<typeof ChoiceComponent>;

export const ChoiceChip: Story = {
  args: {
    label: "Label 2",
    iconLeft: "add_circle",
    iconRight: "add_circle",
    disabled: false,
    selected: false,
    automationContext: "select-item",
    variant: "outlined",
  },
};
