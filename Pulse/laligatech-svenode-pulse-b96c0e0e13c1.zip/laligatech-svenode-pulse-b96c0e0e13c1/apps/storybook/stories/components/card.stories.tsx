import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { Card } from "@pulse/components/card";

// @ts-expect-error - Fix for storybook issue with names in code
Card.displayName = "Card";

const meta: Meta<typeof Card> = {
  component: Card,
  title: "Card",
  args: {
    title: "Title",
  },
  argTypes: {
    icon: {
      control: {
        type: "text",
      },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=11173%3A77359&mode=dev",
    },
  },
};

export default meta;

type Story = StoryObj<typeof Card>;

export const Simple: Story = {
  args: {
    title: "This is a title",
    description: "This is an optional description",
    children: <div>Body content</div>,
    automationContext: "contains-topic-info",
  },
};

export const WithActions: Story = {
  args: {
    title: "Title",
    description: "Description",
    actions: [
      {
        iconName: "house",
        tooltipContent: "tooltip text",
        onClick: action("first icon button clicked"),
      },
      {
        iconName: "settings",
        tooltipContent: "tooltip text",
        onClick: action("second icon button clicked"),
      },
    ],
    children: <div>Body content</div>,
    automationContext: "contains-topic-info",
  },
};

export const WithTag: Story = {
  args: {
    title: "Title",
    description: "Description",
    tag: {
      label: "State",
      variant: "informative",
      automationContext: "informative",
    },
    children: <div>Body content</div>,
    automationContext: "contains-topic-info",
  },
};

export const FullUsage: Story = {
  args: {
    title: "Title",
    description: "Description",
    tag: {
      label: "State",
      variant: "informative",
      automationContext: "informative",
    },
    icon: "house",
    actions: [
      {
        iconName: "house",
        tooltipContent: "tooltip text",
        onClick: action("first icon button clicked"),
      },
      {
        iconName: "settings",
        tooltipContent: "tooltip text",
        onClick: action("second icon button clicked"),
      },
    ],
    children: <div>Body content</div>,
    automationContext: "contains-topic-info",
  },
};
