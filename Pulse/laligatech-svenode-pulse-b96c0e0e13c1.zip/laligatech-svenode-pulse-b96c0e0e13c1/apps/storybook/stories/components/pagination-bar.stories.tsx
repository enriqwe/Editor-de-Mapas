import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { action } from "storybook/actions";
import { PaginationBar } from "@pulse/components/pagination-bar";
import type { PaginationBarProps } from "@pulse/components/pagination-bar";

// @ts-expect-error - Fix for storybook issue with names in code
PaginationBar.displayName = "PaginationBar";

const meta: Meta<typeof PaginationBar> = {
  component: PaginationBar,
  title: "PaginationBar",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=34143-23683&t=gEZYXOXBO2MzJTVn-0",
    },
  },
  argTypes: {
    locale: {
      options: ["es-ES", "fr-FR", "en-EN", "de-DE"],
      control: {
        type: "select",
      },
    },
  },
};

export default meta;

type Story = StoryObj<typeof PaginationBar>;

function PaginationBarWithState(args: PaginationBarProps) {
  const {
    currentPage = 1,
    pageSizesList = [10, 20, 50],
    // onPageChange,
    currentPageSize = 10,
    // setPageSize,
    totalItems,
    automationContext = "",
    locale = "es-ES",
  } = args;

  const [activePage, setActivePage] = useState(currentPage);
  const [pageSize, setPageSize] = useState(currentPageSize);

  return (
    <PaginationBar
      automationContext={automationContext}
      currentPage={activePage}
      currentPageSize={pageSize}
      locale={locale}
      onPageChange={nextPageNumber => {
        action("onPageChange Clicked")(nextPageNumber);
        setActivePage(nextPageNumber);
      }}
      onPageSizeChange={nextPageSize => {
        action("setPageSize Clicked")(nextPageSize);
        setPageSize(nextPageSize);
      }}
      pageSizesList={pageSizesList}
      totalItems={totalItems}
    />
  );
}

export const Simple: Story = {
  args: {
    currentPage: 1,
    onPageChange: action("onPageChange triggered"),
    currentPageSize: 10,
    onPageSizeChange: action("onPageSizeChange triggered"),
    totalItems: 34,
    pageSizesList: [10, 20, 50],
    locale: "es-ES",
    automationContext: "pagination",
  },
};

export const WithState: Story = {
  args: {
    currentPage: 1,
    onPageChange: action("onPageChange triggered"),
    currentPageSize: 10,
    onPageSizeChange: action("onPageSizeChange triggered"),
    totalItems: 34,
    pageSizesList: [10, 20, 50],
    locale: "es-ES",
    automationContext: "pagination",
  },
  render: args => <PaginationBarWithState {...args} />,
};
