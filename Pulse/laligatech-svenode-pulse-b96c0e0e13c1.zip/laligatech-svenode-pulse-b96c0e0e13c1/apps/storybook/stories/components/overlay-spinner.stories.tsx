import type { Meta, StoryObj } from "@storybook/react-vite";
import { OverlaySpinner } from "@pulse/components/overlay-spinner";

// @ts-expect-error - Fix for storybook issue with names in code
OverlaySpinner.displayName = "OverlaySpinner";

const meta: Meta<typeof OverlaySpinner> = {
  component: OverlaySpinner,
  title: "loading/OverlaySpinner",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/CMS-Core-Documentation?type=design&node-id=10246-72193&mode=design&t=pfoglz0DjmN11v48-4",
    },
  },
};

export default meta;

type Story = StoryObj<typeof OverlaySpinner>;

export const Dark: Story = {
  args: {
    text: "Loading...",
    overlay: "dark",
  },
};

export const Light: Story = {
  args: {
    text: "Loading...",
    overlay: "light",
  },
};
