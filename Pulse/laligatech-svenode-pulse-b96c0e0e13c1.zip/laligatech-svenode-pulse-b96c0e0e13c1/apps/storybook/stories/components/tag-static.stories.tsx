import type { Meta, StoryObj } from "@storybook/react-vite";
import { StaticTag as StaticTagComponent } from "@pulse/components/tag";

// @ts-expect-error - Fix for storybook issue with names in code
StaticTagComponent.displayName = "StaticTag";

const meta: Meta<typeof StaticTagComponent> = {
  component: StaticTagComponent,
  title: "Tags/StaticTag",
  argTypes: {
    variant: {
      control: "select",
      options: ["success", "error", "informative", "pending", "warning", "tip"],
    },
    size: {
      control: "radio",
      options: ["small", "large"],
    },
    tooltip: {
      control: "boolean",
    },
  },
  parameters: {
    layout: "centered",
  },
};

export default meta;

type Story = StoryObj<typeof StaticTagComponent>;

export const Default: Story = {
  args: {
    label: "informative message",
    size: "small",
    variant: "informative",
    automationContext: "informative",
    tooltip: true,
  },
};
