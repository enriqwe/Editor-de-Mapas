import type { Meta, StoryObj } from "@storybook/react-vite";
import { Accordion } from "@pulse/components/accordion";

// @ts-expect-error - Fix for storybook issue with names in code
Accordion.displayName = "Accordion";

const meta: Meta<typeof Accordion> = {
  component: Accordion,
  title: "Accordion",
  argTypes: {
    accordionNumber: {
      description: "string | number",
    },
    label: {
      description: "string",
    },
    subLabel: {
      description: "string",
    },
    content: {
      description: "children",
    },
    stroke: {
      options: ["ALL", "BOTTOM"],
      control: "radio",
    },
  },
};

export default meta;

type Story = StoryObj<typeof Accordion>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=21262%3A29672&t=fPIecaxgGPnD0ihT-1",
  },
};

export const WithNumberAndSubLabel: Story = {
  args: {
    accordionNumber: "1",
    label: "Header Label",
    subLabel: "Subtitle ",
    stroke: "ALL",
    content: <span>Here is the hidden content!!</span>,
    automationContext: "show-info",
    initialExpanded: true,
  },
  parameters: defaultParams,
};

export const WithNumberAndSubLabelAndTag: Story = {
  args: {
    accordionNumber: "1",
    label: "Header Label",
    subLabel: "Subtitle ",
    stroke: "ALL",
    content: <span>Here is the hidden content!!</span>,
    automationContext: "show-info",
    initialExpanded: true,
    tag: {
      variant: "success",
      label: "State",
    },
  },
  parameters: defaultParams,
};
