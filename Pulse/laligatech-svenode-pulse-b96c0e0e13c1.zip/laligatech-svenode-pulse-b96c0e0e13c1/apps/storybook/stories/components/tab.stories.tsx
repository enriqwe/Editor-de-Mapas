import type { Meta, StoryObj } from "@storybook/react-vite";
import { Tab } from "@pulse/components/tab";

// @ts-expect-error - Fix for storybook issue with names in code
Tab.Group.displayName = "Tab.Group";
// @ts-expect-error - Fix for storybook issue with names in code
Tab.Item.displayName = "Tab.Item";

const meta: Meta<typeof Tab.Group> = {
  component: Tab.Group,
  title: "Tab",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=33086-25445&t=ChRMi6jgCJm2Ohj1-0",
    },
  },
  render: ({ ...args }) => (
    <Tab.Group {...args} automationContext={args.automationContext}>
      {args.children}
    </Tab.Group>
  ),
};

export default meta;

type Story = StoryObj<typeof Tab.Group>;

export const Template: Story = {
  args: {
    defaultSelectedKey: "tab1",
    automationContext: "info-sections",
    children: [
      <Tab.Item key="tab1" title="Tab 1">
        <div>
          <p>Tab 1 Content</p>
        </div>
      </Tab.Item>,
      <Tab.Item key="tab2" title="Tab 2">
        <div>
          <p>Tab 2 Content</p>
        </div>
      </Tab.Item>,
      <Tab.Item key="tab3" title="Tab 3">
        <div>
          <p>Tab 3 Content</p>
        </div>
      </Tab.Item>,
    ],
  },
};

export const WithDisabledTab: Story = {
  args: {
    defaultSelectedKey: "tab2",
    disabledKeys: ["tab3"],
    automationContext: "info-sections",
    children: [
      <Tab.Item key="tab1" title="Tab 1">
        <div>
          <p>Tab 1 Content</p>
        </div>
      </Tab.Item>,
      <Tab.Item key="tab2" title="Tab 2">
        <div>
          <p>Tab 2 Content</p>
        </div>
      </Tab.Item>,
      <Tab.Item key="tab3" title="Tab 3">
        <div>
          <p>Tab 3 Content</p>
        </div>
      </Tab.Item>,
    ],
  },
};
