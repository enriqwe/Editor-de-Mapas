import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import type { DateRangePickerProps } from "@pulse/components/date-range-picker";
import type { CalendarDate } from "@pulse/components/date-utils";
import { DateRangePicker } from "@pulse/components/date-range-picker";
import { today, getLocalTimeZone } from "@pulse/components/date-utils";

// @ts-expect-error - Fix for storybook issue with names in code
DateRangePicker.displayName = "DateRangePicker";

const meta: Meta<typeof DateRangePicker> = {
  component: DateRangePicker,
  title: "form/DateRangePicker",
  args: {
    onChange: fn(),
  },
  argTypes: {
    label: {
      description: "String",
    },
    validationState: {
      description: "String",
      options: ["valid", "invalid"],
      control: { type: "radio" },
    },
    errorMessage: {
      description: "String",
    },
  },
};

export default meta;

type Story = StoryObj<typeof DateRangePicker>;

const now = today(getLocalTimeZone());
const disabledRanges: [CalendarDate, CalendarDate][] = [
  [now, now.add({ days: 5 })],
  [now.add({ days: 14 }), now.add({ days: 16 })],
  [now.add({ days: 23 }), now.add({ days: 24 })],
];

const isDateUnavailable: DateRangePickerProps["isDateUnavailable"] = date =>
  disabledRanges.some(interval => {
    return date.compare(interval[0]) >= 0 && date.compare(interval[1]) <= 0;
  });

export const DefaultAndWithLabel: Story = {
  args: {
    disabled: false,
    isRequired: false,
    description: "Tristique senectus et netus et",
    label: "Example Label",
    validationState: "valid",
    errorMessage: "This is an error message",
    automationContext: "schedule-dates",
  },
};

export const DisabledRange: Story = {
  args: {
    disabled: false,
    isRequired: false,
    description: "Tristique senectus et netus et",
    label: "Example Label",
    validationState: "valid",
    errorMessage: "This is an error message",
    automationContext: "schedule-dates",
    isDateUnavailable,
  },
};
