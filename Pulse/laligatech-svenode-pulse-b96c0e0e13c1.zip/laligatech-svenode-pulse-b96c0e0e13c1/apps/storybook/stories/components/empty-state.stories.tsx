import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { EmptyState } from "@pulse/components/empty-state";

// @ts-expect-error - Fix for storybook issue with names in code
EmptyState.displayName = "EmptyState";

const meta: Meta<typeof EmptyState> = {
  component: EmptyState,
  title: "EmptyState",
  argTypes: {
    illustrationName: {
      description: "Illustration Name",
      options: [
        "Bank",
        "Beach",
        "BillBoard",
        "Calendar",
        "Computer",
        "Crane",
        "Date",
        "Document",
        "Dollar",
        "Drink",
        "Home",
        "Home2",
        "Image",
        "Mountain",
        "NoResultsFound",
        "NothingHere",
        "PiggyBank",
        "PlayVideo",
        "Search",
        "SearchError",
        "Shopping",
        "Stadium",
        "Stand",
        "Tags",
        "ToDo",
        "Welcome",
      ],
      control: { type: "select" },
    },
    actionLabel: {
      description:
        "Label for the action button. Use it together with actionHandler and actionType",
      control: { type: "text" },
    },
    actionType: {
      description: "Type of the action button",
      options: ["primary", "secondary", "tertiary"],
      control: { type: "select" },
      table: {
        defaultValue: { summary: "secondary" },
      },
    },
    actionHandler: {
      description: "Action to be triggered when clicking on action button",
    },
    size: {
      description: "Size of the empty state",
      options: ["s", "m", "l"],
      control: { type: "radio" },
      table: {
        defaultValue: { summary: "l" },
      },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=34947-23945&t=bh7Ug6O3gCvfW95A-0",
    },
    docs: {
      source: {
        excludeDecorators: true,
      },
    },
  },
};

export default meta;

type Story = StoryObj<typeof EmptyState>;

export const Simple: Story = {
  args: {
    title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    subTitle:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. \n Proin dictum dolor vitae enim venenatis gravida",
    illustrationName: "NothingHere",
    automationContext: "no-organizations",
  },
};

export const WithButton: Story = {
  args: {
    title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    subTitle:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. \n Proin dictum dolor vitae enim venenatis gravida",
    actionType: "secondary",
    actionLabel: "Button label",
    actionHandler: action("click"),
    illustrationName: "Mountain",
    automationContext: "no-organizations",
  },
};
