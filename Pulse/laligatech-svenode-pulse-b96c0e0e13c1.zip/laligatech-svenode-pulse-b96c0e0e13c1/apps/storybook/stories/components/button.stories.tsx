import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Button } from "@pulse/components/button";
import { Icon } from "@pulse/components/icon";

// @ts-expect-error - Fix for storybook issue with names in code
Button.displayName = "Button";

const meta: Meta<typeof Button> = {
  component: Button,
  title: "Button",
  args: {
    // onClick: fn(),
    onPress: fn(),
    children: "Label Button",
  },
  argTypes: {
    variant: {
      control: "select",
      options: ["primary", "secondary", "tertiary", "destructive", "ghost"],
    },
    loadingText: {
      control: "text",
      description: "Text to show when loading state is active",
    },
  },
};

export default meta;

type Story = StoryObj<typeof Button>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1033%3A86&t=cUz8Iqj1hwYUyk8y-0",
  },
  layout: "centered",
};

export const Primary: Story = {
  args: {
    variant: "primary",
    isDisabled: false,
    tooltipContent: "tooltip text",
    IconLeft: "add_circle",
    automationContext: "submit",
    isLoading: false,
  },
  parameters: defaultParams,
};

export const Secondary: Story = {
  args: {
    variant: "secondary",
    isDisabled: false,
    automationContext: "accept",
    IconLeft: "add_circle", //As per the new changes it will accept string also for IconLeft/IconRight
    tooltipContent: "tooltip text",
  },
  parameters: defaultParams,
};

export const Tertiary: Story = {
  args: {
    variant: "tertiary",
    isDisabled: false,
    automationContext: "confirm",
  },
  parameters: defaultParams,
};

export const Destructive: Story = {
  args: {
    variant: "destructive",
    isDisabled: false,
    IconRight: "add_circle",
    automationContext: "cancel",
  },
  parameters: defaultParams,
};

export const Ghost: Story = {
  args: {
    variant: "ghost",
    isDisabled: false,
    automationContext: "cancel",
  },
  parameters: defaultParams,
};

export const LoadingState: Story = {
  args: {
    variant: "primary",
    IconLeft: <Icon icon="add_circle" state="normal" />,
    isLoading: true,
    loadingText: "Loading...",
  },
  parameters: defaultParams,
};
