import type { Meta, StoryObj } from "@storybook/react-vite";
import { TextPopover } from "@pulse/components/text-popover";

// @ts-expect-error - Fix for storybook issue with names in code
TextPopover.displayName = "TextPopover";

const meta: Meta<typeof TextPopover> = {
  component: TextPopover,
  title: "TextPopover",
  argTypes: {
    placement: {
      options: [
        "bottom",
        "bottom left",
        "bottom right",
        "top",
        "top left",
        "top right",
        "left",
        "left top",
        "left bottom",
        "right",
        "right top",
        "right bottom",
      ],
      control: "radio",
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/CMS-Core-Components?type=design&node-id=36786-29654&mode=design&t=0FvJFNSQacptPSMS-0",
    },
    layout: "centered",
  },
};

export default meta;

type Story = StoryObj<typeof TextPopover>;

export const Default: Story = {
  args: {
    automationContext: "textPopover",
    placement: "top",
    popoverContent: <span>Popover content</span>,
    popoverTitle: "Header Popover",
    text: "Link Popover",
  },
};

export const BigPopover: Story = {
  args: {
    automationContext: "textPopover",
    placement: "bottom",
    popoverContent: (
      <table>
        <tbody>
          <tr>
            <td>Popover content</td>
          </tr>
          <tr>
            <td>Popover content</td>
          </tr>
          <tr>
            <td>Popover content</td>
          </tr>
          <tr>
            <td>Popover content</td>
          </tr>
          <tr>
            <td>Popover content</td>
          </tr>
        </tbody>
      </table>
    ),
    popoverTitle: "Header Popover",
    text: "Link Popover",
  },
};
