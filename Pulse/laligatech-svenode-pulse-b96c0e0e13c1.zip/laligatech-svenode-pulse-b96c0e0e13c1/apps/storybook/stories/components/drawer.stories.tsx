import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { Drawer } from "@pulse/components/drawer";

// @ts-expect-error - Fix for storybook issue with names in code
Drawer.displayName = "Drawer";

const meta: Meta<typeof Drawer> = {
  component: Drawer,
  title: "Modal/Drawer",
  argTypes: {},
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1245%3A8503&t=TEaz5CNnWWADmSnA-0",
    },
  },
};
export default meta;

type Story = StoryObj<typeof Drawer>;

export const Simple: Story = {
  args: {
    title: "Title",
    description: "Description",
    isOpen: true,
    children: <p>Content</p>,
    onClose: action("close clicked"),
    footerButtons: [
      { label: "Apply", variant: "primary", onClick: action("Apply clicked") },
      { label: "Clear", variant: "tertiary", onClick: action("Clear clicked") },
    ],
  },
};
