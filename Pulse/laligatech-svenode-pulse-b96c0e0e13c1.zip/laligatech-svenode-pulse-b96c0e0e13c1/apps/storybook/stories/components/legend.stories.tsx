import type { Meta, StoryObj } from "@storybook/react-vite";
import { Legend } from "@pulse/components/legend";

// @ts-expect-error - Fix for storybook issue with names in code
Legend.displayName = "Legend";

const meta: Meta<typeof Legend> = {
  component: Legend,
  title: "Legend",
};

export default meta;

type Story = StoryObj<typeof Legend>;

export const BaseLegend: Story = {
  args: {
    items: Array.from({ length: 20 }, (_, index) => ({
      color: "#2E6ED6",
      label: `Item name ${index + 1}`,
    })),
  },
};
