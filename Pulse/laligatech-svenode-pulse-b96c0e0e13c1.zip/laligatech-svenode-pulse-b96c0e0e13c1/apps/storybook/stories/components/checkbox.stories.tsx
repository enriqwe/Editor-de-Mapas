import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Checkbox } from "@pulse/components/checkbox";

Checkbox.displayName = "Checkbox";

const meta: Meta<typeof Checkbox> = {
  component: Checkbox,
  title: "form/Checkbox",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=32608-22848&t=JkXohTaPuRR6zFNF-0",
    },
  },
  args: {
    onChange: fn(),
  },
  argTypes: {
    align: {
      options: ["right", "left"],
      control: { type: "radio" },
    },
  },
};

export default meta;

type Story = StoryObj<typeof Checkbox>;

export const Simple: Story = {
  args: {
    children: "Default checkbox",
    align: "left",
    hasError: false,
    isDisabled: false,
    isRequired: false,
    isIndeterminate: false,
    automationContext: "unchecked",
  },
};

export const Selected: Story = {
  args: {
    children: <span>Default checkbox</span>,
    isDisabled: false,
    defaultSelected: true,
    align: "left",
    automationContext: "checked",
  },
};

export const Indeterminate: Story = {
  args: {
    children: <span>Indeterminate checkbox</span>,
    isDisabled: false,
    hasError: false,
    align: "left",
    isIndeterminate: true,
    automationContext: "indeterminate",
  },
};
