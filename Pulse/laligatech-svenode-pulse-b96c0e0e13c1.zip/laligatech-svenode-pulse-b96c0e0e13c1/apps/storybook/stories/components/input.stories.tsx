import { useState } from "react";
import { fn } from "storybook/test";
import type { Meta, StoryObj } from "@storybook/react-vite";
import type { InputProps } from "@pulse/components/input";
import { Input } from "@pulse/components/input";

// @ts-expect-error - Fix for storybook issue with names in code
Input.displayName = "Input";

const meta: Meta<typeof Input> = {
  component: Input,
  title: "form/Input",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1194%3A7581&t=k9DdSIO5jdNiFjBm-0",
    },
  },
  argTypes: {},
  args: {
    onChange: fn(),
  },
  render: ({ ...args }) => <InputWithState {...args} />,
};

export default meta;

type Story = StoryObj<typeof Input>;

function InputWithState(props: InputProps) {
  const [value, setValue] = useState("");

  return (
    <Input
      {...props}
      onChange={newValue => {
        setValue(newValue);
        props.onChange?.(newValue);
      }}
      value={value}
    />
  );
}

export const Simple: Story = {
  args: {
    disabled: false,
    isError: false,
    type: "password",
    placeholder: "Placeholder",
    label: "Label",
    subText: "",
    errorMessage: "",
    automationContext: "firstName",
    required: false,
  },
};

export const WithError: Story = {
  args: {
    disabled: false,
    isError: true,
    type: "password",
    placeholder: "Placeholder",
    label: "Label",
    required: true,
    errorMessage: "Subtext (only on error) here",
    subText: "Subtext here",
    automationContext: "invalid",
  },
};

export const WithLabelTooltipContent: Story = {
  args: {
    disabled: false,
    isError: false,
    type: "password",
    placeholder: "Placeholder",
    label: "Label",
    subText: "",
    errorMessage: "",
    automationContext: "firstName",
    required: false,
    labelTooltipContent: "Text Tooltip",
  },
};

export const WithLabelTooltipContentAndError: Story = {
  args: {
    disabled: false,
    isError: true,
    type: "password",
    placeholder: "Placeholder",
    label: "Label",
    required: true,
    errorMessage: "Subtext (only on error) here",
    subText: "Subtext here",
    automationContext: "invalid",
    labelTooltipContent: "Text Tooltip",
  },
};
