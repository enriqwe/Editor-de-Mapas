import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { useState } from "react";
import { Stepper } from "@pulse/components/stepper";
import { Button } from "@pulse/components/button";
import type { StepperContainerProps } from "@pulse/components/stepper";

// @ts-expect-error - Fix for storybook issue with names in code
Stepper.Container.displayName = "Stepper.Container";

const meta: Meta<typeof Stepper.Container> = {
  component: Stepper.Container,
  title: "Stepper",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1696-15902&t=RGpswYlJMiGGzwTS-0",
    },
  },
  render: ({ ...args }) => <StepperWithState {...args} />,
};

export default meta;

type Story = StoryObj<typeof Stepper.Container>;

function StepperWithState(props: StepperContainerProps) {
  const {
    orientation = "horizontal",
    automationContext = "",
    selectedKey,
    onSelectionChange,
    defaultSelectedKey,
  } = props;

  const [activeStep, setActiveStep] = useState<string | number | null>(
    selectedKey || null
  );

  const handleNext = () => {
    setActiveStep(prevActiveStep => {
      if (prevActiveStep === "step1") return "step2";
      if (prevActiveStep === "step2") return "step3";
      if (prevActiveStep === "step3") return "step4";
      return prevActiveStep;
    });
  };

  const handleBack = () => {
    setActiveStep(prevActiveStep => {
      if (prevActiveStep === "step2") return "step1";
      if (prevActiveStep === "step3") return "step2";
      if (prevActiveStep === "step4") return "step3";
      return prevActiveStep;
    });
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          gap: "16px",
          marginBottom: "15px",
        }}
      >
        {selectedKey && (
          <>
            <Button isDisabled={activeStep === "step1"} onPress={handleBack}>
              Back
            </Button>
            <Button isDisabled={activeStep === "step4"} onPress={handleNext}>
              Next
            </Button>
          </>
        )}
      </div>
      <Stepper.Container
        automationContext={automationContext}
        {...(onSelectionChange && {
          onSelectionChange: newKey => {
            onSelectionChange(newKey);
            setActiveStep(newKey);
          },
        })}
        {...(selectedKey && { selectedKey })}
        {...(defaultSelectedKey && { defaultSelectedKey })}
        orientation={orientation}
      >
        <Stepper.Step
          editable
          error={false}
          helperText="Editable"
          key="step1"
          title="Stepper label 1"
        >
          <div>
            <p>Step 1 Content</p>
          </div>
        </Stepper.Step>
        <Stepper.Step
          error={false}
          helperText="Optional"
          key="step2"
          title="Stepper label 2"
        >
          <div>
            <p>Step 2 Content</p>
          </div>
        </Stepper.Step>
        <Stepper.Step
          error
          helperText="Error message"
          key="step3"
          title="Stepper label 3"
        >
          <div>
            <p>Step 3 Content</p>
          </div>
        </Stepper.Step>
        <Stepper.Step error={false} key="step4" title="Finish">
          <div>
            <p>Step End</p>
          </div>
        </Stepper.Step>
      </Stepper.Container>
    </>
  );
}

export const Controlled: Story = {
  args: {
    automationContext: "booking-form",
    selectedKey: "step1",
    onSelectionChange: action("onSelectionChange"),
    orientation: "horizontal",
  },
};

export const Uncontrolled: Story = {
  args: {
    automationContext: "booking-form",
    defaultSelectedKey: "step2",
    orientation: "horizontal",
  },
};
