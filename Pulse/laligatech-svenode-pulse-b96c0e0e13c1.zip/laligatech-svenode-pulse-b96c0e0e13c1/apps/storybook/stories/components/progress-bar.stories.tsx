import type { Meta, StoryObj } from "@storybook/react-vite";
import { ProgressBar } from "@pulse/components/progress-bar";

// @ts-expect-error - Fix for storybook issue with names in code
ProgressBar.displayName = "ProgressBar";

const meta: Meta<typeof ProgressBar> = {
  component: ProgressBar,
  title: "loading/ProgressBar",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1692%3A18131&t=2KpHvPQaR16Icq1I-0",
    },
  },
  render: ({ ...args }) => {
    return (
      <div
        style={{
          margin: "5rem",
        }}
      >
        <ProgressBar {...args} />
      </div>
    );
  },
  argTypes: {
    value: {
      description: "Completion of the progress bar (0-100)",
      control: {
        type: "range",
        min: 0,
        max: 100,
        step: 1,
      },
    },
    status: {
      description: "Status of the progress bar",

      options: ["normal", "error", "success"],
      control: {
        type: "radio",
      },

      table: {
        defaultValue: { summary: "normal" },
      },
    },
    helperText: {
      description: "Complementary information about the progress bar",
      control: {
        type: "text",
      },
    },
    errorText: {
      description: "Message displayed when the progress bar is in error state",
      control: {
        type: "text",
      },
    },

    successText: {
      description: "Message displayed when the progress bar is successful",
      control: {
        type: "text",
      },
    },
  },
};

export default meta;

type Story = StoryObj<typeof ProgressBar>;

export const Default: Story = {
  args: {
    value: 50,
    status: "normal",
    label: "Progress bar label",
    automationContext: "download",
  },
};

export const Error: Story = {
  args: {
    value: 25,
    label: "Progress bar label",
    errorText: "Optional error text",
    status: "error",
    automationContext: "download-error",
  },
};

export const Success: Story = {
  args: {
    value: 100,
    label: "Progress bar label",
    successText: "Optional success text",
    status: "success",
    automationContext: "download-success",
  },
};
