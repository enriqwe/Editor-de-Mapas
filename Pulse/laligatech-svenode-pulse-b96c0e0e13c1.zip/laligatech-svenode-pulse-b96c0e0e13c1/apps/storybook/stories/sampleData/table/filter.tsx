import React, { useState } from "react";
import type { Option } from "@pulse/components/dropdown";
import { Dropdown } from "@pulse/components/dropdown";
import { Input } from "@pulse/components/input";
import { Drawer } from "@pulse/components/drawer";
// import { SelectedOptionType } from '../../Dropdown/base/BaseDropdown.types';

type FiltersValues = Record<string, string>;

export type TableFilter = {
  values: FiltersValues;
  count: number;
};

export type MockTableFilterProps = {
  filters: TableFilter;
  setFilters: (key: TableFilter) => void;
  isOpen: boolean;
  close: () => void;
};

export function MockTableFilter({
  filters,
  setFilters,
  isOpen,
  close,
}: MockTableFilterProps) {
  /**
   *  SUGGESTED METHODS - START
   */

  // Temporary filter inside modal (only propagates changes on apply)
  const [currentFilters, setCurrentFilters] = useState(filters.values);

  const getFiltersCount = (newFilters: FiltersValues) => {
    return Object.values(newFilters).filter(val => Boolean(val)).length;
  };

  // Propagate filter updates only when click on apply
  const onFilterApply = () => {
    setFilters({
      values: currentFilters,
      count: getFiltersCount(currentFilters),
    });

    close();
  };

  // If closing, I should restore original filters
  const onFilterClose = () => {
    setCurrentFilters(filters.values);
    close();
  };

  // If clear, I clear all temporary filters
  const onFilterClear = () => {
    setCurrentFilters({});
  };

  /**
   *  SUGGESTED METHODS - END
   */

  const onChangeDropdown = (dropdownValue: Option) => {
    setCurrentFilters({
      ...currentFilters,
      state: dropdownValue.value,
    });
  };

  const options: Option[] = [
    { value: "Maharashtra", label: "Maharashtra" },
    { value: "Andhra Pradesh", label: "Andhra Pradesh" },
    { value: "Kerala", label: "Kerala" },
    { value: "Haryana", label: "Haryana", isDisabled: true },
  ];

  return (
    <Drawer
      footerButtons={[
        {
          label: "Apply",
          variant: "primary",
          onClick: onFilterApply,
        },
        {
          label: "Clear",
          variant: "tertiary",
          onClick: onFilterClear,
        },
      ]}
      isOpen={isOpen}
      onClose={onFilterClose}
      title=" I am new title"
    >
      <div style={{ display: "flex", gap: "30px", flexDirection: "column" }}>
        <Dropdown
          label="Single selection"
          noOptionsMessage="No options"
          onSelectedOption={value => {
            if (typeof value === "string") {
              onChangeDropdown(value);
            }
          }}
          options={options}
          placeholder="Placeholder"
          {...(currentFilters.state && {
            selectedOption: {
              value: currentFilters.state,
              label: currentFilters.state,
            },
          })}
          closeMenuOnSelect
        />

        <Input
          label="Input selection"
          onChange={(value: string) => {
            setCurrentFilters({
              ...currentFilters,
              label: value,
            });
          }}
          placeholder="I am input"
          type="text"
          value={currentFilters.label || ""}
        />
      </div>
    </Drawer>
  );
}
