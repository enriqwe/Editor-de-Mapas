/**
 * MockData file only to be used for storybook table and testing
 */

import { useState } from "react";
import { Input } from "@pulse/components/input";
import { TextTooltip } from "@pulse/components/text-tooltip";
import { Icon } from "@pulse/components/icon";
import { IconButton } from "@pulse/components/icon-button";
import { action } from "storybook/actions";

function TestInput() {
  const [value, setValue] = useState<string>("");
  return (
    <Input
      automationContext="layout-name-input"
      isError={false}
      label=""
      onBlur={() => action("on blur")}
      onChange={(newValue: string) => {
        setValue(newValue);
      }}
      onFocus={() => action("on focus")}
      placeholder="Layout name"
      type="text"
      value={value}
    />
  );
}

export const paginationTableData = [
  {
    id: 1,
    first_name: "Jessamyn",
    last_name: "Espinazo",
    email: "jespinazo0@chicagotribune.com",
    phone: "162-166-0977",
  },
  {
    id: 2,
    first_name: "Isac",
    last_name: "Tooher",
    email: "itooher1@psu.edu",
    phone: "655-567-3619",
  },
  {
    id: 3,
    first_name: "Tabbatha",
    last_name: "Proschke",
    email: "tproschke2@weibo.com",
    phone: "327-612-4850",
  },
  {
    id: 4,
    first_name: "Ninetta",
    last_name: "Mabb",
    email: "nmabb3@canalblog.com",
    phone: "971-296-0911",
  },
  {
    id: 5,
    first_name: "Danni",
    last_name: "Wallentin",
    email: "dwallentin4@comcast.net",
    phone: "983-297-0506",
    disabled: true,
  },
  {
    id: 6,
    first_name: "Neely",
    last_name: "Purkins",
    email: "npurkins5@mediafire.com",
    phone: "379-119-4237",
  },
  {
    id: 7,
    first_name: "Jessika",
    last_name: "Kinkaid",
    email: "jkinkaid6@eventbrite.com",
    phone: "771-888-6284",
  },
  {
    id: 8,
    first_name: "Julianna",
    last_name: "Swindall",
    email: "jswindall7@aol.com",
    phone: "252-614-0486",
  },
  {
    id: 9,
    first_name: "Corrinne",
    last_name: "Geeve",
    email: "cgeeve8@wisc.edu",
    phone: "450-872-8646",
    disabled: true,
  },
  {
    id: 10,
    first_name: "Trumann",
    last_name: "Flux",
    email: "tflux9@census.gov",
    phone: "249-892-1585",
  },
  {
    id: 11,
    first_name: "Annalise",
    last_name: "Keinrat",
    email: "akeinrata@i2i.jp",
    phone: "659-283-4601",
  },
  {
    id: 12,
    first_name: "Cal",
    last_name: "Haverson",
    email: "chaversonb@multiply.com",
    phone: "689-567-9516",
  },
  {
    id: 13,
    first_name: "Erik",
    last_name: "McGillivrie",
    email: "emcgillivriec@theglobeandmail.com",
    phone: "334-579-0995",
  },
  {
    id: 14,
    first_name: "Cherilyn",
    last_name: "Tuddenham",
    email: "ctuddenhamd@indiegogo.com",
    phone: "408-721-4575",
  },
  {
    id: 15,
    first_name: "Merola",
    last_name: "MacDowal",
    email: "mmacdowale@omniture.com",
    phone: "863-234-5628",
  },
  {
    id: 16,
    first_name: "Olenolin",
    last_name: "O'Shiels",
    email: "ooshielsf@smh.com.au",
    phone: "646-127-1652",
    disabled: true,
  },
  {
    id: 17,
    first_name: "Donnie",
    last_name: "Oliphant",
    email: "doliphantg@i2i.jp",
    phone: "975-457-5826",
  },
  {
    id: 18,
    first_name: "Carly",
    last_name: "Bulleyn",
    email: "cbulleynh@fc2.com",
    phone: "938-211-6682",
  },
  {
    id: 19,
    first_name: "Walt",
    last_name: "Meace",
    email: "wmeacei@printfriendly.com",
    phone: "688-775-4039",
  },
  {
    id: 20,
    first_name: "Debbie",
    last_name: "Rockhall",
    email: "drockhallj@weebly.com",
    phone: "120-270-4052",
    disabled: true,
  },
  {
    id: 21,
    first_name: "Devonna",
    last_name: "Oylett",
    email: "doylettk@jalbum.net",
    phone: "364-921-6359",
  },
  {
    id: 22,
    first_name: "Jourdan",
    last_name: "Grahamslaw",
    email: "jgrahamslawl@irs.gov",
    phone: "939-973-9940",
  },
  {
    id: 23,
    first_name: "Brana",
    last_name: "Haste",
    email: "bhastem@typepad.com",
    phone: "142-349-6034",
  },
  {
    id: 24,
    first_name: "Wilmer",
    last_name: "Trenouth",
    email: "wtrenouthn@netvibes.com",
    phone: "346-897-1305",
  },
  {
    id: 25,
    first_name: "Brandtr",
    last_name: "Esler",
    email: "beslero@wikispaces.com",
    phone: "638-763-4382",
  },
  {
    id: 26,
    first_name: "Andonis",
    last_name: "Durbin",
    email: "adurbinp@newyorker.com",
    phone: "531-854-8916",
    disabled: true,
  },
  {
    id: 27,
    first_name: "Cynthia",
    last_name: "How to preserve",
    email: "chowtopreserveq@de.vu",
    phone: "119-342-9726",
  },
  {
    id: 28,
    first_name: "Jennee",
    last_name: "Cowdroy",
    email: "jcowdroyr@marketwatch.com",
    phone: "804-307-6112",
  },
  {
    id: 29,
    first_name: "Lorin",
    last_name: "D'Hooghe",
    email: "ldhooghes@wix.com",
    phone: "374-113-9906",
  },
  {
    id: 30,
    first_name: "Letti",
    last_name: "Acreman",
    email: "lacremant@ted.com",
    phone: "157-463-7705",
  },
  {
    id: 31,
    first_name: "Drucie",
    last_name: "Watkins",
    email: "dwatkinsu@japanpost.jp",
    phone: "778-273-9630",
  },
  {
    id: 32,
    first_name: "Ev",
    last_name: "Christy",
    email: "echristyv@addthis.com",
    phone: "575-366-6055",
  },
  {
    id: 33,
    first_name: "Nick",
    last_name: "Moores",
    email: "nmooresw@privacy.gov.au",
    phone: "905-406-0567",
  },
  {
    id: 34,
    first_name: "Mollie",
    last_name: "Strut",
    email: "mstrutx@ftc.gov",
    phone: "838-952-4289",
  },
  {
    id: 35,
    first_name: "Dasha",
    last_name: "Gerring",
    email: "dgerringy@histats.com",
    phone: "147-553-3272",
  },
  {
    id: 36,
    first_name: "Hazel",
    last_name: "Barber",
    email: "hbarberz@walmart.com",
    phone: "830-229-8318",
  },
  {
    id: 37,
    first_name: "Danila",
    last_name: "Gidman",
    email: "dgidman10@networkadvertising.org",
    phone: "474-241-8816",
  },
  {
    id: 38,
    first_name: "Gladi",
    last_name: "Torry",
    email: "gtorry11@usgs.gov",
    phone: "865-594-2480",
  },
  {
    id: 39,
    first_name: "Mair",
    last_name: "Garnam",
    email: "mgarnam12@miitbeian.gov.cn",
    phone: "890-209-7033",
  },
  {
    id: 40,
    first_name: "Wilie",
    last_name: "Sebire",
    email: "wsebire13@pen.io",
    phone: "303-945-1363",
  },
  {
    id: 41,
    first_name: "Corrie",
    last_name: "Terrett",
    email: "cterrett14@comcast.net",
    phone: "410-942-4578",
  },
  {
    id: 42,
    first_name: "Dene",
    last_name: "Mullender",
    email: "dmullender15@sun.com",
    phone: "901-439-2803",
  },
  {
    id: 43,
    first_name: "Prue",
    last_name: "Digginson",
    email: "pdigginson16@discuz.net",
    phone: "149-648-9075",
  },
  {
    id: 44,
    first_name: "Blithe",
    last_name: "Huriche",
    email: "bhuriche17@dion.ne.jp",
    phone: "572-905-5251",
  },
  {
    id: 45,
    first_name: "Martyn",
    last_name: "Rickell",
    email: "mrickell18@google.com.hk",
    phone: "471-332-7226",
  },
  {
    id: 46,
    first_name: "Marlene",
    last_name: "Sokill",
    email: "msokill19@samsung.com",
    phone: "654-701-1938",
  },
  {
    id: 47,
    first_name: "Neda",
    last_name: "Muat",
    email: "nmuat1a@opera.com",
    phone: "505-173-1555",
  },
  {
    id: 48,
    first_name: "Darcy",
    last_name: "Tal",
    email: "dtal1b@grimg.com",
    phone: "381-614-2085",
  },
  {
    id: 49,
    first_name: "Lynette",
    last_name: "Bottrill",
    email: "lbottrill1c@etsy.com",
    phone: "959-766-2123",
  },
  {
    id: 50,
    first_name: "Court",
    last_name: "Melonby",
    email: "cmelonby1d@irs.gov",
    phone: "688-175-2186",
  },
  {
    id: 51,
    first_name: "Ansel",
    last_name: "Krolman",
    email: "akrolman1e@noaa.gov",
    phone: "358-653-3696",
  },
  {
    id: 52,
    first_name: "Birch",
    last_name: "Axelbey",
    email: "baxelbey1f@go.com",
    phone: "839-501-4343",
  },
  {
    id: 53,
    first_name: "Ferguson",
    last_name: "Worsfold",
    email: "fworsfold1g@amazon.co.jp",
    phone: "560-349-3879",
  },
  {
    id: 54,
    first_name: "Juli",
    last_name: "Priddis",
    email: "jpriddis1h@patch.com",
    phone: "313-592-4885",
  },
  {
    id: 55,
    first_name: "Sollie",
    last_name: "Burkinshaw",
    email: "sburkinshaw1i@studiopress.com",
    phone: "672-677-2017",
  },
  {
    id: 56,
    first_name: "Fair",
    last_name: "Lemary",
    email: "flemary1j@nature.com",
    phone: "792-335-9018",
  },
  {
    id: 57,
    first_name: "Freeland",
    last_name: "De la Perrelle",
    email: "fdelaperrelle1k@sciencedaily.com",
    phone: "535-745-6903",
  },
  {
    id: 58,
    first_name: "Tabitha",
    last_name: "Tomisch",
    email: "ttomisch1l@zimbio.com",
    phone: "168-603-7561",
  },
  {
    id: 59,
    first_name: "Sidney",
    last_name: "Rembrant",
    email: "srembrant1m@goo.gl",
    phone: "605-204-6189",
  },
  {
    id: 60,
    first_name: "Harcourt",
    last_name: "Gallaher",
    email: "hgallaher1n@sogou.com",
    phone: "623-995-9943",
  },
  {
    id: 61,
    first_name: "Arlena",
    last_name: "Hapke",
    email: "ahapke1o@virginia.edu",
    phone: "893-966-3321",
  },
  {
    id: 62,
    first_name: "Kendell",
    last_name: "Flemming",
    email: "kflemming1p@flickr.com",
    phone: "213-633-2642",
  },
  {
    id: 63,
    first_name: "Latisha",
    last_name: "Emm",
    email: "lemm1q@time.com",
    phone: "984-139-8196",
  },
  {
    id: 64,
    first_name: "Leese",
    last_name: "Shorbrook",
    email: "lshorbrook1r@mashable.com",
    phone: "538-483-8753",
  },
  {
    id: 65,
    first_name: "Nat",
    last_name: "Spellar",
    email: "nspellar1s@simplemachines.org",
    phone: "441-737-1080",
  },
  {
    id: 66,
    first_name: "Farris",
    last_name: "Jepensen",
    email: "fjepensen1t@aboutads.info",
    phone: "383-151-4669",
  },
  {
    id: 67,
    first_name: "Eveline",
    last_name: "Hedge",
    email: "ehedge1u@ocn.ne.jp",
    phone: "537-478-0180",
  },
  {
    id: 68,
    first_name: "Philbert",
    last_name: "Neubigin",
    email: "pneubigin1v@eventbrite.com",
    phone: "812-698-9737",
  },
  {
    id: 69,
    first_name: "Mariele",
    last_name: "Milham",
    email: "mmilham1w@mlb.com",
    phone: "587-156-1202",
  },
  {
    id: 70,
    first_name: "Kym",
    last_name: "Dutch",
    email: "kdutch1x@wp.com",
    phone: "354-451-8528",
  },
  {
    id: 71,
    first_name: "Ewart",
    last_name: "Greenig",
    email: "egreenig1y@examiner.com",
    phone: "400-500-2640",
  },
  {
    id: 72,
    first_name: "Welbie",
    last_name: "Towe",
    email: "wtowe1z@buzzfeed.com",
    phone: "899-501-2617",
  },
  {
    id: 73,
    first_name: "Teddie",
    last_name: "Deakes",
    email: "tdeakes20@shutterfly.com",
    phone: "522-101-7279",
  },
  {
    id: 74,
    first_name: "Vikky",
    last_name: "Siene",
    email: "vsiene21@springer.com",
    phone: "232-886-8536",
  },
  {
    id: 75,
    first_name: "Elyssa",
    last_name: "Heppner",
    email: "eheppner22@grimg.com",
    phone: "294-950-6741",
  },
  {
    id: 76,
    first_name: "Julita",
    last_name: "Peeke",
    email: "jpeeke23@odnoklassniki.ru",
    phone: "961-734-0677",
  },
  {
    id: 77,
    first_name: "Iver",
    last_name: "Whittek",
    email: "iwhittek24@umn.edu",
    phone: "506-979-5280",
  },
  {
    id: 78,
    first_name: "Petr",
    last_name: "Jollie",
    email: "pjollie25@dyndns.org",
    phone: "973-778-3101",
  },
  {
    id: 79,
    first_name: "Robinette",
    last_name: "Sharville",
    email: "rsharville26@opensource.org",
    phone: "556-967-6762",
  },
  {
    id: 80,
    first_name: "Mariana",
    last_name: "Stranieri",
    email: "mstranieri27@xrea.com",
    phone: "156-920-5037",
  },
  {
    id: 81,
    first_name: "Margaretta",
    last_name: "Michelle",
    email: "mmichelle28@businesswire.com",
    phone: "565-521-2997",
  },
  {
    id: 82,
    first_name: "Trev",
    last_name: "Raubenheimers",
    email: "traubenheimers29@moonfruit.com",
    phone: "605-986-7948",
  },
  {
    id: 83,
    first_name: "Emalia",
    last_name: "Anten",
    email: "eanten2a@macromedia.com",
    phone: "338-688-7993",
  },
  {
    id: 84,
    first_name: "Jesselyn",
    last_name: "Erb",
    email: "jerb2b@miibeian.gov.cn",
    phone: "312-456-0905",
  },
  {
    id: 85,
    first_name: "Shara",
    last_name: "Blackadder",
    email: "sblackadder2c@aboutads.info",
    phone: "169-220-5662",
  },
  {
    id: 86,
    first_name: "Barbette",
    last_name: "Meriguet",
    email: "bmeriguet2d@wikipedia.org",
    phone: "228-145-9814",
  },
  {
    id: 87,
    first_name: "Roxane",
    last_name: "Scates",
    email: "rscates2e@kickstarter.com",
    phone: "116-672-0961",
  },
  {
    id: 88,
    first_name: "Hannis",
    last_name: "Bartoshevich",
    email: "hbartoshevich2f@xing.com",
    phone: "834-172-8599",
  },
  {
    id: 89,
    first_name: "Phyllys",
    last_name: "Flarity",
    email: "pflarity2g@biglobe.ne.jp",
    phone: "832-890-6742",
  },
  {
    id: 90,
    first_name: "Kizzee",
    last_name: "Theyer",
    email: "ktheyer2h@tiny.cc",
    phone: "483-457-6897",
  },
  {
    id: 91,
    first_name: "Roslyn",
    last_name: "Smidmore",
    email: "rsmidmore2i@elpais.com",
    phone: "201-771-3550",
  },
  {
    id: 92,
    first_name: "Pearl",
    last_name: "Pounsett",
    email: "ppounsett2j@merriam-webster.com",
    phone: "957-681-3075",
  },
  {
    id: 93,
    first_name: "Monique",
    last_name: "Entwhistle",
    email: "mentwhistle2k@ft.com",
    phone: "347-661-1768",
  },
  {
    id: 94,
    first_name: "Jeanette",
    last_name: "Chawner",
    email: "jchawner2l@timesonline.co.uk",
    phone: "331-416-1392",
  },
  {
    id: 95,
    first_name: "Mariquilla",
    last_name: "Eton",
    email: "meton2m@imgur.com",
    phone: "215-147-2906",
  },
  {
    id: 96,
    first_name: "Maynord",
    last_name: "Dyson",
    email: "mdyson2n@dion.ne.jp",
    phone: "396-388-3573",
  },
  {
    id: 97,
    first_name: "Jerrie",
    last_name: "Dowles",
    email: "jdowles2o@squidoo.com",
    phone: "657-917-4708",
  },
  {
    id: 98,
    first_name: "Patrizio",
    last_name: "Meakin",
    email: "pmeakin2p@theguardian.com",
    phone: "420-451-1498",
  },
  {
    id: 99,
    first_name: "Oona",
    last_name: "Beaushaw",
    email: "obeaushaw2q@time.com",
    phone: "706-269-7851",
  },
  {
    id: 100,
    first_name: "Wynny",
    last_name: "Jindra",
    email: "wjindra2r@opensource.org",
    phone: "230-299-6101",
  },
  {
    id: 101,
    first_name: "Rutledge",
    last_name: "Pettiford",
    email: "rpettiford2s@ehow.com",
    phone: "648-426-5297",
  },
  {
    id: 102,
    first_name: "Lazarus",
    last_name: "Mucci",
    email: "lmucci2t@goo.ne.jp",
    phone: "776-792-5978",
  },
  {
    id: 103,
    first_name: "Nara",
    last_name: "Caldwell",
    email: "ncaldwell2u@eepurl.com",
    phone: "144-214-7759",
  },
  {
    id: 104,
    first_name: "Pietra",
    last_name: "Rozzier",
    email: "prozzier2v@theatlantic.com",
    phone: "994-978-5791",
  },
  {
    id: 105,
    first_name: "Maia",
    last_name: "Woolatt",
    email: "mwoolatt2w@latimes.com",
    phone: "617-129-4470",
  },
  {
    id: 106,
    first_name: "Karim",
    last_name: "Anthony",
    email: "kanthony2x@blinklist.com",
    phone: "393-442-4797",
  },
  {
    id: 107,
    first_name: "Wat",
    last_name: "Eddleston",
    email: "weddleston2y@irs.gov",
    phone: "662-985-8217",
  },
  {
    id: 108,
    first_name: "Solly",
    last_name: "Yellowlee",
    email: "syellowlee2z@bbc.co.uk",
    phone: "203-807-2598",
  },
  {
    id: 109,
    first_name: "Eden",
    last_name: "Oxby",
    email: "eoxby30@hubpages.com",
    phone: "212-316-4674",
  },
  {
    id: 110,
    first_name: "Forrest",
    last_name: "Havis",
    email: "fhavis31@arstechnica.com",
    phone: "666-603-7307",
  },
  {
    id: 111,
    first_name: "Tim",
    last_name: "Mangeot",
    email: "tmangeot32@gnu.org",
    phone: "518-852-2631",
  },
  {
    id: 112,
    first_name: "Bettye",
    last_name: "Myrtle",
    email: "bmyrtle33@time.com",
    phone: "256-637-8179",
  },
  {
    id: 113,
    first_name: "Ashlee",
    last_name: "Lillecrop",
    email: "alillecrop34@hud.gov",
    phone: "402-425-7988",
  },
  {
    id: 114,
    first_name: "Krystle",
    last_name: "Cottham",
    email: "kcottham35@wisc.edu",
    phone: "551-656-3203",
  },
  {
    id: 115,
    first_name: "Prent",
    last_name: "Geertje",
    email: "pgeertje36@eventbrite.com",
    phone: "355-642-9723",
  },
  {
    id: 116,
    first_name: "Hogan",
    last_name: "Kyttor",
    email: "hkyttor37@smh.com.au",
    phone: "712-972-9358",
  },
  {
    id: 117,
    first_name: "Antone",
    last_name: "Bonhill",
    email: "abonhill38@booking.com",
    phone: "480-907-3237",
  },
  {
    id: 118,
    first_name: "Lynnett",
    last_name: "Sanchis",
    email: "lsanchis39@4shared.com",
    phone: "551-989-0017",
  },
  {
    id: 119,
    first_name: "Allen",
    last_name: "Doerffer",
    email: "adoerffer3a@house.gov",
    phone: "730-281-2188",
  },
  {
    id: 120,
    first_name: "Benjie",
    last_name: "Ewbach",
    email: "bewbach3b@51.la",
    phone: "380-475-3326",
  },
  {
    id: 121,
    first_name: "Rusty",
    last_name: "Peiser",
    email: "rpeiser3c@bizjournals.com",
    phone: "780-966-1533",
  },
  {
    id: 122,
    first_name: "Janeczka",
    last_name: "Braden",
    email: "jbraden3d@microsoft.com",
    phone: "979-420-5667",
  },
  {
    id: 123,
    first_name: "Bancroft",
    last_name: "Eyres",
    email: "beyres3e@php.net",
    phone: "691-219-5446",
  },
  {
    id: 124,
    first_name: "Forester",
    last_name: "Courteney",
    email: "fcourteney3f@purevolume.com",
    phone: "273-236-5640",
  },
  {
    id: 125,
    first_name: "Menard",
    last_name: "Clayill",
    email: "mclayill3g@cnn.com",
    phone: "428-737-2222",
  },
  {
    id: 126,
    first_name: "Rayner",
    last_name: "Fettiplace",
    email: "rfettiplace3h@mozilla.com",
    phone: "857-300-3144",
  },
  {
    id: 127,
    first_name: "Sybila",
    last_name: "McGillecole",
    email: "smcgillecole3i@elpais.com",
    phone: "518-280-8303",
  },
  {
    id: 128,
    first_name: "Caresa",
    last_name: "Gerleit",
    email: "cgerleit3j@wiley.com",
    phone: "121-127-5314",
  },
  {
    id: 129,
    first_name: "Efren",
    last_name: "Lieber",
    email: "elieber3k@springer.com",
    phone: "931-689-2020",
  },
  {
    id: 130,
    first_name: "Georgine",
    last_name: "Richin",
    email: "grichin3l@ycombinator.com",
    phone: "182-374-9369",
  },
  {
    id: 131,
    first_name: "Tildi",
    last_name: "Volker",
    email: "tvolker3m@yandex.ru",
    phone: "334-921-5657",
  },
  {
    id: 132,
    first_name: "Loydie",
    last_name: "Buse",
    email: "lbuse3n@indiatimes.com",
    phone: "702-529-3841",
  },
  {
    id: 133,
    first_name: "Fielding",
    last_name: "Percy",
    email: "fpercy3o@amazon.com",
    phone: "718-807-2729",
  },
  {
    id: 134,
    first_name: "Carr",
    last_name: "Coch",
    email: "ccoch3p@odnoklassniki.ru",
    phone: "444-152-8142",
  },
  {
    id: 135,
    first_name: "Hector",
    last_name: "Coultard",
    email: "hcoultard3q@ehow.com",
    phone: "127-569-3832",
  },
  {
    id: 136,
    first_name: "Patrice",
    last_name: "Prandoni",
    email: "pprandoni3r@aboutads.info",
    phone: "294-991-9805",
  },
  {
    id: 137,
    first_name: "Adelice",
    last_name: "Blazy",
    email: "ablazy3s@miitbeian.gov.cn",
    phone: "752-948-8354",
  },
  {
    id: 138,
    first_name: "Rois",
    last_name: "Ledster",
    email: "rledster3t@wikia.com",
    phone: "444-476-3882",
  },
  {
    id: 139,
    first_name: "Jerad",
    last_name: "Jedrzej",
    email: "jjedrzej3u@omniture.com",
    phone: "327-785-3302",
  },
  {
    id: 140,
    first_name: "Derby",
    last_name: "Lamanby",
    email: "dlamanby3v@europa.eu",
    phone: "189-707-3069",
  },
  {
    id: 141,
    first_name: "Dwain",
    last_name: "Duiged",
    email: "dduiged3w@earthlink.net",
    phone: "361-498-7922",
  },
  {
    id: 142,
    first_name: "Pattie",
    last_name: "McLaine",
    email: "pmclaine3x@marketwatch.com",
    phone: "231-123-5063",
  },
  {
    id: 143,
    first_name: "Randene",
    last_name: "Amoore",
    email: "ramoore3y@digg.com",
    phone: "194-919-7539",
  },
  {
    id: 144,
    first_name: "Devi",
    last_name: "Folkard",
    email: "dfolkard3z@disqus.com",
    phone: "993-405-4998",
  },
  {
    id: 145,
    first_name: "Wendye",
    last_name: "Grafham",
    email: "wgrafham40@hp.com",
    phone: "927-680-8556",
  },
  {
    id: 146,
    first_name: "Basia",
    last_name: "Standrin",
    email: "bstandrin41@printfriendly.com",
    phone: "884-204-7067",
  },
  {
    id: 147,
    first_name: "Auberta",
    last_name: "Mains",
    email: "amains42@4shared.com",
    phone: "419-605-9020",
  },
  {
    id: 148,
    first_name: "Jerald",
    last_name: "Aston",
    email: "jaston43@biblegateway.com",
    phone: "909-846-7387",
  },
  {
    id: 149,
    first_name: "Chantal",
    last_name: "Harrigan",
    email: "charrigan44@studiopress.com",
    phone: "895-868-2708",
  },
  {
    id: 150,
    first_name: "Merell",
    last_name: "Hellikes",
    email: "mhellikes45@blogtalkradio.com",
    phone: "916-329-2838",
  },
  {
    id: 151,
    first_name: "Essy",
    last_name: "Avramchik",
    email: "eavramchik46@abc.net.au",
    phone: "381-579-6446",
  },
  {
    id: 152,
    first_name: "Belvia",
    last_name: "Revans",
    email: "brevans47@webnode.com",
    phone: "880-104-7958",
  },
  {
    id: 153,
    first_name: "Felizio",
    last_name: "Burkert",
    email: "fburkert48@com.com",
    phone: "159-588-8350",
  },
  {
    id: 154,
    first_name: "Katrina",
    last_name: "Wickenden",
    email: "kwickenden49@etsy.com",
    phone: "940-298-7998",
  },
  {
    id: 155,
    first_name: "Babb",
    last_name: "Rissen",
    email: "brissen4a@state.gov",
    phone: "439-525-1836",
  },
  {
    id: 156,
    first_name: "Brady",
    last_name: "Splain",
    email: "bsplain4b@economist.com",
    phone: "293-333-0295",
  },
  {
    id: 157,
    first_name: "Angele",
    last_name: "Wase",
    email: "awase4c@twitter.com",
    phone: "147-660-1938",
  },
  {
    id: 158,
    first_name: "Obidiah",
    last_name: "Lanning",
    email: "olanning4d@hhs.gov",
    phone: "808-370-0404",
  },
  {
    id: 159,
    first_name: "Aguistin",
    last_name: "Behneke",
    email: "abehneke4e@usgs.gov",
    phone: "958-671-9826",
  },
  {
    id: 160,
    first_name: "Sydney",
    last_name: "Gunning",
    email: "sgunning4f@com.com",
    phone: "927-511-1016",
  },
  {
    id: 161,
    first_name: "Robbyn",
    last_name: "Guillotin",
    email: "rguillotin4g@youtube.com",
    phone: "506-998-0039",
  },
  {
    id: 162,
    first_name: "Nollie",
    last_name: "Howlin",
    email: "nhowlin4h@addtoany.com",
    phone: "956-434-5477",
  },
  {
    id: 163,
    first_name: "Neall",
    last_name: "Meekin",
    email: "nmeekin4i@pcworld.com",
    phone: "118-593-2459",
  },
  {
    id: 164,
    first_name: "Cher",
    last_name: "Wilsone",
    email: "cwilsone4j@senate.gov",
    phone: "397-293-4853",
  },
  {
    id: 165,
    first_name: "Stefanie",
    last_name: "MacDougal",
    email: "smacdougal4k@about.me",
    phone: "485-775-8981",
  },
  {
    id: 166,
    first_name: "Emilia",
    last_name: "Chismon",
    email: "echismon4l@altervista.org",
    phone: "798-868-5666",
  },
  {
    id: 167,
    first_name: "Levey",
    last_name: "Winward",
    email: "lwinward4m@studiopress.com",
    phone: "743-980-0131",
  },
  {
    id: 168,
    first_name: "Jerald",
    last_name: "Tugman",
    email: "jtugman4n@tumblr.com",
    phone: "993-797-7046",
  },
  {
    id: 169,
    first_name: "Cindee",
    last_name: "Watterson",
    email: "cwatterson4o@tamu.edu",
    phone: "203-545-3541",
  },
  {
    id: 170,
    first_name: "Rikki",
    last_name: "Roston",
    email: "rroston4p@shinystat.com",
    phone: "907-590-6840",
  },
  {
    id: 171,
    first_name: "Cherish",
    last_name: "Housegoe",
    email: "chousegoe4q@hhs.gov",
    phone: "462-236-3954",
  },
  {
    id: 172,
    first_name: "Grier",
    last_name: "Thresh",
    email: "gthresh4r@acquirethisname.com",
    phone: "631-872-7577",
  },
  {
    id: 173,
    first_name: "Bernarr",
    last_name: "Goldhill",
    email: "bgoldhill4s@discuz.net",
    phone: "610-978-1029",
  },
  {
    id: 174,
    first_name: "Gale",
    last_name: "Morgan",
    email: "gmorgan4t@xing.com",
    phone: "114-398-1303",
  },
  {
    id: 175,
    first_name: "Oran",
    last_name: "Dorbin",
    email: "odorbin4u@technorati.com",
    phone: "844-262-8513",
  },
  {
    id: 176,
    first_name: "Teena",
    last_name: "Kennifick",
    email: "tkennifick4v@bbc.co.uk",
    phone: "553-431-4901",
  },
  {
    id: 177,
    first_name: "Dayna",
    last_name: "Andreucci",
    email: "dandreucci4w@tinyurl.com",
    phone: "608-182-0394",
  },
  {
    id: 178,
    first_name: "Olivier",
    last_name: "Salt",
    email: "osalt4x@abc.net.au",
    phone: "188-341-1361",
  },
  {
    id: 179,
    first_name: "Aurie",
    last_name: "Ashlee",
    email: "aashlee4y@godaddy.com",
    phone: "448-362-0005",
  },
  {
    id: 180,
    first_name: "Morna",
    last_name: "Lawford",
    email: "mlawford4z@nba.com",
    phone: "342-714-3524",
  },
  {
    id: 181,
    first_name: "Kipp",
    last_name: "Gascone",
    email: "kgascone50@pcworld.com",
    phone: "150-738-6714",
  },
  {
    id: 182,
    first_name: "Shoshanna",
    last_name: "Calver",
    email: "scalver51@google.com",
    phone: "564-109-1503",
  },
  {
    id: 183,
    first_name: "Ferdinanda",
    last_name: "Foxcroft",
    email: "ffoxcroft52@dmoz.org",
    phone: "363-481-6791",
  },
  {
    id: 184,
    first_name: "Sammy",
    last_name: "Weepers",
    email: "sweepers53@merriam-webster.com",
    phone: "605-545-9234",
  },
  {
    id: 185,
    first_name: "Dita",
    last_name: "Blance",
    email: "dblance54@etsy.com",
    phone: "690-385-8039",
  },
  {
    id: 186,
    first_name: "Krispin",
    last_name: "Pinnell",
    email: "kpinnell55@hp.com",
    phone: "359-244-9565",
  },
  {
    id: 187,
    first_name: "Glad",
    last_name: "Banasik",
    email: "gbanasik56@smh.com.au",
    phone: "145-491-7642",
  },
  {
    id: 188,
    first_name: "Christiane",
    last_name: "Gemlbett",
    email: "cgemlbett57@geocities.jp",
    phone: "680-967-4619",
  },
  {
    id: 189,
    first_name: "Gabriela",
    last_name: "Elflain",
    email: "gelflain58@abc.net.au",
    phone: "807-168-2137",
  },
  {
    id: 190,
    first_name: "Hank",
    last_name: "Suggate",
    email: "hsuggate59@hud.gov",
    phone: "544-625-3422",
  },
  {
    id: 191,
    first_name: "Cathie",
    last_name: "Errigo",
    email: "cerrigo5a@blogtalkradio.com",
    phone: "247-399-7287",
  },
  {
    id: 192,
    first_name: "Anderea",
    last_name: "Lakey",
    email: "alakey5b@privacy.gov.au",
    phone: "451-468-0128",
  },
  {
    id: 193,
    first_name: "Rinaldo",
    last_name: "Haskew",
    email: "rhaskew5c@go.com",
    phone: "936-637-3297",
  },
  {
    id: 194,
    first_name: "Zechariah",
    last_name: "Kilgannon",
    email: "zkilgannon5d@google.it",
    phone: "559-853-9163",
  },
  {
    id: 195,
    first_name: "Alika",
    last_name: "Vaudre",
    email: "avaudre5e@wordpress.com",
    phone: "341-974-4801",
  },
  {
    id: 196,
    first_name: "Juana",
    last_name: "Eidelman",
    email: "jeidelman5f@dyndns.org",
    phone: "672-762-3793",
  },
  {
    id: 197,
    first_name: "Tonnie",
    last_name: "Bienvenu",
    email: "tbienvenu5g@usgs.gov",
    phone: "205-242-4514",
  },
  {
    id: 198,
    first_name: "Saudra",
    last_name: "Lakin",
    email: "slakin5h@hostgator.com",
    phone: "125-221-4594",
  },
  {
    id: 199,
    first_name: "Hiram",
    last_name: "Darridon",
    email: "hdarridon5i@epa.gov",
    phone: "301-682-7586",
  },
  {
    id: 200,
    first_name: "Cinderella",
    last_name: "Bierling",
    email: "cbierling5j@bbc.co.uk",
    phone: "310-319-7100",
  },
];

export const sortingListData = [
  {
    name: "Luke Skywalker",
    height: "172",
    mass: "77",
    birth_year: "1/8/1993",
  },
  {
    name: "C-3PO",
    height: "167",
    mass: "75",
    birth_year: "23/1/1993",
  },
  {
    name: "R2-D2",
    height: "96",
    mass: "32",
    birth_year: "2/12/1990",
  },
  {
    name: "Darth Vader",
    height: "202",
    mass: "136",
    birth_year: "2/11/1989",
  },
  {
    name: "Leia Organa",
    height: "150",
    mass: "49",
    birth_year: "2/1/1890",
  },
  {
    name: "Owen Lars",
    height: "178",
    mass: "120",
    birth_year: "2/1/2000",
  },
  {
    name: "Beru Whitesun lars",
    height: "165",
    mass: "75",
    birth_year: "2/1/1970",
  },
  {
    name: "R5-D4",
    height: "97",
    mass: "32",
    birth_year: "2/1/1995",
  },
  {
    name: "Biggs Darklighter",
    height: "183",
    mass: "84",
    birth_year: "11/1/1991",
  },
  {
    name: "Obi-Wan Kenobi",
    height: "182",
    mass: "77",
    birth_year: "1/1/1998",
  },
];

const iconSection = () => {
  return (
    <>
      <IconButton iconName="visibility" />
      <IconButton iconName="edit" />
      <IconButton iconName="delete" />
    </>
  );
};

function UserSection() {
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <Icon icon="account_circle" />
      <span style={{ marginLeft: "8px" }}>Alberto García</span>
    </div>
  );
}

export const rowWithInputMockData = [
  {
    id: 1,
    layout_name: <TestInput />,
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
  {
    id: 2,
    layout_name: <TestInput />,
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
];

export const usersMockData = [
  {
    id: 1,
    layout_name: (
      <TextTooltip>
        Title page, if it is too long Title page, if it is too long Title page
      </TextTooltip>
    ),
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
  {
    id: 2,
    layout_name: (
      <TextTooltip>
        Title page, if it is too long Title page, if it is too long Title page
      </TextTooltip>
    ),
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
  {
    id: 3,
    layout_name: "",
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
  {
    id: 4,
    layout_name: (
      <TextTooltip>
        Title page, if it is too long Title page, if it is too long Title page
      </TextTooltip>
    ),
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
  {
    id: 5,
    layout_name: (
      <TextTooltip>
        Title page, if it is too long Title page, if it is too long Title page
      </TextTooltip>
    ),
    last_editor: <UserSection />,
    state: "Published",
    languages: "ESP | ENG",
    icon_section: (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto auto",
          columnGap: "24px",
        }}
      >
        {iconSection()}
      </div>
    ),
  },
];

export const defaultHeadersData = [
  { label: "Layout Name", key: "layout_name" },
  { label: "Last Editor", key: "last_editor" },
  { label: "State", key: "state" },
  { label: "Languages", key: "languages" },
  { label: "Actions", key: "icon_section" },
];

export const FEAndBEHeadersData = [
  { label: "First Name", key: "first_name", sortable: true },
  { label: "Last Name", key: "last_name" },
  { label: "Email", key: "email" },
  { label: "Phone", key: "phone", sortable: true },
];
