import "styled-components";
import type { ThemeType } from "@pulse/foundations";

declare module "styled-components" {
  // eslint-disable-next-line -- This is necessary to extend the DefaultTheme
  export interface DefaultTheme extends ThemeType {}
}
