// prepare.js

const fs = require("fs"); // Or `import fs from "fs";` with ESM
if (fs.existsSync('.git')) {
  require('husky').install()
}
