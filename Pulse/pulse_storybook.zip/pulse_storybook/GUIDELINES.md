# Guidelines

## Adding new components

- Add folder in `libs/components/src/components`
  - Create an index.ts to only export what is necessary
- Add export en `libs/components/src/index.ts`
- Add entrypoint in `libs/components/package.json`
- Add component in `libs/components/vite.config.ts`
- Add story in `apps/storybook`, importing only the component:
  - `import {Button} from @pulse/components/button` instead of `import {Button} from @pulse/components`. This makes reloads in storybook extra fast

## Adding dependencies

If you need to add a package, you must add it to the package.json of the corresponding package.
Steps:

- Go to the package folder (libs/components most probably)
- Run `pnpm add [package-name]` or `pnpm add -D [package-name]`
- As a general rule, never install packages globally

## Code conventions

Eslint has many rules to help with consistency, but can auto-fix many of them. If you are using VSC, you can fix many issues with the command `ESLint: fix all auto-fixable Problems`

## Components

All components are located in `libs/components/src/components`
For each component:

- Kebab case must be used for file names
- Always add an index.ts file exporting only (export only whats needed):
  - Component
  - Type.
    - This should follow the convention: `[ComponentName]Props`. For example, `ButtonProps` for Button
- If your component has sub-components, add a sub-components folder inside your main component folder
- Story files are no longer located with the components, but in the corresponding `stories` folder in `apps/storybook`

### Assets

- Assets should be located in the components folder. Avoid global assets folder

### Icons

- If your component has icons, name should be `[iconName].icon.tsx`
- Icon should be exported as a TSX Component (check any current icon)

## Storybook

Storybook provides us with an interactive UI playground for our components. This allows us to preview our components in the browser and instantly see changes when developing locally. This example preconfigures Storybook to:

- Automatically find any stories inside the `apps/storybook/stories/` folder
- You can use MDX for component documentation pages

## Setup

## Important! For migration from @svenues/sv-components, check MIGRATION.md

### Consuming new library

#### Add npm registry in .npmrc

```bash
@pulse:registry=https://nexus-llt.laliga.es/repository/npm-hosted
```

#### Install packages

```bash
npm install @pulse/foundations
npm install @pulse/components
```

#### Add ThemeProvider

```ts
import { themes } from "@pulse/foundations";
import { ThemeProvider } from "styled-components";

<ThemeProvider theme={themes.default}>
  <App />
</ThemeProvider>;
```

#### Importing a Button

You can import components individually or from package root

Option 1 (better for three shaking)

```ts
import { Button } from "@pulse/components/button";

<Button>Test</Button>;
```

Option 2

```ts
import { Button } from "@pulse/components";

<Button>Test</Button>;
```
