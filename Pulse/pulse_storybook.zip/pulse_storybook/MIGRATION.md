# Migration from @svenues/sv-components

## Consuming new library

### Add npm registry in .npmrc

```bash
@pulse:registry=https://nexus-llt.laliga.es/repository/npm-hosted
```

### Install packages

```bash
npm install @pulse/foundations
npm install @pulse/components
```

### Replace ThemeProvider

```ts
import { themes } from "@pulse/foundations";
import { ThemeProvider } from "styled-components";

<ThemeProvider theme={themes.default}>
  <App />
</ThemeProvider>;
```

## Export changes: component properties

- All components export it's props as `[ComponentName]Props`. Example:

```ts
import { Button } from "@pulse/components/button";
import type { ButtonProps } from "@pulse/components/button";
```

## Export changes: @internationalized/date

You no longer need to install this library for date pickers, time pickers, etc
You can directy import this methods from pulse library itself

```ts
import {
  Time,
  CalendarDate,
  CalendarDateTime,
  today,
  getLocalTimeZone,
  parseDate,
  parseDateTime,
  parseTime,
} from "@pulse/components/date-utils";
```

If you need some more method, feel free to export them on `/libs/components/src/index.ts`

# Changes per component

### Button

- Improved accesibility support
- Deprecated onClick in favor of onPress (with keyboard and more devices support)

### Card

- Card (v1) was already deprecated so it was not migrated
- CardV2 was renamed to Card.

### EmpyState

- EmptyState (v1) was already deprecated so it was not migrated
- EmptyStateV2 was renamed to EmptyState

## Navigation Chip

- NavigationChip was already deprecated and was not migrated

## Choice Chip

- "label" prop was deprecated. Use "text" instead
- "onClick" prop was deprecated. Use "onPress" instead
- "disabled" prop was deprecated. Use "isDisabled" instead
- "selected" prop was deprecated. Use "isSelected" instead

## OverflowMenu

- OverFlow Menu now export it's own items.

```ts
import { OverflowMenu, OverflowMenuItem } from "@pulse/components/overflow-menu";

<OverflowMenu ...>
  <OverflowMenuItem ...>
  <OverflowMenuItem ...>
  ...
</OverflowMenu>

```

Check storybook example for details

## Loader / ProgressBar

- "Loader" component was renamed to "ProgressBar"

## Checkbox

- Orientation "verticle" was fixed and renamed to "vertical"

Due to several issues, individual Checkboxes and grouped checkboxes are now different components

- Single Checkbox (without Group) :

```ts
<Checkbox />
```

- Checkbox with Group:

```ts
<Checkbox.Group>
  <Checkbox.Item />
  ...
</Checkbox.Group>
```

## TimePicker:

- `time` prop has been renamed to `value`
- Every prop that uses time, has been replaced with Time object: invalidTime, value, and onTimeSelected output. So, instead of
- ITime type has been replaced with Time object to have better consistency.

So, instead of

```ts
invalidTime="12:30"
value={{ hour: 14, minute: 00 }}
onTimeSelected={(time: {hour: number, minute: number}) => {
  console.log(time.hour + ":" + time.minute)
}}
```

you must use

```ts
invalidTime={new Time(12,30)}
value={new Time(14, 00)}
onTimeSelected={(time: Time) => {
  console.log(time.toString()) // for output HH:MM:SS
  console.log(time.toString().slice(0, 5)) // for output HH:MM
}}
```

## DatePicker

- disabled was renamed to isDisabled for consistency

## Stepper

- Prop `stepSelected` has been deprecated in favor of `selectedKey` . Take into account you need to use the key instead of the step number

## Modal

- useModal is no longer exported from the library, because there is no real value in just having a wrapper on a useState. In case you want to create it locally , code is the following:
- in ModalTrigger, use `isOpen` instead of `isShowing`
- `toggle` prop was removed due to overlapped responsibilities with `isShowing` (now `isOpen`). You can use a controlled Modal to handle this (see Controlled example on storybook)

```ts
import { useState } from "react";

export const useModal = (show = false) => {
  const [isShowing, setIsShowing] = useState(show);

  function toggle() {
    setIsShowing(!isShowing);
  }

  return {
    isShowing,
    toggle,
  };
};
```

## PaginationBar

- `defaultPageSize` was deprecated. Use `currentPageSize` instead
- `dataPerPagesOption` was deprecated. Use `pageSizesList` instead
- `setPageSize` was deprecated. Use `onPageSizeChange` instead

# Pending work

## Link / Breadcrumb

- React Router has been removed from these components, and a method to integrate with them will be added next

## Notifications

- This will be migrated next, using the new designs

# Known issues

- Tooltips on button have been temporarily disabled due to a collision of events with onClick. This will be fixed asap
-

# Troubleshooting

If you have this error when importing this module: "Cannot find module '@pulse/foundations' or its corresponding type declarations." , it probably means you have an old tsconfig configuration

Solutions:

1. Change "moduleResolution" in tsconfig to "bundler" .

You will need Typescript 5

2. Change "moduleResolution" in tsconfig to "nodenext" .

This may requires you to add ".js" to all imports (don't add ".ts") (https://www.totaltypescript.com/
relative-import-paths-need-explicit-file-extensions-in-ecmascript-imports)
