export const options = [
  { value: "value one", label: "Option one" },
  { value: "value two", label: "Option two" },
  { value: "value three", label: "Option three", isDisabled: true },
  { value: "value four", label: "Option four" },
  { value: "value five", label: "Option five" },
  { value: "value six", label: "Option six" },
  { value: "value seven", label: "Option seven" },
  { value: "value eight", label: "Option eight" },
  { value: "value nine", label: "Option nine" },
];

const colors = [
  { value: "blue", label: "Blue" },
  { value: "red", label: "Red" },
  { value: "blue", label: "Blue" },
];

export const groupedOptions = [
  { label: "Numbers", options: options },
  { label: "Colors", options: colors },
];

export const numberOptions = [
  { value: "10", label: "10" },
  { value: "15", label: "15" },
  { value: "20", label: "20" },
];

const colors5 = [
  { value: "gray2", label: "gray2" },
  { value: "white2", label: "white2" },
];

const colors4 = [
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "colors5", label: "colors5", options: colors5 },
];

const colors3 = [
  { value: "gray", label: "gray" },
  { value: "white", label: "white" },
];

const colors2 = [
  { value: "blue", label: "Blue" },
  { value: "red", label: "Red" },
  { value: "colors3", label: "colors3", options: colors3 },
  { value: "colors4", label: "colors4", options: colors4 },
];

export const otherGroupedOptions = [
  { label: "Numbers", options: options, value: "numbers" },
  { label: "colors2", options: colors2, value: "colors2" },
];
