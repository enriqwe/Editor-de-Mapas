import type { ColumnDef } from "@pulse/components/table-v2";

import {
  OverflowMenu,
  OverflowMenuItem,
} from "@pulse/components/overflow-menu";

export type Person = {
  firstName: string;
  lastName: string;
  age: number;
  visits: number;
  progress: number;
  status: "relationship" | "complicated" | "single";
  subRows?: Person[];
};

export const dataWithSubRows: Person[] = [
  {
    firstName: "tanner",
    lastName: "linsley",
    age: 24,
    visits: 100,
    status: "relationship",
    progress: 50,
  },
  {
    firstName: "tandy",
    lastName: "miller",
    age: 40,
    visits: 40,
    status: "single",
    progress: 80,
  },
  {
    firstName: "joe",
    lastName: "dirte",
    age: 45,
    visits: 20,
    status: "complicated",
    progress: 10,
    subRows: [
      {
        firstName: "agust",
        lastName: "yoshimar",
        age: 22,
        visits: 100,
        status: "relationship",
        progress: 50,
      },
      {
        firstName: "julio",
        lastName: "ginesque",
        age: 24,
        visits: 100,
        status: "single",
        progress: 50,
      },
      {
        firstName: "jonas",
        lastName: "h2o",
        age: 24,
        visits: 100,
        status: "relationship",
        progress: 50,
        subRows: [
          {
            firstName: "jonas",
            lastName: "h2o",
            age: 24,
            visits: 100,
            status: "relationship",
            progress: 50,
          },
        ],
      },
    ],
  },
];

export const defaultData: Person[] = [
  {
    firstName: "tanner",
    lastName: "linsley perez",
    age: 24,
    visits: 100,
    status: "relationship",
    progress: 50,
  },
  {
    firstName: "tandy",
    lastName: "miller",
    age: 40,
    visits: 40,
    status: "single",
    progress: 80,
  },
  {
    firstName: "joe",
    lastName: "dirte",
    age: 45,
    visits: 20,
    status: "complicated",
    progress: 10,
  },
  {
    firstName: "agust",
    lastName: "yoshimar",
    age: 22,
    visits: 100,
    status: "relationship",
    progress: 50,
  },
  {
    firstName: "julio",
    lastName: "ginesque",
    age: 24,
    visits: 100,
    status: "single",
    progress: 50,
  },
  {
    firstName: "jonas",
    lastName: "h2o",
    age: 24,
    visits: 100,
    status: "relationship",
    progress: 50,
  },
];

export const defaultColumns: ColumnDef<Person>[] = [
  {
    id: "firstName",
    cell: info => info.getValue(),
    accessorKey: "firstName",
  },
  {
    id: "lastName",
    cell: info => <span>{info.getValue<string>()}</span>,
    accessorFn: row => row.lastName,
    header: () => <span>Last Name</span>,
  },
  {
    id: "age",
    header: () => "Age",
    cell: info => info.renderValue(),
    accessorKey: "age",
  },
  {
    id: "visits",
    header: () => <span>Visits</span>,
    accessorKey: "visits",
  },
  {
    id: "status",
    accessorKey: "status",
    header: "Status",
  },
  {
    id: "progress",
    accessorKey: "progress",
    header: "Profile Progress",
  },
  {
    id: "actions",
    header: "Actions",
    cell: () => (
      <OverflowMenu
        items={[
          { id: 1, name: "Home" },
          { id: 2, name: "Profile" },
          { id: 3, name: "Contact Us" },
        ]}
        onAction={() => {}}
        placement="end"
      >
        {items => (
          <OverflowMenuItem key={items.id} textValue={items.name}>
            <div>{items.name}</div>
          </OverflowMenuItem>
        )}
      </OverflowMenu>
    ),
  },
];

export const pinnedColumns: ColumnDef<Person>[] = [
  {
    id: "firstName",
    cell: info => info.getValue(),
    accessorKey: "firstName",
  },
  {
    id: "lastName",
    cell: info => <span>{info.getValue<string>()}</span>,
    accessorFn: row => row.lastName,
    header: () => <span>Last Name</span>,
  },
  {
    id: "age",
    header: () => "Age",
    cell: info => info.renderValue(),
    accessorKey: "age",
  },
  {
    id: "visits",
    header: () => <span>Visits</span>,
    accessorKey: "visits",
  },
  {
    id: "status",
    accessorKey: "status",
    header: "Status",
  },
  {
    id: "progress",
    accessorKey: "progress",
    header: "Profile Progress",
  },
  {
    id: "actions",
    header: "Actions",
    meta: {
      pinned: "right",
    },
    cell: () => (
      <OverflowMenu
        items={[
          { id: 1, name: "Home" },
          { id: 2, name: "Profile" },
          { id: 3, name: "Contact Us" },
        ]}
        onAction={() => {}}
        placement="end"
      >
        {items => (
          <OverflowMenuItem key={items.id} textValue={items.name}>
            <div>{items.name}</div>
          </OverflowMenuItem>
        )}
      </OverflowMenu>
    ),
  },
];

export const multiplyRows = (arr: any, n: number) => Array(n).fill(arr).flat();
