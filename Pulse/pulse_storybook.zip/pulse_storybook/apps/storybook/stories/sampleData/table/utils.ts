/**
 * Mock file only to serve as a simulation for Table with Backend logic
 */

import type { Dispatch, SetStateAction } from "react";
import type { TableProps } from "@pulse/components/table";

export function BEMockLogic(props: {
  totalData: any[];
  rowsData: any[];
  pageSize: number;
  updatePageSize: Dispatch<SetStateAction<number>>;
  updateActivePage: Dispatch<SetStateAction<number>>;
  updateRowsData: Dispatch<SetStateAction<any[]>>;
  updateSortDescriptor: Dispatch<
    SetStateAction<NonNullable<TableProps["initialSort"]>>
  >;

  setLoading: Dispatch<SetStateAction<boolean>>;
}) {
  const {
    totalData = [],
    rowsData = [],
    pageSize,
    updateSortDescriptor,
    updateRowsData,
    updateActivePage,
    updatePageSize,
    setLoading,
  } = props;

  const sort: TableProps["sortHandler"] = sortDescriptor => {
    setLoading(true);
    setTimeout(() => {
      const updatedList = rowsData.sort((itemA: any, itemB: any) => {
        const first = itemA[
          sortDescriptor.columnKey as keyof typeof itemA
        ].toLowerCase() as string;
        const second = itemB[
          sortDescriptor.columnKey as keyof typeof itemB
        ].toLowerCase() as string;
        let compareResult =
          (parseInt(first, 10) || first) < (parseInt(second, 10) || second) ?
            -1
          : 1;
        if (sortDescriptor.order === "descending") {
          compareResult *= -1;
        }
        return compareResult;
      });
      updateSortDescriptor(sortDescriptor);
      updateRowsData(updatedList);
      setLoading(false);
    }, 1000);
  };

  const pageChangeHandler = (pageNumber: number) => {
    setLoading(true);
    setTimeout(() => {
      updateActivePage(pageNumber);
      const firstPageIndex = (pageNumber - 1) * pageSize;
      const lastPageIndex = firstPageIndex + pageSize;
      updateRowsData(totalData.slice(firstPageIndex, lastPageIndex));
      setLoading(false);
    }, 1000);
  };

  const pageSizeChangeHandler = (newPageSize: number) => {
    setLoading(true);
    setTimeout(() => {
      updateActivePage(1);
      updatePageSize(newPageSize);
      updateRowsData(totalData.slice(0, newPageSize));
      setLoading(false);
    }, 1000);
  };

  return {
    sort,
    onPageChange: (newpageNumber: number) => {
      pageChangeHandler(newpageNumber);
    },
    onPageSizeChange: (newPageSize: number) => {
      pageSizeChangeHandler(newPageSize);
    },
  };
}
