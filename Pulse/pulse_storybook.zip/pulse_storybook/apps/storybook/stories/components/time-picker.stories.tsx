import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { action } from "storybook/actions";
import { TimePicker } from "@pulse/components/time-picker";
import { Time } from "@pulse/components/date-utils";
import type { TimePickerProps } from "@pulse/components/time-picker";

// @ts-expect-error - Fix for storybook issue with names in code
TimePicker.displayName = "TimePicker";

const meta: Meta<typeof TimePicker> = {
  component: TimePicker,
  title: "form/TimePicker",
  argTypes: {},
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=32575-21742&t=YVtlMQCVJNyKW6SL-0",
    },
  },
  render: args => {
    return <TimePickerWithState {...args} />;
  },
};

export default meta;

type Story = StoryObj<typeof TimePicker>;

function TimePickerWithState(props: TimePickerProps) {
  const [value, setValue] = useState<Time | null>(props.value || null);
  return (
    <TimePicker
      {...props}
      onTimeSelected={params => {
        setValue(params);
        action(params.toString());
      }}
      {...(value && { value })}
    />
  );
}

export const Simple: Story = {
  args: {
    label: "Time picker",
    required: false,
    withHelper: "Tristique senectus et netus et",
    disabled: false,
    error: false,
    invalidTime: new Time(2, 0),
    automationContext: "meeting-time",
    intervalTime: 15,
  },
};

export const WithValue: Story = {
  args: {
    label: "Time picker",
    required: false,
    withHelper: "Tristique senectus et netus et",
    disabled: false,
    error: false,
    invalidTime: new Time(2, 0),
    automationContext: "meeting-time",
    intervalTime: 15,
    value: new Time(15, 0),
  },
};
