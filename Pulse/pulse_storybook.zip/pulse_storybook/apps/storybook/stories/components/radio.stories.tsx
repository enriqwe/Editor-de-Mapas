import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Radio } from "@pulse/components/radio";

// @ts-expect-error - Fix for storybook issue with names in code
Radio.displayName = "Radio";

const meta: Meta<typeof Radio.Group> = {
  component: Radio.Group,
  title: "form/Radio",
  args: {
    onChange: fn(),
  },
  argTypes: {
    label: {
      description: "string",
    },
    defaultValue: {
      description: "string",
    },
    isDisabled: {
      description: "boolean",
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=32575-21741&mode=design&t=ZX8tbmnGt7izsEOf-0",
    },
  },
  render: args => {
    return <Radio.Group {...args}>{args.children}</Radio.Group>;
  },
};

export default meta;

type Story = StoryObj<typeof Radio.Group>;

export const Simple: Story = {
  args: {
    label: "Favorite sports",
    column: false,
    iconLeftAlign: true,
    isDisabled: false,
    automationContext: "favorite-sports",
    defaultValue: "baseball",
    isRequired: false,
    hasError: false,
    children: [
      <Radio.Item key="soccer" value="soccer">
        Soccer
      </Radio.Item>,
      <Radio.Item key="baseball" value="baseball">
        Baseball
      </Radio.Item>,
      <Radio.Item key="basketball" value="basketball">
        Basketball
      </Radio.Item>,
    ],
  },
};
