import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import {
  OverflowMenu,
  OverflowMenuItem,
} from "@pulse/components/overflow-menu";
import { Icon } from "@pulse/components/icon";

// @ts-expect-error - Fix for storybook issue with names in code
OverflowMenu.displayName = "OverflowMenu";
// @ts-expect-error - Fix for storybook issue with names in code
OverflowMenuItem.displayName = "OverflowMenuItem";

const meta: Meta<typeof OverflowMenu> = {
  component: OverflowMenu,
  title: "OverflowMenu",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=33121-25984&t=XLuxiptj5j5ASN2D-0",
    },
    // layout: "centered",
  },
  argTypes: {
    placement: {
      options: [
        "bottom end",
        "bottom start",
        "top start",
        "top end",
        "end",
        "start",
      ],
      control: { type: "radio" },
    },
  },
  render: ({ ...args }) => (
    <OverflowMenu onAction={() => fn()} {...args}>
      {args.children}
    </OverflowMenu>
  ),
};
export default meta;

type Story = StoryObj<typeof OverflowMenu>;

export const Simple: Story = {
  args: {
    placement: "end",
    automationContext: "nav-options",
    children: [
      <OverflowMenuItem key="Home">Home</OverflowMenuItem>,
      <OverflowMenuItem key="Profile">Profile</OverflowMenuItem>,
      <OverflowMenuItem key="Contact Us">Contact Us</OverflowMenuItem>,
    ],
  },
};

export const WithIcons: Story = {
  args: {
    placement: "end",
    automationContext: "nav-options",
    children: [
      <OverflowMenuItem key="Home" textValue="Home">
        <Icon icon="edit" size="s" /> Home
      </OverflowMenuItem>,
      <OverflowMenuItem key="Profile" textValue="Profile">
        <Icon icon="edit" size="s" /> Profile
      </OverflowMenuItem>,
      <OverflowMenuItem key="Contact Us" textValue="Contact Us">
        <Icon icon="edit" size="s" /> Contact Us
      </OverflowMenuItem>,
    ],
  },
};
