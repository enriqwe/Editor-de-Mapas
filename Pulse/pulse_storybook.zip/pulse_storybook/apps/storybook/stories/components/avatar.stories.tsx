import type { Meta, StoryObj } from "@storybook/react-vite";
import { Avatar } from "@pulse/components/avatar";

// @ts-expect-error - Fix for storybook issue with names in code
Avatar.displayName = "Avatar";

const meta: Meta<typeof Avatar> = {
  component: Avatar,
  title: "Avatar",
  argTypes: {
    size: {
      control: "radio",
      options: ["s", "m", "l"],
      description: "Size of the avatar",
      table: {
        defaultValue: { summary: "m" },
      },
    },
  },
};
export default meta;

type Story = StoryObj<typeof Avatar>;

export const Image: Story = {
  args: {
    src: "/images/avatar.png",
    name: "User Name",
    size: "m",
    automationContext: "user-image",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1242%3A8251&t=7BdsJyCSqjGm4hzj-0",
    },
  },
};

export const Text: Story = {
  args: {
    name: "User Name",
    size: "m",
    automationContext: "username",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1242%3A8251&t=7BdsJyCSqjGm4hzj-0",
    },
  },
};

export const Icon: Story = {
  args: {
    size: "m",
    automationContext: "user-icon",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1242%3A8251&t=7BdsJyCSqjGm4hzj-0",
    },
  },
};
