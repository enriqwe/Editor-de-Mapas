import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Toggle } from "@pulse/components/toggle";
import type { ToggleProps } from "@pulse/components/toggle";

Toggle.displayName = "Toggle";

const meta: Meta<ToggleProps> = {
  component: Toggle,
  title: "form/Toggle",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1112%3A333&t=EzsaZNLWwhT5r0YS-0",
    },
  },
  args: {
    onChange: fn(),
  },
  argTypes: {
    size: {
      control: "radio",
      options: ["small", "regular"],
      table: {
        defaultValue: {
          summary: "regular",
        },
      },
    },
  },
};

export default meta;

type Story = StoryObj<ToggleProps>;

export const Regular: Story = {
  args: {
    label: "Label as string prop",
    isDisabled: false,
    defaultSelected: false,
    reversed: false,
    isReadOnly: false,
    alignBothSides: false,
    children: <span>Label as children</span>,
    automationContext: "theme-mode",
    size: "regular",
  },
};

export const Small: Story = {
  args: {
    ...Regular.args,
    size: "small",
  },
};

export const Disabled: Story = {
  args: {
    ...Regular.args,
    isDisabled: true,
    isSelected: true,
    label: "Dark Mode",
  },
};

export const Reversed: Story = {
  args: {
    ...Regular.args,
    defaultSelected: true,
    label: "Dark Mode",
    reversed: true,
  },
};

export const RightLeftAligned: Story = {
  args: {
    ...Regular.args,
    defaultSelected: false,
    label: "Right Left Aligned",
    reversed: true,
    alignBothSides: true,
  },
};
