import type { Meta, StoryObj } from "@storybook/react-vite";
import { Breadcrumb } from "@pulse/components/breadcrumb";

// @ts-expect-error - Fix for storybook issue with names in code
Breadcrumb.displayName = "Breadcrumb";

const meta: Meta<typeof Breadcrumb> = {
  component: Breadcrumb,
  title: "Breadcrumb",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=984%3A157&t=2S6z8OhFuoCB8udR-0",
    },
  },
};

export default meta;

type Story = StoryObj<typeof Breadcrumb>;

export const Primary: Story = {
  args: {
    to: [
      { to: "event", label: "Event" },
      { to: "new_event", label: "New Event" },
    ],
    automationContext: "event-path",
  },
};
