import type { Meta, StoryObj } from "@storybook/react-vite";
import { useArgs } from "storybook/preview-api";
import { SideNav } from "@pulse/components/side-nav";
import { PulseContext } from "@pulse/components/context";
import { action } from "storybook/actions";

// @ts-expect-error - Fix for storybook issue with names in code
SideNav.displayName = "SideNav";

const meta: Meta<typeof SideNav> = {
  component: SideNav,
  title: "SideNav",
  parameters: {
    layout: "fullscreen",
  },
  argTypes: {
    isExpanded: {
      type: "boolean",
    },
    isOpen: {
      type: "boolean",
    },
  },
};

export default meta;

type Story = StoryObj<typeof SideNav>;

export const Default: Story = {
  render: function Render(args) {
    const [, setArgs] = useArgs();

    return (
      <PulseContext router={{navigate: action("Navigate")}}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "auto minmax(0, 1fr)",
            gridTemplateRows: "minmax(0, 1fr)",
            height: "400px",
          }}
        >
          <SideNav
            {...args}
            onClose={() => {
              setArgs({ ...args, isOpen: false });
            }}
          />
          <div style={{ padding: "1rem" }}>Page content</div>
        </div>
      </PulseContext>
    );
  },
  args: {
    isExpanded: true,
    isOpen: false,
    activeItemId: "7",
    items: [
      {
        id: "1",
        label: "Dashboard (1)",
        icon: "monitoring",
        link: {
          href: "#",
        },
      },
      {
        id: "2",
        label: "Contenido (2)",
        icon: "folder",
        items: [
          {
            id: "3",
            label: "Noticias (3)",
            link: {
              href: "#",
            },
          },
          {
            id: "4",
            label: "Galerías (4)",
            link: {
              href: "#",
            },
          },
          {
            id: "5",
            label: "Multimedia (5)",
            items: [
              {
                id: "6",
                label: "Imágenes (6)",
                link: {
                  href: "#",
                },
              },
              {
                id: "7",
                label: "Vídeos (7)",
                link: {
                  href: "#",
                },
              },
              {
                id: "8",
                label: "Documentos (8)",
                link: {
                  href: "#",
                },
              },
            ],
          },
        ],
      },
      {
        id: "9",
        label: "Interacciones (9)",
        icon: "waving_hand",
        items: [
          {
            id: "10",
            label: "Formularios (10)",
            items: [
              {
                id: "11",
                label: "Recibidos (11)",
                link: {
                  href: "#",
                },
              },
              {
                id: "12",
                label: "Pendientes (12)",
                link: {
                  href: "#",
                },
              },
            ],
          },
          {
            id: "13",
            label: "Votaciones (13)",
            items: [
              {
                id: "14",
                label: "Recibidas (14)",
                link: {
                  href: "#",
                },
              },
              {
                id: "15",
                label: "Resultados (15)",
                link: {
                  href: "#",
                },
              },
            ],
          },
        ],
      },
      {
        id: "16",
        label: "Organización (16)",
        icon: "domain",
        items: [
          {
            id: "17",
            label: "Permisos (17)",
            link: {
              href: "#",
            },
          },
          {
            id: "18",
            label: "Usuarios (18)",
            link: {
              href: "#",
            },
          },
        ],
      },
    ],
  },
  // parameters: {
  //   design: {
  //     type: "figma",
  //     url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=26714-17408&t=gFsAf0hbDfqaQYiB-0",
  //   },
  //   layout: "centered",
  // },
};
