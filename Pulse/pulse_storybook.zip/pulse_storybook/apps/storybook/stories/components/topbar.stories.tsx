import type { Meta, StoryObj } from "@storybook/react-vite";
import { Topbar } from "@pulse/components/topbar";
import { PulseContext } from "@pulse/components/context";
import type { TopbarProps } from "@pulse/components/topbar";
import { useState } from "react";
import { action } from "storybook/actions";

// @ts-expect-error - Fix for storybook issue with names in code
Topbar.displayName = "Topbar";

const meta: Meta<typeof Topbar> = {
  component: Topbar,
  title: "Topbar",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/CMS-Core-Components?m=auto&node-id=39304-32203&t=qAWrHimoPhehPfY4-1",
    },
  },
};

export default meta;

type Story = StoryObj<typeof Topbar>;

type Locale = NonNullable<TopbarProps["languages"]>["items"][number];
type OrganizationItem = NonNullable<
  TopbarProps["organizations"]
>["items"][number];

function TopbarStateWrapper(props: TopbarProps) {
  const { logo, userProfile, organizations, languages } = props;

  const [currentOrganization, setCurrentOrganization] = useState<
    OrganizationItem | undefined
  >(organizations?.current);
  const [currentLanguage, setCurrentLanguage] = useState<Locale | undefined>(
    languages?.current
  );

  const finalArgs: TopbarProps = {
    logo,
    userProfile: {
      name: userProfile.name,
      items: userProfile.items,
    },
  };

  if (organizations && currentOrganization) {
    finalArgs.organizations = {
      current: currentOrganization,
      items: organizations.items,
      onChange: (value: OrganizationItem) => {
        organizations.onChange(value);
        setCurrentOrganization(value);
      },
    };
  }

  if (languages && currentLanguage) {
    finalArgs.languages = {
      current: currentLanguage,
      items: languages.items,
      onChange: (value: Locale) => {
        languages.onChange(value);
        setCurrentLanguage(value);
      },
    };
  }

  return (
    <PulseContext locale={currentLanguage}>
      <Topbar {...finalArgs} />
    </PulseContext>
  );
}

export const Default: Story = {
  render: argsParam => {
    return <TopbarStateWrapper {...argsParam} />;
  },
  args: {
    logo: {
      href: "https://example.com",
      src: {
        mobile: "images/sportian_isotype.png",
        desktop: "images/sportian_positive.png",
      },
    },
    organizations: {
      current: {
        id: "1",
        label: "Organization 1",
        logoSrc: "images/sportian_isotype.png",
      },
      items: [
        {
          id: "1",
          label: "Organization 1",
          logoSrc: "images/sportian_isotype.png",
        },
        {
          id: "2",
          label: "Org 2",
          logoSrc: "images/sportian_isotype.png",
        },
        {
          id: "3",
          label: "Client 3",
          logoSrc: "images/sportian_isotype.png",
        },
      ],
      onChange: action("Organization changed"),
    },
    userProfile: {
      name: "John Doe",
      items: [
        {
          id: "1",
          label: "User Action",
          icon: "settings",
          onPress: action("User Action click"),
        },
        {
          id: "2",
          label: "Settings",
          onPress: action("Settings 1 click"),
        },
        {
          id: "3",
          label: "Log Out",
          onPress: action("Log Out 3 click"),
        },
      ],
    },
    onHamburguerPress: action("Hamburguer pressed"),
    languages: {
      current: "es-ES",
      items: ["es-ES", "en-US", "fr-FR", "de-DE"],
      onChange: action("Language changed"),
    },
  },
};
