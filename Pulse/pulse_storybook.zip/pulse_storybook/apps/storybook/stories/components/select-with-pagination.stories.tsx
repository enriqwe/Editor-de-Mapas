import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { useEffect, useRef, useState } from "react";
import { SelectWithPagination } from "@pulse/components/select-with-pagination";
import type {
  SelectWithPaginationProps,
  SelectWithPaginationOption,
  SelectWithPaginationRef,
} from "@pulse/components/select-with-pagination";

const defaultOpt: SelectWithPaginationOption[] = [
  {
    label: "Liam Garcia | liam.garcia@x.dummyjson.com",
    value: 1,
  },
  {
    label: "Michael Williams | michael.williams@x.dummyjson.com",
    value: 2,
  },
  {
    label: "Sophia Brown | sophia.brown@x.dummyjson.com",
    value: 3,
    isDisabled: true,
  },
  {
    label: "James Davis | james.davis@x.dummyjson.com",
    value: 4,
  },
  {
    label: "Emma Miller | emma.miller@x.dummyjson.com",
    value: 5,
  },
  {
    label: "Olivia Wilson | olivia.wilson@x.dummyjson.com",
    value: 6,
  },
  {
    label: "Alexander Jones | alexander.jones@x.dummyjson.com",
    value: 7,
  },
  {
    label: "Ava Taylor | ava.taylor@x.dummyjson.com",
    value: 8,
    isDisabled: true,
  },
  {
    label: "Ethan Martinez | ethan.martinez@x.dummyjson.com",
    value: 9,
  },
  {
    label: "Isabella Anderson | isabella.anderson@x.dummyjson.com",
    value: 10,
  },
];

SelectWithPagination.displayName = "SelectWithPagination";

const meta: Meta<typeof SelectWithPagination> = {
  component: SelectWithPagination,
  title: "Select With Pagination",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1033%3A86&t=cUz8Iqj1hwYUyk8y-0",
    },
  },
  argTypes: {
    isClearable: { type: "boolean" },
    noOptionsMessage: { type: "string" },
  },
  args: {
    isClearable: false,
    options: [],
    isMulti: false,
    label: "Testing a label",
    required: false,
    disabled: false,
    automationContext: "select",
  },
  render: args => {
    return <SelectWithPaginationWithState {...args} />;
  },
};

export default meta;

type Story = StoryObj<typeof SelectWithPagination>;

// const StorySelectWithPagination = (
//   props: ComponentProps<typeof SelectWithPagination> & {
//     // this props is for storybook test purpose only
//     // if true, a button is added to simulate an external action that clears the input
//     showClearInputButton: boolean;
//     showClearSelectionButton: boolean;
//   }
// ) => <SelectWithPagination {...props} />;

function SelectWithPaginationWithState(
  props: Partial<SelectWithPaginationProps>
) {
  const {
    name,
    isClearable,
    isMulti,
    automationContext,
    label,
    dropdownInline,
    disabled,
    required,
    noOptionsMessage,
    // options = [],
    tooltipContent,
    helperText,
    errorMessage,
    minInputLength,
    placeholder,
    clearInputOnChange = false,
    // showClearInputButton = false,
    allowedCharRegExp,
    menuPlacement = "auto",
    // showClearSelectionButton = false,
  } = props;

  const [isLoading, setIsLoading] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [value, setValue] = useState<
    SelectWithPaginationOption | SelectWithPaginationOption[] | null
  >(null);
  const pageSize = props.pageSize ?? 10;
  const [options, setOptions] = useState<SelectWithPaginationOption[]>(
    props.options ?? []
  );
  const [totalOptions, setTotalOptions] = useState<number>(0);

  const [page, setPage] = useState(0);
  const selectRef = useRef<SelectWithPaginationRef | null>(null);

  const getData = async (
    input: string,
    newPage: number,
    newPageSize: number
  ) => {
    const response = await fetch(
      `https://dummyjson.com/users/search?q=${input.toLowerCase()}&skip=${newPage}&limit=${newPageSize}&select=firstName,lastName,email`
    );
    const data = (await response.json()) as {
      users: {
        firstName: string;
        lastName: string;
        email: string;
        id: number;
      }[];
      total: number;
    };

    return data;
  };

  useEffect(() => {
    async function updateThisPage() {
      if (page) {
        setIsLoading(true);
        const data = await getData(searchValue, page * pageSize, pageSize);

        setTimeout(() => {
          setOptions(prev => {
            return [
              ...prev,
              ...data.users.map(val => ({
                label: `${val.firstName} ${val.lastName} | ${val.email}`,
                value: val.id,
              })),
            ];
          });
          setTotalOptions(data.total);
          setIsLoading(false);
        }, 2000);
      }
    }
    updateThisPage().catch(() => {
      //console.log("something went wrong");
    });
  }, [page]);

  useEffect(() => {
    async function updateSearchValue() {
      if (searchValue) {
        setIsLoading(true);
        const data = await getData(searchValue, 0, pageSize);

        const { users } = data;
        setOptions(
          users.map(val => ({
            label: `${val.firstName} ${val.lastName} | ${val.email}`,
            value: val.id,
          }))
        );
        setTotalOptions(data.total);
        setIsLoading(false);
      }
      if (!searchValue) {
        setOptions([]);
        setTotalOptions(0);
        setPage(0);
        setIsLoading(false);
      }
    }

    updateSearchValue().catch(() => {
      // console.log("something went wrong");
    });
  }, [searchValue, pageSize]);

  // const onChange = (newValue) => {
  //   setValue(newValue);
  // };

  const onPageEndReached = () => {
    if (totalOptions > options.length && !isLoading)
      setPage(prevPage => prevPage + 1);
  };

  /*   const onInputClear = () => {
    selectRef.current?.clearInput();
  };

  const onClearSelectedOptions = () => {
    selectRef.current?.clearSelectedOptions();
  }; */

  return (
    <div style={{ width: 500 }}>
      <SelectWithPagination
        clearInputOnChange={clearInputOnChange}
        disabled={disabled}
        dropdownInline={dropdownInline}
        initialValue={value}
        isClearable={isClearable}
        isLoading={isLoading}
        isMulti={isMulti}
        label={label}
        menuPlacement={menuPlacement}
        name={name}
        noOptionsMessage={noOptionsMessage}
        onChange={newValue => {
          setValue(
            Array.isArray(newValue) ?
              ([...newValue] as SelectWithPaginationOption[])
            : (newValue as SelectWithPaginationOption)
          );
        }}
        onInputChange={setSearchValue}
        onPageEndReached={onPageEndReached}
        options={options}
        pageSize={pageSize}
        ref={selectRef}
        required={required}
        totalOptions={totalOptions}
        {...(placeholder && { placeholder })}
        {...(automationContext && { automationContext })}
        {...(tooltipContent && { tooltipContent })}
        {...(helperText && { helperText })}
        {...(errorMessage && { errorMessage })}
        {...(minInputLength && { minInputLength })}
        {...(allowedCharRegExp && { allowedCharRegExp })}
      />
      {/* {showClearInputButton ?
        <Button onPress={onInputClear}>Clear input</Button>
      : null}
      {showClearSelectionButton ?
        <Button onPress={onClearSelectedOptions}>Clear Selection</Button>
      : null} */}
    </div>
  );
}

export const Default: Story = {
  args: {
    tooltipContent: "info",
    required: true,
    helperText: "Optional helper text",
    errorMessage: "",
    minInputLength: 0,
    placeholder: "Start typing and choose an option...",
    onInputChange: action("onInputChange"),
  },
};

export const SingleSelect: Story = {
  args: {
    isMulti: false,
    tooltipContent: "tooltip info content",
    placeholder: "Start typing and choose an option...",
  },
};

export const MultiSelect: Story = {
  args: {
    isMulti: true,
    tooltipContent: "tooltip info content",
    placeholder: "Start typing and choose an option...",
  },
};

// export const MultiSelectWithClearButton: Story = {
//   args: {
//     isMulti: true,
//     tooltipContent: "tooltip info content",
//     placeholder: "Start typing and choose an option...",
//     showClearInputButton: true,
//     showClearSelectionButton: true,
//   },
// };

export const Error: Story = {
  args: {
    placeholder: "Start typing and choose an option...",
    errorMessage: "Some validation or api error",
  },
};

export const MinimunInputCharacters: Story = {
  args: {
    tooltipContent: "info",
    helperText: "Optional helper text",
    minInputLength: 3,
    placeholder: "Start typing and choose an option...",
  },
};

export const DefaultOptions: Story = {
  args: {
    tooltipContent: "info",
    helperText: "Optional helper text",
    placeholder: "Start typing and choose an option...",
    options: defaultOpt,
  },
};

export const SingleSelectWithAllowedCharRegExp: Story = {
  args: {
    tooltipContent: "tooltip info content",
    placeholder: "Start typing and choose an option...",
    allowedCharRegExp: /^[a-zA-Z0-9\u00C0-\u017F]*$/,
  },
};

export const MultiSelectWithAllowedCharRegExp: Story = {
  args: {
    isMulti: true,
    tooltipContent: "tooltip info content",
    placeholder: "Start typing and choose an option...",
    allowedCharRegExp: /^[a-zA-Z0-9\u00C0-\u017F]*$/,
  },
};
