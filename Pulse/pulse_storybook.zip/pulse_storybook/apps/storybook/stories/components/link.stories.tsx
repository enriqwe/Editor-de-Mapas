import type { Meta, StoryObj } from "@storybook/react-vite";
import { Link } from "@pulse/components/link";

// @ts-expect-error - Fix for storybook issue with names in code
Link.displayName = "Link";

const meta: Meta<typeof Link> = {
  component: Link,
  title: "Link",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1174%3A2410&t=WhH1cNBThAmYubzY-0",
    },
  },
  argTypes: {
    variant: {
      options: ["standalone", "inline"],
      control: { type: "radio" },
      table: {
        defaultValue: {
          summary: "standalone",
        },
      },
    },
    iconLeft: {
      control: {
        type: "text",
      },
    },
    iconRight: {
      control: {
        type: "text",
      },
    },
  },
};

export default meta;

type Story = StoryObj<typeof Link>;

// randomURL to avoid always seeing the :visited style
const randomDomain = Math.random().toString(36).substring(2, 15);
const randomURL = `https://${randomDomain}.com`;

export const Standalone: Story = {
  args: {
    children: "Link label 1",
    href: randomURL,
    isDisabled: false,
    size: "m",
    automationContext: "hacker-rank",
    target: "_blank",
    variant: "standalone",
  },
};

export const Inline: Story = {
  args: {
    children: "Link label 1",
    href: randomURL,
    isDisabled: false,
    size: "m",
    automationContext: "hacker-rank",
    target: "_blank",
    variant: "inline",
  },
};

export const Visited: Story = {
  args: {
    children: "Link label 1",
    href: "https://www.google.com/",
    isDisabled: false,
    size: "m",
    automationContext: "visited",
    target: "_blank",
  },
};

export const Disabled: Story = {
  args: {
    children: "Link label 1",
    href: "https://www.hackerrank.com/",
    isDisabled: true,
    size: "m",
    automationContext: "not-allowed",
  },
};

export const IconLeft: Story = {
  args: {
    children: "Link label 1",
    href: randomURL,
    isDisabled: false,
    iconLeft: "chevron_left",
    size: "m",
    automationContext: "hacker-rank",
  },
};

export const IconRight: Story = {
  args: {
    children: "Link label 1",
    href: randomURL,
    iconRight: "open_in_new",
    isDisabled: false,
    size: "m",
    automationContext: "hacker-rank",
  },
};
