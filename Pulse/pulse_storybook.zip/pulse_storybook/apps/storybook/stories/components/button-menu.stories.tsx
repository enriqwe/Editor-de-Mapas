import type { Meta, StoryObj } from "@storybook/react-vite";
import { ButtonMenu } from "@pulse/components/button-menu";
import { action } from "storybook/actions";
import type { ButtonMenuProps } from "@pulse/components/button-menu";

// @ts-expect-error - Fix for storybook issue with names in code
ButtonMenu.displayName = "ButtonMenu";

const meta: Meta<ButtonMenuProps> = {
  component: ButtonMenu.Menu,
  title: "ButtonMenu",
  parameters: {
    docs: {
      description: {
        component:
          "ButtonMenu is a component that allows users to trigger actions from a list of options.",
      },
      design: {
        type: "figma",
        url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=43583-19258&mode=design&t=C9OWOoPijOBPR9NJ-0",
      },
      layout: "centered",
    },
  },
  argTypes: {
    label: {
      description: "The label of the button menu.",
    },
    placement: {
      description:
        "The placement of the menu relative to the button. The default value is `left`.",
      options: ["left", "right", "stretch"],
      control: "radio",
    },
    variant: {
      description:
        "The visual style of the button menu. The default value is `filled`.",
      options: ["filled", "flat", "outline"],
      control: "radio",
    },
    children: {
      description:
        "The content of the button menu. It can be a single item, a group of items, or a list of groups.",
    },
  },
  render: ({ ...args }: ButtonMenuProps) => (
    <ButtonMenu.Menu {...args}>{args.children}</ButtonMenu.Menu>
  ),
  decorators: [
    Story => (
      <div style={{ display: "flex", justifyContent: "center" }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;

type Story = StoryObj<typeof ButtonMenu.Menu>;

export const MultipleItems: Story = {
  args: {
    label: "Choose an option",
    placement: "left",
    variant: "flat",
    children: [
      <ButtonMenu.Item
        iconLeft="move"
        key="Action item 1"
        name="Action item 1"
        onClick={action("action item 1 clicked")}
      />,
      <ButtonMenu.Item
        iconLeft="edit"
        key="Action item 2"
        name="Action item 2"
        onClick={action("action item 2 clicked")}
      />,
      <ButtonMenu.Item
        iconLeft="delete"
        key="Action item 3"
        name="Action item 3"
        onClick={action("action item 3 clicked")}
      />,
    ],
  },
};

export const OneItem: Story = {
  args: {
    label: "Choose an option",
    placement: "left",
    variant: "outline",
    children: [
      <ButtonMenu.Item
        iconLeft="download"
        name="Action item 1"
        onClick={action("action item 1 clicked")}
      />,
    ],
  },
};

export const OneGroupMultipleItems: Story = {
  args: {
    label: "Choose an option",
    placement: "left",
    variant: "filled",
    children: (
      <ButtonMenu.Group key="grouped list title" name="grouped list title">
        <ButtonMenu.Item
          iconLeft="edit"
          name="Action item 1"
          onClick={action("action item 1 clicked")}
        />
        <ButtonMenu.Item
          iconLeft="delete"
          name="Action item 2"
          onClick={action("action item 2 clicked")}
        />
        <ButtonMenu.Item
          iconLeft="add_circle"
          name="Action item 3"
          onClick={action("action item 3 clicked")}
        />
      </ButtonMenu.Group>
    ),
  },
};

export const MultipleGroups: Story = {
  args: {
    label: "Choose an option",
    placement: "left",
    variant: "filled",
    children: [
      <ButtonMenu.Group key="grouped list 1 title" name="grouped list 1 title">
        <ButtonMenu.Item
          iconLeft="edit"
          name="Action item 1"
          onClick={action("action item 1 clicked")}
        />
        <ButtonMenu.Item
          iconLeft="delete"
          name="Action item 2"
          onClick={action("action item 2 clicked")}
        />
      </ButtonMenu.Group>,
      <ButtonMenu.Group key="grouped list 2 title" name="grouped list 2 title">
        <ButtonMenu.Item
          iconLeft="add_circle"
          name="Action item 3"
          onClick={action("action item 3 clicked")}
        />
        <ButtonMenu.Item
          iconLeft="download"
          name="Action item 4"
          onClick={action("action item 4 clicked")}
        />
      </ButtonMenu.Group>,
    ],
  },
};
