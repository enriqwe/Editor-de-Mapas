import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { DynamicTag as DynamicTagComponent } from "@pulse/components/tag";

// @ts-expect-error - Fix for storybook issue with names in code
DynamicTagComponent.displayName = "DynamicTag";

const meta: Meta<typeof DynamicTagComponent> = {
  component: DynamicTagComponent,
  title: "Tags/DynamicTag",
  args: {
    onClick: fn(),
  },
  argTypes: {
    variant: {
      control: "select",
      options: ["default", "deleted"],
    },
  },
};

export default meta;

type Story = StoryObj<typeof DynamicTagComponent>;

export const Default: Story = {
  args: {
    label: "Default",
    variant: "default",
    disabled: false,
    automationContext: "informative",
  },
};
