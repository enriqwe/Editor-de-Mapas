import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { DatePicker } from "@pulse/components/date-picker";
import { today, getLocalTimeZone } from "@pulse/components/date-utils";

// @ts-expect-error - Fix for storybook issue with names in code
DatePicker.displayName = "DatePicker";

const meta: Meta<typeof DatePicker> = {
  component: DatePicker,
  title: "form/DatePicker",
  args: {
    onChange: fn(),
  },
  argTypes: {
    label: {
      description: "string",
    },
    validationState: {
      description: "string",
      options: ["valid", "invalid"],
      control: { type: "radio" },
    },
    isRequired: {
      description: "boolean",
    },
    minValue: {
      description:
        "Minimun  date value user can enter. Give date format in yyyy/mm/dd",
    },
    errorMessage: {
      description: "Error message to be shown when validation fails",
    },
  },
};

export default meta;

type Story = StoryObj<typeof DatePicker>;

// const Template: ComponentStory<typeof DatePicker> = args => {
//   const [date, setDate] = useState("");

//   return (
//     <>
//       <DatePicker
//         onChange={value => setDate(value.toString())}
//         minValue={today(getLocalTimeZone())}
//         onBlur={() => action("onBlur action")}
//         errorMessage={"You have an error"}
//         {...args}
//       />
//     </>
//   );
// };

// const today = generateDate();

export const DefaultAndWithLabel: Story = {
  args: {
    label: "Example Label",
    description: "Tristique senectus et netus et",
    disabled: false,
    isRequired: false,
    automationContext: "date-of-birth",
    locale: "es-ES",
    minValue: today(getLocalTimeZone()),
  },
};

export const DefaultWithLabelAndLabelTooltipContent: Story = {
  args: {
    label: "Example Label",
    validationState: "valid",
    description: "Tristique senectus et netus et",
    disabled: false,
    isRequired: false,
    automationContext: "date-of-birth",
    labelTooltipContent: "Text Tooltip",
  },
};

export const RequiredLabelAndLabelTooltipContent: Story = {
  args: {
    label: "Example Label",
    description: "Tristique senectus et netus et",
    disabled: false,
    isRequired: true,
    automationContext: "date-of-birth",
    labelTooltipContent: "Text Tooltip",
  },
};

export const WithErrorMessage: Story = {
  args: {
    label: "Example Label",
    validationState: "invalid",
    description: "Tristique senectus et netus et",
    disabled: false,
    isRequired: false,
    automationContext: "date-of-birth",
    errorMessage: "You have an error",
  },
};
