import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { IconButton } from "@pulse/components/icon-button";

// @ts-expect-error - Fix for storybook issue with names in code
IconButton.displayName = "IconButton";

const meta: Meta<typeof IconButton> = {
  component: IconButton,
  title: "IconButton",
  args: {
    onPress: fn(),
  },
  argTypes: {
    iconSize: {
      control: "radio",
      options: ["xs", "s", "m", "l", "xl"],
      description: "Ignored if `size` is not undefined"
    },
    size: {
      control: "radio",
      options: ["default", "medium", "small", undefined],
    },
  }
};
export default meta;

type Story = StoryObj<typeof IconButton>;

export const Iconbutton: Story = {
  args: {
    iconName: "menu",
    tooltipContent: "tooltip text",
    isDisabled: false,
    automationContext: "more-icon-button",
    iconSize: "m",
    size: "default",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=32569-20916&t=HL2XlY1mT6TKf0X3-0",
    },
    layout: "centered",
  },
};
