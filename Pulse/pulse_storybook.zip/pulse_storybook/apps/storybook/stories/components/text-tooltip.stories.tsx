import type { Meta, StoryObj } from "@storybook/react-vite";
import { TextTooltip } from "@pulse/components/text-tooltip";

// @ts-expect-error - Fix for storybook issue with names in code
TextTooltip.displayName = "TextTooltip";

const meta: Meta<typeof TextTooltip> = {
  component: TextTooltip,
  title: "TextTooltip",
  argTypes: {},
  args: {
    children:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  },
};

export default meta;

type Story = StoryObj<typeof TextTooltip>;

export const Simple: Story = {
  args: {
    alwaysShow: true,
    tooltipText: "custom tooltip text",
  },
};

export const DoNotCapitalize: Story = {
  args: {
    alwaysShow: true,
    capitalize: false,
    tooltipText: "custom tooltip text",
  },
};
