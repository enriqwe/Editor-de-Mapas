import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Box } from "@pulse/components/box";

// @ts-expect-error - Fix for storybook issue with names in code
Box.displayName = "Box";

const meta: Meta<typeof Box> = {
  component: Box,
  title: "Box",
  args: {
    icon: "house",
    title: "Title",
    subtitle: "This is a subtitle",
    actionsType: "chips",
    children: "Content",
  },
};

export default meta;

type Story = StoryObj<typeof Box>;

export const FullUsageWithChips: Story = {
  args: {
    icon: "house",
    title: "Title",
    subtitle: "This is a subtitle",
    actionsType: "chips",
    actions: [
      {
        label: "Enabled",
        disabled: false,
        onClick: fn(),
      },
      {
        label: "Disabled",
        disabled: true,
        onClick: fn(),
      },
    ],
    children: "Content",
  },
};

export const FullUsageWithIcons: Story = {
  args: {
    icon: "house",
    title: "Title",
    subtitle: "This is a subtitle",
    actionsType: "icons",
    actions: [
      {
        iconName: "house",
        tooltipContent: "tooltip text",
        onClick: fn(),
        disabled: false,
        automationContext: "house-icon-button",
      },
      {
        iconName: "settings",
        tooltipContent: "tooltip text",
        onClick: fn(),
        disabled: false,
        automationContext: "settings-icon-button",
      },
    ],
    children: "Content",
  },
};
