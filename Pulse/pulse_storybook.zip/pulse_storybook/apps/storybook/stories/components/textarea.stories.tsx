import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Textarea } from "@pulse/components/textarea";

// @ts-expect-error - Fix for storybook issue with names in code
Textarea.displayName = "Textarea";

const meta: Meta<typeof Textarea> = {
  component: Textarea,
  title: "form/Textarea",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1194%3A7581&t=k9DdSIO5jdNiFjBm-0",
    },
  },
  args: {
    onChange: fn(),
  },
  argTypes: {
    maxLength: {
      control: {
        type: "number",
      },
    },
  },
};

export default meta;

type Story = StoryObj<typeof Textarea>;

export const BaseTextarea: Story = {
  args: {
    disabled: false,
    isError: false,
    required: false,
    subText: "Subtexto",
    placeholder: "Placeholder text",
    automationContext: "address",
  },
};

export const WithLabelTooltipContentAndRequired: Story = {
  args: {
    disabled: false,
    isError: false,
    required: true,
    placeholder: "Placeholder",
    automationContext: "address",
    labelTooltipContent: "Text Tooltip",
    maxLength: 30,
  },
};

export const WithError: Story = {
  args: {
    disabled: false,
    isError: true,
    errorMessage: "Error message",
    required: true,
    placeholder: "Placeholder",
    automationContext: "address",
    labelTooltipContent: "Text Tooltip",
  },
};
