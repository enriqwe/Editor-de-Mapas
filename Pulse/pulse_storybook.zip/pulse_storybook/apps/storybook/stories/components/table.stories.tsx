import type { Meta, StoryObj } from "@storybook/react-vite";
import { useEffect, useState } from "react";
import { action } from "storybook/actions";
import { Table } from "@pulse/components/table";
import type { TableProps } from "@pulse/components/table";

import {
  FEAndBEHeadersData,
  defaultHeadersData,
  paginationTableData,
  rowWithInputMockData,
  usersMockData,
} from "../sampleData/table/data";
import { BEMockLogic } from "../sampleData/table/utils";
import { MockTableFilter, type TableFilter } from "../sampleData/table/filter";

// @ts-expect-error - Fix for storybook issue with names in code
Table.displayName = "Table";

const meta: Meta<typeof Table> = {
  component: Table,
  title: "Table",
  argTypes: {
    locale: {
      options: ["es-ES", "fr-FR", "de-DE", "en-EN"],
      control: { type: "select" },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?node-id=34143-23683&t=gEZYXOXBO2MzJTVn-0",
    },
  },
  args: {
    dataHandling: "frontend",
    ariaLabel: "default-table",
  },
};

export default meta;

type Story = StoryObj<typeof Table>;

function TableBEComponent(props: TableProps) {
  const {
    dataHandling = "backend",
    tableData,
    disablePagination = false,
    paginationProps = {},
    initialSort = { columnKey: "", order: "ascending" },
    showSelectAll = false,
    selectedRows = () => null,
    automationContext = "",
  } = props;

  const { data, headers } = tableData;
  const {
    totalRecords = data.length,
    activePageNo = 1,
    pageSizeList = [],
    defaultPageSize = 10,
  } = paginationProps;

  const [activePage, setActivePage] = useState(activePageNo);
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const [rowsData, setRowsData] = useState<any>([]);
  const [sortDescriptor, setSortDescriptor] = useState(initialSort);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!disablePagination) {
      const firstPageIndex = (activePage - 1) * pageSize;
      const lastPageIndex = firstPageIndex + pageSize;
      setRowsData(data.slice(firstPageIndex, lastPageIndex));
    }
  }, [activePage, pageSize, data, disablePagination]);

  // mock utility function only to simulate backend logic
  const mockBEProps = BEMockLogic({
    rowsData,
    totalData: data,
    pageSize,
    updatePageSize: setPageSize,
    updateActivePage: setActivePage,
    updateRowsData: setRowsData,
    updateSortDescriptor: setSortDescriptor,
    setLoading: setIsLoading,
  });

  return (
    <Table
      ariaLabel="default-table"
      automationContext={automationContext}
      dataHandling={dataHandling}
      disablePagination={disablePagination}
      initialSort={sortDescriptor}
      loading={isLoading}
      paginationProps={{
        pageSizeList,
        totalRecords,
        activePageNo: activePage,
        defaultPageSize: pageSize,
        onPageChange: mockBEProps.onPageChange,
        onPageSizeChange: mockBEProps.onPageSizeChange,
      }}
      selectedRows={selectedRows}
      showSelectAll={showSelectAll}
      sortHandler={mockBEProps.sort}
      tableData={{
        headers,
        data: rowsData,
      }}
    />
  );
}

export const Simple: Story = {
  args: {
    tableData: {
      headers: defaultHeadersData,
      data: usersMockData,
    },
    showSelectAll: true,
    selectedRows: action("selected rows"),
    automationContext: "default-table",
    locale: "es-ES",
  },
};

export const FrontendDataHandling: Story = {
  args: {
    automationContext: "table-fe",
    disablePagination: false,
    initialSort: {
      columnKey: "phone",
      order: "ascending",
    },
    paginationProps: {
      pageSizeList: [10, 20, 30, 40, 50],
      activePageNo: 1,
      defaultPageSize: 10,
    },
    tableData: {
      data: paginationTableData.slice(0, 35),
      headers: FEAndBEHeadersData,
    },
    dataHandling: "frontend",
    showSelectAll: true,
    selectedRows: action("selected rows"),
    locale: "es-ES",
  },
};

export const BackendDataHandling: Story = {
  args: {
    automationContext: "table-be",
    disablePagination: false,
    initialSort: {
      columnKey: "phone",
      order: "ascending",
    },
    paginationProps: {
      pageSizeList: [10, 20, 30, 40, 50],
      activePageNo: 1,
      defaultPageSize: 10,
    },
    tableData: {
      data: paginationTableData.slice(0, 35),
      headers: FEAndBEHeadersData,
    },
    dataHandling: "backend",
    showSelectAll: true,
    selectedRows: action("selected rows"),
  },
  render: args => {
    return <TableBEComponent {...args} />;
  },
};

export const WithInputs: Story = {
  args: {
    tableData: {
      headers: defaultHeadersData,
      data: rowWithInputMockData,
    },
    showSelectAll: true,
    selectedRows: action("selected rows"),
    automationContext: "default-table",
  },
};

// Example with filters

function TableWithFiltersComponent(props: TableProps) {
  const [openTableFilter, setOpenTableFilter] = useState(false);

  const filtersCount = props.filtersCount;
  const filterInit: TableFilter = { values: {}, count: filtersCount ?? 0 };
  const [filters, setFilters] = useState(filterInit);

  return (
    <>
      <MockTableFilter
        close={() => {
          setOpenTableFilter(false);
        }}
        filters={filters}
        isOpen={openTableFilter}
        setFilters={x => {
          setFilters(x);
        }}
      />
      <Table
        {...props}
        filtersCount={filters.count}
        onFilterClick={() => {
          setOpenTableFilter(true);
        }}
      />
    </>
  );
}

export const EmptyState: Story = {
  args: {
    ariaLabel: "default-table",
    automationContext: "table-fe",
    disablePagination: false,
    initialSort: {
      columnKey: "phone",
      order: "ascending",
    },
    paginationProps: {
      pageSizeList: [10, 20, 30, 40, 50],
      activePageNo: 1,
      defaultPageSize: 10,
    },
    tableData: {
      data: [],
      headers: FEAndBEHeadersData,
    },
    filtersCount: 1,
    onFilterClick: action("on filter click"),
  },
};

export const WithFilters: Story = {
  args: {
    ariaLabel: "default-table",
    automationContext: "table-fe",
    disablePagination: false,
    initialSort: {
      columnKey: "phone",
      order: "ascending",
    },
    locale: "es-ES",
    paginationProps: {
      pageSizeList: [10, 20, 30, 40, 50],
      activePageNo: 1,
      defaultPageSize: 10,
    },
    tableData: {
      data: paginationTableData,
      headers: FEAndBEHeadersData,
    },
    filtersCount: 0,
    onFilterClick: action("on filter click"),
    showSelectAll: true,
    selectedRows: action("selected rows"),
  },
  render: args => {
    return <TableWithFiltersComponent {...args} />;
  },
};

// Example with dynamic massive actions

function TableWithDynamicMassiveActions(props: TableProps) {
  const [massiveActions, setMassiveActions] = useState<{
    options: {
      text: string;
      onSelect: (selectedKeys?: (string | number)[]) => void;
    }[];
  }>({ options: [] });

  const handleSelectedRows = (selectedKeys: string[]) => {
    action("selected rows")(selectedKeys);

    if (selectedKeys.length > 0) {
      setMassiveActions({
        options: [
          {
            text: "Action Text 1",
            onSelect: newSelectedKeys => {
              action(
                `Massive Action selected key: Action Text 1, ${
                  newSelectedKeys?.length ?
                    `Selected rows keys: ${newSelectedKeys.join(", ")}`
                  : "No Row selected"
                }`
              )(newSelectedKeys);
            },
          },
          {
            text: "Action Text 2",
            onSelect: newSelectedKeys => {
              action(
                `Massive Action selected key: Action Text 2, ${
                  newSelectedKeys?.length ?
                    `Selected rows keys: ${newSelectedKeys.join(", ")}`
                  : "No Row selected"
                }`
              )(newSelectedKeys);
            },
          },
        ],
      });
    } else {
      setMassiveActions({ options: [] });
    }
  };

  return (
    <Table
      {...props}
      massiveActions={massiveActions}
      selectedRows={handleSelectedRows}
    />
  );
}

export const WithDynamicMassiveActions: Story = {
  args: {
    tableData: {
      data: paginationTableData,
      headers: FEAndBEHeadersData,
    },
    showSelectAll: true,
    automationContext: "table-with-massive-actions",
  },
  render: args => {
    return <TableWithDynamicMassiveActions {...args} />;
  },
};
