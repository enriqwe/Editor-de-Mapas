import type { Meta, StoryObj } from "@storybook/react-vite";
import { CreatableDropdown } from "@pulse/components/dropdown";
import { Avatar } from "@pulse/components/avatar";
import { action } from "storybook/actions";

import {
  options,
  groupedOptions,
  numberOptions,
  otherGroupedOptions,
} from "../sampleData/dropdown";

// @ts-expect-error - Fix for storybook issue with names in code
CreatableDropdown.displayName = "CreatableDropdown";

const meta: Meta<typeof CreatableDropdown> = {
  component: CreatableDropdown,
  title: "form/CreatableDropdown",
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1540%3A9379&t=3squNbLOqUnEHeP7-0",
    },
  },
  render: ({ ...args }) => {
    return (
      <div style={{ width: "400px" }}>
        <CreatableDropdown {...args} />
      </div>
    );
  },
};

export default meta;

type Story = StoryObj<typeof CreatableDropdown>;

export const CreatableSingleSelect: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    selectedOption: { value: "option two", label: "Option two" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Placeholder",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    maxLength: 20,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
    formatCreateLabel: inputValue => `${inputValue} (New element)`,
    isValidNewOption: inputValue => Boolean(inputValue.length),
  },
};

export const CreatableSingleSelectControlled: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Placeholder",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    maxLength: 20,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    automationContext: "select-size",
    formatCreateLabel: inputValue => `${inputValue} (New element)`,
    isValidNewOption: inputValue => Boolean(inputValue.length),
  },
};

export const CreatableMultiSelect: Story = {
  args: {
    label: "Label Dropdown",
    options,
    additionalText: "Additional text",
    selectedOption: { value: "option one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Placeholder",
    noOptionsMessage: "NO RESULTS",
    required: true,
    disabled: false,
    multi: true,
    maxLength: 20,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: true,
    automationContext: "select-city",
  },
};

export const CreatableGroupedOptions: Story = {
  args: {
    label: "Label Dropdown",
    options: groupedOptions,
    additionalText: "Additional text",
    selectedOption: { value: "option one", label: "Option one" },
    onSelectedOption: () => null,
    placeholder: "Placeholder",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    automationContext: "select-size",
  },
};

export const CreatableMultilevelOptions: Story = {
  args: {
    label: "Label Dropdown",
    options: otherGroupedOptions,
    additionalText: "Additional text",
    selectedOption: { value: "option one", label: "Option one" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    placeholder: "Placeholder",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    multiLevel: true,
  },
};

const getValue = (label: string) => (
  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
    <Avatar name={label} size="s" />
    {label}
  </div>
);

export const CreatableTransparent: Story = {
  args: {
    label: "Label Dropdown",
    placeholder: "Select..",
    options,
    noOptionsMessage: "No options",
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    required: false,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    transparent: true,
    searchable: false,
    customDropdownValue: false,
  },
};

export const CreatableTransparentCustomValue: Story = {
  args: {
    label: "Label Dropdown",
    value: getValue("User name"),
    placeholder: getValue("User name"),
    options,
    noOptionsMessage: "No options",
    required: false,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: true,
    hideSelectedOptions: false,
    transparent: true,
    searchable: false,
    customDropdownValue: true,
  },
};

export const CreatableDropdownInline: Story = {
  args: {
    label: "Label",
    options: numberOptions,
    selectedOption: { value: "15", label: "15" },
    onSelectedOption: e => !Array.isArray(e) && action(e.value),
    onBlur: () => action("onBlur"),
    placeholder: "Placeholder",
    noOptionsMessage: "No options",
    required: true,
    disabled: false,
    multi: false,
    error: false,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    automationContext: "select-city",
    dropdownInline: true,
  },
};
