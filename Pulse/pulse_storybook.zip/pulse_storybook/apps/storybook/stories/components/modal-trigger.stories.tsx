import type { Meta, StoryObj } from "@storybook/react-vite";
import { action } from "storybook/actions";
import { ModalTrigger, ModalWithSection } from "@pulse/components/modal";

// @ts-expect-error - Fix for storybook issue with names in code
ModalTrigger.displayName = "ModalTrigger";

const meta: Meta<typeof ModalTrigger> = {
  component: ModalTrigger,
  title: "Modal/ModalTrigger",
  argTypes: {
    label: {
      description: "string",
    },
    defaultOpen: {
      description: "boolean",
    },
    children: {
      description: "ReactNode | JSX.Element",
    },
    type: {
      control: { type: "radio" },
      options: ["short", "medium", "large"],
      table: {
        defaultValue: {
          summary: "short",
        },
      },
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=33264-27017&t=gFsAf0hbDfqaQYiB-0",
    },
  },
  render: ({ ...args }) => (
    <ModalTrigger {...args}>{args.children}</ModalTrigger>
  ),
};

export default meta;

type Story = StoryObj<typeof ModalTrigger>;

function ModalWithSectionComponent(close: () => void) {
  return (
    <div>
      <ModalWithSection.Header
        closeHandler={close}
        description="Lörem ipsum bioktiga exorad pregen'"
        title="Title"
      />
      <ModalWithSection.Body>
        <section>
          Aenean ac ultrices est. Integer rutrum sollicitudin lacus, a bibendum
          sem varius at. Aenean ac. Aenean ac ultrices est. Integer rutrum
          sollicitudin lacus, a bibendum sem varius at. Aenean ac.
        </section>
      </ModalWithSection.Body>
      <ModalWithSection.Footer
        actions={[
          {
            buttonVariant: "primary",
            buttonLabel: "Submit",
            clickHandler: action("Submit click"),
          },
          {
            buttonVariant: "secondary",
            buttonLabel: "Cancel",
            clickHandler: close,
          },
        ]}
      />
    </div>
  );
}

export const Controlled: Story = {
  args: {
    label: "Open Modal",
    isOpen: false,
    onOpenChange: action("custom behavior!"),
    children: ModalWithSectionComponent,
    automationContext: "confirmation-popup",
    type: "short",
  },
};

export const Uncontrolled: Story = {
  args: {
    label: "Open Modal",
    defaultOpen: false,
    children: ModalWithSectionComponent,
    automationContext: "confirmation-popup",
  },
};

export const Default: Story = {
  args: {
    label: "Open Modal",
    defaultOpen: false,
    children: ModalWithSectionComponent,
    automationContext: "confirmation-popup",
  },
};

export const Opened: Story = {
  args: {
    label: "Open Modal",
    defaultOpen: true,
    children: ModalWithSectionComponent,
    automationContext: "confirmation-popup",
  },
};

export const CustomCallback: Story = {
  args: {
    label: "Open Modal",
    defaultOpen: false,
    children: ModalWithSectionComponent,
    onOpenChange: action("custom behavior!"),
    isDismissable: false,
    isKeyboardDismissDisabled: false,
    automationContext: "confirmation-popup",
  },
};
