import type { Meta, StoryObj } from "@storybook/react-vite";
import { Spinner } from "@pulse/components/spinner";

// @ts-expect-error - Fix for storybook issue with names in code
Spinner.displayName = "Spinner";

const meta: Meta<typeof Spinner> = {
  component: Spinner,
  title: "loading/Spinner",
  argTypes: {
    size: {
      control: "select",
      options: ["sm", "md", "lg", "xl", "xxl"],
    },
    variant: {
      control: "radio",
      options: ["dark", "light"],
    },
  },
};

export default meta;

type Story = StoryObj<typeof Spinner>;

export const Dark: Story = {
  args: {
    size: "md",
    helperText: "Loading...",
    automationContext: "loading",
    variant: "dark",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=26714-17408&t=gFsAf0hbDfqaQYiB-0",
    },
    layout: "centered",
  },
};

export const Light: Story = {
  globals: {},
  args: {
    size: "md",
    helperText: "Loading...",
    automationContext: "loading",
    variant: "light",
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/ejN0wGNquxjfIuoTPwXTby/Design-System-Core?type=design&node-id=26714-17408&t=gFsAf0hbDfqaQYiB-0",
    },
    layout: "centered",
  },
  render: function Render(args) {
    return (
      <div style={{ backgroundColor: "#000", width: "500px", height: "500px" }}>
        <Spinner {...args} />
      </div>
    );
  },
};
