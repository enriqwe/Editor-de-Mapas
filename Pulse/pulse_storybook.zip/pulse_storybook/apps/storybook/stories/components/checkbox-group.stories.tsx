import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { CheckboxGroup } from "@pulse/components/checkbox";

// @ts-expect-error - Fix for storybook issue with names in code
CheckboxGroup.displayName = "CheckboxGroup";

const meta: Meta<typeof CheckboxGroup.Group> = {
  component: CheckboxGroup.Group,
  title: "form/CheckboxGroup",
  args: {
    onChange: fn(),
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=1067%3A142&t=sZyZmHOqCfRSUKkS-4",
    },
  },
  argTypes: {
    orientation: {
      options: ["horizontal", "vertical"],
      control: { type: "radio" },
    },
    label: {
      description: "string",
    },
    automationContext: {
      description: "string",
    },
    description: {
      description: "string",
    },
    isDisabled: {
      description: "boolean",
    },
    errorMessage: {
      description: "string",
    },
  },
  render: args => {
    return <CheckboxGroup.Group {...args}>{args.children}</CheckboxGroup.Group>;
  },
};

export default meta;

type Story = StoryObj<typeof CheckboxGroup.Group>;

export const Uncontrolled: Story = {
  args: {
    label: "Team Selector",
    description: "Select Team.",
    defaultValue: ["baseball"],
    children: [
      <CheckboxGroup.Item isDisabled key="soccer" value="soccer">
        Soccer
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="baseball" value="baseball">
        Baseball
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="basketball" value="basketball">
        Basketball
      </CheckboxGroup.Item>,
    ],
  },
};

export const Controlled: Story = {
  args: {
    label: "Team Selector",
    description: "Select Team.",
    value: ["baseball"],
    onChange: fn(),
    children: [
      <CheckboxGroup.Item isDisabled key="soccer" value="soccer">
        Soccer
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="baseball" value="baseball">
        Baseball
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="basketball" value="basketball">
        Basketball
      </CheckboxGroup.Item>,
    ],
  },
};

export const Horizontal: Story = {
  args: {
    orientation: "horizontal",
    isDisabled: false,
    children: [
      <CheckboxGroup.Item isDisabled key="soccer" value="soccer">
        Soccer
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="baseball" value="baseball">
        Baseball
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="basketball" value="basketball">
        Basketball
      </CheckboxGroup.Item>,
    ],
  },
};

export const Vertical: Story = {
  args: {
    orientation: "vertical",
    isDisabled: false,
    children: [
      <CheckboxGroup.Item isDisabled key="soccer" value="soccer">
        Soccer
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="baseball" value="baseball">
        Baseball
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="basketball" value="basketball">
        Basketball
      </CheckboxGroup.Item>,
    ],
  },
};

export const Multiline: Story = {
  args: {
    label: "Month Selector",
    description: "Select month.",
    isDisabled: false,
    errorMessage: "",
    automationContext: "month-selector",
    orientation: "horizontal",
    children: [
      <CheckboxGroup.Item key="january" value="january">
        January
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="february" value="february">
        February
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="march" value="march">
        March
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="april" value="april">
        April
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="may" value="may">
        May
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="june" value="june">
        June
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="july" value="july">
        July
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="august" value="august">
        August
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="september" value="september">
        September
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="october" value="october">
        October
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="november" value="november">
        Novemeber
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="december" value="december">
        December
      </CheckboxGroup.Item>,
    ],
  },
};

export const Required: Story = {
  args: {
    label: "Month Selector",
    description: "Select month.",
    isDisabled: false,
    automationContext: "month-selector",
    isRequired: true,
    orientation: "horizontal",
    children: [
      <CheckboxGroup.Item isDisabled key="soccer" value="soccer">
        Soccer
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="baseball" value="baseball">
        Baseball
      </CheckboxGroup.Item>,
      <CheckboxGroup.Item key="basketball" value="basketball">
        Basketball
      </CheckboxGroup.Item>,
    ],
  },
};
