import type { Meta, StoryObj } from "@storybook/react-vite";
import { useState } from "react";
import { TableV2 } from "@pulse/components/table-v2";
import { action } from "storybook/actions";

import {
  defaultColumns,
  dataWithSubRows,
  defaultData,
  multiplyRows,
  pinnedColumns,
} from "../sampleData/table-v2/data";
import type { Person } from "../sampleData/table-v2/data";

const meta: Meta<typeof TableV2<Person>> = {
  component: TableV2,
  title: "TableV2 (Beta)",
  args: {
    data: multiplyRows(defaultData, 5),
    columns: defaultColumns,
    ariaLabel: "Example Table",
  },
  argTypes: {
    locale: {
      options: ["es-ES", "fr-FR", "de-DE", "en-EN"],
      control: { type: "select" },
    },
    loading: {
      control: { type: "boolean" },
    },
  },
};

export default meta;

type Story = StoryObj<typeof TableV2<Person>>;

export const Simple: Story = {};

export const WithToolbar: Story = {
  args: {
    toolbar: {
      filters: {
        count: 10,
        onClick: action("Filter clicked"),
      },
      massiveActions: {
        options: [
          {
            text: "Delete",
            onSelect: action("Delete selected rows"),
          },
          {
            text: "Export",
            onSelect: action("Export selected rows"),
          },
        ],
      },
    },
    enableRowSelection: true,
  },
};

export const WithSorting: Story = {
  args: {
    enableColumnSorting: true,
    toolbar: {
      filters: {
        count: 10,
        onClick: action("Filter clicked"),
      },
      massiveActions: {
        options: [
          {
            text: "Delete",
            onSelect: action("Delete selected rows"),
          },
          {
            text: "Export",
            onSelect: action("Export selected rows"),
          },
        ],
      },
    },
    enableRowSelection: true,
  },
};

export const WithSubRows: Story = {
  args: {
    data: dataWithSubRows,
    columns: defaultColumns,
  },
};

export const WithResizableColumns: Story = {
  args: {
    enableColumnResizing: true,
  },
};

export const WithFixedAndFixableColumns: Story = {
  args: {
    columns: pinnedColumns,
    enableColumnPinning: true,
    toolbar: {
      filters: {
        count: 10,
        onClick: action("Filter clicked"),
      },
      massiveActions: {
        options: [
          {
            text: "Delete",
            onSelect: action("Delete selected rows"),
          },
          {
            text: "Export",
            onSelect: action("Export selected rows"),
          },
        ],
      },
    },
  },
};

export const WithRowSelection: Story = {
  args: {
    enableRowSelection: true,
  },
};

function TableWithState() {
  const [sortingState, setSortingState] = useState([
    { id: "firstName", desc: false },
  ]);

  const [pageSize, setPageSize] = useState(3);
  /* const [data, setData] = useState<Person[]>(multiplyRows(defaultData, 4).slice(0, pageSize)); */
  const [currentPage, setCurrentPage] = useState(1);

  let data: Person[] = multiplyRows(defaultData, 4);
  if (sortingState.length > 0 && sortingState[0]) {
    const firstSorting = sortingState[0];
    data = data.sort((a, b) => {
      const column = firstSorting.id as keyof Person;
      if (!a[column] || !b[column]) {
        return 0;
      }

      if (a[column] < b[column]) {
        return firstSorting.desc ? 1 : -1;
      }
      if (a[column] > b[column]) {
        return firstSorting.desc ? -1 : 1;
      }
      return 0;
    });
  }
  data = data.splice((currentPage - 1) * pageSize, pageSize);

  const totalRows = multiplyRows(defaultData, 4).length;

  return (
    <>
      <TableV2
        ariaLabel="Tan Stack Table Controlled"
        columns={defaultColumns}
        controlled={{
          currentPage,
          totalRows,
          pageSize,
          onPageChange: newPage => {
            action(`Page change triggered`)(newPage);
            setCurrentPage(newPage);
          },
          onPageSizeChange: newPageSize => {
            action(`Page size change triggered`)(newPageSize);
            setPageSize(newPageSize);
          },
          sortingState,
          onSortChange: newSortingState => {
            action(`Sorting change triggered`)(newSortingState);
            setSortingState(newSortingState);
          },
        }}
        data={data}
        pageSizes={[10, 20, 50]}
      />
      <p>
        <span>PageSize: {pageSize}</span>
        <br />
        <span>CurrentPage: {currentPage}</span>
        <br />
        <span>Data length: {totalRows}</span>
        <br />
        <span>Sorting state: {JSON.stringify(sortingState)}</span>
      </p>
    </>
  );
}

export const ControlledModeWithSimulatedBackend: Story = {
  render: () => <TableWithState />,
};
