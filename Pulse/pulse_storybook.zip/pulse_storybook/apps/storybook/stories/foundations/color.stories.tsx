import type { Meta, StoryObj } from "@storybook/react-vite";
import { useTheme } from "styled-components";
import type { JSX } from "react";

import { Table, Code, StoryContainer } from "../utils/components";
import { keyify } from "../utils/keyify";

function ColorShowcase({ type }: { type: string }) {
  const theme = useTheme();

  const {
    background: deprecatedBackground,
    border: deprecatedBorder,
    text: deprecatedText,
    icon: deprecatedIcon,
    ...colors
  } = theme.color;

  const deprecatedColors = {
    background: deprecatedBackground,
    border: deprecatedBorder,
    text: deprecatedText,
    icon: deprecatedIcon,
  };

  let rowItems: JSX.Element[] = [];
  const headers = ["Token"];

  if (type === "deprecated") {
    const deprecatedColorVariables = keyify(deprecatedColors);

    rowItems = deprecatedColorVariables.map((colorVariable: string) => (
      <tr key={colorVariable}>
        <td>color.{colorVariable}</td>
      </tr>
    ));
  } else {
    const colorVariables = Object.keys(colors) as (keyof typeof colors)[];

    const filteredColorVariables = colorVariables.filter(
      (colorVariable: string) => colorVariable.startsWith(type)
    );
    headers.push("Default theme");
    rowItems = filteredColorVariables.map(colorVariable => (
      <tr key={colorVariable}>
        <td>color.{colorVariable}</td>
        <td>
          <span style={{ width: "90px", display: "inline-block" }}>
            {colors[colorVariable]}{" "}
          </span>

          <span
            style={{
              backgroundColor: colors[colorVariable],
              border: "solid 1px black",
              borderRadius: "50%",
              width: "20px",
              height: "20px",
              display: "inline-block",
              verticalAlign: "middle",
            }}
          />
        </td>
      </tr>
    ));
  }

  return (
    <>
      <p>These are dynamic values that will depend on the theme</p>
      <Table headers={headers}>{rowItems}</Table>;
    </>
  );
}

const meta: Meta<typeof ColorShowcase> = {
  title: "Colors",
  component: ColorShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof ColorShowcase>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=644-1227",
  },
};

export const Docs: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors</h1>
      <p>
        Color tokens allow us to have different themes, providing customization
        for every client using our products
      </p>
      <h2>Usage</h2>
      <p>
        {" "}
        You should be able to see usage on each subsection:
        <ul>
          <li>Text</li>
          <li>Background</li>
          <li>Border</li>
          <li>Icon</li>
        </ul>
      </p>
      <h2>Important: changes from version 2.0.0</h2>
      <p>
        While we tried to keep retrocompatibility, we needed a better
        integration with Figma.
      </p>
      <p>
        We have now in place a process that allows us to generate tokens from
        Figma, but this change required a modification in the way we structure
        the tokens. This means we will be deprecating tokens with object
        notation:
      </p>
      <Code>
        <>
          <span>
            color.<strong>text</strong>.***
          </span>
          <br />
          <span>
            color.<strong>bg</strong>.***
          </span>
          <br />
          <span>
            color.<strong>border</strong>.***
          </span>
          <br />
          <span>
            color.<strong>icon</strong>.***
          </span>
          <br />
        </>
      </Code>

      <p>We will start using tokens with camelCase notation. For example:</p>
      <Code>
        <span>
          color.<strong>text</strong>Body
        </span>
        <br />
        <span>
          color.<strong>bg</strong>TableThead
        </span>
        <br />
        <span>
          color.<strong>border</strong>Brand
        </span>
        <br />
        <span>
          color.<strong>icon</strong>Default
        </span>
        <br />
      </Code>

      <p>
        It is important to notice there is no 1-1 mapping to previous tokens.
        However:
        <ul>
          <li>All Figmas will start using the new tokens</li>
          <li>
            Your visual designers should be able to help you with these
            replacements, but you can contact the DS team for any doubt
          </li>
        </ul>
        ,
      </p>
    </>
  ),
};

export const TextTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors - Text Tokens</h1>
      <p>These tokens should be used to apply color to texts</p>

      <ColorShowcase type="text" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
  color: \${({ theme }) => theme.color.textBody};
\``}
      </Code>
    </>
  ),
};

export const BackgroundTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors - Background Tokens</h1>
      <p>These tokens should be used to apply color to backgrounds</p>
      <ColorShowcase type="bg" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
    backgroundColor: \${({ theme }) => theme.color.bgTableThead};

\``}
      </Code>
    </>
  ),
};

export const BorderTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors - Border Tokens</h1>
      <p>These tokens should be used to apply color to borders</p>
      <ColorShowcase type="border" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
  border-color: \${({ theme }) => theme.color.borderBrand};
\``}
      </Code>
    </>
  ),
};

export const IconTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors - Icon Tokens</h1>
      <p>These tokens should be used to apply color to icons</p>
      <ColorShowcase type="icon" />
      <h2>Usage</h2>
      <Code>
        {`const StyledIcon = styled.i\`
  color: \${({ theme }) => theme.color.iconDefault};
\``}
      </Code>
    </>
  ),
};

export const DeprecatedTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Colors - To be deprecated</h1>
      <p>
        These tokens will be supported temporarily, while all Figmas are
        migrated.
      </p>
      <ColorShowcase type="deprecated" />
      <h2>Usage</h2>
      <Code>
        {`const StyledWarning = styled.i\`
  color: \${({ theme }) => theme.color.text.warning};
\``}
      </Code>
    </>
  ),
};
