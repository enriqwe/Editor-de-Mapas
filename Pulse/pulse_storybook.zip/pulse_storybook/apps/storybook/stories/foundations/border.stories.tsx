import type { Meta, StoryObj } from "@storybook/react-vite";
import type { JSX } from "react";
import { useTheme } from "styled-components";

import { Table, Code, StoryContainer } from "../utils/components";

function BorderShowcase({ type }: { type: string }) {
  const theme = useTheme();

  const { x4, x8, x12, x16, x50, circle, ...newBorders } = theme.border;
  const deprecatedBorders = {
    x4,
    x8,
    x12,
    x16,
    x50,
    circle,
  };

  let rowItems: JSX.Element[] = [];

  let border: Record<string, string>;
  let filteredBorderVariables;

  if (type === "deprecated") {
    border = deprecatedBorders;
    const borderKeys = Object.keys(
      deprecatedBorders
    ) as (keyof typeof deprecatedBorders)[];
    filteredBorderVariables = borderKeys;
  } else {
    border = newBorders;
    const borderKeys = Object.keys(border) as (keyof typeof newBorders)[];
    filteredBorderVariables = borderKeys.filter((borderVariable: string) =>
      borderVariable.startsWith(type)
    );
  }

  rowItems = filteredBorderVariables.map(borderVariable => (
    <tr key={borderVariable}>
      <td>border.{borderVariable}</td>
      <td>{border[borderVariable]}</td>
    </tr>
  ));

  return (
    <>
      <p>These are dynamic values that will depend on the theme</p>
      <Table headers={["Token", "Default theme value"]}>{rowItems}</Table>
    </>
  );
}

const meta: Meta<typeof BorderShowcase> = {
  title: "Borders",
  component: BorderShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof BorderShowcase>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=884-1681",
  },
};

export const Docs: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Borders</h1>
      <p>
        Border tokens allow us to have different border-widths and border-radius
        per theme
      </p>
      <h2>Important: changes from version 2.0.0</h2>
      <p>
        Previous values were fixed, and it was not clear whether they were
        intended for border-width or border-radius, so we decided to split them
        into two different tokens. You will be able to see recommended new
        tokens in:
        <ul>
          <li>Width Tokens</li>
          <li>Radius Tokens</li>
        </ul>
      </p>
      <p>
        Temporarily, we will support the deprecated tokens, but please start
        using the new ones and make a plan to replace the old ones. Version
        3.0.0 will remove the deprecated tokens.
      </p>
    </>
  ),
};

export const WidthTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Borders Width Tokens</h1>
      <p>These tokens should be used to set the width of the border </p>

      <BorderShowcase type="width" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
  border-width: \${({ theme }) => theme.border.widthXS};
\``}
      </Code>
      <Code>
        {`const StyledTable = styled.table\`
  border: \${({ theme }) => \`solid \${theme.border.widthXS} \${theme.color.borderBrand}\`};
\``}
      </Code>
    </>
  ),
};

export const RadiusTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Borders Radius Tokens</h1>
      <p>These tokens should be used to set the radius of the border</p>

      <BorderShowcase type="radius" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
  border-radius: \${({ theme }) => theme.border.radiusM};
\``}
      </Code>
    </>
  ),
};

export const DeprecatedTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Borders tokens - To be deprecated</h1>
      <p>
        These tokens will be supported temporarily, but will be deprecated in
        version 3.0.0
      </p>
      <BorderShowcase type="deprecated" />
    </>
  ),
};
