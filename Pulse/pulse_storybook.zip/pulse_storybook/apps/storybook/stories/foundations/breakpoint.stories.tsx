import type { Meta, StoryObj } from "@storybook/react-vite";
import styled from "styled-components";

import { Table, Code, StoryContainer } from "../utils/components";

const StyledParagraph1 = styled.p`
  color: blue;
  background-color: white;
  ${({ theme }) =>
    theme.breakpoint.m({
      "color": "white",
      "background-color": "blue",
    })}
`;

const StyledParagraph2 = styled.p`
  color: blue;
  background-color: white;
  ${({ theme }) =>
    theme.breakpoint.mOnly({
      "color": "white",
      "background-color": "blue",
    })}
  ${({ theme }) =>
    theme.breakpoint.l({
      "color": "white",
      "background-color": "red",
    })}
`;

const StyledParagraph3 = styled.p`
  ${({ theme }) =>
    theme.breakpoint.generate(
      {
        "color": "black",
        "background-color": "lightblue",
      },
      {
        "color": "black",
        "background-color": "lightcoral",
      },
      {
        "color": "black",
        "background-color": "lightcyan",
      }
    )}
`;

function BreakpointShowcase() {
  return (
    <>
      <h1>Breakpoints</h1>
      <p>
        There are 2 breakpoints (3 ranges) currently defined:
        <ul>
          <li>small: up to 767px</li>
          <li>medium: from 768px to 1199px</li>
          <li>large: from 1200px</li>
        </ul>
      </p>
      <section>
        <h2>How to use breakpoint utilities</h2>
        <h3>Preferred alternative: Using media queries utilities</h3>
        <p>
          You can use methods that wrap properties in media queries:
          <Table headers={["Token", "Description", "Value"]}>
            <tr>
              <td>theme.breakpoint.sOnly(props)</td>
              <td>Only up to 767px</td>
              <td>
                <Code>{`@media screen and (max-width: \${sMax}px) {
      \${props}
    }`}</Code>
              </td>
            </tr>
            <tr>
              <td>
                theme.breakpoint.m(props) or theme.breakpoint.tablet(props)
              </td>
              <td>768px and above</td>
              <td>
                <Code>{`@media screen and (min-width: \${mMin}px) {
  \${props}
}`}</Code>
              </td>
            </tr>
            <tr>
              <td>
                theme.breakpoint.mOnly(props) or
                theme.breakpoint.tabletOnly(props)
              </td>
              <td>Only between 768px and 1199px</td>
              <td>
                <Code>{`@media screen and (min-width: \${mMin}px) and (max-width: \${mMax}px) {
      \${props}
    }`}</Code>
              </td>
            </tr>
            <tr>
              <td>
                theme.breakpoint.l(props) or theme.breakpoint.desktop(props)
              </td>
              <td>1200px and above</td>
              <td>
                <Code>{`@media screen and (min-width: \${lMin}px) {
  \${props}
}`}</Code>
              </td>
            </tr>
          </Table>
        </p>
        <h3>Usage</h3>
        <h4>Example Code</h4>
        <Code>
          {`const StyledTable = styled.table\`
  color: blue                               // Apply for mobile
  background-color: white                   // Apply for mobile

  \${({ theme }) => theme.breakpoint.m({
    'color': 'white',                       // Apply for tablet and above
    'background-color': 'blue'              // Apply for tablet and above
  }}
\``}
        </Code>
        <h4>Result</h4>
        <StyledParagraph1>Responsive text</StyledParagraph1>
        <Code>
          {`const StyledTable = styled.table\`
  color: blue                               // Apply for mobile
  background-color: white                   // Apply for mobile

  \${({ theme }) => theme.breakpoint.mOnly({
    'color': 'white',                       // Apply for tablet only
    'background-color': 'blue'              // Apply for tablet only
  }}

  \${({ theme }) => theme.breakpoint.l({
    'color': 'white',                       // Apply for desktop
    'background-color': 'red'               // Apply for desktop
  }}
\``}
        </Code>
        <h4>Result</h4>
        <StyledParagraph2>Responsive text</StyledParagraph2>
      </section>
      <section>
        <h3>Option 2 - Using generate() method</h3>
        <p>
          You can also use a method to create styles for all breakpoints at
          once:
          <Code>{`generate = (
  smallBreakpointProps?: CSSObject,
  mediumBreakpointProps?: CSSObject,
  largeBreakpointProps?: CSSObject
): string`}</Code>
        </p>
        <h3>Usage</h3>
        <h4>Example Code</h4>
        <Code>
          {`\${theme.breakpoint.generate(
  {
    'color': 'black',
    'background-color': 'lightblue'
  },
  {
    'color': 'black',
    'background-color': 'lightcoral'
  },
  {
    'color': 'black',
    'background-color': 'lightcyan'
  }`}
        </Code>
        <h4>Result</h4>
        <StyledParagraph3>Responsive text</StyledParagraph3>
      </section>
      <section>
        <h3>Option 3 - Using just the values</h3>
        <p>
          You can directly use the values:
          <Table headers={["Token", "Value", "Description"]}>
            <tr>
              <td>theme.breakpoint.sMax</td>
              <td>767</td>
              <td>Max value (in px) in small resolution</td>
            </tr>
            <tr>
              <td>theme.breakpoint.mMin</td>
              <td>768</td>
              <td>Min value (in px) in medium resolution: 768</td>
            </tr>
            <tr>
              <td>theme.breakpoint.mMax</td>
              <td>1199</td>
              <td>Max value (in px) in medium resolution: 1199</td>
            </tr>
            <tr>
              <td>theme.breakpoint.lMin</td>
              <td>1200</td>
              <td>Min value (in px) in large resolution: 1200</td>
            </tr>
          </Table>
        </p>
        <p>You can also use methods to generate media queries:</p>
      </section>
    </>
  );
}

const meta: Meta<typeof BreakpointShowcase> = {
  title: "Breakpoints",
  component: BreakpointShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof BreakpointShowcase>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=884-1681",
  },
};

export const BreakpointsTokens: Story = {
  parameters: defaultParams,
};
