import type { StoryObj, Meta } from "@storybook/react-vite";
import { useTheme } from "styled-components";

import { Table, Code, StoryContainer } from "../utils/components";

function SpacingShowcase() {
  const { spacing } = useTheme();

  const spacingVariables = Object.keys(spacing) as (keyof typeof spacing)[];
  const rowItems = spacingVariables.map(spacingVariable => (
    <tr key={spacingVariable}>
      <td>spacing.{spacingVariable}</td>
      <td>{spacing[spacingVariable]}</td>
    </tr>
  ));

  return (
    <>
      <h1>Spacing</h1>
      <p>Spacing variables should be used for padding, margins</p>
      <p>These are fixed values that will not change depending on the theme</p>
      <Table headers={["Theme prop", "Value"]}>{rowItems}</Table>
      <h2>Usage</h2>

      <Code>
        {`const StyledTable = styled.table\`
  padding: \${({ theme }) => theme.spacing.x20};
\``}
      </Code>
      <Code>
        {`const StyledTable = styled.table\`
  margin: \${({ theme }) => \`\${theme.spacing.x20} \${theme.spacing.x12}\`};
\``}
      </Code>
    </>
  );
}

const meta: Meta<typeof SpacingShowcase> = {
  title: "Spacing",
  component: SpacingShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof SpacingShowcase>;

export const Spacing: Story = {
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=903%3A134&t=JUtPamDrxf9JIiVS-0",
    },
  },
};
