import type { Meta, StoryObj } from "@storybook/react-vite";
import type { JSX } from "react";
import { useTheme } from "styled-components";

import { Table, Code, StoryContainer } from "../utils/components";

function ShadowShowcase({ type }: { type: string }) {
  const { shadow } = useTheme();

  const { high, low, med, drawer, ...newShadows } = shadow;

  let rowItems: JSX.Element[] = [];

  if (type === "deprecated") {
    rowItems = [
      <tr key="high">
        <td>shadow.high</td>
        <td>{high}</td>
      </tr>,
      <tr key="low">
        <td>shadow.low</td>
        <td>{low}</td>
      </tr>,
      <tr key="med">
        <td>shadow.med</td>
        <td>{med}</td>
      </tr>,
      <tr key="left">
        <td>shadow.drawer.left</td>
        <td>-{drawer.left}</td>
      </tr>,
      <tr key="right">
        <td>shadow.drawer.right</td>
        <td>{drawer.right}</td>
      </tr>,
      <tr key="top">
        <td>shadow.drawer.top</td>
        <td>{drawer.top}</td>
      </tr>,
    ];
  } else {
    const shadowKeys = Object.keys(newShadows) as (keyof typeof newShadows)[];
    rowItems = shadowKeys.map(shadowVariable => (
      <tr key={shadowVariable}>
        <td>shadow.{shadowVariable}</td>
        <td>{shadow[shadowVariable]}</td>
      </tr>
    ));
  }

  return (
    <>
      <p>These are dynamic values that will depend on the theme</p>
      <Table headers={["Token", "Default theme value"]}>{rowItems}</Table>
    </>
  );
}

const meta: Meta<typeof ShadowShowcase> = {
  title: "Shadow",
  component: ShadowShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof ShadowShowcase>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=884-1681",
  },
};

export const ShadowTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Shadows</h1>
      <p />
      <ShadowShowcase type="normal" />
      <h2>Usage</h2>
      <Code>
        {`const StyledBox = styled.div\`
  box-shadow: \${({ theme }) => theme.shadow.default};
\``}
      </Code>
      <h2>Important: changes from version 2.0.0</h2>
      <p />
      <p>
        Temporarily, we will support the deprecated tokens, but please start
        using the new ones and make a plan to replace the old ones. Version
        3.0.0 will remove the deprecated tokens.
      </p>
    </>
  ),
};

export const DeprecatedTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Shadow tokens - To be deprecated</h1>
      <p>
        These tokens will be supported temporarily, but will be deprecated in
        version 3.0.0
      </p>
      <ShadowShowcase type="deprecated" />
    </>
  ),
};
