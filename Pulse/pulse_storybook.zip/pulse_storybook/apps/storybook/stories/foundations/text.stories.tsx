import type { Meta, StoryObj } from "@storybook/react-vite";
import type { JSX } from "react";
import { useTheme } from "styled-components";
import type { ThemeType } from "@pulse/foundations";

import { Table, Code, StoryContainer } from "../utils/components";
import { keyify } from "../utils/keyify";

type TextMobile = ThemeType["text"]["mobile"];
type TextDesktop = ThemeType["text"]["desktop"];
type TextNew = Omit<ThemeType["text"], "mobile" | "desktop" | "core">;
// import { text } from "./2.0/text";
// import { typography, typographyApi } from "./typography";

const weights = ["Regular", "SemiBold", "Bold", "Black"];

const getWeightLessTypes = (types: Record<string, any>) => {
  const weightLessTypes = new Set<string>();
  Object.keys(types).forEach(type => {
    const cleanedType = weights.reduce(
      (acc, weight) => acc.replace(new RegExp(`${weight}$`), ""),
      type
    );
    weightLessTypes.add(cleanedType);
  });
  return Array.from(weightLessTypes);
};

function BuildDoc({
  platform,
  format,
  weightLessTypes,
  tokens,
}: {
  platform?: "mobile" | "desktop";
  format?: "js" | "css";
  weightLessTypes: string[];
  tokens: TextNew | TextDesktop | TextMobile;
}) {
  let suffix = "";
  let prefix = "text";

  // let tokens:TokenType = types;
  if (platform === "desktop") {
    prefix = `${prefix}.desktop`;
    // tokens = desktop;
    suffix = format === "js" ? "" : "CSS";
  } else if (platform === "mobile") {
    prefix = `${prefix}.mobile`;
    // tokens = mobile;
    suffix = format === "js" ? "" : "CSS";
  }

  const headers = [
    "",
    "Regular Token",
    "SemiBold Token",
    "Bold Token",
    "Black Token",
  ];
  const rowItems = weightLessTypes.map(typeVariable => (
    <tr key={typeVariable}>
      <td>
        {prefix}.{typeVariable}
      </td>
      {weights.map(weight => (
        <td key={weight} style={{ backgroundColor: "#FFF5CF" }}>
          {prefix}.{typeVariable}
          {weight}
          {suffix}
        </td>
      ))}
    </tr>
  ));

  const extendedRowItems = weightLessTypes.map(typeVariable => (
    <tr key={typeVariable}>
      <td>
        {prefix}.{typeVariable}
      </td>
      {weights.map(weight => {
        const variableWithWeight =
          `${typeVariable}${weight}` as keyof typeof tokens;
        const variableWithWeightAndSuffix =
          `${typeVariable}${weight}${suffix}` as keyof typeof tokens;
        const value =
          format === "css" ?
            (tokens[variableWithWeightAndSuffix] as string)
          : JSON.stringify(tokens[variableWithWeight], null, 2);
        return (
          <td key={weight}>
            <Code>{value}</Code>
          </td>
        );
      })}
    </tr>
  ));

  return (
    <>
      <Table headers={headers}>{rowItems}</Table>
      <br />
      <details>
        <summary>Token values info</summary>
        <Table headers={headers}>{extendedRowItems}</Table>
      </details>
    </>
  );
}

function TextShowcase({ type }: { type: string }) {
  const { text, font } = useTheme();
  const { core, mobile, desktop, ...newTypes } = text;

  const weightLessTypes = getWeightLessTypes(newTypes);

  let rowItems: JSX.Element[] = [];
  let headers: string[] = [];
  let finalRender: JSX.Element | undefined;
  let keys;

  switch (type) {
    case "type":
      finalRender = (
        <section id="tokens">
          <h2>Tokens</h2>
          <BuildDoc
            format="css"
            tokens={newTypes}
            weightLessTypes={weightLessTypes}
          />
        </section>
      );
      break;
    case "perDevice":
      finalRender = (
        <>
          <section id="tokensJS">
            <h2>Tokens - JS</h2>
            <p>
              These tokens return styles in an object format, to be used by
              styled components
            </p>
            <h3>Desktop</h3>
            <BuildDoc
              format="js"
              platform="desktop"
              tokens={desktop}
              weightLessTypes={weightLessTypes}
            />
            <h4>Usage</h4>
            <Code>
              {`const StyledTable = styled.table\`
  \${({ theme }) => theme.text.desktop.bodyMediumBold};
\``}
            </Code>
            <h3>Mobile</h3>
            <BuildDoc
              format="js"
              platform="mobile"
              tokens={mobile}
              weightLessTypes={weightLessTypes}
            />
            <h4>Usage</h4>
            <Code>
              {`const StyledTable = styled.table\`
  \${({ theme }) => theme.text.mobile.bodyMediumBold};
\``}
            </Code>
          </section>
          <section id="tokensCSS">
            <h2>Tokens - CSS</h2>
            <p>
              These tokens return styles in CSS format, in case it is necessary
            </p>
            <h3>Desktop</h3>
            <BuildDoc
              format="css"
              platform="desktop"
              tokens={desktop}
              weightLessTypes={weightLessTypes}
            />
            <h4>Usage</h4>
            <Code>
              {`const StyledTable = styled.table\`
  \${({ theme }) => theme.text.desktop.bodyMediumBoldCSS};
\``}
            </Code>
            <h3>Mobile</h3>
            <BuildDoc
              format="css"
              platform="mobile"
              tokens={mobile}
              weightLessTypes={weightLessTypes}
            />
            <h4>Usage</h4>
            <Code>
              {`const StyledTable = styled.table\`
  \${({ theme }) => theme.text.mobile.bodyMediumBoldCSS};
\``}
            </Code>
          </section>
        </>
      );
      break;
    case "core":
      headers = ["Token", "Value"];
      keys = Object.keys(core) as (keyof typeof core)[];
      rowItems = keys.map(coreVariable => (
        <tr key={coreVariable}>
          <td>text.core.{coreVariable}</td>
          <td>{core[coreVariable]}</td>
        </tr>
      ));
      break;
    case "deprecated":
      headers = ["Token"];
      rowItems = keyify(font).map(typographyVariable => (
        <tr key={typographyVariable}>
          <td>font.{typographyVariable}</td>
        </tr>
      ));
      break;

    default:
      break;
  }

  return finalRender || <Table headers={headers}>{rowItems}</Table>;
}

const meta: Meta<typeof TextShowcase> = {
  title: "Text",
  component: TextShowcase,
  decorators: [
    Story => {
      return (
        <StoryContainer>
          <Story />
        </StoryContainer>
      );
    },
  ],
};

export default meta;

type Story = StoryObj<typeof TextShowcase>;

const defaultParams = {
  design: {
    type: "figma",
    url: "https://www.figma.com/file/aRtU6qzJz8lntGlgHMAG94/Design-System-Doc?node-id=884-1681",
  },
};

export const Docs: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <section>
        <h1>Text</h1>
        <p>
          Text tokens should be used to set the font-family, font-size,
          font-weight and line-height.
        </p>
        <p>
          Prefer to use <strong>Types Tokens</strong> as your primary option.
          This will make it easier to adapt to different themes and are adjusted
          to a responsive behavior.
        </p>
        <p>
          If you want to avoid responsive behavior, you can use{" "}
          <strong>Per device Tokens</strong>.
        </p>
        <p>
          As last resort, you can use <strong>Core Tokens</strong>. These are
          fixed values that will not change, but this is not recommended because
          it will not adapt to different themes.
        </p>
      </section>
      <section>
        <h2>Usage</h2>
        <p>You should be able to see usage on each story:</p>
        <h2>Important: changes from version 2.0.0</h2>
        <p>
          While we tried to keep retrocompatibility, we needed a better
          integration with Figma and a better typography support. Previous
          tokens had limitations like
          <ul>
            <li>Supporting just one font family</li>
            <li>Hard to sync with Figma with the object structure</li>
            <li>Not responsive typography</li>
          </ul>
          so please start using the new tokens and make a plan to replace the
          old ones.
        </p>
      </section>
    </>
  ),
};

export const TypesTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <div>
      <section>
        <h1>Text Types Tokens</h1>
        <p>
          These tokens should be used to set any typography and will define:
          <ul>
            <li>Font Family</li>
            <li>Font Size</li>
            <li>Font Weight</li>
            <li>Line Height</li>
          </ul>
          for all breakpoints
          <ul>
            <li>Mobile</li>
            <li>Tablet</li>
            <li>Desktop</li>
          </ul>
          Note: right now, tablet and desktop resolutions share the same values
          for fonts
        </p>
        <p>
          The output of using any of these tokens is responsive CSS. As an
          example, this is the output of <code>text.bodySmallBlack</code>:
          <Code>
            {`@media screen and (min-width: \${mMin}px) {
  font-family: Nunito Sans;
  font-size: 12px;
  font-weight: 900;
  line-height: 18px;
}
@media screen and (max-width: \${sMax}px) {
  font-family: Nunito Sans;
  font-size: 12px;
  font-weight: 900;
  line-height: 18px;
}`}
          </Code>
          where mMin and sMax are the breakpoints on the DS (you can check
          breakpoints section for more)
        </p>
      </section>

      <TextShowcase type="type" />
      <h2>Usage</h2>
      <Code>
        {`const StyledTable = styled.table\`
  \${({ theme }) => theme.text.bodyMediumBold};
\``}
      </Code>
    </div>
  ),
};

export const PerDeviceTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Per device Tokens</h1>
      <p>You can use this tokens if you want to only get values for </p>

      <TextShowcase type="perDevice" />
    </>
  ),
};

export const CoreTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Core Tokens</h1>
      <p>
        These tokens have fixed values. These will not change per theme, but
        remember to use them as last resort. Try to use &quot;Types Tokens&quot;
        as much as possible
      </p>

      <TextShowcase type="core" />
      <h2>Usage</h2>
      <Code>
        {`const StyledParagraph = styled.p\`
  font-family: \${({ theme }) => theme.fonte.familyPrimary};
  font-size: \${({ theme }) => theme.text.size12};
  line-height: \${({ theme }) => theme.text.lineHeight20};
  font-weight: \${({ theme }) => theme.text.weightNormal};
\``}
      </Code>
    </>
  ),
};

export const DeprecatedTokens: Story = {
  parameters: defaultParams,
  render: () => (
    <>
      <h1>Font - To be deprecated</h1>
      <p>
        These tokens will be supported temporarily, while all Figmas are
        migrated.
      </p>
      <p>
        Here are some potential replacements, but remember you should base your
        changes in Figma and not replace blindly
      </p>
      <TextShowcase type="deprecated" />
      <h2>Replacements</h2>
      <Table headers={["Deprecated Token", "Recommended replacement"]}>
        <tr>
          <td>font.sizes.xs</td>
          <td>bodySmall</td>
        </tr>
        <tr>
          <td>font.sizes.sm</td>
          <td>bodyMedium</td>
        </tr>
        <tr>
          <td>font.sizes.m</td>
          <td>bodyBase</td>
        </tr>
        <tr>
          <td>font.sizes.l</td>
          <td>bodyLead</td>
        </tr>
        <tr>
          <td>font.sizes.xl</td>
          <td>heading6</td>
        </tr>
        <tr>
          <td>font.sizes.xxl</td>
          <td>heading5</td>
        </tr>
        <tr>
          <td>font.sizes.xxxl</td>
          <td>heading4</td>
        </tr>
        <tr>
          <td>font.sizes.h</td>
          <td>heading3</td>
        </tr>
        <tr>
          <td>weights.regular</td>
          <td>
            prefer to use &quot;Types tokens&quot; instead of setting weight
            individually, otherwise you can use text.core.weightNormal
          </td>
        </tr>
        <tr>
          <td>weights.semibold</td>
          <td>
            prefer to use &quot;Types tokens&quot; instead of setting weight
            individually, otherwise you can use text.core.weightSemibold
          </td>
        </tr>
        <tr>
          <td>weights.bold</td>
          <td>
            prefer to use &quot;Types tokens&quot; instead of setting weight
            individually, otherwise you can use text.core.weightBold
          </td>
        </tr>
        <tr>
          <td>resolve()</td>
          <td>
            This method is no longer recommended. Use &quot;Types tokens&quot;
            instead
          </td>
        </tr>
      </Table>
    </>
  ),
};
