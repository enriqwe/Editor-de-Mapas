type AnyObject = Record<string, any>;

export const keyify = (obj: AnyObject, prefix = ""): string[] => {
  const keys = Object.keys(obj);

  return keys.reduce((res: string[], el: keyof typeof obj) => {
    if (Array.isArray(obj[el])) {
      return [...res, prefix + el];
    } else if (typeof obj[el] === "object" && obj[el] !== null) {
      return [...res, ...keyify(obj[el], `${prefix + el}.`)];
    }
    return [...res, prefix + el];
  }, []);
};
