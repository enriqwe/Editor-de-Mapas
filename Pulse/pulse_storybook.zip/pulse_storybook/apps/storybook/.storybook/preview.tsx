import { ThemeProvider } from "styled-components";
import { themes } from "@pulse/foundations";
// import "@pulse/foundations/default.theme.css";

import { withThemeFromJSXProvider } from "@storybook/addon-themes";

export const decorators = [
  withThemeFromJSXProvider({
    themes: {
      default: themes.default,
    },
    defaultTheme: "default",
    Provider: ThemeProvider,
  }),
];

export const tags = ["autodocs"];
