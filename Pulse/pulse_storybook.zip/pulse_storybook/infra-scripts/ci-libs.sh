#!/bin/sh

#!/bin/sh

mkdir -p dist/libs/foundations/
mkdir -p dist/libs/components/
cp -r libs/foundations/package.json libs/foundations/README.md libs/foundations/dist  dist/libs/foundations/
cp -r libs/components/package.json libs/components/README.md libs/components/dist  dist/libs/components/



