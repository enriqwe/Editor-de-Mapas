#!/bin/sh

echo $npm_config_vers > dist/version
