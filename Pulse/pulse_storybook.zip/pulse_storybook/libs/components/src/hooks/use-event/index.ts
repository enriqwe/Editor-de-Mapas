import useEvent from "./use-event"

export default useEvent