/* istanbul ignore file */
import { useEffect, useLayoutEffect } from "react";

import { canUseDOM } from "@utils/dom";

const useIsomorphicLayoutEffect = canUseDOM ? useLayoutEffect : useEffect;

export default useIsomorphicLayoutEffect;
