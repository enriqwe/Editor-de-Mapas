import { RouterProvider } from "react-aria";
import { createElement, type ComponentProps, type ComponentType } from "react";

import { LocaleProvider } from "@providers/locale/locale";
import type { Locale } from "@providers/translation";

type RouterProviderProps = ComponentProps<typeof RouterProvider>;

type PulseContextProps = {
  locale?: Locale;
  router?: Omit<RouterProviderProps, "children">;
  children: React.ReactNode;
};

function Mount<
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- ignore
  C extends ComponentType<any>,
  P extends ComponentProps<C>,
>(props: {
  Component: C;
  if: boolean;
  withProps?: P extends { children: React.ReactNode } ? Omit<P, "children"> : P;
  children: React.ReactNode;
}) {
  const { Component, withProps, if: doIt, children } = props;

  if (!doIt) return children;
  return createElement(Component, withProps, children);
}

export function PulseContext(props: PulseContextProps) {
  const { locale = "es-ES", router } = props;

  return (
    <LocaleProvider locale={locale}>
      <Mount Component={RouterProvider} if={Boolean(router)} withProps={router}>
        {props.children}
      </Mount>
    </LocaleProvider>
  );
}
