export type Locale = "es-ES" | "en-US" | "fr-FR" | "de-DE";

const translationsKeys = [
  "paginationBar.Description",
  "paginationBar.LinesPerPage",
  "paginationBar.PagesSeparator",
  "topbar.userMenu.items.lang.label",
  "topbar.a11y.toggle.label",
  "topbar.a11y.logo.link.label",
  "topbar.a11y.logo.img.alt",
  "topbar.a11y.orgsMenu.label",
  "topbar.a11y.langsMenu.label",
  "topbar.a11y.userMenu.label",
  "topbar.a11y.langsModal.input.label",
] as const;

export type TranslationsKeys = (typeof translationsKeys)[number];

export const translations: Record<Locale, Record<TranslationsKeys, string>> = {
  "es-ES": {
    "paginationBar.Description":
      "Mostrando {{currentPage}} de {{totalItems}} resultados",
    "paginationBar.LinesPerPage": "Lineas por página",
    "paginationBar.PagesSeparator": "de",
    "topbar.userMenu.items.lang.label": "Idioma",
    "topbar.a11y.toggle.label": "Alternar barra lateral",
    "topbar.a11y.logo.link.label": "Ir a la página principal",
    "topbar.a11y.logo.img.alt": "Logotipo",
    "topbar.a11y.orgsMenu.label": "Seleccionar organización",
    "topbar.a11y.langsMenu.label": "Seleccionar idioma",
    "topbar.a11y.userMenu.label": "Menú de usuario",
    "topbar.a11y.langsModal.input.label": "Idioma",
  },
  "en-US": {
    "paginationBar.Description":
      "Showing {{currentPage}} of {{totalItems}} results",
    "paginationBar.LinesPerPage": "Lines per page",
    "paginationBar.PagesSeparator": "of",
    "topbar.userMenu.items.lang.label": "Language",
    "topbar.a11y.toggle.label": "Toggle sidebar",
    "topbar.a11y.logo.link.label": "Go to homepage",
    "topbar.a11y.logo.img.alt": "Logo",
    "topbar.a11y.orgsMenu.label": "Select organization",
    "topbar.a11y.langsMenu.label": "Select language",
    "topbar.a11y.userMenu.label": "User menu",
    "topbar.a11y.langsModal.input.label": "Language",
  },
  "fr-FR": {
    "paginationBar.Description":
      "Affichage de {{currentPage}} sur {{totalItems}} résultats",
    "paginationBar.LinesPerPage": "Lignes par page",
    "paginationBar.PagesSeparator": "sur",
    "topbar.userMenu.items.lang.label": "Langue",
    "topbar.a11y.toggle.label": "Basculer la barre latérale",
    "topbar.a11y.logo.link.label": "Aller à la page d'accueil",
    "topbar.a11y.logo.img.alt": "Logo",
    "topbar.a11y.orgsMenu.label": "Sélectionner l'organisation",
    "topbar.a11y.langsMenu.label": "Sélectionner la langue",
    "topbar.a11y.userMenu.label": "Menu utilisateur",
    "topbar.a11y.langsModal.input.label": "Langue",
  },
  "de-DE": {
    "paginationBar.Description":
      "{{currentPage}} von {{totalItems}} Ergebnissen wird angezeigt",
    "paginationBar.LinesPerPage": "Zeilen pro Seite",
    "paginationBar.PagesSeparator": "von",
    "topbar.userMenu.items.lang.label": "Sprache",
    "topbar.a11y.toggle.label": "Seitenleiste umschalten",
    "topbar.a11y.logo.link.label": "Zur Startseite",
    "topbar.a11y.logo.img.alt": "Logo",
    "topbar.a11y.orgsMenu.label": "Organisation auswählen",
    "topbar.a11y.langsMenu.label": "Sprache auswählen",
    "topbar.a11y.userMenu.label": "Benutzermenü",
    "topbar.a11y.langsModal.input.label": "Sprache",
  },
};
