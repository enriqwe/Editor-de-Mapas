import { useContext } from "react";

import { LocaleContext } from "./locale";

export function useLocale() {
  return useContext(LocaleContext);
}