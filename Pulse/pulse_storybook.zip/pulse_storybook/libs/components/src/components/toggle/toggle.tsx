import type { ForwardedRef } from "react";
import { forwardRef, useRef, useEffect } from "react";
import { useToggleState } from "react-stately";
import {
  mergeProps,
  useFocusRing,
  useHover,
  useSwitch,
  VisuallyHidden,
} from "react-aria";

import * as S from "./toggle.styled";
import type { ToggleProps } from "./toggle.types";

import { automationClass } from "@utils/automation-class";

function ToggleComponent(
  props: ToggleProps,
  ref: ForwardedRef<HTMLInputElement>
) {
  const {
    reversed = false,
    alignBothSides = false,
    isDisabled = false,
    automationContext,
    size = "regular",
    label,
  } = props;
  const state = useToggleState(props);
  const internalRef = useRef(null);
  const { inputProps } = useSwitch(
    {
      ...props,
      children: label,
    },
    state,
    internalRef
  );
  const { isFocusVisible, focusProps } = useFocusRing();
  const { isHovered, hoverProps } = useHover({
    isDisabled,
  });

  const automationClasses = automationClass("toggle", automationContext);

  useEffect(() => {
    if (ref) {
      if (typeof ref === "function") {
        ref(internalRef.current);
      } else {
        ref.current = internalRef.current;
      }
    }
  }, [ref]);

  return (
    <S.Root
      $isDisabled={isDisabled}
      $isReversed={reversed}
      $size={size}
      className={automationClasses}
      {...hoverProps}
    >
      {props.label || props.children}
      <VisuallyHidden>
        <input {...mergeProps(inputProps, focusProps)} ref={internalRef} />
      </VisuallyHidden>
      <S.Track
        $isDisabled={isDisabled}
        $isFocusVisible={isFocusVisible}
        $isSelected={state.isSelected}
        $size={size}
      >
        <S.Thumb
          $isDisabled={isDisabled}
          $isHovered={isHovered}
          $isSelected={state.isSelected}
          $size={size}
        />
      </S.Track>
      {alignBothSides && (props.label || props.children)}
    </S.Root>
  );
}

export const Toggle = forwardRef(ToggleComponent);

// TODO: standarize the use of forwardRef
