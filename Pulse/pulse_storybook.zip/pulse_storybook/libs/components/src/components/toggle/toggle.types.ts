import type { AriaSwitchProps } from "react-aria";

type Size = "small" | "regular";

export type ToggleProps = AriaSwitchProps & {
  alignBothSides?: boolean;
  automationContext?: string;
  isDisabled?: boolean;
  label?: string;
  reversed?: boolean;
  size?: Size;
};
