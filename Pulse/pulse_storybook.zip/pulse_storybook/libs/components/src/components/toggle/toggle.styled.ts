import styled, { css } from "styled-components";

import type { ToggleProps } from "./toggle.types";

export const Root = styled.label<{
  $isDisabled: ToggleProps["isDisabled"];
  $size: ToggleProps["size"];
  $isReversed: ToggleProps["reversed"];
}>`
  display: flex;
  place-items: center;
  ${({ theme }) => theme.text.bodyLeadRegular};

  gap: ${({ theme }) => theme.spacing.x8};

  color: ${({ $isDisabled, theme }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.textLabel};

  ${({ $isReversed }) => {
    if ($isReversed)
      return css`
        flex-direction: row-reverse;
        justify-content: start;
      `;
  }}
`;

export const Track = styled.div<{
  $isDisabled: ToggleProps["isDisabled"];
  $size: ToggleProps["size"];
  $isSelected: boolean;
  $isFocusVisible: boolean;
}>`
  position: relative;
  display: flex;
  align-items: center;
  box-sizing: border-box;
  border: ${({ theme }) => `${theme.border.widthS} solid`};
  border-radius: ${({ theme }) => theme.border.radiusM};

  ${({ $size }) => {
    if ($size === "small")
      return css`
        width: 40px;
        height: 20px;
      `;

    return css`
      width: 44px;
      height: 24px;
    `;
  }}

  ${({ theme, $isDisabled, $isSelected }) => {
    let background = theme.color.bgFormControlDefault;

    if ($isDisabled) {
      background = theme.color.bgFormControlDisabled;
    } else if ($isSelected) {
      background = theme.color.bgFormControlActive;
    }
    return css`
      background: ${background};
      border-color: ${background};
    `;
  }}

  ${({ $isFocusVisible, theme }) => {
    return (
      $isFocusVisible &&
      css`
        outline: solid 2px ${theme.color.borderFocus};
        outline-offset: ${theme.spacing.x4};
      `
    );
  }}
`;

export const Thumb = styled.div<{
  $isDisabled: ToggleProps["isDisabled"];
  $size: ToggleProps["size"];
  $isHovered: boolean;
  $isSelected: boolean;
}>`
  box-sizing: border-box;
  position: absolute;
  left: ${({ theme, $isSelected }) =>
    $isSelected ? theme.spacing.x20 : "0px"};
  background: ${({ theme }) => theme.color.bgPrimary};
  border-radius: ${({ theme }) => theme.border.radiusCircle};

  ${({ $size }) => {
    if ($size === "small")
      return css`
        height: 16px;
        width: 16px;
      `;

    return css`
      width: 20px;
      height: 20px;
    `;
  }}

  ${({ theme, $isHovered, $isDisabled }) => {
    return (
      $isHovered &&
      !$isDisabled &&
      css`
        outline: solid 6px ${theme.color.bgFormControlActiveHover};
      `
    );
  }}
`;
