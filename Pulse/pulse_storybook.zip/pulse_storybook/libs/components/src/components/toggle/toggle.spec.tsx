import { screen } from "@testing-library/react";

import { Toggle } from "./toggle";

import { render } from "@test-utils";

describe("lLToggle", () => {
  it("should render properly", () => {
    const onChangeMock = jest.fn();
    render(<Toggle label="Label Mock" onChange={onChangeMock} />);
    expect(
      screen.getByRole("switch", { name: "Label Mock" })
    ).toBeInTheDocument();
  });

  it("should be able to toggle switch by default", async () => {
    const onChangeMock = jest.fn();

    const { user } = render(
      <Toggle label="Label Mock" onChange={onChangeMock} />
    );
    const toggle = screen.getByRole("switch", {
      name: "Label Mock",
      checked: false,
    });

    await user.click(toggle);

    expect(toggle).toBeChecked();
    expect(onChangeMock).toHaveBeenCalledWith(true);
  });

  it("should not be able to toggle switch if toggle is disabled", async () => {
    const onChangeMock = jest.fn();

    const { user } = render(
      <Toggle isDisabled label="Label Mock" onChange={onChangeMock} />
    );
    const toggle = screen.getByRole("switch", { name: "Label Mock" });

    await user.click(toggle);

    expect(toggle).not.toBeChecked();
    expect(onChangeMock).not.toHaveBeenCalledWith(true);
  });

  it("should have selected class applied by default when prop is passed", () => {
    const onChangeMock = jest.fn();

    render(<Toggle isSelected label="Label Mock" onChange={onChangeMock} />);
    const toggle = screen.getByRole("switch", { name: "Label Mock" });

    expect(toggle).toBeChecked();
  });
});
