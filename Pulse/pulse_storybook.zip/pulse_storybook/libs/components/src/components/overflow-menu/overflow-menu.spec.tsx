import { Item } from "react-stately";
import { screen } from "@testing-library/react";

import { OverflowMenu } from "./overflow-menu";

import { render } from "@test-utils";
import { Icon } from "@components/icon";

describe("overflow Menu", () => {
  it("should render properly complex items", async () => {
    const onChange = jest.fn();
    const { user } = render(
      <OverflowMenu onAction={onChange} placement="bottom start">
        <Item textValue="Edit 1">
          <Icon icon="edit" size="s" /> <div>Edit 1</div>
        </Item>
        <Item textValue="Edit 2">
          <Icon icon="edit" size="s" /> <div>Edit 2</div>
        </Item>
        <Item textValue="Edit 3">
          <Icon icon="edit" size="s" /> <div>Edit 3</div>
        </Item>
      </OverflowMenu>
    );

    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();

    await user.click(button);

    expect(screen.getAllByRole("menuitem")).toHaveLength(3);
    expect(screen.getByText("Edit 1")).toBeInTheDocument();
    expect(screen.getByText("Edit 2")).toBeInTheDocument();
    expect(screen.getByText("Edit 3")).toBeInTheDocument();
  });

  it("should render properly simple items", async () => {
    const onChange = jest.fn();
    const { user } = render(
      <OverflowMenu onAction={onChange} placement="bottom start">
        <Item>Edit 1</Item>
        <Item>Edit 2</Item>
        <Item>Edit 3</Item>
      </OverflowMenu>
    );
    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();

    await user.click(button);

    expect(screen.getAllByRole("menuitem")).toHaveLength(3);
    expect(screen.getByText("Edit 1")).toBeInTheDocument();
    expect(screen.getByText("Edit 2")).toBeInTheDocument();
    expect(screen.getByText("Edit 3")).toBeInTheDocument();
  });
});
