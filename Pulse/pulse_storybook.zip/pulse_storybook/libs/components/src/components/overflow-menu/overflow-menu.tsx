import { useRef } from "react";
import type { MenuTriggerProps } from "react-stately";
import { useMenuTriggerState, Item } from "react-stately";
import type { AriaMenuProps } from "react-aria";
import { mergeProps, useButton, useMenuTrigger } from "react-aria";

import { Menu } from "./sub-components/menu/menu";
import * as S from "./overflow-menu.styled";

import { Popover } from "@components/internal/popover";
import { Icon } from "@components/icon";
import { automationClass } from "@utils/automation-class";

type Placement =
  | "bottom start"
  | "bottom end"
  | "top start"
  | "top end"
  | "end"
  | "start";

export type OverflowMenuProps<T> = {
  placement?: Placement;
  label?: string;
  automationContext?: string;
} & AriaMenuProps<T> &
  MenuTriggerProps;

export function OverflowMenu<T extends object>(props: OverflowMenuProps<T>) {
  const state = useMenuTriggerState(props);
  const { placement = "start" } = props;
  const OverflowMenuRef = useRef<HTMLButtonElement>(null);
  const { menuTriggerProps, menuProps } = useMenuTrigger<T>(
    {},
    state,
    OverflowMenuRef
  );
  const automationClasses = automationClass(
    "overflowMenu",
    props.automationContext
  );
  const { buttonProps } = useButton(
    {
      ...menuTriggerProps,
    },
    OverflowMenuRef
  );

  return (
    <S.OverflowMenu className={`overflow-menu ${automationClasses}`}>
      <S.MenuButton
        aria-label="menuIcon"
        {...mergeProps(buttonProps)}
        ref={OverflowMenuRef}
      >
        <Icon color="inherit" icon="more_vert" />
      </S.MenuButton>
      {state.isOpen && (
        <Popover
          placement={placement}
          state={state}
          triggerRef={OverflowMenuRef}
        >
          <Menu {...props} {...menuProps} />
        </Popover>
      )}
    </S.OverflowMenu>
  );
}

export const OverflowMenuItem = Item;
export type OverflowMenuItemProps = React.ComponentProps<typeof Item>;

// TODO: fix '<Item> with non-plain text contents is unsupported by type to select for accessibility. Please add a `textValue` prop.'
