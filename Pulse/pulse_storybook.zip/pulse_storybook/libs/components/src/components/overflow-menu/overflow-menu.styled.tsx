import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const OverflowMenu = styled.div`
  display: inline-block;
`;

export const MenuButton = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: space-around;
  border: none;
  border-radius: ${cssVars.border.radiusM};
  padding: ${cssVars.spacing.x4};
  font: ${cssVars.text.bodyBaseSemiBold};
  background-color: transparent;
  color: ${cssVars.color.iconBrand};

  &:hover {
    cursor: pointer;
    background-color: ${cssVars.color.bgButtonSecondaryHover};
  }

  &:disabled {
    cursor: not-allowed;
    color: ${cssVars.color.textDisabled};
    background-color: ${cssVars.color.bgDisabled};
  }

  &:focus {
    background-color: ${cssVars.color.bgButtonSecondaryHover};
    outline-offset: 2px;
    outline: ${cssVars.border.widthS} solid ${cssVars.color.borderFocus};
  }

  &:hover:not(:disabled) {
    background-color: ${cssVars.color.bgButtonSecondaryHover};
  }
`;
