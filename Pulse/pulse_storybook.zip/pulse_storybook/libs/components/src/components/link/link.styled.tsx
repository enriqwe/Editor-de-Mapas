import styled, { css } from "styled-components";

import type { BaseLinkProps } from "./link.types";

export const LabelContainer = styled.span<{
  $variant?: BaseLinkProps["variant"];
  $iconLeft?: BaseLinkProps["iconLeft"];
  $iconRight?: BaseLinkProps["iconRight"];
}>`
  ${({ $variant }) => {
    if ($variant === "standalone") {
      return css`
        &:hover {
          text-decoration: underline;
        }
      `;
    }
    return css`
      text-decoration: underline;
    `;
  }}

  ${({ $iconLeft }) => {
    if ($iconLeft) {
      return css`
        margin-left: 4px;
      `;
    }
  }}

  ${({ $iconRight }) => {
    if ($iconRight) {
      return css`
        margin-right: 4px;
      `;
    }
  }}
`;

export const BaseStyles = css<{
  $isDisabled?: boolean;
  $size: NonNullable<BaseLinkProps["size"]>;
  $fontWeight: NonNullable<BaseLinkProps["fontWeight"]>;
}>`
  position: relative;
  display: inline-flex;
  align-items: start;
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-style: normal;
  ${({ theme, $size, $fontWeight }) =>
    theme.font.resolve(
      theme.font.sizes[$size],
      theme.font.weights[$fontWeight]
    )};

  text-decoration: none;

  line-height: ${({ theme }) => theme.spacing.x20};
  letter-spacing: 0.02em;
  pointer-events: ${({ $isDisabled }) => $isDisabled && "none"};
  cursor: ${({ $isDisabled }) => ($isDisabled ? "default" : "pointer")};

  color: ${({ theme, $isDisabled }) => {
    if ($isDisabled) {
      return theme.color.text.disabled;
    }
    return theme.color.text.link.primary;
  }};

  &:visited {
    color: ${({ theme, $isDisabled }) => {
      if ($isDisabled) {
        return theme.color.text.disabled;
      }
      return theme.color.text.link.visited;
    }};
  }

  &:hover {
    color: ${({ theme, $isDisabled }) => {
      if ($isDisabled) {
        return theme.color.text.disabled;
      }
      return theme.color.text.link.primaryHover;
    }};
  }
`;

export const Anchor = styled.a<{
  $isDisabled?: boolean;
  $size: NonNullable<BaseLinkProps["size"]>;
  $fontWeight: NonNullable<BaseLinkProps["fontWeight"]>;
}>`
  ${BaseStyles}
`;
