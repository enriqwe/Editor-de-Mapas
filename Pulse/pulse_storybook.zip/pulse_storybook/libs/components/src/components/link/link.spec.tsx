import { screen } from "@testing-library/react";

import { Link } from "./link";

import { render } from "@test-utils";

describe("link", () => {
  it("should render successfully and property", () => {
    render(
      <Link href="www.example.com" size="sm">
        LinkText
      </Link>
    );

    expect(screen.getByRole("link")).toBeInTheDocument();
    // expect(screen.getByRole('link', { name: 'Link arrow-right' })).toBeInTheDocument();
  });

  it("should render correctly with variant inline", () => {
    render(
      <Link href="www.example.com" size="sm" variant="inline">
        LinkText
      </Link>
    );

    // expect(screen.getByText(/Link/)).toBeInTheDocument();
    expect(screen.getByRole("link")).toBeInTheDocument();
  });

  it("should render correctly with iconLeft", () => {
    render(
      <Link
        fontWeight="regular"
        href="www.example.com"
        iconLeft="chevron_left"
        size="m"
      >
        LinkText
      </Link>
    );

    expect(screen.getByRole("link")).toBeInTheDocument();
    expect(screen.getByText("chevron_left")).toBeInTheDocument();
  });

  it("should render correctly with iconRight", () => {
    render(
      <Link
        fontWeight="regular"
        href="www.example.com"
        iconRight="chevron_right"
        size="m"
      >
        LinkText
      </Link>
    );

    expect(screen.getByRole("link")).toBeInTheDocument();
    expect(screen.getByText("chevron_right")).toBeInTheDocument();
  });

  it("should render correctly with iconLeft and iconRight", () => {
    render(
      <Link
        fontWeight="regular"
        href="www.example.com"
        iconLeft="chevron_left"
        iconRight="chevron_right"
        size="m"
      >
        LinkText
      </Link>
    );

    expect(screen.getByRole("link")).toBeInTheDocument();
    expect(screen.getByText("chevron_left")).toBeInTheDocument();
    expect(screen.getByText("chevron_right")).toBeInTheDocument();
  });
});
