import type { AriaLinkOptions } from "react-aria";

export type BaseLinkProps = {
  children: React.ReactNode;
  fontWeight?: "regular" | "bold" | "semibold"; //TODO: evaluate if we need this, or if we can use the font tokens from the theme ("bodyBase | "bodyLead"  | ...)
  size?: "sm" | "m";
  automationContext?: string;
  iconLeft?: string;
  iconRight?: string;
  to?: string;
  variant?: "standalone" | "inline";
} & (
  | { customElement?: React.ElementType; to?: string }
  | Record<string, never>
);

export type LinkProps = BaseLinkProps & AriaLinkOptions;
