import { screen } from "@testing-library/react";

import { Icon } from "./icon";

import { render } from "@test-utils";

describe("icon", () => {
  it("should render successfully", () => {
    render(<Icon icon="settings" />);

    expect(screen.getByTestId("icon")).toBeInTheDocument();
    expect(screen.getByTestId("icon")).toHaveTextContent("settings");
  });

  it("should render icon with click handler", async () => {
    const handleClick = jest.fn();

    const { user } = render(<Icon icon="settings" onClick={handleClick} />);

    await user.click(screen.getByTestId("icon"));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("should render tooltiptrigger component", () => {
    const handleClick = jest.fn();

    const { container } = render(
      <Icon
        icon="settings"
        onClick={handleClick}
        tooltipContent="tooltip helper text"
      />
    );

    expect(screen.getByTestId("icon")).toBeInTheDocument();
    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });
});
