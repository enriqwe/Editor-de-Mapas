export { Icon } from "./icon";
export type { IconProps } from "./icon.types";
