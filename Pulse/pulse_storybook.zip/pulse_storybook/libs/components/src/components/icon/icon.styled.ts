import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

import type { Sizes, State } from "./icon.types";

const iconSizes = {
  xs: cssVars.spacing.x16,
  s: cssVars.spacing.x20,
  m: cssVars.spacing.x24,
  l: cssVars.spacing.x40,
  xl: cssVars.spacing.x48,
}

const iconColor = (color?: string, state?: State) => {
  let finalColor: string;
  if (color) {
    finalColor = color;
  } else {
    switch (state) {
      case "default":
        finalColor = cssVars.color.iconDefault;
        break;
      case "informative":
        finalColor = cssVars.color.iconInfo;
        break;
      case "success":
        finalColor = cssVars.color.iconSuccess;
        break;
      case "error":
        finalColor = cssVars.color.iconError;
        break;
      case "warning":
        finalColor = cssVars.color.iconWarning;
        break;
      case "disabled":
        finalColor = cssVars.color.iconDisabled;
        break;
      case "tip":
        finalColor = cssVars.color.iconTips;
        break;
      case "normal":
        finalColor = cssVars.color.surfacePrimary;
        break;
      case "secondary":
        finalColor = cssVars.color.textLabel;
        break;
      default:
        finalColor = "";
    }
  }
  return finalColor;
};

export const Wrapper = styled.span<{
  $size: Sizes;
  $fill: boolean;
  $color?: string;
  $hoverColor?: string;
  $showHoverAndActiveState?: boolean;
  $state?: State;
}>`
  font-variation-settings: ${({ $fill }) =>
    `'FILL' ${$fill ? 1 : 0}, 'wght' 400, 'GRAD' 0, 'opsz' 48`};

  font-size: ${({ $size }) => iconSizes[$size]};

  color: ${({ $state, $color }) =>
    $color === "inherit" ? "inherit" : iconColor($color, $state)};

  pointer-events: ${({ $state }) => ($state === "disabled" ? "none" : "auto")};

  &[data-hovfoc="true"]:hover,
  &[data-hovfoc="true"]:active {
    --test-hovered: 1;
    color: ${({ $hoverColor }) => $hoverColor ?? cssVars.color.iconBrandHover};
    cursor: pointer;
  }
`;
