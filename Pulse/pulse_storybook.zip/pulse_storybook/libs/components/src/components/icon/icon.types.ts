import type { TooltipTriggerProps } from "@components/tooltip";

export type Sizes = "xs" | "s" | "m" | "l" | "xl";

export type State =
  | "default"
  | "informative"
  | "success"
  | "error"
  | "warning"
  | "tip"
  | "disabled"
  | "normal"
  | "secondary";

export type IconProps = {
  "fill"?: boolean;
  "size"?: "xs" | "s" | "m" | "l" | "xl";
  "icon": string;
  "color"?: string;
  "hoverColor"?: string;
  /** @deprecated use an IconButton if you need to trigger an action */
  "onClick"?: () => void;
  "showHoverAndActiveState"?: boolean;
  "state"?: State;
  "automationContext"?: string;
  "tooltipContent"?: React.ReactNode;
  "tooltipPosition"?: TooltipTriggerProps["position"];
  "aria-hidden"?: boolean;
};
