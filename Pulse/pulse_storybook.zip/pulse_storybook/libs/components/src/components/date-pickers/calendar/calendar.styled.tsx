import styled from "styled-components";

export const CalendarRoot = styled.div`
  display: flex;
  color: ${({ theme }) => theme.color.textBrandDefault};
  flex-direction: column;
  align-items: center;
`;
