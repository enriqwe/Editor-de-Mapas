import styled from "styled-components";

export const CalendarGridTable = styled.table`
  width: 100%;
  padding: ${({ theme }) => theme.spacing.x16};
  border-spacing: 0;
`;
export const CalendarGridTableHeader = styled.thead``;

export const CalendarGridTableHeaderText = styled.th`
  text-align: center;
  ${({ theme }) => theme.text.bodyMediumBold}
  color: ${({ theme }) => theme.color.textHeading};
  padding: 14px 0;
`;
