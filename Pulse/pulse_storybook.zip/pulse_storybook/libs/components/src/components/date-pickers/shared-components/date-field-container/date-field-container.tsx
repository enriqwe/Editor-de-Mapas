import type { DOMAttributes, PropsWithChildren, ForwardedRef } from "react";
import { forwardRef } from "react";

import * as S from "./date-field-container.styled";

type DateFieldContainerProps = PropsWithChildren<{
  groupProps: DOMAttributes<HTMLDivElement>;
  isError: boolean;
  disabled?: boolean;
}>;

function DateFieldContainerComponent(
  props: DateFieldContainerProps,
  ref: ForwardedRef<HTMLDivElement>
) {
  const { children, groupProps, isError, disabled = false } = props;

  return (
    <S.DateFieldContainer
      $disabled={disabled}
      $isError={isError}
      ref={ref}
      {...groupProps}
    >
      {children}
    </S.DateFieldContainer>
  );
}

export const DateFieldContainer = forwardRef(DateFieldContainerComponent);
