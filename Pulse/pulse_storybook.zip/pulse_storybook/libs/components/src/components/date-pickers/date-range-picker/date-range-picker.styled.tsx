import styled from "styled-components";

export const Container = styled.div`
  display: inline-flex;
  text-align: left;
  flex-direction: column;
  width: 100%;
`;

export const CalendarSection = styled.div`
  min-width: 300px;
  max-width: 340px;
`;

export const MultipleDateFieldContainer = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.x8};
`;

export const ErrorSubText = styled.p`
  ${({ theme }) => theme.text.bodySmallRegular}
  color: ${({ theme }) => theme.color.textError};
  margin: ${({ theme }) => theme.spacing.x8} 0 0 0;
`;

export const Description = styled.p<{
  $isDisabled?: boolean;
}>`
  ${({ theme }) => theme.text.bodySmallRegular}
  color: ${({ $isDisabled, theme }) =>
    $isDisabled ? theme.color.textDisabled : theme.color.textHelpertext};
  margin: ${({ theme }) => theme.spacing.x8} 0 0 0;
`;
