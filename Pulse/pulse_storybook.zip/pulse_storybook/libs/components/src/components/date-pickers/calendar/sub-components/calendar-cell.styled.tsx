import styled, { css } from "styled-components";

export const CalendarTableCell = styled.td<{ $isFocusVisible: boolean }>`
  position: relative;
  z-index: ${({ $isFocusVisible, theme }) =>
    $isFocusVisible ? theme.zIndex.int1 : theme.zIndex.auto};
`;

export const CalendarCell = styled.div<{
  $disabled: boolean;
  $isFocusVisible: boolean;
  $isSelectionEnd: boolean;
  $isSelectionStart: boolean;
  $isUnavailable: boolean;
  $selected: boolean;
}>`
  outline: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: ${({ $disabled, $isUnavailable }) =>
    $disabled || $isUnavailable ? "not-allowed" : "pointer"};
  width: 44px;
  height: 44px;

  ${({ theme }) => theme.text.bodyMediumSemiBold};
  text-decoration: ${({ $isUnavailable }) =>
    $isUnavailable ? "line-through" : "none"};

  border-radius: ${({ theme }) => theme.border.radiusS};

  ${({ theme, $disabled, $selected, $isSelectionStart, $isSelectionEnd }) => {
    if ($disabled) {
      return css`
        color: ${theme.color.textDisabled};
        background-color: transparent;
      `;
    }

    if ($selected) {
      if ($isSelectionStart && $isSelectionEnd) {
        // One day selected
        return css`
          color: ${theme.color.textOnBrand};
          background-color: ${theme.color.bgBrandSelected};
        `;
      }
      if ($isSelectionStart) {
        return css`
          color: ${theme.color.textOnBrand};
          background-color: ${theme.color.bgBrandSelected};
          border-radius: ${theme.border.radiusS} 0 0 ${theme.border.radiusS};
        `;
      }

      if ($isSelectionEnd) {
        return css`
          color: ${theme.color.textOnBrand};
          background-color: ${theme.color.bgBrandSelected};
          border-radius: 0 ${theme.border.radiusS} ${theme.border.radiusS} 0;
        `;
      }

      return css`
        color: ${theme.color.textBrandHover};
        background-color: ${theme.color.bgBrandHover};
        border-radius: 0;
      `;
    }

    // Default cells
    return css`
      color: ${theme.color.textBrandDefault};
      background-color: transparent;

      &:hover {
        color: ${theme.color.textBrandHover};
        background-color: ${theme.color.bgBrandHover};
      }
    `;
  }}

  ${({ theme, $isFocusVisible }) =>
    $isFocusVisible &&
    ` box-shadow: inset 0px 0px 0px 2px ${theme.color.borderFocus};
  `}
`;

export const CalendarCellTodayAdorment = styled.span<{
  $isFocusVisible: boolean;
  $selected: boolean;
  $isSelectionStart: boolean;
  $isSelectionEnd: boolean;
}>`
  background-color: ${({ theme }) => theme.color.bgBrandDefault};
  color: ${({ theme }) => theme.color.textOnBrand};
  border-radius: ${({ theme }) => theme.border.radiusCircle};
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;

  ${({ theme, $selected, $isSelectionStart, $isSelectionEnd }) => {
    if ($selected) {
      if ($isSelectionStart || $isSelectionEnd) {
        return css`
          color: ${theme.color.textBrandDefault};
          background-color: ${theme.color.bgSecondary};
        `;
      }
    }
  }}

  ${({ theme, $isFocusVisible }) =>
    $isFocusVisible && {
      backgroundColor: theme.color.bgBrandHover,
      color: theme.color.textOnBrand,
    }}
`;
