import type { AriaButtonProps } from "react-aria";
import type { CalendarState, RangeCalendarState } from "react-stately";
import { useState } from "react";

import * as S from "./calendar-content.styled";
import { CalendarGrid } from "./calendar-grid";
import { YearCalendar } from "./year-calendar";

import { IconButton } from "@components/icon-button";

type CalendarContentProps = {
  state: CalendarState | RangeCalendarState;
  nextButtonProps: AriaButtonProps;
  prevButtonProps: AriaButtonProps;
  title: string | number;
};

export function CalendarContent({
  state,
  nextButtonProps,
  prevButtonProps,
  title,
}: CalendarContentProps) {
  const [isYearCalendarOpen, setIsYearCalendarOpen] = useState(false);

  return (
    <>
      <S.CalendarHeader>
        <S.CalendarHeaderTitle>
          {isYearCalendarOpen ? state.focusedDate.year : title}

          <IconButton
            aria-label={isYearCalendarOpen ? "Close" : "Expand"}
            iconName={isYearCalendarOpen ? "expand_less" : "expand_more"}
            iconSize="xs"
            onPress={() => {
              setIsYearCalendarOpen(!isYearCalendarOpen);
            }}
          />
        </S.CalendarHeaderTitle>
        <S.NextPreviousWrapper>
          <IconButton
            {...prevButtonProps}
            iconName="north"
            iconSize="xs"
            onPress={() => {
              let date;
              if (isYearCalendarOpen) {
                date = state.focusedDate.add({ years: -1 });
              } else {
                date = state.focusedDate.add({ months: -1 });
              }
              state.setFocusedDate(date);
            }}
          />
          <IconButton
            {...nextButtonProps}
            iconName="south"
            iconSize="xs"
            onPress={() => {
              let date;
              if (isYearCalendarOpen) {
                date = state.focusedDate.add({ years: 1 });
              } else {
                date = state.focusedDate.add({ months: 1 });
              }
              state.setFocusedDate(date);
            }}
          />
        </S.NextPreviousWrapper>
      </S.CalendarHeader>
      {isYearCalendarOpen ?
        <YearCalendar
          onMonthSelected={() => {
            setIsYearCalendarOpen(false);
          }}
          state={state}
        />
      : <CalendarGrid state={state} />}
    </>
  );
}
