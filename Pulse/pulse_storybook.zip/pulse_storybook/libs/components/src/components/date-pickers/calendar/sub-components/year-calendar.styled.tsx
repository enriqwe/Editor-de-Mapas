import styled, { css } from "styled-components";

export const Table = styled.table`
  width: 100%;
  padding: ${({ theme }) =>
    `${theme.border.radiusS} 0 ${theme.border.radiusL}`};
  border-spacing: 0;
`;

export const Body = styled.tbody`
  width: 100%;
`;

export const Row = styled.tr`
  width: 100%;
`;

export const Cell = styled.td<{
  $selected?: boolean;
  $disabled?: boolean;
}>`
  width: 85px;
  height: 68px;
  text-align: center;
  padding: 0;

  ${({ $disabled, theme }) =>
    $disabled &&
    css`
      background-color: ${theme.color.bgDisabled};
      border-radius: 0;
    `}
`;

export const CellButton = styled.button<{
  $selected?: boolean;
}>`
  /* width: 100%;
  height: 100%; */
  padding: 8px 16px;
  border: none;
  border-radius: ${({ theme }) => theme.border.radiusS};
  cursor: ${({ disabled }) => (disabled ? "not-allowed" : "pointer")};

  ${({ theme }) => theme.text.bodyBaseRegular};

  ${({ $selected, disabled, theme }) => {
    if ($selected) {
      return css`
        color: ${theme.color.textOnBrand};
        background-color: ${theme.color.bgBrandSelected};
      `;
    } else if (disabled) {
      return css`
        color: ${theme.color.textDisabled};
        background-color: ${theme.color.bgDisabled};
        border-radius: 0;
      `;
    }
    return css`
      color: ${theme.color.textBrandDefault};
      background-color: ${theme.color.bgSecondary};

      &:hover {
        color: ${theme.color.textBrandHover};
        background-color: ${theme.color.bgBrandHover};
      }
    `;
  }}
`;
