import type { AriaButtonProps } from "react-aria";

import { IconButton } from "@components/icon-button";

export type CalendarButtonProps = AriaButtonProps;

export function CalendarButton(props: CalendarButtonProps) {
  return <IconButton {...props} iconName="calendar_month" iconSize="m" />;
}
