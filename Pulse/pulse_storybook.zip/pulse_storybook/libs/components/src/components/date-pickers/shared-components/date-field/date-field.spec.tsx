import { screen } from "@testing-library/react";
import { I18nProvider } from "react-aria";

import { DateField } from "./date-field";

import { render } from "@test-utils";

describe("dateFieldContainer and CalenerIcon", () => {
  it("should returns a date in correct format if locale is es-ES", () => {
    render(
      <I18nProvider locale="es-ES">
        <DateField label="birthday" />
      </I18nProvider>
    );

    expect(screen.getByRole("group").textContent).toEqual("dd/mm/aaaa");
  });

  it("should returns a date in correct format if locale is en-US", () => {
    render(
      <I18nProvider locale="en-US">
        <DateField label="birthday" />
      </I18nProvider>
    );

    expect(screen.getByRole("group").textContent).toEqual("mm/dd/yyyy");
  });
});
