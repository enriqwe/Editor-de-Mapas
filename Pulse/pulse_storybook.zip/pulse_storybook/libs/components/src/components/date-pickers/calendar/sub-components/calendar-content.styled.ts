import styled from "styled-components";

export const CalendarHeader = styled.div`
  display: flex;
  padding: ${({ theme }) => theme.spacing.x24}
    ${({ theme }) => theme.spacing.x24} 10px;
  justify-content: space-between;
  width: -webkit-fill-available;
  width: -moz-available;
  align-items: center;
`;

export const CalendarHeaderTitle = styled.h2`
  flex: 1 1 0%;
  white-space: nowrap;
  margin: 0;
  ${({ theme }) => theme.text.heading6Bold};
`;

export const NextPreviousWrapper = styled.div`
  display: flex;
  gap: 10px;
`;
