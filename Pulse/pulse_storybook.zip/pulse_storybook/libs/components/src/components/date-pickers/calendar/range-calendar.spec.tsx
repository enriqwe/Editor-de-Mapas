import { screen } from "@testing-library/react";

import { RangeCalendar } from "./range-calendar";

import { CalendarDate } from "@utils/date";
import { render } from "@test-utils";

describe("rangeCalendar", () => {
  it("should render successfully (date + buttons)", () => {
    const start = new CalendarDate(2022, 2, 3);
    const end = new CalendarDate(2022, 2, 10);
    render(<RangeCalendar value={{ start, end }} />);

    const PrevButton = screen.getByRole("button", { name: "Previous" });
    const Next = screen.getByRole("button", { name: "Next" });
    const MonthText = screen.getByText("February 2022");

    expect(PrevButton).toBeTruthy();
    expect(Next).toBeTruthy();
    expect(MonthText).toBeTruthy();
  });

  it("select date should work properly", async () => {
    const { user } = render(<RangeCalendar />);

    const startDayButton = screen.getByText("15");
    const endDayButton = screen.getByText("18");

    await user.click(startDayButton);
    await user.click(endDayButton);

    const selectedDays = screen.getAllByRole("gridcell", { selected: true });
    expect(selectedDays.length === 4).toBeTruthy();
  });

  it("select year should work properly", async () => {
    const start = new CalendarDate(2022, 2, 3);
    const end = new CalendarDate(2022, 2, 10);

    const { user } = render(<RangeCalendar value={{ start, end }} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    const selectedMonth = screen.getByRole("application", {
      name: "February 2022",
    });

    expect(selectedMonth).toBeInTheDocument();
  });

  it("change year should work properly", async () => {
    const start = new CalendarDate(2023, 2, 3);
    const end = new CalendarDate(2023, 2, 10);
    const { user } = render(<RangeCalendar value={{ start, end }} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);
    const nextBtn = screen.getByRole("button", { name: "Next" });
    await user.click(nextBtn);
    const selectedYear = screen.getByText("2024");

    expect(expandBtn).toBeTruthy();
    expect(nextBtn).toBeTruthy();
    expect(selectedYear).toBeTruthy();
  });

  it("select month should work properly", async () => {
    const start = new CalendarDate(2023, 2, 3);
    const end = new CalendarDate(2023, 2, 10);
    const { user } = render(<RangeCalendar value={{ start, end }} />);

    const expandBtn = screen.getByRole("button", { name: "Expand" });
    await user.click(expandBtn);

    const selectedMonth = screen.getByRole("button", { name: "Apr" });
    await user.click(selectedMonth);

    const updatedMonth = screen.getByText("April 2023");

    expect(updatedMonth).toBeTruthy();
    expect(selectedMonth).toBeTruthy();
    expect(expandBtn).toBeTruthy();
  });
});
