import React, { useRef } from "react";
import type { AriaDatePickerProps } from "react-aria";
import { I18nProvider, useDatePicker } from "react-aria";
import { useDatePickerState } from "react-stately";

import { CalendarButton } from "../shared-components/calendar-button";
import { Calendar } from "../calendar";
import { DateField } from "../shared-components/date-field";
import { DateFieldContainer } from "../shared-components/date-field-container";

import * as S from "./date-picker.styled";

import type { Locale } from "@providers/translation";
import type { DateValue } from "@utils/date";
import { Label } from "@components/internal";
import { Dialog } from "@components/internal/dialog";
import { Popover } from "@components/internal/popover";
import { automationClass } from "@utils/automation-class";

export type DatePickerProps = {
  /** @deprecated use isDisabled instead */
  disabled?: boolean;
  automationContext?: string;
  locale?: Locale;
  labelTooltipContent?: React.ReactNode;
  errorMessage?: string;
} & AriaDatePickerProps<DateValue>;

export function DatePicker(props: DatePickerProps) {
  const {
    description,
    isRequired = false,
    automationContext,
    errorMessage,
    locale = "es-ES",
    labelTooltipContent,
  } = props;

  const isDisabled = props.isDisabled ?? props.disabled ?? false;

  const state = useDatePickerState({
    ...props,
    isDisabled,
  });

  const { isOpen, isInvalid } = state;
  const DateFieldRef = useRef(null);
  const {
    groupProps,
    labelProps,
    fieldProps,
    buttonProps,
    dialogProps,
    calendarProps,
    descriptionProps,
    errorMessageProps,
  } = useDatePicker(props, state, DateFieldRef);

  const automationClasses = automationClass("datePicker", automationContext);

  const getDescriptionAndErrorSection = () => {
    if (description && !isInvalid) {
      return (
        <S.Description {...descriptionProps} $isDisabled={isDisabled}>
          {description}
        </S.Description>
      );
    } else if (isInvalid && errorMessage) {
      return (
        <S.ErrorSubText {...errorMessageProps}>{errorMessage}</S.ErrorSubText>
      );
    }
  };

  return (
    <I18nProvider locale={locale}>
      <S.Container className={automationClasses}>
        {props.label && (
          <Label
            {...labelProps}
            infoTooltipContent={labelTooltipContent}
            isDisabled={isDisabled}
            isRequired={isRequired}
            label={props.label}
          />
        )}
        <DateFieldContainer
          disabled={isDisabled}
          groupProps={groupProps}
          isError={isInvalid}
          ref={DateFieldRef}
        >
          <DateField {...fieldProps} isDisabled={isDisabled} />
          <CalendarButton {...buttonProps} />
        </DateFieldContainer>
        {!isOpen && getDescriptionAndErrorSection()}
        {isOpen && (
          <Popover
            placement="bottom end"
            state={state}
            triggerRef={DateFieldRef}
          >
            <Dialog {...dialogProps}>
              <S.CalendarSection>
                <Calendar {...calendarProps} />
              </S.CalendarSection>
            </Dialog>
          </Popover>
        )}
      </S.Container>
    </I18nProvider>
  );
}
