import { useRef } from "react";
import { useCalendarCell, useFocusRing, mergeProps } from "react-aria";
import type { CalendarState, RangeCalendarState } from "react-stately";

import * as S from "./calendar-cell.styled";

import type { CalendarDate } from "@utils/date";
import { isSameDay, today, getLocalTimeZone } from "@utils/date";

export function CalendarCell({
  state,
  date,
}: {
  state: CalendarState | RangeCalendarState;
  date: CalendarDate;
}) {
  const ref = useRef(null);
  const {
    cellProps,
    buttonProps,
    isSelected: selected,
    isOutsideVisibleRange,
    isDisabled: disabled,
    formattedDate,
    isUnavailable,
    // isInvalid, not implemented on DS
  } = useCalendarCell({ date }, state, ref);

  // The start and end date of the selected range will have
  // an emphasized appearance.

  const highlightedRange = (state as RangeCalendarState).highlightedRange;
  const isSelectionStart =
    highlightedRange ? isSameDay(date, highlightedRange.start) : selected;
  const isSelectionEnd =
    highlightedRange ? isSameDay(date, highlightedRange.end) : selected;

  const { focusProps, isFocusVisible } = useFocusRing();

  const isToday = isSameDay(date, today(getLocalTimeZone()));
  return (
    <S.CalendarTableCell {...cellProps} $isFocusVisible={isFocusVisible}>
      <S.CalendarCell
        {...mergeProps(buttonProps, focusProps)}
        $disabled={disabled}
        $isFocusVisible={isFocusVisible}
        $isSelectionEnd={isSelectionEnd}
        $isSelectionStart={isSelectionStart}
        $isUnavailable={isUnavailable}
        $selected={selected}
        hidden={isOutsideVisibleRange}
        ref={ref}
      >
        {isToday ?
          <S.CalendarCellTodayAdorment
            $isFocusVisible={isFocusVisible}
            $isSelectionEnd={isSelectionEnd}
            $isSelectionStart={isSelectionStart}
            $selected={selected}
          >
            {formattedDate}
          </S.CalendarCellTodayAdorment>
        : formattedDate}
      </S.CalendarCell>
    </S.CalendarTableCell>
  );
}
