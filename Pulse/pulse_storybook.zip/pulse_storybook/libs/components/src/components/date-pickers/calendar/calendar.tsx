import { useRef, useState } from "react";
import type { AriaCalendarProps, DateValue } from "react-aria";
import { useCalendar, useLocale } from "react-aria";
import type { CalendarStateOptions } from "react-stately";
import { useCalendarState } from "react-stately";

import * as S from "./calendar.styled";
import { CalendarContent } from "./sub-components/calendar-content";

import { createCalendar } from "@utils/date";
import { automationClass } from "@utils/automation-class";

export function Calendar(
  props: (CalendarStateOptions | AriaCalendarProps<DateValue>) & {
    automationContext?: string;
  }
) {
  const { locale } = useLocale();

  const state = useCalendarState({
    ...props,
    locale,
    createCalendar,
  });

  const ref = useRef(null);
  const { calendarProps, prevButtonProps, nextButtonProps, title } =
    useCalendar(props, state);

  const automationClasses = automationClass(
    "calendar",
    props.automationContext
  );

  return (
    <S.CalendarRoot {...calendarProps} className={automationClasses} ref={ref}>
      <CalendarContent
        nextButtonProps={nextButtonProps}
        prevButtonProps={prevButtonProps}
        state={state}
        title={title}
      />
    </S.CalendarRoot>
  );
}
