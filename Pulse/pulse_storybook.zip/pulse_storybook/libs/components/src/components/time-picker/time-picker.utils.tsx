export const generateTimeOptions = (
  interval: number
): { value: string; label: string }[] => {
  const options = [];

  for (let hours = 0; hours < 24; hours++) {
    for (let minutes = 0; minutes < 60; minutes += interval) {
      const formattedHours = hours.toString().padStart(2, "0");
      const formattedMinutes = minutes.toString().padStart(2, "0");
      const timeValue = `${formattedHours}:${formattedMinutes}`;
      options.push({ value: timeValue, label: timeValue });
    }
  }

  return options;
};
