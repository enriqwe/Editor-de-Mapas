import type { AriaPopoverProps } from "react-aria";
import type { OverlayTriggerState } from "react-stately";

export type PopoverProps = {
  automationContext?: string;
  children: React.ReactNode;
  crossOffset?: number;
  hasBorder?: boolean;
  marginSpace?: string;
  offset?: number;
  showArrow?: boolean;
  state: OverlayTriggerState;
} & React.PropsWithChildren<Omit<AriaPopoverProps, "popoverRef">>;

export type StyledPopoverProps = {
  border?: string;
  boxShadow?: string;
  hasBorder: boolean;
};
