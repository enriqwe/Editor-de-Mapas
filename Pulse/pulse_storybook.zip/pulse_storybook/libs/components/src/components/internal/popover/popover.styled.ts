import styled from "styled-components";

export const Popover = styled.div<{
  $hasBorder: boolean;
}>`
  box-shadow: ${({ $hasBorder, theme }) =>
    $hasBorder ? "none" : theme.shadow.med};
  border: ${({ $hasBorder, theme }) =>
    $hasBorder ?
      `${theme.border.widthXS} solid ${theme.color.border.box}`
    : "none"};
  background: ${({ theme }) => theme.color.background.box};
  border-radius: ${({ theme }) => theme.border.radiusS};
`;

export const UnderLay = styled.div`
  position: fixed;
  inset: 0;
`;

export const Arrow = styled.svg`
  position: absolute;
  fill: #fff;
  stroke: ${({ theme }) => theme.color.border.box};
  stroke-width: 1px;
  width: 20px;
  height: 12px;

  &[data-placement="top"] {
    top: 100%;
    transform: translate(-50%, -5%);
  }

  &[data-placement="bottom"] {
    bottom: 100%;
    transform: translate(-50%, 5%) rotate(180deg);
  }

  &[data-placement="left"] {
    left: 100%;
    transform: translate(-20%, -50%) rotate(-90deg);
  }

  &[data-placement="right"] {
    right: 100%;
    transform: translate(20%, -50%) rotate(90deg);
  }
`;
