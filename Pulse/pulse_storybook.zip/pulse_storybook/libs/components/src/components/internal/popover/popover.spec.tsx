import { axe, toHaveNoViolations } from "jest-axe";
import { renderHook, screen } from "@testing-library/react";
import { useOverlayTriggerState } from "react-stately";
import { useRef } from "react";

import { Popover } from "./popover";
import type { PopoverProps } from "./popover.types";

import { render } from "@test-utils";

const { result } = renderHook(() => useOverlayTriggerState({}));
const { result: refResult } = renderHook(() => useRef<HTMLButtonElement>(null));

const defaultPopoverProps: Omit<PopoverProps, "children"> = {
  state: result.current,
  triggerRef: refResult.current,
};

function DefaultPopover(props: Partial<PopoverProps>) {
  return (
    <Popover {...defaultPopoverProps} {...props}>
      <span>Popover content</span>
    </Popover>
  );
}

describe("popover test suit", () => {
  expect.extend(toHaveNoViolations);

  it("should render component correctly with popover content", async () => {
    const { container } = render(<DefaultPopover />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });

  it("should render component correctly with popover content when showArrow and hasBorder are true", async () => {
    const { container } = render(<DefaultPopover hasBorder showArrow />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
    expect(screen.getByText(/Popover content/i)).toBeInTheDocument();
  });
});
