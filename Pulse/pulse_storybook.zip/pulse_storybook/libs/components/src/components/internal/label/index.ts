export { Label } from "./label";
export type { LabelProps } from "./label";
