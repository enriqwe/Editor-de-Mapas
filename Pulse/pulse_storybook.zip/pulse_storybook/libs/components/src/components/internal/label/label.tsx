import type { LabelAriaProps } from "react-aria";
import type { ReactNode } from "react";

import * as S from "./label.styled";

import { Icon } from "@components/icon";

export type LabelProps = {
  isDisabled?: boolean;
  isRequired?: boolean;
  infoTooltipContent?: ReactNode;
} & LabelAriaProps;

export function Label(props: LabelProps) {
  const { isDisabled, isRequired, infoTooltipContent, ...rest } = props;
  return (
    <S.Container>
      <S.Label $isDisabled={isDisabled} {...rest} data-testid="label">
        {props.label}
      </S.Label>
      {isRequired && <S.RequiredIcon>*</S.RequiredIcon>}
      <S.TooltipIconWrapper>
        {Boolean(infoTooltipContent) && (
          <Icon
            color="inherit"
            icon="info"
            size="s"
            tooltipContent={infoTooltipContent}
          />
        )}
      </S.TooltipIconWrapper>
    </S.Container>
  );
}
