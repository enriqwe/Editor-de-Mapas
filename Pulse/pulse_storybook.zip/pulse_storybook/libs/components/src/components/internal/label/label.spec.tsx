import { screen } from "@testing-library/react";

import { Label } from "./label";

import { render } from "@test-utils";

describe("label", () => {
  it("should not show required or tooltip icon by default", () => {
    render(<Label />);

    const label = screen.queryByText("*");
    expect(label).not.toBeInTheDocument();

    const icon = screen.queryByTestId("icon");
    expect(icon).not.toBeInTheDocument();
  });

  it("should show required icon if isRequired is true", () => {
    render(<Label isRequired />);

    const label = screen.getByText("*");
    expect(label).toBeInTheDocument();
  });

  it("should show  icon with tooltip if infoTooltipContent is set", () => {
    render(<Label infoTooltipContent={<p>Tooltip content</p>} isRequired />);

    const icon = screen.getByTestId("icon");
    expect(icon).toBeInTheDocument();
  });
});
