import { useDialog } from "react-aria";
import type { AriaDialogProps } from "react-aria";
import { useRef } from "react";
import type { PropsWithChildren, ReactNode } from "react";

export type DialogProps = PropsWithChildren<{
  title?: string | ReactNode;
}> &
  AriaDialogProps;

export function Dialog({ title, children, ...props }: DialogProps) {
  const ref = useRef(null);
  const { dialogProps, titleProps } = useDialog(props, ref);

  return (
    <div {...dialogProps} ref={ref}>
      {title && (
        <h3 {...titleProps} style={{ marginTop: 0 }}>
          {title}
        </h3>
      )}
      {children}
    </div>
  );
}
