import styled from "styled-components";

export const Button = styled.button`
  display: inline-flex;
  align-items: center;
  border: none;
  width: auto;
  gap: ${({ theme }) => theme.spacing.x4};
  border-radius: ${({ theme }) => theme.spacing.x12};
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-weight: ${({ theme }) => theme.font.weights.bold};
  background: ${({ theme }) => theme.color.background.button.tertiary};
  color: ${({ theme }) => theme.color.text.button.ghost};
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  padding: ${({ theme }) => `2px ${theme.spacing.x4}`};

  span {
    color: ${({ theme }) => theme.color.text.button.ghost};
    font-weight: ${({ theme }) => theme.font.weights.bold};
  }

  &:hover {
    color: ${({ theme }) => theme.color.text.button.ghostHover};

    span {
      color: ${({ theme }) => theme.color.text.button.ghostHover};
      font-weight: ${({ theme }) => theme.font.weights.bold};
    }
  }

  &:active {
    color: ${({ theme }) => theme.color.text.button.ghostActive};

    span {
      color: ${({ theme }) => theme.color.text.button.ghostActive};
      font-weight: ${({ theme }) => theme.font.weights.bold};
    }
  }

  &:focus,
  &:focus-visible {
    color: ${({ theme }) => theme.color.text.button.ghostHover};

    span {
      color: ${({ theme }) => theme.color.text.button.ghostHover};
      font-weight: ${({ theme }) => theme.font.weights.bold};
    }
  }

  &:focus-visible {
    outline-offset: 1px;
    outline: 1px solid ${({ theme }) => theme.color.border.button.focus};
  }

  &:hover {
    cursor: pointer;
  }
`;

export const Title = styled.div`
  font-family: ${({ theme }) => theme.font.fontFamily};
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.m, theme.font.weights.bold)};
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  gap: ${({ theme }) => theme.spacing.x16};
`;

export const Overlay = styled.div`
  padding: ${({ theme }) =>
    `${theme.spacing.x8} ${theme.spacing.x8} ${theme.spacing.x16} ${theme.spacing.x16}`};
  max-width: calc((100vw / 12) * 4);
`;

export const Content = styled.div`
  font-family: ${({ theme }) => theme.font.fontFamily};
  margin-top: ${({ theme }) => theme.spacing.x12};
  padding-right: ${({ theme }) => theme.spacing.x8};
  overflow: auto;
`;
