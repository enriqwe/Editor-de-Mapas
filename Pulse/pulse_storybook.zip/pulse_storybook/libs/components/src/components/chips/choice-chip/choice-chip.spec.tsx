import { screen } from "@testing-library/react";

import { ChoiceChip } from "./choice-chip";

import { render } from "@test-utils";

describe("choiceChip", () => {
  it("should render successfully", () => {
    render(<ChoiceChip text="test" />);
    const button = screen.getByRole("button");
    expect(button).toBeTruthy();
  });

  it("calls onClick when clicked", async () => {
    const handleClick = jest.fn();
    const { user } = render(
      <ChoiceChip isSelected onPress={handleClick} text="example" />
    );
    const button = screen.getByRole("button");
    expect(button).toBeTruthy();

    await user.click(button);

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("should render selected and disabled state", () => {
    render(
      <ChoiceChip iconLeft="settings" isDisabled isSelected text="test" />
    );
    const button = screen.getByRole("button");
    expect(button).toBeTruthy();
    expect(button).toBeDisabled();
    expect(screen.getByText(/settings/i)).toBeTruthy();
  });

  it("should render with filled variant with disabled state", () => {
    render(<ChoiceChip isDisabled text="test" variant="filled" />);
    const button = screen.getByRole("button");
    expect(button).toBeTruthy();
    expect(button).toBeDisabled();
  });
});
