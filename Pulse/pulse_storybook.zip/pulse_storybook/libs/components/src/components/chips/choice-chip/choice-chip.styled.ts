import { ToggleButton } from "react-aria-components";
import styled, { css } from "styled-components";

import type { ChoiceChipProps } from "./choice-chip.types";

const styledOutline = css`
  outline-offset: 2px;
  outline: ${({ theme }) =>
    `${theme.border.widthS} solid ${theme.color.borderFocus}`};
`;

const ChoiceChip = styled(ToggleButton)<{
  isDisabled: boolean;
  isSelected: boolean;
  $size: NonNullable<ChoiceChipProps["size"]>;
  $iconLeft: boolean;
  $iconRight: boolean;
}>`
  display: flex;
  align-items: center;
  justify-content: center;

  ${({ theme }) => theme.text.bodyMediumRegular};

  background: none;
  border-width: ${({ theme }) => theme.border.widthXS};
  border-radius: ${({ theme }) => theme.border.radiusL};

  cursor: pointer;

  padding-top: ${({ theme, $size }) => {
    if ($size === "s") return theme.spacing.x2;
    if ($size === "m") return theme.spacing.x4;
    return theme.spacing.x6; // for size "l"
  }};
  padding-bottom: ${({ theme, $size }) => {
    if ($size === "s") return theme.spacing.x2;
    if ($size === "m") return theme.spacing.x4;
    return theme.spacing.x6; // for size "l"
  }};
  padding-left: ${({ theme, $iconLeft }) =>
    $iconLeft ? theme.spacing.x6 : theme.spacing.x12};
  padding-right: ${({ theme, $iconRight }) =>
    $iconRight ? theme.spacing.x6 : theme.spacing.x12};

  gap: ${({ theme }) => theme.spacing.x4};

  color: ${({ theme, isDisabled }) =>
    isDisabled ? theme.color.textDisabled : theme.color.textBody};

  & > span {
    color: ${({ theme, isDisabled }) =>
      isDisabled ? theme.color.textDisabled : theme.color.textBody};
  }
`;

export const ChoiceChipOutlined = styled(ChoiceChip)<{
  isDisabled: boolean;
  isSelected: boolean;
}>`
  border: ${({ theme, isDisabled }) =>
    `${theme.border.widthXS} solid ${isDisabled ? theme.color.borderDisabled : theme.color.borderChipDefault}`};

  background-color: ${({ theme, isSelected }) =>
    isSelected && theme.color.bgChipSelected};

  color: ${({ theme, isSelected }) => isSelected && theme.color.textInverse};
  & > span {
    color: ${({ theme, isSelected }) => isSelected && theme.color.iconInverse};
  }

  &:hover,
  :focus {
    border-color: ${({ theme }) => theme.color.borderChipHover};
  }

  &:focus-visible {
    ${styledOutline}
  }
`;

export const ChoiceChipFilled = styled(ChoiceChip)<{
  isDisabled: boolean;
  isSelected: boolean;
}>`
  border-color: transparent;
  background-color: ${({ theme, isDisabled, isSelected }) => {
    if (isDisabled) {
      return theme.color.bgDisabled;
    }
    if (isSelected) {
      return theme.color.bgChipSelected;
    }
    return theme.color.bgChipDefault;
  }};

  color: ${({ theme, isSelected }) => isSelected && theme.color.textInverse};
  & > span {
    color: ${({ theme, isSelected }) => isSelected && theme.color.iconInverse};
  }

  &:hover,
  :focus {
    background-color: ${({ theme }) => theme.color.bgChipHover};
  }

  &:focus-visible {
    ${styledOutline}
  }
`;
