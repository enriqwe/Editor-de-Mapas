import { screen } from "@testing-library/react";

import { ActionChip } from "./action-chip";

import { render } from "@test-utils";

describe("actionChip", () => {
  it("should render successfully", () => {
    render(<ActionChip label="test" onClick={() => ""} />);
    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();
  });

  it("calls onClick when clicked", async () => {
    const handleClick = jest.fn();
    const { user } = render(
      <ActionChip label="example" onClick={handleClick} />
    );
    const button = screen.getByRole("button");

    await user.click(button);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("should render with disabled state", () => {
    render(<ActionChip disabled iconLeft="settings" label="test" />);
    const button = screen.getByRole("button");

    expect(button).toBeDisabled();
    expect(screen.getByText(/settings/i)).toBeTruthy();
  });
});
