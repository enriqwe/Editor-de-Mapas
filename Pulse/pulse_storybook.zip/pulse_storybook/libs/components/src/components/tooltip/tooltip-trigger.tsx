import { useRef } from "react";
import { useTooltipTrigger } from "react-aria";
import { useTooltipTriggerState } from "react-stately";

import { StyledTooltipContainer, StyledTooltipTrigger } from "./tooltip.styled";
import { Tooltip } from "./tooltip";
import type { TooltipTriggerProps } from "./tooltip.types";

import { automationClass } from "@utils/automation-class";

export function TooltipTrigger({
  triggerElement,
  automationContext,
  tooltipContent,
  position = "bottom",
}: TooltipTriggerProps) {
  const tooltipAutomationClasses = automationClass(
    "tooltip",
    automationContext
  );

  const tooltipRef = useRef(null);
  const tooltipState = useTooltipTriggerState({ delay: 0 });
  const { triggerProps, tooltipProps } = useTooltipTrigger(
    { delay: 0 },
    tooltipState,
    tooltipRef
  );

  const getTooltip = () => {
    return (
      <Tooltip
        {...(tooltipProps.id ? { id: tooltipProps.id } : {})}
        automationContext={tooltipAutomationClasses}
        placement={position}
        state={{
          isOpen: tooltipState.isOpen,
          open: () => {
            tooltipState.open();
          },
          close: () => {
            tooltipState.close();
          },
          setOpen: isOpen => {
            isOpen ? tooltipState.open() : tooltipState.close();
          },
          toggle: () => {
            tooltipState.isOpen ? tooltipState.close() : tooltipState.open();
          },
        }}
        triggerRef={tooltipRef}
      >
        {tooltipContent}
      </Tooltip>
    );
  };

  const { onPointerEnter, onPointerLeave, onFocus, onMouseEnter } =
    triggerProps;

  return (
    <StyledTooltipContainer className="tooltip-trigger">
      <StyledTooltipTrigger
        aria-describedby={triggerProps["aria-describedby"]}
        onFocus={onFocus}
        onMouseEnter={onMouseEnter}
        onPointerEnter={onPointerEnter}
        onPointerLeave={onPointerLeave}
        ref={tooltipRef}
      >
        {triggerElement}
      </StyledTooltipTrigger>
      {tooltipState.isOpen && getTooltip()}
    </StyledTooltipContainer>
  );
}
