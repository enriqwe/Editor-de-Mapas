import { screen } from "@testing-library/react";

import { TooltipTrigger } from "./tooltip-trigger";

import { render } from "@test-utils";

describe("tooltip", () => {
  it("should render properly", () => {
    render(
      <TooltipTrigger
        tooltipContent="Tooltip text"
        triggerElement={<button type="button">Label</button>}
      />
    );
    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();
  });
});
