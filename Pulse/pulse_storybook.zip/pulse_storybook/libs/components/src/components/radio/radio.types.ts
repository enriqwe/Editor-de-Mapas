export type RadioVariants =
  | "normal"
  | "disabled"
  | "selected"
  | "disabledSelected"
  | "error";
