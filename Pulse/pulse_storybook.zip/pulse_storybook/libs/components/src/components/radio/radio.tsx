import type { ForwardedRef, PropsWithChildren } from "react";
import {
  Children,
  cloneElement,
  createContext,
  forwardRef,
  useContext,
  useRef,
} from "react";
import type { AriaRadioProps } from "react-aria";
import {
  VisuallyHidden,
  mergeProps,
  useFocusRing,
  useRadio,
  useRadioGroup,
} from "react-aria";
import type {
  RadioGroupState,
  RadioGroupProps as _RadioGroupProps,
} from "react-stately";
import { useRadioGroupState } from "react-stately";

import * as S from "./radio.styled";
import { RadioIcon } from "./sub-components/radio-icon";
import { RequiredIcon } from "./icons/required.icon";

import { automationClass } from "@utils/automation-class";

const RadioContext = createContext<RadioGroupState | null>(null);

type RadioGroupProps = _RadioGroupProps &
  PropsWithChildren<{
    column?: boolean;
    iconLeftAlign?: boolean;
    hasError?: boolean;
    automationContext?: string;
  }>;

type RadioItemProps = AriaRadioProps &
  PropsWithChildren<{
    iconLeftAlign?: boolean;
    hasError?: boolean;
  }>;

function Item(props: RadioItemProps, baseRef: ForwardedRef<HTMLInputElement>) {
  const { children, iconLeftAlign = true, hasError = false } = props;

  const state = useContext(RadioContext);

  if (!state) {
    throw new Error(
      "Radio.Item components must be rendered as children of Radio.Group"
    );
  }

  const internalRef = useRef<HTMLInputElement>(null);
  const { isFocusVisible, focusProps } = useFocusRing();

  const { inputProps, isSelected, isDisabled } = useRadio(
    props,
    state,
    internalRef
  );

  return (
    <div>
      <S.RadioItem
        $disabled={isDisabled}
        $iconLeftAlign={iconLeftAlign}
        // variant={variant}
      >
        <VisuallyHidden>
          <input
            {...mergeProps(inputProps, focusProps)}
            ref={baseRef ?? internalRef}
          />
        </VisuallyHidden>
        <RadioIcon
          hasError={hasError}
          isDisabled={isDisabled}
          isFocusVisible={isFocusVisible}
          isSelected={isSelected}
          // variant={variant}
        />
        {children}
      </S.RadioItem>
    </div>
  );
}

function Group(props: RadioGroupProps) {
  const {
    children,
    label,
    column = false,
    iconLeftAlign = true,
    hasError = false,
    automationContext,
  } = props;
  const state = useRadioGroupState(props);
  const { radioGroupProps, labelProps } = useRadioGroup(props, state);

  const automationClasses = automationClass("radio", automationContext);

  const RenderChildren = () =>
    Children.map(children, child => {
      return cloneElement(child as React.ReactElement<RadioItemProps>, {
        iconLeftAlign,
        hasError,
      });
    });

  return (
    <S.RadioGroup {...radioGroupProps} className={automationClasses}>
      <S.RadioGroupTitle {...labelProps}>
        {label} {props.isRequired && <RequiredIcon />}
      </S.RadioGroupTitle>
      <S.RadioItemContainer $column={column}>
        <RadioContext.Provider value={state}>
          {RenderChildren()}
        </RadioContext.Provider>
      </S.RadioItemContainer>
    </S.RadioGroup>
  );
}

export const Radio = {
  Group,
  Item: forwardRef(Item),
};
