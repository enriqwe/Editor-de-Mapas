import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const Container = styled.div`
  width: 36px;
  height: 36px;

  outline-width: 2px;
  outline-offset: -1px;
  outline-color: ${cssVars.color.borderFocus};
  outline-style: none;

  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: ${cssVars.border.radiusCircle};

  &:hover {
    background-color: ${cssVars.color.bgFormControlActiveHover};
  }

  &[data-focus-visible="true"] {
    outline-style: solid;
  }

  &[data-has-error="true"] {
    &:hover {
      background-color: ${cssVars.color.bgFormControlActiveHoverError};
    }
  }

  &[data-disabled="true"] {
    &:hover {
      background-color: transparent;
    }
  }
`;

export const Svg = styled.svg`
  width: 24px;
  height: 24px;
  border-radius: ${cssVars.border.radiusCircle};
  background-color: ${cssVars.color.bgSecondary};

  &[data-disabled="true"] {
    background-color: ${cssVars.color.bgDisabled}
  }

  &[data-selected="true"] {
    background-color: ${cssVars.color.bgSecondary};
  }
`;

export const Border = styled.circle`
  fill: transparent;
  color: ${cssVars.color.borderFormControlDefault};

  &[data-selected="true"] {
    color: ${cssVars.color.bgFormControlActive};
  }

  &[data-has-error="true"] {
    color: ${cssVars.color.borderError};
  }

  &[data-disabled="true"] {
    color: ${cssVars.color.borderDisabled};
  }
`;

export const Circle = styled.circle`
  &[data-selected="false"] {
    opacity: 0;
  }

  &[data-selected="true"] {
    color: ${cssVars.color.bgFormControlActive};
  }

  &[data-has-error="true"] {
    color: ${cssVars.color.bgFormControlActiveError};
  }

  &[data-disabled="true"] {
    color: ${cssVars.color.bgFormControlActiveDisabled};
  }
`;
