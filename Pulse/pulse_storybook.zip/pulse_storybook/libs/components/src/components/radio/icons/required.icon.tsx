export function RequiredIcon() {
  return <span style={{ color: "#DF320C" }}>*</span>;
}
