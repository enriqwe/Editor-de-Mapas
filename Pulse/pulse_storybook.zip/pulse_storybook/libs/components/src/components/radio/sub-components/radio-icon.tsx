import * as S from "./radio-icon.styled";

type RadioIconProps = {
  isSelected?: boolean;
  isDisabled?: boolean;
  isFocusVisible?: boolean;
  hasError?: boolean;
};

export function RadioIcon({
  isSelected = false,
  isDisabled = false,
  isFocusVisible = false,
  hasError = false,
}: RadioIconProps) {
  return (
    <S.Container
      data-disabled={isDisabled}
      data-focus-visible={isFocusVisible}
      data-has-error={hasError}
    >
      <S.Svg
        aria-hidden
        data-disabled={isDisabled}
        data-selected={isSelected}
        viewBox="0 0 20 20"
      >
        <S.Circle
          cx={10}
          cy={10}
          data-disabled={isDisabled}
          data-has-error={hasError}
          data-selected={isSelected}
          fill="currentColor"
          r={5}
        />
        <S.Border
          cx={10}
          cy={10}
          data-disabled={isDisabled}
          data-has-error={hasError}
          data-selected={isSelected}
          fill="none"
          r={9}
          stroke="currentColor"
          strokeWidth={2}
        />
      </S.Svg>
    </S.Container>
  );
}
