import { useVisibilityState } from "./hooks";
import * as S from "./legend.styled";
import type { LegendProps } from "./legend.types";

import { automationClass } from "@utils/automation-class";
import { Button } from "@components/button";

export function Legend({ items, automationContext }: LegendProps) {
  const automationClasses = automationClass("legend", automationContext);

  const {
    visibleItems,
    isShowMoreButtonDisplayed,
    areItemsHidden,
    containerRef,
    handleShowMoreChange,
  } = useVisibilityState({
    items,
  });

  //TODO: ref should be created here, not in hook
  return (
    <S.Container
      className={automationClasses}
      ref={containerRef as React.RefObject<HTMLDivElement>}
    >
      {visibleItems.map(item => (
        <S.Item key={`${item.color}-${item.label}`}>
          <S.ItemColor $background={item.color} />
          <S.ItemLabel>{item.label}</S.ItemLabel>
        </S.Item>
      ))}
      {isShowMoreButtonDisplayed && (
        <Button
          automationContext="buttonShowMore"
          onPress={handleShowMoreChange}
          type="button"
          variant="ghost"
        >
          {areItemsHidden ? "Ver mas" : "Ver menos"}
        </Button>
      )}
    </S.Container>
  );
}
