import React from "react";
import { renderHook, act } from "@testing-library/react";

import type { UseVisibilityStateProps } from "./use-visibility-state.types";
import { useVisibilityState } from "./use-visibility-state";

describe("useVisibilityState", () => {
  let initialProps: UseVisibilityStateProps;

  beforeEach(() => {
    initialProps = {
      items: [
        {
          color: "#2E6ED6",
          label: "First Item",
        },
        {
          color: "#EAF1FB",
          label: "Second Item",
        },
        { color: "#09A57F", label: "Third Item" },
        { color: "#09A57F", label: "Fourth Item" },
        { color: "#09A57F", label: "Fifth Item" },
      ],
    };

    jest.spyOn(React, "useRef").mockReturnValue({
      current: {
        clientHeight: 20,
      },
    });
  });

  it("should return the correct properties", () => {
    const { result } = renderHook(useVisibilityState, {
      initialProps,
    });

    expect(result.current).toEqual({
      handleShowMoreChange: expect.any(Function),
      visibleItems: initialProps.items,
      isShowMoreButtonDisplayed: false,
      areItemsHidden: true,
      containerRef: {
        current: {
          clientHeight: 20,
        },
      },
    });
  });

  describe("handleShowMoreChange", () => {
    describe("show more action", () => {
      it("should set the whole visible item list to the item list", () => {
        const { result } = renderHook(useVisibilityState, {
          initialProps: {
            ...initialProps,
          },
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        expect(result.current.visibleItems).toEqual(initialProps.items);
      });

      it("should update the areItemsHidden property to false", () => {
        const { result } = renderHook(useVisibilityState, {
          initialProps: {
            ...initialProps,
          },
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        expect(result.current.areItemsHidden).toEqual(false);
      });
    });

    describe("show less action", () => {
      it("should update the isShowMoreButtonDisplayed property to true", () => {
        const { result } = renderHook(useVisibilityState, {
          initialProps: {
            ...initialProps,
          },
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        expect(result.current.isShowMoreButtonDisplayed).toEqual(false);
      });

      it("should update the areItemsHidden property to true", () => {
        const { result } = renderHook(useVisibilityState, {
          initialProps: {
            ...initialProps,
          },
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        act(() => {
          result.current.handleShowMoreChange();
        });

        expect(result.current.areItemsHidden).toEqual(true);
      });
    });
  });

  describe("visibleItems", () => {
    it("should not update the visible items if the container ref is not set", () => {
      jest.spyOn(React, "useRef").mockReturnValue({
        current: null,
      });

      const { result } = renderHook(useVisibilityState, {
        initialProps: {
          ...initialProps,
        },
      });

      expect(result.current.visibleItems).toEqual([initialProps.items[0]]);
    });

    it("should add items to the visible items list until the current height is bigger than the max height", () => {
      jest
        .spyOn(React, "useRef")
        .mockReturnValueOnce({
          current: {
            clientHeight: 20,
          },
        })
        .mockReturnValueOnce({
          current: {
            clientHeight: 20,
          },
        })
        .mockReturnValueOnce({
          current: {
            clientHeight: 50,
          },
        });

      const { result } = renderHook(useVisibilityState, {
        initialProps,
      });

      expect(result.current.visibleItems).toEqual([
        initialProps.items[0],
        initialProps.items[1],
      ]);
    });
  });

  describe("isShowMoreButtonDisplayed", () => {
    describe("should set the property to false", () => {
      it("if the current height is smaller than the max height and the visible items list is equal to the items list", () => {
        jest.spyOn(React, "useRef").mockReturnValueOnce({
          current: {
            clientHeight: 20,
          },
        });

        const { result } = renderHook(useVisibilityState, {
          initialProps,
        });

        expect(result.current.isShowMoreButtonDisplayed).toEqual(false);
      });
    });

    describe("should set the property to true", () => {
      it("if the current height is smaller than the max height but the visible items list is not equal to the items list", () => {
        jest
          .spyOn(React, "useRef")
          .mockReturnValueOnce({
            current: {
              clientHeight: 20,
            },
          })
          .mockReturnValueOnce({
            current: {
              clientHeight: 50,
            },
          })
          .mockReturnValueOnce({
            current: {
              clientHeight: 20,
            },
          });

        const { result } = renderHook(useVisibilityState, {
          initialProps,
        });

        expect(result.current.isShowMoreButtonDisplayed).toEqual(true);
      });

      it("if the current height is equal to the max height", () => {
        jest.spyOn(React, "useRef").mockReturnValueOnce({
          current: {
            clientHeight: 42,
          },
        });

        const { result } = renderHook(useVisibilityState, {
          initialProps,
        });

        expect(result.current.isShowMoreButtonDisplayed).toEqual(true);
      });

      it("if the current height is bigger than the max height", () => {
        jest
          .spyOn(React, "useRef")
          .mockReturnValueOnce({
            current: {
              clientHeight: 20,
            },
          })
          .mockReturnValueOnce({
            current: {
              clientHeight: 50,
            },
          });

        const { result } = renderHook(useVisibilityState, {
          initialProps,
        });

        expect(result.current.isShowMoreButtonDisplayed).toEqual(true);
      });
    });
  });
});
