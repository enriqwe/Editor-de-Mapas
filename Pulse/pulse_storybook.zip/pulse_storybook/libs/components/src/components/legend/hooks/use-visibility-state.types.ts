import type { RefObject } from "react";

import type { LegendProps } from "../legend.types";

export type UseVisibilityStateProps = {
  items: LegendProps["items"];
};

export type UseVisibilityStateReturnData = {
  containerRef: RefObject<HTMLDivElement | null>;
  handleShowMoreChange: () => void;
  visibleItems: LegendProps["items"];
  isShowMoreButtonDisplayed: boolean;
  areItemsHidden: boolean;
};
