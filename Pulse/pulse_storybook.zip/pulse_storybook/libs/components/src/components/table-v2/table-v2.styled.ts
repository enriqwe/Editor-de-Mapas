import styled, { css } from "styled-components";
import type { Column } from "@tanstack/react-table";

export const Table = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
`;

export const ToolbarContainer = styled.div`
  flex-shrink: 0;
  width: 100%;
`;

export const TableBodyContainer = styled.div`
  flex-shrink: 0;
  width: 100%;
  overflow-x: auto;
  white-space: nowrap;
`;

export const PaginationContainer = styled.div`
  flex-shrink: 0;
  width: 100%;
`;

export const TableBody = styled.table<{
  $width: number;
}>`
  border-collapse: collapse;
  position: relative;
  font-family: ${({ theme }) => theme.font.fontFamily};
  min-width: ${({ $width }) => $width}px;
  width: 100%;
  text-align: left;
  border-spacing: 0;
`;

export function commonPinningStyles(column: Column<unknown>) {
  const isPinned = column.getIsPinned();
  const isLastLeftPinnedColumn =
    isPinned === "left" && column.getIsLastColumn("left");
  const isFirstRightPinnedColumn =
    isPinned === "right" && column.getIsFirstColumn("right");

  let boxShadow = "none";
  if (isLastLeftPinnedColumn) {
    boxShadow = "-4px 0 4px -4px gray inset";
  } else if (isFirstRightPinnedColumn) {
    boxShadow = "4px 0 4px -4px gray inset";
  }

  return css`
    box-shadow: ${boxShadow};
    left: ${isPinned === "left" ? `${column.getStart("left")}px` : "auto"};
    right: ${isPinned === "right" ? `${column.getAfter("right")}px` : "auto"};
    opacity: ${isPinned ? 0.95 : 1};
    position: ${isPinned ? "sticky" : "relative"};
    z-index: ${isPinned ? 1 : 0};
  `;
}
