import * as S from "./resize-separator.styled";

type ResizeSeparatorType = {
  resetSize: () => void;
  resizeHandler: (event: unknown) => void;
  isResizing: boolean;
};

export function ResizeSeparator({
  resetSize,
  isResizing,
  resizeHandler,
}: ResizeSeparatorType) {
  return (
    <S.Resizer
      className={`resizer ${isResizing ? "isResizing" : ""}`}
      data-testid="resize-separator"
      onDoubleClick={resetSize}
      onMouseDown={resizeHandler}
      onTouchStart={resizeHandler}
    />
  );
}
