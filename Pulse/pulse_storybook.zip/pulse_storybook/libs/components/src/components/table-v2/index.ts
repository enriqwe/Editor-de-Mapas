export { TableV2 } from "./table-v2";
export type { ColumnDef, TableV2Props } from "./table-v2.types";
