import styled from "styled-components";

export const ToolBar = styled.section`
  display: flex;
  align-items: flex-end;
  margin: ${({ theme }) =>
    `${theme.spacing.x24} 0 ${theme.spacing.x24} ${theme.spacing.x4}`};
`;

export const InputFilterWrapper = styled.div`
  display: flex;
  gap: ${({ theme }) => theme.spacing.x8};
  justify-content: flex-end;
  flex: 1;
`;

export const ButtonMenuContainer = styled.div`
  display: flex;
  gap: ${({ theme }) => theme.spacing.x8};
  align-items: center;
`;
