import styled from "styled-components";

export const Resizer = styled.div`
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  width: 5px;
  background: rgba(0, 0, 0, 0.2);
  cursor: col-resize;
  user-select: none;
  touch-action: none;

  @media (hover: hover) {
    &.resizer {
      opacity: 0;
    }

    *:hover > &.resizer {
      opacity: 1;
    }
  }

  &.isResizing {
    opacity: 1;
  }
`;
