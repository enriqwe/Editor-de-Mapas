import { screen } from "@testing-library/react";
import type { SortingState } from "@tanstack/react-table";

import { TableV2 } from "./table-v2";

import { render } from "@test-utils";

type TestData = {
  id: number;
  name: string;
  age: number;
  subRows?: TestData[];
};

// Mock data
const data: TestData[] = [
  { id: 1, name: "John Doe", age: 30 },
  { id: 2, name: "Jane Doe", age: 25 },
  { id: 3, name: "Bob Smith", age: 40 },
];

const columns = [
  { header: "ID", accessorKey: "id" },
  { header: "Name", accessorKey: "name" },
  { header: "Age", accessorKey: "age" },
];

const defaultControlledProps = {
  currentPage: 1,
  totalRows: data.length,
  pageSize: 10,
  onPageChange: jest.fn(),
  onPageSizeChange: jest.fn(),
  onSortChange: jest.fn(),
  sortingState: [] as SortingState,
};

describe("tableV2", () => {
  it("should render table with data and headers", () => {
    render(
      <TableV2
        columns={columns}
        controlled={defaultControlledProps}
        data={data}
      />
    );

    // Check headers
    columns.forEach(column => {
      expect(screen.getByText(column.header)).toBeInTheDocument();
    });

    // Check data
    data.forEach(row => {
      expect(screen.getByText(row.name)).toBeInTheDocument();
      expect(screen.getByText(row.age.toString())).toBeInTheDocument();
      expect(screen.getAllByText(row.id.toString())[0]).toBeInTheDocument();
    });
  });

  it("should handle pagination and next page correctly", async () => {
    const onPageChange = jest.fn();

    const { user } = render(
      <TableV2
        columns={columns}
        controlled={{
          ...defaultControlledProps,
          pageSize: 2,
          onPageChange,
        }}
        data={data}
      />
    );

    // Go to next page
    const nextPageButton = screen.getByText("chevron_right");
    await user.click(nextPageButton);

    expect(onPageChange).toHaveBeenCalledWith(2);
  });

  it("should handle pagination and previous page correctly", async () => {
    const onPageChange = jest.fn();
    const onPageSizeChange = jest.fn();
    const onSortChange = jest.fn();

    const { user } = render(
      <TableV2
        columns={columns}
        controlled={{
          ...defaultControlledProps,
          currentPage: 2,
          pageSize: 2,
          onPageChange,
          onPageSizeChange,
          onSortChange,
        }}
        data={data}
      />
    );

    const previousPageButton = screen.getByText("chevron_left");
    await user.click(previousPageButton);

    expect(onPageChange).toHaveBeenCalledWith(1);
  });

  it("should enable row selection when enableRowSelection is true", async () => {
    const { user } = render(
      <TableV2
        columns={columns}
        controlled={defaultControlledProps}
        data={data}
        enableRowSelection
      />
    );

    // Check for checkboxes
    const checkboxes = screen.getAllByRole("checkbox");
    expect(checkboxes.length).toBe(data.length + 1); // +1 for header checkbox

    // Select first row
    const firstRowCheckbox = checkboxes[1]!;
    await user.click(firstRowCheckbox);
    expect(firstRowCheckbox).toBeChecked();
  });

  it("should handle column sorting when enableColumnSorting is true", async () => {
    const onSortChange = jest.fn();

    const { user } = render(
      <TableV2
        columns={columns}
        controlled={{
          ...defaultControlledProps,
          onSortChange,
        }}
        data={data}
        enableColumnSorting
      />
    );

    // Click age header to sort
    const ageHeader = screen.getByText("Age");
    await user.click(ageHeader);

    expect(onSortChange).toHaveBeenCalled();
  });

  it("should render toolbar when toolbar props are provided", () => {
    const toolbar = {
      filters: {
        count: 2,
        onClick: jest.fn(),
      },
      massiveActions: {
        options: [
          { text: "Delete", onSelect: jest.fn() },
          { text: "Export", onSelect: jest.fn() },
        ],
      },
    };

    render(
      <TableV2
        columns={columns}
        controlled={defaultControlledProps}
        data={data}
        toolbar={toolbar}
      />
    );

    // Check for filter badge
    expect(screen.getByText("Filtros (2)")).toBeInTheDocument();

    // Check for massive actions
    expect(screen.getByText("Selecciona una opción")).toBeInTheDocument();
  });

  it("should render table with subRows", () => {
    const dataWithSubRows: TestData[] = [
      {
        id: 1,
        name: "John Doe",
        age: 30,
        subRows: [{ id: 2, name: "Jane Doe", age: 25 }],
      },
      { id: 3, name: "Bob Smith", age: 40 },
    ];

    render(
      <TableV2
        columns={columns}
        controlled={defaultControlledProps}
        data={dataWithSubRows}
      />
    );

    // It's 3 because it includes the header row
    expect(screen.getAllByRole("row")).toHaveLength(3);

    // Check data
    dataWithSubRows.forEach(row => {
      expect(screen.getByText(row.name)).toBeInTheDocument();
      expect(screen.getByText(row.age.toString())).toBeInTheDocument();
      expect(screen.getAllByText(row.id.toString())[0]).toBeInTheDocument();
    });
  });

  it("should handle disablePagination correctly", () => {
    render(
      <TableV2
        columns={columns}
        controlled={defaultControlledProps}
        data={data}
        disablePagination
      />
    );

    expect(screen.queryByText("chevron_right")).not.toBeInTheDocument();
    expect(screen.queryByText("chevron_left")).not.toBeInTheDocument();
  });

  it("should change page in uncontrolled mode", async () => {
    const { user } = render(
      <TableV2 columns={columns} data={data} defaultPageSize={2} />
    );

    // Go to next page
    const nextPageButton = screen.getByText("chevron_right");
    await user.click(nextPageButton);

    let pageNo = screen.getByRole("textbox");
    expect(pageNo.getAttribute("value")).toBe("2");

    const previousPageButton = screen.getByText("chevron_left");
    await user.click(previousPageButton);

    pageNo = screen.getByRole("textbox");
    expect(pageNo.getAttribute("value")).toBe("1");
  });

  // Missing test cases:
  // - not controlled onPageSizeChange
  // - enable column resizing
});
