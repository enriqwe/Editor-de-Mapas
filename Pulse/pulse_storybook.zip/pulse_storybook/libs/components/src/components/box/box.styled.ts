// import styled from "styled-components";
import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const Box = styled.div`
  border: ${cssVars.border.widthXS} solid ${cssVars.color.borderDefault};
  border-radius: ${cssVars.border.radiusL};
  box-sizing: border-box;
  background: ${cssVars.color.bgSecondary};
`;

export const Header = styled.div`
  display: flex;
  gap: ${cssVars.spacing.x8};
  border-bottom: ${`${cssVars.border.widthXS} solid ${cssVars.color.borderDivider}`};
  padding: ${cssVars.spacing.x24};
  flex-direction: row;
`;

export const TitlesContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

export const Title = styled.p`
  font: ${cssVars.text.bodyLeadBold};
  margin: 0;
`;

export const SubTitle = styled.p`
  font: ${cssVars.text.bodyMediumRegular};
  color: ${cssVars.color.textSubheading};
  margin: 0;
`;

export const Actions = styled.div`
  display: flex;
  gap: ${cssVars.spacing.x8};
  margin-left: auto;
  align-self: center;
`;

export const Content = styled.div`
  padding: ${cssVars.spacing.x24};
`;

export const MenuItemName = styled.div`
  font: ${cssVars.text.bodyBaseRegular};
`;
