import type { Key, PropsWithChildren } from "react";

import type { ActionChipProps } from "@components/chips";
import type { IconButtonProps } from "@components/icon-button";

export type MenuItem = {
  id: number;
  name: string;
  icon?: string;
};

export type BoxOverflowMenu = {
  onAction: (key: Key) => void;
  items: MenuItem[];
};

export type BoxProps = PropsWithChildren<
  {
    title: string;
    icon?: string;
    automationContext?: string;
    subtitle?: string;
  } & (
    | {
        actionsType: "chips";
        actions: ActionChipProps[];
      }
    | {
        actionsType: "icons";
        actions: IconButtonProps[];
      }
    | {
        actionsType?: undefined;
        actions?: undefined;
      }
  )
>;
