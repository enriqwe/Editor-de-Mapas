import type { BoxProps } from "./box.types";
import * as S from "./box.styled";

import { ActionChip } from "@components/chips";
import { IconButton } from "@components/icon-button";
import { Icon } from "@components/icon";

export function Box({
  title,
  icon,
  subtitle,
  children,
  actionsType,
  actions,
  automationContext,
}: BoxProps) {
  const renderActions = () => {
    switch (actionsType) {
      case "chips": {
        return actions.map(actionProps => (
          <ActionChip
            key={actionProps.label}
            {...actionProps}
            automationContext={`box-${automationContext}`}
          />
        ));
      }
      case "icons": {
        return actions.map(actionProps => (
          <IconButton
            key={actionProps.iconName}
            {...actionProps}
            automationContext={`box-${automationContext}`}
          />
        ));
      }
      default:
        return null;
    }
  };

  return (
    <S.Box>
      <S.Header>
        {icon && <Icon icon={icon} />}
        <S.TitlesContainer>
          <S.Title>{title}</S.Title>
          {subtitle && <S.SubTitle>{subtitle}</S.SubTitle>}
        </S.TitlesContainer>
        {actions && <S.Actions>{renderActions()}</S.Actions>}
      </S.Header>
      <S.Content>{children}</S.Content>
    </S.Box>
  );
}
