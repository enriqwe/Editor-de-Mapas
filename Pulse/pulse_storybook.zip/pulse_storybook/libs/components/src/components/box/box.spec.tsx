import { screen } from "@testing-library/react";

import { Box } from "./box";

import { render } from "@test-utils";

describe("box", () => {
  it("should render successfully with required props only", () => {
    const { container } = render(
      <Box title="title">
        <p>Test content</p>
      </Box>
    );

    expect(container).toBeTruthy();

    expect(screen.getByText(/title/i)).toBeInTheDocument(); // title
    expect(screen.getByText(/test content/i)).toBeInTheDocument(); // container
  });

  it("should render successfully with optional props (chips)", () => {
    const chips = [
      {
        label: "Chip 0",
        disabled: false,
        onClick: jest.fn(),
      },
      {
        label: "Chip 1",
        disabled: true,
        onClick: jest.fn(),
      },
    ];

    render(
      <Box
        actions={chips}
        actionsType="chips"
        icon="house"
        subtitle="subtitle"
        title="title"
      >
        <p>Test content</p>
      </Box>
    );

    // const actionsContainer = screen.qu

    expect(screen.getByText(/subtitle/i)).toBeInTheDocument(); // subtitle
    expect(screen.getByText(/house/i)).toBeInTheDocument(); // icon
    expect(screen.getAllByRole("button").length).toEqual(2); // chips (buttons)
    expect(screen.getByText(/chip 0/i)).toBeInTheDocument();
    expect(screen.getByText(/chip 1/i).closest("button")).toBeDisabled();
  });

  it("should render successfully with optional props (iconbutton)", () => {
    const icons = [
      {
        iconName: "house",
        tooltipContent: "tooltip text",
        onClick: jest.fn(),
        disabled: false,
        automationContext: "house-icon-button",
      },
      {
        iconName: "settings",
        tooltipContent: "tooltip text",
        onClick: jest.fn(),
        disabled: false,
        automationContext: "settings-icon-button",
      },
    ];

    render(
      <Box
        actions={icons}
        actionsType="icons"
        icon="house"
        subtitle="subtitle"
        title="title"
      >
        <p>Test content</p>
      </Box>
    );

    // const actionsContainer = screen.getByTestId('actions-container');
    //
    const buttons = screen.queryAllByRole("button");

    expect(buttons.length).toEqual(2); // icons (buttons)
    expect(buttons[0]).toHaveTextContent("house"); // fixed to access the iconName
    expect(screen.getByText(/settings/i)).toBeInTheDocument();
  });
});
