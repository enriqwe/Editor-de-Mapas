import { screen } from "@testing-library/react";

import { SelectWithPagination } from "./select-with-pagination";

import { render } from "@test-utils";

describe("test SelectWithPagination component", () => {
  beforeAll(() => {
    jest.useFakeTimers({ advanceTimers: true });
  });

  afterAll(() => {
    jest.useRealTimers();
  });

  const mockedOptions = [
    { label: "Mocked option 1", value: "mocked-option-1" },
    { label: "Mocked option 2", value: "mocked-option-2" },
    { label: "Mocked option 3", value: "mocked-option-3" },
    { label: "Mocked option 4", value: "mocked-option-4" },
    { label: "Mocked option 5", value: "mocked-option-5" },
    { label: "Mocked option 6", value: "mocked-option-6" },
    { label: "Mocked option 7", value: "mocked-option-7" },
    { label: "Mocked option 8", value: "mocked-option-8" },
    { label: "Mocked option 9", value: "mocked-option-9" },
    { label: "Mocked option 10", value: "mocked-option-10" },
  ];

  it("should render without errors", () => {
    const mockedOnChange = jest.fn();
    render(
      <SelectWithPagination
        helperText="Optional helper text"
        isLoading={false}
        label="This is a label"
        onChange={mockedOnChange}
        onInputChange={jest.fn()}
        onPageEndReached={jest.fn()}
        options={mockedOptions}
        pageSize={mockedOptions.length}
        required
        tooltipContent="tooltip info"
        totalOptions={mockedOptions.length}
      />
    );
    const placeholder = screen.getByText("Select...");
    const label = screen.getByText("This is a label");
    const subText = screen.getByText("Optional helper text");
    const infoIcon = screen.getByText("info");

    expect(placeholder).toBeTruthy();
    expect(label).toBeTruthy();
    expect(subText).toBeTruthy();
    expect(infoIcon).toBeTruthy();
  });

  it("should call onChange when the first option is selected", async () => {
    const mockedOnChange = jest.fn();
    const { user } = render(
      <SelectWithPagination
        isLoading={false}
        onChange={mockedOnChange}
        onInputChange={jest.fn()}
        onPageEndReached={jest.fn()}
        options={mockedOptions}
        pageSize={mockedOptions.length}
        totalOptions={mockedOptions.length}
      />
    );

    const mySelectComponent = screen.getByRole("combobox");
    await user.click(mySelectComponent);
    await user.keyboard("[ArrowDown]");

    const option1 = screen.getByText("Mocked option 1");
    await user.click(option1);

    expect(mockedOnChange).toHaveBeenCalledTimes(1);
    expect(mockedOnChange).toHaveBeenCalledWith({
      label: "Mocked option 1",
      value: "mocked-option-1",
    });
  });

  it("should call onChange for each selection", async () => {
    const mockedOnChange = jest.fn();
    const { user } = render(
      <SelectWithPagination
        clearInputOnChange
        isLoading={false}
        onChange={mockedOnChange}
        onInputChange={jest.fn()}
        onPageEndReached={jest.fn()}
        options={mockedOptions}
        pageSize={mockedOptions.length}
        totalOptions={mockedOptions.length}
      />
    );

    const input = screen.getByRole("combobox");

    await user.click(input);

    const option1 = screen.getByText("Mocked option 1");
    await user.click(option1);

    await user.click(input);
    const option2 = screen.getByText("Mocked option 2");
    await user.click(option2);

    await user.click(input);
    const option9 = screen.getByText("Mocked option 9");
    await user.click(option9);

    expect(mockedOnChange).toHaveBeenCalledTimes(3);
  });

  it("should type into the input component", async () => {
    const mockedOnInputChange = jest.fn();
    const mockOnPageEndReached = jest.fn();
    const { user } = render(
      <SelectWithPagination
        isLoading={false}
        isMulti
        onChange={jest.fn()}
        onInputChange={mockedOnInputChange}
        onPageEndReached={mockOnPageEndReached}
        options={mockedOptions}
        pageSize={mockedOptions.length}
        totalOptions={mockedOptions.length}
      />
    );

    const input = screen.getByRole("combobox");

    expect(input).toBeDefined();
    expect(input).not.toBeNull();
    expect(mockedOnInputChange).toHaveBeenCalledTimes(0);
    await user.type(input, "optio");

    jest.runAllTimers();

    expect(mockedOnInputChange).toHaveBeenCalledTimes(1);
    expect(mockedOnInputChange).toHaveBeenCalledWith("optio");
  });

  it("test on input select change", async () => {
    const mockOnInputSelectChange = jest
      .fn()
      .mockImplementation((inputValue: string) => {
        return inputValue;
      });
    const SelectComponent = (
      <div>
        <SelectWithPagination
          isLoading={false}
          isMulti
          onChange={jest.fn()}
          onInputChange={mockOnInputSelectChange}
          onPageEndReached={jest.fn()}
          options={mockedOptions}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    const { user } = render(SelectComponent);

    const mySelectComponent: HTMLInputElement = screen.getByRole("combobox");

    await user.click(mySelectComponent);

    expect(mySelectComponent.value).toContain("");

    await user.click(mySelectComponent);
    await user.click(screen.getByTestId("outside"));

    expect(mySelectComponent).not.toHaveFocus();
  });

  it("test on input select change with allowed char regex", async () => {
    const mockOnInputSelectChange = jest
      .fn()
      .mockImplementation((inputValue: string) => {
        return inputValue;
      });
    const SelectComponent = (
      <div>
        <SelectWithPagination
          allowedCharRegExp={/^[a-zA-Z0-9\u00C0-\u017F]*$/}
          isLoading={false}
          isMulti
          onChange={jest.fn()}
          onInputChange={mockOnInputSelectChange}
          onPageEndReached={jest.fn()}
          options={mockedOptions}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    const { user } = render(SelectComponent);

    const mySelectComponent: HTMLInputElement = screen.getByRole("combobox");
    await user.type(mySelectComponent, "#");

    expect(mySelectComponent.value).toContain("");

    await user.click(mySelectComponent);
    await user.click(screen.getByTestId("outside"));

    expect(mySelectComponent).not.toHaveFocus();
  });

  it("dropdown menu should be closed on blur", async () => {
    const SelectComponent = (
      <div>
        <SelectWithPagination
          isLoading={false}
          isMulti
          onChange={jest.fn()}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          options={mockedOptions}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    const { user } = render(SelectComponent);
    const mySelectComponent = screen.getByRole("combobox");

    await user.click(mySelectComponent);

    const visibleOption = screen.getByText("Mocked option 2");
    expect(visibleOption).toBeInTheDocument();

    await user.click(screen.getByTestId("outside"));

    const nonVisibleOption = screen.queryByText("Mocked option 2");
    expect(nonVisibleOption).not.toBeInTheDocument();
    expect(mySelectComponent).not.toHaveFocus();
  });

  it("default values", () => {
    const SelectComponent = (
      <div>
        <SelectWithPagination
          disabled
          initialValue={[{ label: "some-label", value: "some-value" }]}
          isLoading={false}
          isMulti
          name="select-with-pagination"
          onChange={jest.fn()}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    render(SelectComponent);
    const option = screen.getByText("some-label");
    expect(option).toBeTruthy();
  });

  it("minimun input length", async () => {
    const mockedOnInputChange = jest.fn();
    const mockOnPageEndReached = jest.fn();
    const { user } = render(
      <SelectWithPagination
        isLoading={false}
        isMulti
        minInputLength={2}
        onChange={jest.fn()}
        onInputChange={mockedOnInputChange}
        onPageEndReached={mockOnPageEndReached}
        options={mockedOptions}
        pageSize={mockedOptions.length}
        totalOptions={mockedOptions.length}
      />
    );

    const mySelectComponent = screen.getByRole("combobox");

    expect(mySelectComponent).toBeDefined();
    expect(mySelectComponent).not.toBeNull();
    expect(mockedOnInputChange).toHaveBeenCalledTimes(0);

    await user.type(mySelectComponent, "o");

    jest.runAllTimers();

    expect(mockedOnInputChange).toHaveBeenCalledTimes(0);

    await user.type(mySelectComponent, "pt");

    jest.runAllTimers();

    expect(mockedOnInputChange).toHaveBeenCalledTimes(1);
    expect(mockedOnInputChange).toHaveBeenCalledWith("opt");
  });

  it("error state", () => {
    const SelectComponent = (
      <div>
        <SelectWithPagination
          errorMessage="some error"
          initialValue={[{ label: "some-label", value: "some-value" }]}
          isLoading={false}
          name="select-with-pagination"
          onChange={jest.fn()}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    render(SelectComponent);
    const errorText = screen.getByText("some error");
    expect(errorText).toBeTruthy();
  });

  it("clear user input", async () => {
    const mockOnChange = jest.fn();
    const SelectComponent = (
      <div>
        <SelectWithPagination
          isLoading={false}
          name="select-with-pagination"
          onChange={mockOnChange}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          options={mockedOptions}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    const { user } = render(SelectComponent);

    const mySelectComponent = screen.getByRole("combobox");
    await user.click(mySelectComponent);
    await user.click(screen.getByText("Mocked option 2"));

    expect(mockOnChange).toHaveBeenNthCalledWith(1, {
      label: "Mocked option 2",
      value: "mocked-option-2",
    });

    const clearIcon = screen.getByText("clear");
    await user.click(clearIcon);

    expect(mockOnChange).toHaveBeenNthCalledWith(2, null);
  });

  it("loading state", () => {
    const SelectComponent = (
      <div>
        <SelectWithPagination
          initialValue={[{ label: "some-label", value: "some-value" }]}
          isLoading
          name="select-with-pagination"
          onChange={jest.fn()}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    render(SelectComponent);

    const spinnerSVG = screen.getByTestId("spinner");
    expect(spinnerSVG).toBeTruthy();
  });

  it("clear select value in multi state", async () => {
    const mockOnChange = jest.fn();
    const SelectComponent = (
      <div>
        <SelectWithPagination
          isLoading={false}
          isMulti
          name="select-with-pagination"
          onChange={mockOnChange}
          onInputChange={jest.fn()}
          onPageEndReached={jest.fn()}
          options={mockedOptions}
          pageSize={mockedOptions.length}
          totalOptions={mockedOptions.length}
        />
        <div data-testid="outside" />
      </div>
    );
    const { user } = render(SelectComponent);

    const mySelectComponent = screen.getByRole("combobox");
    await user.click(mySelectComponent);

    await user.click(screen.getByText("Mocked option 2"));
    expect(mockOnChange).toHaveBeenNthCalledWith(1, [
      {
        label: "Mocked option 2",
        value: "mocked-option-2",
      },
    ]);

    const clearIcon = screen.getByText("clear");
    await user.click(clearIcon);

    expect(mockOnChange).toHaveBeenNthCalledWith(2, []);
  });
});
