// import type { TableProps } from '@react-types/table';
import { useEffect, useRef } from "react";
import type { AriaTableProps } from "react-aria";
import { useTable } from "react-aria";
import {
  Cell,
  Column,
  Row,
  TableBody,
  TableHeader,
  useTableState,
} from "react-stately";
import type { TableStateProps } from "react-stately";

import { TableRowGroup, TableHeaderRow, TableRow } from "./sub-components";
import * as S from "./table-content.styled";
import type { TableContentProps } from "./table.types";
import { TableColumnHeader } from "./sub-components/table-units/table-column-header";
import {
  TableSelectAllCell,
  TableCheckboxCell,
} from "./sub-components/table-units/table-checkbox";
import { TableCell } from "./sub-components/table-units/table-cell";

import { EmptyState } from "@components/empty-state";

const SELECTALL = "all";
const MULTIPLE = "multiple";

function TableComponent<T extends object>(
  props: AriaTableProps &
    TableStateProps<T> & { showSelectionCheckboxes?: boolean }
) {
  const {
    sortDescriptor,
    onSortChange,
    children,
    selectionMode = MULTIPLE,
    showSelectionCheckboxes = false,
    disabledKeys = [],
    selectedKeys = new Set(),
    onSelectionChange = () => null,
  } = props;

  const tableRef = useRef<HTMLTableElement>(null);
  // const bodyRef = useRef<HTMLTableSectionElement>(null);
  // const headerRef = useRef<HTMLTableSectionElement>(null);

  const state = useTableState({
    onSortChange,
    children,
    sortDescriptor,
    showSelectionCheckboxes,
    selectionMode,
    disabledKeys,
    selectedKeys,
    onSelectionChange,
  });
  const { collection } = state;
  const { gridProps } = useTable<T>(props, state, tableRef);

  useEffect(() => {
    if (selectedKeys === SELECTALL) {
      onSelectionChange(state.selectionManager.selectedKeys);
    }
  }, [selectedKeys]);

  return (
    <S.Table {...gridProps} ref={tableRef}>
      <TableRowGroup type="thead">
        {collection.headerRows.map(headerRow => (
          <TableHeaderRow item={headerRow} key={headerRow.key} state={state}>
            {[...state.collection.getChildren!(headerRow.key)].map(column =>
              column.props.isSelectionCell ?
                <TableSelectAllCell
                  column={column}
                  key={column.key}
                  state={state}
                />
              : <TableColumnHeader
                  column={column}
                  key={column.key}
                  state={state}
                />
            )}
          </TableHeaderRow>
        ))}
      </TableRowGroup>
      <TableRowGroup type="tbody">
        {[...collection].map(row => {
          const rowValue = (row.value as { disabled?: boolean }) || undefined;
          return (
            <TableRow item={row} key={row.key} state={state}>
              {[...state.collection.getChildren!(row.key)].map(cell =>
                cell.props.isSelectionCell ?
                  <TableCheckboxCell cell={cell} key={cell.key} state={state} />
                : <TableCell
                    cell={cell}
                    isDisabled={rowValue.disabled}
                    key={cell.key}
                    state={state}
                  />
              )}
            </TableRow>
          );
        })}
      </TableRowGroup>
    </S.Table>
  );
}

export function TableContent({
  ariaLabel = "",
  sortDescriptor,
  rowsData,
  onSort,
  headers,
  showSelectAll = false,
  disabledKeys = [],
  selectedKeys = new Set(),
  setSelectedKeys = () => null,
  appliedFilters,
}: TableContentProps) {
  if (rowsData.length <= 0 && appliedFilters) {
    return (
      <S.EmptyStateWrapper>
        <EmptyState
          automationContext="table-empty-state"
          illustrationName="Search"
          subTitle="Intenta ajustando la búsqueda o quitando los filtros."
          title="No hay resultados"
        />
      </S.EmptyStateWrapper>
    );
  }

  return (
    <TableComponent
      aria-label={ariaLabel}
      disabledKeys={disabledKeys}
      onSelectionChange={setSelectedKeys}
      onSortChange={sortDesc => {
        onSort({ columnKey: sortDesc.column, order: sortDesc.direction });
      }}
      selectedKeys={selectedKeys}
      selectionMode={MULTIPLE}
      showSelectionCheckboxes={showSelectAll}
      sortDescriptor={{
        column: sortDescriptor.columnKey as string,
        direction: sortDescriptor.order,
      }}
    >
      <TableHeader columns={headers}>
        {column => {
          return (
            <Column allowsSorting={column.sortable} key={column.key}>
              {column.label}
            </Column>
          );
        }}
      </TableHeader>
      <TableBody items={rowsData}>
        {item => (
          <Row>
            {(columnKey: string | number) => <Cell>{item[columnKey]}</Cell>}
          </Row>
        )}
      </TableBody>
    </TableComponent>
  );
}
