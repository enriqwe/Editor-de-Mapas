import type { SortingProps, TableFELogicProps } from "./table.types";
import { SortDirection } from "./table.constant";

export const sortTableData = (items: any[], sortDescriptor: SortingProps) => {
  return items.sort((itemA, itemB) => {
    const first =
      itemA[sortDescriptor.columnKey as keyof typeof itemA].toLowerCase();
    const second =
      itemB[sortDescriptor.columnKey as keyof typeof itemB].toLowerCase();
    let compareResult =
      (parseInt(first, 10) || first) < (parseInt(second, 10) || second) ?
        -1
      : 1;
    if (sortDescriptor.order === SortDirection.DESCENDING) {
      compareResult *= -1;
    }
    return compareResult;
  });
};

export function TableFELogic(props: TableFELogicProps) {
  const {
    totalData = [],
    pageSize,
    updateSortDescriptor,
    updateRowsData,
    updateActivePage,
    updatePageSize,
    getPageData,
  } = props;

  //sorting table rows data on client side
  const sort = (items: any[], sortDescriptor: SortingProps) => {
    const FIRST_PAGE = 1;
    const updatedList = sortTableData(items, sortDescriptor);
    /** get the sorted data of the first page */
    const updatedRows = getPageData(updatedList, FIRST_PAGE, pageSize);
    updateSortDescriptor(sortDescriptor);
    updateRowsData(updatedRows);
    /** Always navigate to the first page after sorting */
    updateActivePage(FIRST_PAGE);
  };

  //page event handler called on page change
  const pageChangeHandler = (pageNumber: number) => {
    updateActivePage(pageNumber);
    const updatedRows = getPageData(totalData, pageNumber, pageSize);
    updateRowsData(updatedRows);
  };

  //page event handler called on page size change
  const pageSizeChangeHandler = (newPageSize: number) => {
    updateActivePage(1);
    updatePageSize(newPageSize);
    const updatedRows = getPageData(totalData, 1, newPageSize);
    updateRowsData(updatedRows);
  };

  return {
    /** Sort operation performing always on total table data */
    sort: (sortDescriptor: SortingProps) => {
      sort(totalData, sortDescriptor);
    },
    onPageChange: (pageNumber: number) => {
      pageChangeHandler(pageNumber);
    },
    onPageSizeChange: (newPageSize: number) => {
      pageSizeChangeHandler(newPageSize);
    },
  };
}
