import { screen } from "@testing-library/react";
import type { ComponentProps } from "react";

import { Table } from "./table";
import {
  FEAndBEHeadersData,
  defaultHeadersData,
  paginationTableData,
  usersMockData,
} from "./mocks/data";

import { render } from "@test-utils";

const defaultProps: ComponentProps<typeof Table> = {
  dataHandling: "frontend",
  ariaLabel: "default_table",
  tableData: {
    headers: defaultHeadersData,
    data: usersMockData,
  },
};

describe("table", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should render successfully", () => {
    render(<Table {...defaultProps} disablePagination />);

    expect(screen.getByRole("grid")).toBeInTheDocument();
    const rowGroups = screen.getAllByRole("rowgroup");
    expect(rowGroups[0]?.tagName).toBe("THEAD");
    expect(rowGroups[1]?.tagName).toBe("TBODY");

    expect(screen.getByText("Layout Name")).toBeInTheDocument();
    expect(screen.getByText("Last Editor")).toBeInTheDocument();
    expect(screen.getByText("State")).toBeInTheDocument();
    expect(screen.getByText("Languages")).toBeInTheDocument();
  });

  it("should show rows data correctly", () => {
    render(<Table {...defaultProps} disablePagination />);

    expect(screen.getAllByRole("row").length).toEqual(6);
    // expect(container.getElementsByClassName("paginationBar").length).toBe(0);
    expect(screen.queryByTestId("pagination-bar")).not.toBeInTheDocument();
  });

  it("should show pagination correctly", () => {
    render(<Table {...defaultProps} />);

    expect(screen.getByTestId("pagination-bar")).toBeInTheDocument();
    expect(screen.getByLabelText("default_table")).toBeTruthy();
  });

  it("should not show filters container", () => {
    const { container } = render(<Table {...defaultProps} />);
    expect(container.getElementsByTagName("section").length).toBe(0);
  });

  it("sorting should work correctly for frontend", async () => {
    const { user } = render(
      <Table
        {...defaultProps}
        initialSort={{
          columnKey: "phone",
          order: "ascending",
        }}
        paginationProps={{
          pageSizeList: [10, 20, 30, 40, 50],
          activePageNo: 1,
          defaultPageSize: 10,
        }}
        tableData={{
          headers: FEAndBEHeadersData,
          data: paginationTableData,
        }}
      />
    );

    const firstNameColumn = screen.getByRole("columnheader", {
      name: "First Name",
    });
    expect(firstNameColumn.getAttribute("aria-sort") === "none").toBeTruthy();

    const phoneColumn = screen.getByRole("columnheader", { name: "Phone" });
    expect(phoneColumn.getAttribute("aria-sort") === "ascending").toBeTruthy();
    await user.click(phoneColumn);
    expect(phoneColumn.getAttribute("aria-sort") === "descending").toBeTruthy();

    await user.click(firstNameColumn);
    expect(
      firstNameColumn.getAttribute("aria-sort") === "ascending"
    ).toBeTruthy();
  });

  it("sorting should work correctly for backend", async () => {
    const sortHandler = jest.fn();
    const { user } = render(
      <Table
        {...defaultProps}
        dataHandling="backend"
        initialSort={{
          columnKey: "phone",
          order: "ascending",
        }}
        paginationProps={{
          pageSizeList: [10, 20, 30, 40, 50],
          activePageNo: 1,
          defaultPageSize: 10,
        }}
        sortHandler={sortHandler}
        tableData={{
          headers: FEAndBEHeadersData,
          data: paginationTableData,
        }}
      />
    );

    const phoneColumn = screen.getByRole("columnheader", { name: "Phone" });
    await user.click(phoneColumn);
    expect(sortHandler).toHaveBeenCalledTimes(1);

    const firstNameColumn = screen.getByRole("columnheader", {
      name: "First Name",
    });
    await user.click(firstNameColumn);
    expect(sortHandler).toHaveBeenCalledTimes(2);
  });

  it("pagination should work correctly for frontend", async () => {
    const { container, user } = render(
      <Table
        {...defaultProps}
        dataHandling="frontend"
        initialSort={{
          columnKey: "phone",
          order: "ascending",
        }}
        paginationProps={{
          pageSizeList: [10, 20, 30, 40, 99999],
          // activePageNo: 1,
          defaultPageSize: 20,
        }}
        tableData={{
          headers: FEAndBEHeadersData,
          data: paginationTableData,
        }}
      />
    );

    const pageNo = screen.getByRole("textbox");
    let nextPage = screen.getByText(/chevron_right/i);
    expect(pageNo.getAttribute("value") === "1").toBeTruthy();

    await user.click(nextPage);

    nextPage = screen.getByText(/chevron_right/i);
    expect(pageNo.getAttribute("value") === "2").toBeTruthy();

    await user.click(nextPage);
    nextPage = screen.getByText(/chevron_right/i);

    expect(pageNo.getAttribute("value") === "3").toBeTruthy();

    let prevPage = screen.getByText(/chevron_left/i);
    await user.click(prevPage);

    expect(pageNo.getAttribute("value") === "2").toBeTruthy();

    prevPage = screen.getByText(/chevron_left/i);
    await user.click(prevPage);

    expect(pageNo.getAttribute("value") === "1").toBeTruthy();

    const pageSizeDropdown = container.querySelector('[class$="singleValue"]');
    expect(pageSizeDropdown?.innerHTML === "20").toBeTruthy();
  });

  it("pagination should work correctly for backend", async () => {
    const onPageChange = jest.fn();
    const onPageSizeChange = jest.fn();
    const { container, user } = render(
      <Table
        {...defaultProps}
        dataHandling="backend"
        initialSort={{
          columnKey: "phone",
          order: "ascending",
        }}
        paginationProps={{
          pageSizeList: [10, 20, 30, 40, 99999],
          activePageNo: 1,
          defaultPageSize: 20,
          onPageChange,
          onPageSizeChange,
        }}
        tableData={{
          headers: FEAndBEHeadersData,
          data: paginationTableData,
        }}
      />
    );

    const nextPage = screen.getByText(/chevron_right/i);
    await user.click(nextPage);

    expect(onPageChange).toHaveBeenCalledTimes(1);

    const prevPage = screen.getByText(/chevron_left/i);
    await user.click(prevPage);

    expect(onPageChange).toHaveBeenCalledTimes(2);

    const pageSizeDropdown = container.querySelector('[class$="singleValue"]');
    expect(pageSizeDropdown?.innerHTML === "20").toBeTruthy();

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText("99999")).toBeInTheDocument();
    await user.click(screen.getByText("99999"));
    expect(onPageSizeChange).toHaveBeenCalledTimes(1);
  });

  it("checkbox selection should work correctly", async () => {
    const { user } = render(
      <Table {...defaultProps} disablePagination showSelectAll />
    );

    const selectCheckboxes: HTMLInputElement[] =
      screen.getAllByLabelText("select row");
    expect(selectCheckboxes).toHaveLength(5);
    expect(selectCheckboxes[0]?.checked).toBe(false);
    expect(selectCheckboxes[1]?.checked).toBe(false);
    expect(selectCheckboxes[2]?.checked).toBe(false);
    expect(selectCheckboxes[3]?.checked).toBe(false);
    expect(selectCheckboxes[4]?.checked).toBe(false);

    const selectAllCheckbox = screen.getByRole("checkbox", {
      name: "select all",
    });

    await user.click(selectAllCheckbox);

    const selectCheckboxes2: HTMLInputElement[] =
      screen.getAllByLabelText("select row");

    expect(selectCheckboxes2[0]?.checked).toBe(true);
    expect(selectCheckboxes2[1]?.checked).toBe(true);
    expect(selectCheckboxes2[2]?.checked).toBe(true);
    expect(selectCheckboxes2[3]?.checked).toBe(true);
    expect(selectCheckboxes2[4]?.checked).toBe(true);
  });

  it("should render empty state with applied filters correctly and there is no results", async () => {
    render(
      <Table
        {...defaultProps}
        filtersCount={1}
        showSelectAll
        tableData={{
          headers: defaultHeadersData,
          data: [],
        }}
      />
    );

    expect(await screen.findByText("No hay resultados")).toBeInTheDocument();
  });

  it("should render button menu section when massiveActions is passed", () => {
    render(
      <Table
        {...defaultProps}
        massiveActions={{ options: [{ text: "Item 1", onSelect: jest.fn() }] }}
      />
    );

    expect(screen.getByText(/Selecciona una opción/i)).toBeInTheDocument();
  });

  it("should call maassive action button menu item onSelect when click on it", async () => {
    const onSelect = jest.fn();

    const { user } = render(
      <Table
        {...defaultProps}
        massiveActions={{ options: [{ text: "Item 1", onSelect }] }}
      />
    );

    const buttonMenu = screen.getByText(/Selecciona una opción/i);

    await user.click(buttonMenu);

    const item = screen.getByText(/item 1/i);

    await user.click(item);

    expect(onSelect).toHaveBeenCalledWith([]);
  });

  it("should render filters section when onFilterClick  is passed", () => {
    const { container } = render(
      <Table {...defaultProps} onFilterClick={jest.fn()} />
    );

    expect(container.getElementsByTagName("section").length).toBe(1);
    expect(screen.getByText(/Filtros/i)).toBeInTheDocument();
  });
});
