import styled from "styled-components";

export const Table = styled.table`
  border-collapse: collapse;
  position: relative;
  font-family: ${({ theme }) => theme.font.fontFamily};
  width: 100%;
  table-layout: fixed;
  overflow: scroll;
`;

export const EmptyStateWrapper = styled.div`
  margin-top: ${({ theme }) => theme.spacing.x64};
  margin-bottom: ${({ theme }) => theme.spacing.x64};
`;
