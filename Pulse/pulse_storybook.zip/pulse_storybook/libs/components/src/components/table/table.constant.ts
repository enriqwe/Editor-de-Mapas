export const SortDirection = {
  ASCENDING: "ascending",
  DESCENDING: "descending",
} as const;

export const DataHandling = {
  FRONTEND: "frontend",
  BACKEND: "backend",
} as const;
