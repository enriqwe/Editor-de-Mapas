import type { SortingProps, TableBELogicProps } from "./table.types";

export function TableBELogic(props: TableBELogicProps) {
  const {
    sortHandler,
    updateSortDescriptor,
    onPageChange,
    onPageSizeChange,
    updateActivePage,
    updatePageSize,
  } = props;

  const sort = (sortDescriptor: SortingProps) => {
    sortHandler(sortDescriptor);
    updateSortDescriptor(sortDescriptor);
  };

  const pageChangeHandler = (pageNumber: number) => {
    onPageChange(pageNumber);
    updateActivePage(pageNumber);
  };

  const pageSizeChangeHandler = (pageSize: number) => {
    onPageSizeChange(pageSize);
    updatePageSize(pageSize);
  };

  return {
    sort: (sortDescriptor: SortingProps) => {
      sort(sortDescriptor);
    },
    onPageChange: (pageNumber: number) => {
      pageChangeHandler(pageNumber);
    },
    onPageSizeChange: (pageSize: number) => {
      pageSizeChangeHandler(pageSize);
    },
  };
}
