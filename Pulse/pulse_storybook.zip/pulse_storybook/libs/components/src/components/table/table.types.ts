import type { Key } from "react";
import type { Selection } from "react-stately";

import type { DataHandling } from "./table.constant";

import type { Locale } from "@providers/translation";

export type HeaderProps = {
  key: string;
  label: string;
  sortable?: boolean;
};

export type SortingProps = {
  columnKey: Key;
  order: "ascending" | "descending";
};

export type TableContentProps = {
  ariaLabel?: string;
  headers: HeaderProps[];
  rowsData: any[];
  sortDescriptor: SortingProps;
  onSort: (sortDescriptor: SortingProps) => void;
  showSelectAll?: boolean;
  disabledKeys?: any[];
  selectedKeys?: Selection;
  setSelectedKeys?: (val: Selection) => void;
  appliedFilters: boolean;
};

export type TableProps = {
  dataHandling?: (typeof DataHandling)[keyof typeof DataHandling];
  ariaLabel?: string;
  disablePagination?: boolean;
  tableData: {
    headers: HeaderProps[];
    data: any[];
  };
  paginationProps?: {
    totalRecords?: number;
    activePageNo?: number;
    defaultPageSize?: number;
    pageSizeList?: number[];
    onPageChange?: (pageNumber: number) => void;
    onPageSizeChange?: (pageSize: number) => void;
  };
  initialSort?: SortingProps;
  sortHandler?: (sortDescriptor: SortingProps) => void;
  automationContext?: string;
  loading?: boolean;
  massiveActions?: {
    options: {
      text: string;
      onSelect: (selectedKeys?: (string | number)[]) => void;
    }[];
  };
  filtersCount?: number;
  onFilterClick?: () => void;
  showSelectAll?: boolean;
  selectedRows?: (rows: any[]) => void;
  locale?: Locale;
};

type TableLogicProps = {
  pageSize: number;
  updatePageSize: (pageSize: number) => void;
  updateActivePage: (pageNumber: number) => void;
};

export type TableFELogicProps = {
  totalData: any[];
  getPageData: (data: any[], activePage: number, pageSize: number) => any[];
  updateSortDescriptor: (sortDescriptor: SortingProps) => void;
  updateRowsData: (items: any[]) => void;
} & TableLogicProps;

export type TableBELogicProps = {
  sortHandler: (sortDescriptor: SortingProps) => void;
  updateSortDescriptor: (sortDescriptor: SortingProps) => void;
  onPageChange: (pageNumber: number) => void;
  onPageSizeChange: (pageNumber: number) => void;
} & TableLogicProps;
