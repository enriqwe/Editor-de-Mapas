import { screen } from "@testing-library/react";

import { CheckboxGroup } from "./checkbox-group";

import { render } from "@test-utils";

describe("checkboxGroup", () => {
  it("should render properly [default state]", () => {
    render(
      <CheckboxGroup.Group label="Favorite sports">
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
        <CheckboxGroup.Item value="basketball">Basketball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    expect(screen.getByText("Soccer")).toBeTruthy();
    expect(screen.getByText("Baseball")).toBeTruthy();
    expect(screen.getByText("Basketball")).toBeTruthy();
    expect(screen.getByText("Favorite sports")).toBeTruthy();
  });

  it("should uncheck when click on the checkbox", async () => {
    const { user } = render(
      <CheckboxGroup.Group label="Favorite sports">
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
        <CheckboxGroup.Item value="basketball">Basketball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    const checkbox = screen.getByRole("checkbox", {
      checked: false,
      name: "Soccer",
    });

    await user.click(checkbox);
    expect(checkbox).toBeChecked();

    await user.click(checkbox);
    expect(checkbox).not.toBeChecked();
  });
  it("should check when checkbox is not disabled", async () => {
    const { user } = render(
      <CheckboxGroup.Group label="Favorite sports" orientation="horizontal">
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    expect(screen.getByText("Favorite sports")).toBeTruthy();
    const checkboxBaseball = screen.getByRole("checkbox", {
      checked: false,
      name: "Baseball",
    });
    await user.click(checkboxBaseball);
    expect(checkboxBaseball).toBeChecked();
    expect(checkboxBaseball).not.toBeDisabled();
  });

  it("should description and error message displayed successfully", () => {
    render(
      <CheckboxGroup.Group
        aria-label="Favorite sports"
        description="description text"
        errorMessage="error message text"
      >
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
        <CheckboxGroup.Item value="basketball">Basketball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    expect(screen.getByText("description text")).toBeTruthy();
    expect(screen.getByText("error message text")).toBeTruthy();
  });
  it("should disable all checkbox items of group", () => {
    render(
      <CheckboxGroup.Group
        aria-label="Favorite sports"
        description="description text"
        errorMessage="error message text"
        isDisabled
      >
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
        <CheckboxGroup.Item value="basketball">Basketball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    const checkboxBaseball = screen.getByRole("checkbox", {
      checked: false,
      name: "Baseball",
    });
    expect(checkboxBaseball).toHaveAttribute("disabled");
    const checkboxSoccer = screen.getByRole("checkbox", {
      checked: false,
      name: "Soccer",
    });
    expect(checkboxSoccer).toHaveAttribute("disabled");
    const checkboxBasketball = screen.getByRole("checkbox", {
      checked: false,
      name: "Basketball",
    });
    expect(checkboxBasketball).toHaveAttribute("disabled");
  });
  it("should render asterisk when checkbox group is required", () => {
    render(
      <CheckboxGroup.Group
        description="description text"
        errorMessage="error message text"
        isRequired
        label="Favorite sports"
      >
        <CheckboxGroup.Item value="soccer">Soccer</CheckboxGroup.Item>
        <CheckboxGroup.Item value="baseball">Baseball</CheckboxGroup.Item>
        <CheckboxGroup.Item value="basketball">Basketball</CheckboxGroup.Item>
      </CheckboxGroup.Group>
    );
    expect(screen.getByText(/\*/i)).toBeTruthy();
  });
});
