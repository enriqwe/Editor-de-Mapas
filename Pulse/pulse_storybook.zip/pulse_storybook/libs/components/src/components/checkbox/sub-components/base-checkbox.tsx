import type {
  CheckboxAria,
  AriaCheckboxProps,
  FocusRingAria,
} from "react-aria";
import type { InputHTMLAttributes } from "react";

import * as S from "./base-checkbox.styled";

import { Icon } from "@components/icon";

type BaseCheckboxProps = {
  hasError?: boolean;
  onChange: InputHTMLAttributes<HTMLInputElement>["onChange"];
  onClick: InputHTMLAttributes<HTMLInputElement>["onClick"];
  onMouseDown: InputHTMLAttributes<HTMLInputElement>["onMouseDown"];
  onPointerDown: InputHTMLAttributes<HTMLInputElement>["onPointerDown"];
  onPointerUp: InputHTMLAttributes<HTMLInputElement>["onPointerUp"];
  isDisabled: AriaCheckboxProps["isDisabled"];
  isIndeterminate: AriaCheckboxProps["isIndeterminate"];
  isFocusVisible: FocusRingAria["isFocusVisible"];
  isSelected: CheckboxAria["isSelected"];
};

function FillIcon({
  isIndeterminate,
  isSelected,
}: {
  isIndeterminate: boolean;
  isSelected: boolean;
  isDisabled: boolean;
}) {
  if (isIndeterminate)
    return <Icon color="inherit" icon="check_indeterminate_small" size="s" />;
  else if (isSelected)
    return <Icon color="inherit" icon="check_small" size="s" />;

  return null;
}

export function BaseCheckbox({
  isIndeterminate = false,
  isDisabled = false,
  isSelected,
  hasError = false,
  isFocusVisible,
  onChange,
  onClick,
  onMouseDown,
  onPointerDown,
  onPointerUp,
}: BaseCheckboxProps) {
  return (
    <S.CheckBoxIcon
      $hasError={hasError}
      $isDisabled={isDisabled}
      $isFocusVisible={isFocusVisible}
      $isIndeterminate={isIndeterminate}
      $isSelected={isSelected && !isIndeterminate}
      onChange={onChange}
      onClick={onClick}
      onMouseDown={onMouseDown}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
    >
      <FillIcon
        isDisabled={isDisabled}
        isIndeterminate={isIndeterminate}
        isSelected={isSelected}
      />
    </S.CheckBoxIcon>
  );
}
