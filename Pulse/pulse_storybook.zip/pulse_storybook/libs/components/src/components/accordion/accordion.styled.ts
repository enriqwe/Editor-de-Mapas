import styled from "styled-components";

export const AccordionContainer = styled.div<{
  $isExpanded?: boolean;
  stroke?: string;
}>`
  ${({ stroke, theme }) =>
    stroke === "ALL" ?
      {
        border: `${theme.border.widthXS} solid ${theme.color.borderDefault}`,
        borderRadius: theme.border.radiusM,
      }
    : {
        borderBottom: `${theme.border.widthXS} solid ${theme.color.borderDefault}`,
        borderRadius: `${theme.border.radiusM} ${theme.border.radiusM} 0 0 `,
      }}
  ${({ $isExpanded, stroke, theme }) => {
    if ($isExpanded && stroke === "ALL") {
      return {
        border: `${theme.border.widthXS} solid ${theme.color.borderBrandSelected}`,
        borderRadius: theme.border.radiusM,
      };
    }
  }};
`;

export const AccordionHeader = styled.div<{
  $isExpanded?: boolean;
}>`
  display: flex;
  padding: ${({ theme }) => theme.spacing.x16};
  cursor: pointer;
  user-select: none;

  &:hover {
    background: ${({ theme }) => theme.color.bgAccordionHover};
    border-radius: ${({ theme, $isExpanded }) =>
      $isExpanded ?
        `${theme.border.radiusM} ${theme.border.radiusM} 0 0`
      : theme.border.radiusM};
  }
`;

export const Number = styled.div<{
  $isExpanded: boolean;
}>`
  box-sizing: border-box;

  border-radius: ${({ theme }) => theme.border.radiusCircle};
  overflow: hidden;
  user-select: none;
  height: 24px;
  width: 24px;
  ${({ theme }) => theme.text.bodyBaseBold};

  text-align: center;
  margin-right: ${({ theme }) => theme.spacing.x8};
  color: ${({ theme, $isExpanded }) =>
    $isExpanded ? theme.color.textInverse : theme.color.textBody};
  background-color: ${({ theme, $isExpanded }) =>
    $isExpanded ? theme.color.bgBrandDefault : theme.color.bgInfo};
`;

export const LabelGroup = styled.div`
  display: flex;
  flex-direction: column;
  margin-right: auto;
`;

export const AccordionLabel = styled.h3`
  margin: 0;
  color: ${({ theme }) => theme.color.textHeading};
  ${({ theme }) => theme.text.bodyLeadSemiBold};
`;

export const AccordionSubLabel = styled.p`
  margin: 0;
  color: ${({ theme }) => theme.color.textSubheading};
  ${({ theme }) => theme.text.bodyMediumRegular};
`;

export const AccordionContent = styled.div`
  ${({ theme }) => theme.text.bodyBaseRegular};
  padding: ${({ theme }) => `0 ${theme.spacing.x16} ${theme.spacing.x32}`};
`;

export const ExpandIconContainer = styled.div`
  padding-top: ${({ theme }) => theme.spacing.x2};
`;

export const Tag = styled.div`
  padding: 0 ${({ theme }) => theme.spacing.x12};
`;
