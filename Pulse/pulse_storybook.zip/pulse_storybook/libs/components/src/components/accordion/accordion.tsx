import type { ReactElement } from "react";
import React, { useRef, useState } from "react";

import * as S from "./accordion.styled";

import { Icon } from "@components/icon";
import { StaticTag } from "@components/tag";
import { automationClass } from "@utils/automation-class";

type Tag = React.ComponentProps<typeof StaticTag>;

export type AccordionProps = {
  label: string;
  content: string | ReactElement;
  subLabel?: string | ReactElement;
  accordionNumber?: string | number;
  automationContext?: string;
  initialExpanded?: boolean;
  stroke?: "ALL" | "BOTTOM";
  tag?: Omit<Tag, "size" | "automationContext">;
};

export function Accordion({
  label,
  subLabel,
  content,
  tag,
  accordionNumber,
  automationContext,
  stroke = "BOTTOM",
  initialExpanded = false,
}: AccordionProps) {
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const ref = useRef<HTMLDivElement>(null);

  const automationClasses = automationClass("accordion", automationContext);

  const toggleAccordion = () => {
    setIsExpanded(!isExpanded);

    if (ref.current) {
      ref.current.focus();
    }
  };

  return (
    <S.AccordionContainer
      $isExpanded={isExpanded}
      className={automationClasses}
      ref={ref}
      stroke={stroke}
    >
      <S.AccordionHeader $isExpanded={isExpanded} onClick={toggleAccordion}>
        {accordionNumber && (
          <S.Number $isExpanded={isExpanded}>{accordionNumber}</S.Number>
        )}
        <S.LabelGroup>
          <S.AccordionLabel>{label}</S.AccordionLabel>
          {subLabel && <S.AccordionSubLabel>{subLabel}</S.AccordionSubLabel>}
        </S.LabelGroup>
        <S.Tag>
          {tag && (
            <StaticTag
              {...tag}
              automationContext={`accordion-${automationContext}`}
              size="large"
            />
          )}
        </S.Tag>
        <S.ExpandIconContainer>
          <Icon icon={isExpanded ? "expand_less" : "expand_more"} />
        </S.ExpandIconContainer>
      </S.AccordionHeader>
      {isExpanded && <S.AccordionContent>{content}</S.AccordionContent>}
    </S.AccordionContainer>
  );
}
