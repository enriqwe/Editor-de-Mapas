import { screen } from "@testing-library/react";

import { Accordion } from "./accordion";

import { render } from "@test-utils";

describe("accordion", () => {
  it("should only show label by default", () => {
    render(
      <Accordion
        accordionNumber="A1"
        content="hidden content!"
        label="click to show content"
      />
    );

    expect(screen.getByText("click to show content")).toBeInTheDocument();
    expect(screen.getByText("expand_more")).toBeInTheDocument();
    expect(screen.queryByText("hidden content!")).not.toBeInTheDocument();
    expect(screen.getByText("A1")).toBeInTheDocument();
  });

  it("should show hidden content when clicking accordion", async () => {
    const { user } = render(
      <Accordion content="hidden content!" label="click to show content" />
    );
    const accordion = screen.getByText("click to show content");

    await user.click(accordion);

    expect(screen.getByText("hidden content!")).toBeInTheDocument();
  });

  it("should render subLabel when subLabel prop is passed", () => {
    render(
      <Accordion
        content="hidden content!"
        label="click to show content"
        subLabel="subLabel!"
      />
    );
    const subLabel = screen.getByText("subLabel!");

    expect(subLabel).toBeInTheDocument();
  });

  it("should render accordion number and hidden content when initialExpanded is true", () => {
    render(
      <Accordion
        accordionNumber="A1"
        content="hidden content!"
        initialExpanded
        label="click to show content"
        stroke="ALL"
        subLabel="subLabel!"
      />
    );

    expect(screen.getByText("hidden content!")).toBeInTheDocument();
    expect(screen.getByText("A1")).toBeInTheDocument();
    expect(screen.getByText("expand_less")).toBeInTheDocument();
  });
});
