import type { PropsWithChildren } from "react";

import type { StaticTagProps } from "@components/tag";
import type { IconButtonProps } from "@components/icon-button";

type PartialStaticProps = Omit<StaticTagProps, "size">;

export type CardProps = PropsWithChildren<{
  icon?: string;
  title: string;
  description?: string;
  tag?: PartialStaticProps;
  actions?: IconButtonProps[];
  automationContext?: string;
}>;
