import * as S from "./card.styled";
import type { CardProps } from "./card.types";

import { Icon } from "@components/icon";
import { IconButton } from "@components/icon-button";
import { StaticTag } from "@components/tag";
import { automationClass } from "@utils/automation-class";

export function Card({
  icon,
  title,
  description,
  tag,
  actions = [],
  children,
  automationContext,
}: CardProps) {
  const automationClasses = automationClass("card", automationContext);

  return (
    <S.Card className={automationClasses}>
      <S.Header>
        {icon && <Icon icon={icon} />}

        <S.TextContainer>
          <S.Title>{title}</S.Title>
          {description && <S.Description>{description}</S.Description>}
        </S.TextContainer>
        {tag && <StaticTag {...tag} size="large" />}

        {actions.length > 0 && (
          <S.Actions data-testid="actions-container">
            {actions.map(({ onPress, ...actionProps }) => (
              <IconButton
                onPress={onPress}
                {...actionProps}
                key={actionProps.iconName}
              />
            ))}
          </S.Actions>
        )}
      </S.Header>
      <S.Content>{children}</S.Content>
    </S.Card>
  );
}
