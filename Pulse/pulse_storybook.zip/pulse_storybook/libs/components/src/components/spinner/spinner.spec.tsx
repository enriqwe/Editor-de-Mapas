import { screen } from "@testing-library/react";

import { Spinner } from "./spinner";

import { render } from "@test-utils";

describe("spinner", () => {
  it("should render properly [default state]", () => {
    const { baseElement } = render(<Spinner size="sm" />);
    expect(baseElement).toBeTruthy();
  });

  it("should render properly [XL + text]", () => {
    render(<Spinner helperText="HelperTextTest" size="xl" />);
    const helpLabel = screen.getAllByText("HelperTextTest");
    expect(helpLabel).toBeTruthy();
  });
});
