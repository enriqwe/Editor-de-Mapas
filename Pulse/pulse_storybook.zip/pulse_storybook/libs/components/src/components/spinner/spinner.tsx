import { SpinnerIcon } from "./sub-components/spinner-icon";
import * as S from "./spinner.styled";

import { automationClass } from "@utils/automation-class";

type SpinnerProps = {
  size: "sm" | "md" | "lg" | "xl" | "xxl";
  helperText?: string;
  automationContext?: string;
  variant?: "dark" | "light";
};

export function Spinner({
  size,
  helperText,
  automationContext,
  variant = "dark",
}: SpinnerProps) {
  const automationClasses = automationClass("spinner", automationContext);

  return (
    <S.Wrapper className={automationClasses} data-testid="spinner">
      <SpinnerIcon size={size} variant={variant} />
      {helperText && <S.Text $variant={variant}>{helperText}</S.Text>}
    </S.Wrapper>
  );
}
