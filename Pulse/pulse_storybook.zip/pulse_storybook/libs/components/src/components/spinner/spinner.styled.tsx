import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
`;

export const Text = styled.label<{ $variant: string }>`
  font: ${cssVars.text.bodyBaseBold};
  margin-top: ${cssVars.spacing.x16};
  color: ${({ $variant }) =>
    $variant === "light" ?
      cssVars.color.textInverse
    : cssVars.color.textHeading};
`;
