import styled from "styled-components";

import type {
  StaticSizeProps,
  VariantDynamicProps,
  VariantStaticProps,
} from "./tag.types";

const Tag = styled.div<{ tooltip?: boolean; $size?: StaticSizeProps }>`
  border-radius: ${({ theme }) => theme.border.radiusL};
  ${({ tooltip }) => !tooltip && "display: inline-flex;"}
  ${({ tooltip }) => !tooltip && "align-items: center;"}
`;

export const StaticTag = styled(Tag)<{
  $variant: VariantStaticProps;
  $tooltip?: boolean;
  $size?: StaticSizeProps;
}>`
  ${({ theme, $variant }) => {
    let color;
    let background;
    switch ($variant) {
      case "pending":
        color = theme.color.textPending;
        background = theme.color.bgPending;
        break;
      case "success":
        color = theme.color.textSuccess;
        background = theme.color.bgSuccess;
        break;
      case "warning":
        color = theme.color.textWarning;
        background = theme.color.bgWarning;
        break;
      case "error":
        color = theme.color.textError;
        background = theme.color.bgError;
        break;
      case "informative":
        color = theme.color.textInfo;
        background = theme.color.bgInfo;
        break;
      case "tip":
        color = theme.color.textTips;
        background = theme.color.bgTips;
        break;
    }
    return `
      color: ${color};
      background-color: ${background};
    `;
  }}

  padding: ${({ theme }) => `${theme.spacing.x4} ${theme.spacing.x12}`};
  text-align: center;
  ${({ $tooltip }) => !$tooltip && "pointer-events: none;"}
  text-decoration: ${({ $size }) => ($size === "large" ? "none" : "uppercase")};
`;

export const StaticText = styled.p<{ $size: StaticSizeProps }>`
  margin: 0;
  ${({ $size }) =>
    $size === "large" &&
    `&::first-letter {
          text-transform: capitalize;
      }`}
  text-transform: ${({ $size }) =>
    $size === "small" ? "uppercase" : "lowercase"};
  ${({ theme, $size }) =>
    $size === "large" ?
      theme.text.bodyMediumSemiBold
    : theme.text.bodySmallSemiBold};
`;

export const DynamicTag = styled(Tag)<{
  $variant: VariantDynamicProps;
  disabled: boolean;
}>`
  padding: ${({ theme }) => `${theme.spacing.x4} ${theme.spacing.x8}`};
  text-align: start;
  pointer-events: ${({ disabled }) => (disabled ? "none" : "auto")};
  gap: ${({ theme }) => theme.spacing.x4};
  color: ${({ theme, disabled }) =>
    disabled ? theme.color.textDisabled : theme.color.textHelpertext};
  background-color: ${({ theme, $variant, disabled }) =>
    disabled ?
      theme.color.bgDisabled
    : theme.color.background.tagDynamic[$variant]};
  ${({ theme, disabled, $variant }) =>
    !disabled &&
    `&:hover {
      box-shadow: inset 0px 0px 0px 1.5px  ${
        $variant === "default" ?
          theme.color.border.tagDynamic.hover
        : theme.color.border.tagDynamic.deletedHover
      };
    path {
      fill:
        ${
          $variant === "default" ?
            theme.color.icon.tagDynamic.hover
          : theme.color.icon.tagDynamic.deletedHover
        };
    }
  } `}
`;

export const TagText = styled.p`
  ${({ theme }) => theme.text.bodyMediumRegular}
  margin: 0;
`;
