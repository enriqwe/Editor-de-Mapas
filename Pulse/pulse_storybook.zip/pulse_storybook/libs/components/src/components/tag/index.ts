export { StaticTag, DynamicTag } from "./tag";
export type { StaticTagProps, DynamicTagProps } from "./tag.types";
