import { useTheme } from "styled-components";

import * as S from "./tag.styled";
import type { DynamicTagProps, StaticTagProps } from "./tag.types";

import { Icon } from "@components/icon";
import { TextTooltip } from "@components/text-tooltip";
import { automationClass } from "@utils/automation-class";

export function StaticTag({
  label,
  size,
  variant,
  tooltip = false,
  automationContext,
}: StaticTagProps) {
  const automationClasses = automationClass("staticTag", automationContext);
  return (
    <S.StaticTag
      $size={size}
      $variant={variant}
      className={automationClasses}
      data-testid="static-tag"
      {...(tooltip && { $tooltip: true })}
    >
      <S.StaticText $size={size}>
        {tooltip ?
          <TextTooltip automationContext={automationContext ?? "tag"}>
            {label}
          </TextTooltip>
        : label}
      </S.StaticText>
    </S.StaticTag>
  );
}

export function DynamicTag({
  label,
  onClick,
  variant,
  disabled = false,
  automationContext,
}: DynamicTagProps) {
  const theme = useTheme();
  const automationClasses = automationClass("dynamicTag", automationContext);

  return (
    <S.DynamicTag
      $variant={variant}
      className={automationClasses}
      disabled={disabled}
      onClick={onClick}
    >
      <S.TagText>{label}</S.TagText>
      <Icon
        color={
          disabled ?
            theme.color.icon.disabled
          : theme.color.icon.tagDynamic[variant]
        }
        icon="close"
        size="xs"
      />
    </S.DynamicTag>
  );
}
