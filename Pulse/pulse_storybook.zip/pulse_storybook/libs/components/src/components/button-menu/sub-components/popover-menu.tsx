import { useMenuTriggerState } from "react-stately";
import { useRef } from "react";
import { useButton, useMenuTrigger } from "react-aria";

import * as S from "../button-menu.styled";
import type {
  ButtonMenuItemProps,
  PopoverMenuProps,
} from "../button-menu.types";

import { ButtonMenuContainer } from "./button-menu-container";

import { Popover } from "@components/internal/popover";
import { Icon } from "@components/icon";

const POPOVER_PLACEMENT: Record<string, "bottom left" | "bottom right"> = {
  left: "bottom left",
  right: "bottom right",
  stretch: "bottom left",
};

function PopoverMenu(props: PopoverMenuProps<ButtonMenuItemProps>) {
  const { automationClasses, disabled, label, placement, variant } = props;
  const state = useMenuTriggerState(props);
  const MenuTriggerRef = useRef(null);
  const { menuTriggerProps, menuProps } = useMenuTrigger<ButtonMenuItemProps>(
    { isDisabled: disabled },
    state,
    MenuTriggerRef
  );
  const { buttonProps } = useButton({ ...menuTriggerProps }, MenuTriggerRef);

  return (
    <S.PopoverMenu $placement={placement}>
      <S.Button
        {...buttonProps}
        $placement={placement}
        $variant={variant}
        className={automationClasses}
        disabled={disabled}
        ref={MenuTriggerRef}
      >
        {label}
        <Icon icon={state.isOpen ? "expand_less" : "expand_more"} />
      </S.Button>
      {state.isOpen ?
        <Popover
          placement={POPOVER_PLACEMENT[placement]}
          state={state}
          triggerRef={MenuTriggerRef}
        >
          <ButtonMenuContainer {...props} {...menuProps} />
        </Popover>
      : null}
    </S.PopoverMenu>
  );
}

export { PopoverMenu };
