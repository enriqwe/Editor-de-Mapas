import styled, { css } from "styled-components";

import type {
  ButtonMenuPlacement,
  ButtonMenuVariant,
} from "./button-menu.types";

type ButtonProps = {
  $justifyContent?: string;
  $oneItem?: boolean;
  $padding?: string;
  $placement: ButtonMenuPlacement;
  $variant: ButtonMenuVariant;
};

const outline = css`
  outline-offset: 2px;
  outline: 2px solid ${({ theme }) => theme.color.border.button.focus};
`;

const filledStyles = css`
  background: ${({ theme }) => theme.color.background.buttonMenu.default};
  color: ${({ theme }) => theme.color.text.buttonMenu.filled};

  span:last-child {
    color: ${({ theme }) => theme.color.text.buttonMenu.filled};
  }

  &:hover:not(:disabled) {
    background: white;
    color: ${({ theme }) => theme.color.text.buttonMenu.hover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.buttonMenu.hover};
    }
  }

  &:active:not(:disabled) {
    background: ${({ theme }) => theme.color.background.buttonMenu.default};
    color: ${({ theme }) => theme.color.text.pressed};
    outline: none;

    span:last-child {
      color: ${({ theme }) => theme.color.text.pressed};
    }
  }

  &:focus {
    background: white;
    color: ${({ theme }) => theme.color.text.buttonMenu.hover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.buttonMenu.hover};
    }

    ${outline}
  }

  &:disabled {
    background: ${({ theme }) => theme.color.background.disabled};

    span:last-child {
      color: ${({ theme }) => theme.color.text.disabled};
    }
  }
`;

const flatStyles = css`
  background: white;
  color: ${({ theme }) => theme.color.text.buttonMenu.filled};

  span:last-child {
    color: ${({ theme }) => theme.color.text.buttonMenu.filled};
  }

  &:hover:not(:disabled) {
    background: ${({ theme }) => theme.color.background.button.tertiaryHover};
    color: ${({ theme }) => theme.color.text.buttonMenu.hover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.buttonMenu.hover};
    }
  }

  &:active:not(:disabled) {
    background: white;
    color: ${({ theme }) => theme.color.text.pressed};
    outline: none;

    span:last-child {
      color: ${({ theme }) => theme.color.text.pressed};
    }
  }

  &:focus {
    background: ${({ theme }) => theme.color.background.button.tertiaryHover};
    color: ${({ theme }) => theme.color.text.button.tertiaryHover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.button.tertiaryHover};
    }

    ${outline}
  }

  &:disabled {
    background: ${({ theme }) => theme.color.background.disabled};

    span:last-child {
      color: ${({ theme }) => theme.color.text.disabled};
    }
  }
`;

const outlineStyles = css`
  background: white;
  color: ${({ theme }) => theme.color.text.buttonMenu.filled};
  border: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.border.button.secondary}`};

  span:last-child {
    color: ${({ theme }) => theme.color.text.buttonMenu.filled};
  }

  &:hover:not(:disabled) {
    background: ${({ theme }) => theme.color.background.button.secondaryHover};
    color: ${({ theme }) => theme.color.text.buttonMenu.hover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.buttonMenu.hover};
    }
  }

  &:active:not(:disabled) {
    background: white;
    color: ${({ theme }) => theme.color.text.pressed};
    outline: none;

    span:last-child {
      color: ${({ theme }) => theme.color.text.pressed};
    }
  }

  &:focus {
    background: ${({ theme }) => theme.color.background.button.secondaryHover};
    color: ${({ theme }) => theme.color.text.button.secondaryHover};

    span:last-child {
      color: ${({ theme }) => theme.color.text.button.secondaryHover};
    }

    ${outline}
  }

  &:disabled {
    background: ${({ theme }) => theme.color.background.disabled};
    border: ${({ theme }) =>
      `${theme.border.widthXS} solid ${theme.color.border.disabled}`};

    span:last-child {
      color: ${({ theme }) => theme.color.text.disabled};
    }
  }
`;

const variantStyles = (variant: ButtonMenuVariant) =>
  ({
    filled: filledStyles,
    flat: flatStyles,
    outline: outlineStyles,
  })[variant];

export const Item = styled.li<{ $isFocusVisible: boolean }>`
  /* outline: ${({ $isFocusVisible, theme }) =>
    $isFocusVisible ?
      `${theme.color.border.button.focus} auto 1px`
    : "none"}; */
  display: flex;
  cursor: pointer;
  align-items: center;
  padding: ${({ theme }) => theme.spacing.x12};
  gap: ${({ theme }) => theme.spacing.x8};
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-weight: ${({ theme }) => theme.font.weights.regular};
  font-size: ${({ theme }) => theme.font.sizes.m.fontSize};

  &:hover {
    background: ${({ theme }) => theme.color.background.default};
  }

  &:focus,
  &:focus-visible {
    border-radius: ${({ theme }) => theme.border.radiusS};
    outline: ${({ theme }) => `${theme.color.border.button.focus} auto 1px`};
  }
`;

export const Group = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  overflow: auto;
  min-width: 200px;

  &:focus,
  &:focus-visible {
    border-radius: ${({ theme }) => theme.border.radiusS};
    outline: ${({ theme }) => theme.color.border.button.focus} auto 1px;
  }
`;

export const GroupTitle = styled.span`
  display: block;
  margin-top: ${({ theme }) => theme.spacing.x8};
  padding: 0 ${({ theme }) => theme.spacing.x12};
  ${({ theme }) => theme.spacing.x8};
  font-family: ${({ theme }) => theme.font.fontFamily};
  font-weight: ${({ theme }) => theme.font.weights.semibold};
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  text-transform: uppercase;
`;

export const GroupSeparator = styled.li`
  border-top: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.border.divider.default}`};
  margin: ${({ theme }) => `${theme.spacing.x4} ${theme.spacing.x6}`};
`;

export const Button = styled.button<ButtonProps>`
  justify-content: ${({ $placement }) =>
    $placement === "stretch" ? "center" : "space-around"};
  padding: ${({ $oneItem, theme }) =>
    $oneItem ?
      `${theme.spacing.x8} ${theme.spacing.x16}`
    : `${theme.spacing.x8} ${theme.spacing.x8} ${theme.spacing.x8} ${theme.spacing.x16}`};

  display: inline-flex;
  gap: ${({ theme }) => theme.spacing.x4};
  align-items: center;
  justify-content: ${({ $justifyContent }) => $justifyContent};
  height: ${({ theme }) => theme.spacing.x40};
  border: none;
  font-family: ${({ theme }) => theme.font.fontFamily};
  padding: ${({ $padding }) => $padding};
  font-weight: ${({ theme }) => theme.font.weights.semibold};
  font-size: ${({ theme }) => theme.font.sizes.m.fontSize};
  border-radius: ${({ theme }) => theme.border.radiusM};

  &:hover {
    cursor: pointer;
  }

  &:disabled {
    cursor: not-allowed;
    color: ${({ theme }) => theme.color.text.disabled};
  }

  ${({ $variant }) => variantStyles($variant)};
`;

export const PopoverMenu = styled.div<{
  $placement: ButtonMenuPlacement;
}>`
  width: ${({ $placement }) => ($placement === "stretch" ? "200px" : "auto")};
`;
