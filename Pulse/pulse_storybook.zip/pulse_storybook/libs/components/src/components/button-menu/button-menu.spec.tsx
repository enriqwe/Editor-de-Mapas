import { axe, toHaveNoViolations } from "jest-axe";
import { screen } from "@testing-library/react";

import { ButtonMenu } from "./button-menu";
import type { ButtonMenuProps } from "./button-menu.types";

import { render } from "@test-utils";

const defaultProps: Omit<ButtonMenuProps, "children"> = {
  label: "Choose an option",
  automationContext: "",
};

const onClickCallback = jest.fn();

function DefaultButtonMenu(props: Partial<ButtonMenuProps>) {
  return (
    <ButtonMenu.Menu {...defaultProps} {...props}>
      {props.children ? props.children : []}
    </ButtonMenu.Menu>
  );
}

describe("buttonMenu test suit", () => {
  expect.extend(toHaveNoViolations);

  it("should render component correctly", async () => {
    const { container } = render(<DefaultButtonMenu />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
  });

  it("should render popover menu when click on trigger button", async () => {
    const { user, container } = render(
      <DefaultButtonMenu variant="flat">
        <ButtonMenu.Item
          iconLeft="download"
          name="Action item 1"
          onClick={onClickCallback}
        />
        <ButtonMenu.Item
          iconRight="edit"
          name="Action item 2"
          onClick={jest.fn()}
        />
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button");

    await user.click(triggerButton);

    expect(screen.getByText(/Action item 1/i)).toBeInTheDocument();
  });

  it("should render button with first item name when there is just one item", async () => {
    const { container } = render(
      <DefaultButtonMenu variant="outline">
        <ButtonMenu.Item
          iconLeft="download"
          name="Action item 1"
          onClick={onClickCallback}
        />
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();
    expect(screen.getByText(/Action item 1/i)).toBeInTheDocument();
  });

  it("should call onClick callback when click on menu first item", async () => {
    const { container, user } = render(
      <DefaultButtonMenu placement="stretch">
        <ButtonMenu.Item
          iconLeft="download"
          name="Action item 1"
          onClick={onClickCallback}
        />
        <ButtonMenu.Item
          iconRight="edit"
          name="Action item 2"
          onClick={jest.fn()}
        />
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button");

    await user.click(triggerButton);

    const firstItem = screen.getByText(/Action item 1/i);

    await user.click(firstItem);

    expect(onClickCallback).toHaveBeenCalled();
  });

  it("should render popover menu with grouped list when click on trigger button", async () => {
    const { user, container } = render(
      <DefaultButtonMenu>
        <ButtonMenu.Group name="grouped list title">
          <ButtonMenu.Item
            iconLeft="edit"
            name="Action item 1"
            onClick={jest.fn()}
          />
          <ButtonMenu.Item
            iconLeft="delete"
            name="Action item 2"
            onClick={jest.fn()}
          />
        </ButtonMenu.Group>
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button");

    await user.click(triggerButton);

    expect(screen.getByText(/grouped list title/i)).toBeInTheDocument();
  });

  it("should render popover menu with multiple grouped list", async () => {
    const { user, container } = render(
      <DefaultButtonMenu>
        <ButtonMenu.Group name="grouped list 1 title">
          <ButtonMenu.Item
            iconLeft="edit"
            name="Action item 1"
            onClick={jest.fn()}
          />
        </ButtonMenu.Group>
        <ButtonMenu.Group name="grouped list 2 title">
          <ButtonMenu.Item
            iconLeft="edit"
            name="Action item 2"
            onClick={jest.fn()}
          />
          <ButtonMenu.Item
            iconLeft="delete"
            name="Action item 3"
            onClick={jest.fn()}
          />
        </ButtonMenu.Group>
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const triggerButton = screen.getByRole("button");

    await user.click(triggerButton);

    expect(screen.getAllByRole("group").length).toEqual(2);
    expect(screen.getByText(/grouped list 1 title/i)).toBeTruthy();
    expect(screen.getByText(/grouped list 2 title/i)).toBeTruthy();
  });

  it("should render button with first item name when there is just one group with one item", async () => {
    const { container } = render(
      <DefaultButtonMenu variant="outline">
        <ButtonMenu.Group name="grouped list 1 title">
          <ButtonMenu.Item
            iconLeft="download"
            name="Action item 1"
            onClick={onClickCallback}
          />
        </ButtonMenu.Group>
      </DefaultButtonMenu>
    );
    const results = await axe(container);

    expect(results).toHaveNoViolations();
    expect(screen.getByText(/Action item 1/i)).toBeInTheDocument();
  });

  it("should render group", () => {
    render(
      <ButtonMenu.Group name="grouped list 1 title">
        <ButtonMenu.Item iconLeft="edit" name="Action item 1" />
        <ButtonMenu.Item iconLeft="setting" name="Action item 2" />
      </ButtonMenu.Group>
    );
    const groupElement = screen.getByText(/grouped list 1 title/i);
    expect(groupElement).toBeInTheDocument();
  });
});
