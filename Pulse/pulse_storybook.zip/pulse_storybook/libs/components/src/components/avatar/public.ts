export { PublicAvatar as Avatar } from "./avatar";
export type { PublicAvatarProps as AvatarProps } from "./avatar.types";