export type AvatarSize = "s" | "m" | "l";
export type AvatarVariant = "default" | "topbar";

export type AvatarProps = {
  src?: string;
  size?: AvatarSize;
  name?: string;
  automationContext?: string;
  variant: AvatarVariant;
};

export type PublicAvatarProps = Omit<AvatarProps, "variant">;

export type AvatarIconProps = {
  size: AvatarSize;
  name?: string;
};
