import * as S from "./avatar.styled";
import type { AvatarProps, AvatarSize, PublicAvatarProps } from "./avatar.types";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

type IconSizesMap = {
  [key in AvatarSize]: "m" | "s" | "xs";
};

const iconSizesMap: IconSizesMap = {
  s: "xs",
  m: "s",
  l: "m",
};

export function Avatar(props: AvatarProps) {
  const { automationContext, size = "m", name, src, variant } = props;
  const automationClasses = automationClass("avatar", automationContext);

  let internalComponent;
  if (src) {
    internalComponent = <img alt="Avatar" src={src} />;
  } else if (name) {
    internalComponent = <span>{name.slice(0, 1).toUpperCase()}</span>;
  } else {
    internalComponent = <Icon icon="person" size={iconSizesMap[size]} />;
  }

  return (
    <S.Avatar $variant={variant} className={automationClasses} size={size} src={src}>
      {internalComponent}
    </S.Avatar>
  );
}

export function PublicAvatar(props: PublicAvatarProps) {
  return <Avatar {...props} variant="default" />;
}