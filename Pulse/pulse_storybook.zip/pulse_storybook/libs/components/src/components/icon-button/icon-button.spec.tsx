import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import { IconButton } from "./icon-button";

import { render } from "@test-utils";

describe("icon-button", () => {
  expect.extend(toHaveNoViolations);

  it("should render Icon Button", async () => {
    const onPressMock = jest.fn();

    const { user } = render(
      <IconButton iconName="settings" onPress={onPressMock} />
    );

    const button = screen.getByRole("button");
    await user.click(button);

    expect(onPressMock).toHaveBeenCalledTimes(1);
    expect(screen.getByTestId("icon")).toHaveTextContent("settings");
    // expect(screen.getByTestId(/material-icon/i)).toHaveStyle("font-size: 24px");
  });

  it("should have no a11y violations", async () => {
    const { container } = render(
      <IconButton
        aria-label="open settings"
        iconName="settings"
        onPress={jest.fn()}
        tooltipContent="tooltip Text"
      />
    );

    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });

  it("should render properly the tooltip when hover event is active for icon button", async () => {
    const onPressMock = jest.fn();
    const { user } = render(
      <IconButton
        iconName="settings"
        onPress={onPressMock}
        tooltipContent="tooltip Text"
      />
    );

    const button = screen.getByRole("button");
    await user.hover(button);

    expect(screen.getByText(/Tooltip text/i)).toBeInTheDocument();
  });

  // it("should render Icon Button with xl size variant", async () => {
  //   const onPressMock = jest.fn();
  //   const { user } = render(
  //     <IconButton iconName="settings" iconSize="xl" onPress={onPressMock} />
  //   );
  //   const button = screen.getByRole("button");
  //   await user.click(button);
  //   expect(onPressMock).toHaveBeenCalledTimes(1);
  //   expect(screen.getByTestId(/material-icon/i)).toHaveTextContent("settings");
  //   expect(screen.getByTestId(/material-icon/i)).toHaveStyle("font-size: 48px");
  // });
});
