import { styled } from "@linaria/react";
import { cssVars } from "@pulse/foundations";

import type { IconButtonProps } from "./icon-button.types";

export const IconButton = styled.button<{$size: IconButtonProps["size"]}>`
  display: inline-flex;
  align-items: center;
  justify-content: space-around;
  /* height: 40px; */
  border: none;
  border-radius: ${({$size}) => {
    if ($size === "small") {
      return cssVars.border.radiusXS
    }
    return cssVars.border.radiusS
  }};
  padding: ${({$size}) => {
    if (!$size) {
      return cssVars.spacing.x4
    }
    switch ($size) {
      case "default":
        return cssVars.spacing.x8
      case "medium":
        return cssVars.spacing.x6
      case "small":
        return cssVars.spacing.x2
    }
  }};
  font: ${cssVars.text.bodyBaseSemiBold};
  background-color: transparent;
  color: ${cssVars.color.iconBrand};

  &:hover {
    cursor: pointer;
    background-color: ${cssVars.color.bgButtonSecondaryHover};
  }

  &:disabled {
    cursor: not-allowed;
    color: ${cssVars.color.textDisabled};
    border: none;
    background-color: ${cssVars.color.bgDisabled};
  }

  &:focus-visible {
    background-color: ${cssVars.color.bgButtonSecondaryHover};
    outline-offset: 2px;
    outline: ${cssVars.border.widthS} solid ${cssVars.color.borderFocus};
  }

  @supports not selector(:focus-visible) {
    &:focus {
      background-color: ${cssVars.color.bgButtonSecondaryHover};
      outline-offset: 2px;
      outline: ${cssVars.border.widthS} solid ${cssVars.color.borderFocus};
    }
  }

  &:hover:not(:disabled) {
    background-color: ${cssVars.color.bgButtonSecondaryHover};
  }
`;
