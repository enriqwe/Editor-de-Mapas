export { OverlaySpinner } from "./overlay-spinner";
export type { OverlaySpinnerProps } from "./overlay-spinner";
