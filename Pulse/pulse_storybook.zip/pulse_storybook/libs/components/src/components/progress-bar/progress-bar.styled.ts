import type { DefaultTheme } from "styled-components";
import styled, { css } from "styled-components";

import type { Variants } from "./progress-bar.types";

const variantStyles = (theme: DefaultTheme, variant: Variants = "normal") =>
  ({
    normal: "#2b58bf",
    error: theme.color.icon.error,
    success: theme.color.icon.success,
  })[variant];

const variantTextStyles = (theme: DefaultTheme, variant: Variants = "normal") =>
  ({
    normal: css`
      color: ${theme.color.text.body};
    `,
    error: css`
      color: ${theme.color.text.stepper.error};
    `,
    success: css`
      color: ${theme.color.text.body};
    `,
  })[variant];

export const Root = styled.div<{
  maxWidth?: number;
}>`
  min-width: 48px;
  max-width: 100%;

  display: flex;
  flex-direction: column;
`;

export const ProgressBar = styled.div<{ $width: string; $status: Variants }>`
  width: ${({ $width }) => $width};
  height: 6px;
  background-color: ${({ theme, $status }) => variantStyles(theme, $status)};
  border-radius: ${({ theme }) => theme.border.radiusL};
`;

export const ProgressBarBackground = styled.div`
  height: 6px;
  width: 100%;
  background-color: ${({ theme }) => theme.color.background.disabled};
`;

export const Label = styled.label`
  font-family: ${({ theme }) => theme.font.fontFamily};
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.xs, theme.font.weights.semibold)};
  color: ${({ theme }) => theme.color.text.helperText};
  margin-bottom: ${({ theme }) => theme.spacing.x12};
`;

export const Text = styled.p<{
  $status?: Variants;
}>`
  font-family: ${({ theme }) => theme.font.fontFamily};
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.xs, theme.font.weights.regular)};
  margin-top: ${({ theme }) => theme.spacing.x8};
  ${({ theme, $status }) => variantTextStyles(theme, $status)}
  display: flex;
  align-items: center;

  .material-symbols-outlined {
    margin-right: ${({ theme }) => theme.spacing.x4};
  }
`;
