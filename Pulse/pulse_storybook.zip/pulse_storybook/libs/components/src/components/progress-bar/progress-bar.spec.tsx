import { screen } from "@testing-library/react";

import { ProgressBar } from "./progress-bar";

import { render } from "@test-utils";

describe("progressBar", () => {
  it("should render properly with custom label", () => {
    render(<ProgressBar errorText="textError" label="testLabel" value={80} />);
    const helpLabel = screen.getByText("testLabel");
    expect(helpLabel).toBeTruthy();
  });

  it("should render properly with custom label + error label", () => {
    render(
      <ProgressBar
        errorText="textError"
        label="testLabel"
        status="error"
        value={80}
      />
    );
    const helpLabel = screen.getByText("textError");
    expect(helpLabel).toBeTruthy();
  });

  it("should render properly with custom label + success label", () => {
    render(
      <ProgressBar
        errorText="textError"
        label="testLabel"
        status="success"
        successText="testSuccess"
        value={80}
      />
    );
    const helpLabel = screen.getByText("testSuccess");
    expect(helpLabel).toBeTruthy();
  });
});
