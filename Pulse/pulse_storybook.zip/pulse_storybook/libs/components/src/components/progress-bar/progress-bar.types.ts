export type Variants = "normal" | "error" | "success";

export type ProgressBarProps = {
  value: number;
  status?: Variants;
  label?: string;
  helperText?: string;
  errorText?: string;
  successText?: string;
  automationContext?: string;
};
