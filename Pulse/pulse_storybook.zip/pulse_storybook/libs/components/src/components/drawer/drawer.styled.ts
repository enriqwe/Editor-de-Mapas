import styled from "styled-components";

export const DrawerUnderlay = styled.div`
  position: fixed;
  z-index: ${({ theme }) => theme.zIndex.overlay};
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  align-items: center;
  justify-content: right;
  display: flex;
  background-color: #00000099; //Todo: create a theme color for this
`;

export const Drawer = styled.div`
  background-color: ${({ theme }) => theme.color.surfacePrimary};
  border-radius: ${({ theme }) => theme.border.radiusXS};
  box-shadow: ${({ theme }) => theme.shadow.drawer.left};
  box-sizing: border-box;

  display: flex;
  flex-direction: column;
  justify-content: space-between;

  height: 100dvh;
  width: 400px;

  padding: ${({ theme }) => `${theme.spacing.x32} ${theme.spacing.x24}`};

  overflow: auto;

  animation: slide 300ms;

  @keyframes slide {
    from {
      transform: translateX(100%);
    }

    to {
      transform: translateX(0);
    }
  }
`;

export const DrawerHeader = styled.header`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing.x8};
  padding-bottom: ${({ theme }) => theme.spacing.x16};
`;

export const HeaderTitleRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

export const Title = styled.h1`
  ${({ theme }) => theme.text.heading6Bold};
  color: ${({ theme }) => theme.color.textHeading};
  margin: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  flex: 1;
`;

export const Description = styled.p`
  ${({ theme }) => theme.text.bodyMediumRegular};
  color: ${({ theme }) => theme.color.textSubheading};
  margin: 0;
  overflow: hidden;
  white-space: wrap;
  text-overflow: ellipsis;
`;

export const DrawerBody = styled.section`
  overflow: auto;
  padding: ${({ theme }) => `${theme.spacing.x12} 0`};
  height: 100%;
  color: ${({ theme }) => theme.color.textBody};
`;

export const DrawerFooter = styled.footer`
  position: sticky;
  bottom: 0;
  display: flex;
  justify-content: flex-start;
  flex-direction: row-reverse;
  gap: ${({ theme }) => theme.spacing.x16};
  padding: ${({ theme }) => `${theme.spacing.x16} 0 0`};
`;
