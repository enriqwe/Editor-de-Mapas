import type { ReactNode } from "react";
import { useRef } from "react";
import { useDialog, Overlay, useModalOverlay } from "react-aria";
import { useOverlayTriggerState } from "react-stately";

import * as S from "./drawer.styled";

import { Button } from "@components/button";
import type { ButtonProps } from "@components/button";
import { IconButton } from "@components/icon-button";

export type FooterButtonProps = {
  label: string;
  variant: ButtonProps["variant"];
  onClick: () => void;
  disabled?: boolean;
};

export type DrawerProps = {
  children: ReactNode;
  title?: string;
  description?: string;
  isOpen?: boolean;
  onClose?: () => void;
  footerButtons?: FooterButtonProps[];
};

export function Drawer({
  title,
  children,
  description,
  isOpen = false,
  footerButtons = [],
  onClose,
}: DrawerProps) {
  const state = useOverlayTriggerState({
    isOpen,
  });
  const ref = useRef(null);
  const { modalProps, underlayProps } = useModalOverlay({}, state, ref);

  const diaglogRef = useRef(null);
  const { dialogProps, titleProps } = useDialog({}, diaglogRef);

  if (!isOpen) {
    return <div />;
  }

  return (
    <Overlay>
      <S.DrawerUnderlay {...underlayProps}>
        <S.Drawer {...modalProps} ref={ref}>
          <S.DrawerHeader {...dialogProps} ref={ref}>
            <S.HeaderTitleRow>
              <S.Title {...titleProps} title={title}>
                {title}
              </S.Title>
              {onClose && (
                <IconButton
                  aria-label="Close drawer button"
                  data-testid="close"
                  iconName="close"
                  onPress={onClose}
                />
              )}
            </S.HeaderTitleRow>
            {description ?
              <S.Description>{description}</S.Description>
            : null}
          </S.DrawerHeader>
          <S.DrawerBody>{children}</S.DrawerBody>
          <S.DrawerFooter>
            {footerButtons.map(
              ({ label, variant, onClick, disabled = false }) => (
                <Button
                  isDisabled={disabled}
                  key={label}
                  onPress={onClick}
                  variant={variant}
                >
                  {label}
                </Button>
              )
            )}
          </S.DrawerFooter>
        </S.Drawer>
      </S.DrawerUnderlay>
    </Overlay>
  );
}
