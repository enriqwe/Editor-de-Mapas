import { screen } from "@testing-library/react";

import { Drawer } from "./drawer";

import { render } from "@test-utils";

describe("drawer", () => {
  it("does not render when isOpen is false", () => {
    render(
      <Drawer isOpen={false} title="Test Title">
        <div>Test Content</div>
      </Drawer>
    );
    expect(screen.queryByText("Test Title")).toBeNull();
  });

  it("does not render if isOpen is not set", () => {
    render(
      <Drawer title="Test Title">
        <div>Test Content</div>
      </Drawer>
    );
    expect(screen.queryByText("Test Title")).toBeNull();
  });

  it("renders correctly when isOpen is true", () => {
    render(
      <Drawer description="Test description" isOpen title="Test Title">
        <div>Test Content</div>
      </Drawer>
    );
    expect(screen.getByText("Test Title")).toBeInTheDocument();
    expect(screen.getByText("Test Content")).toBeInTheDocument();
  });

  it("calls onClose when close icon is clicked", async () => {
    const onClose = jest.fn();
    const { user } = render(
      <Drawer isOpen onClose={onClose} title="Test Title">
        <div>Test Content</div>
      </Drawer>
    );
    const closeButton = screen.getByRole("button", {
      name: "Close drawer button",
    });

    await user.click(closeButton);

    expect(onClose).toHaveBeenCalled();
  });

  it("calls footer button onClick handlers when clicked", async () => {
    const onClick1 = jest.fn();
    const onClick2 = jest.fn();

    const { user } = render(
      <Drawer
        footerButtons={[
          { label: "Apply", variant: "primary", onClick: onClick1 },
          { label: "Clear", variant: "tertiary", onClick: onClick2 },
        ]}
        isOpen
        title="Test Title"
      >
        <div>Test Content</div>
      </Drawer>
    );

    await user.click(screen.getByText("Apply"));
    expect(onClick1).toHaveBeenCalled();

    await user.click(screen.getByText("Clear"));
    expect(onClick2).toHaveBeenCalled();
  });

  it("verify footer button disabled state", async () => {
    const onClick1 = jest.fn();
    const onClick2 = jest.fn();

    const { user } = render(
      <Drawer
        footerButtons={[
          {
            label: "Apply",
            variant: "primary",
            onClick: onClick1,
            disabled: true,
          },
          { label: "Clear", variant: "tertiary", onClick: onClick2 },
        ]}
        isOpen
        title="Test Title"
      >
        <div>Test Content</div>
      </Drawer>
    );

    await user.click(screen.getByText("Apply"));
    expect(onClick1).not.toHaveBeenCalled();
  });
});
