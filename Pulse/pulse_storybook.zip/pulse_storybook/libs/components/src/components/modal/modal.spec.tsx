import { screen } from "@testing-library/react";

import { ModalTrigger } from "./modal-trigger";
import { ModalWithSection } from "./modal-with-section";

import { render } from "@test-utils";

describe("modal", () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  const props = {
    variant: "primary" as const,
    label: "Open Modal",
    defaultOpen: true,
  };

  const onOpenChange = jest.fn();

  it("should render modal successfully", () => {
    render(
      <ModalTrigger {...props}>
        {closeFn => (
          <button onClick={closeFn} type="button">
            Close Modal
          </button>
        )}
      </ModalTrigger>
    );

    expect(screen.getByText("Open Modal")).toBeInTheDocument();

    expect(
      screen.getByRole("button", {
        name: "Close Modal",
      })
    ).toBeInTheDocument();
  });
  it("should hide the modal content if it is not open and show it when clicking on Open Modal", async () => {
    props.defaultOpen = false;

    const { user } = render(
      <ModalTrigger {...props}>
        {closeFn => (
          <button onClick={closeFn} type="button">
            Close Modal
          </button>
        )}
      </ModalTrigger>
    );
    const triggerButton = screen.getByText("Open Modal");

    expect(screen.queryByText("Close Modal")).not.toBeInTheDocument();
    await user.click(triggerButton);

    expect(screen.getByText("Close Modal")).toBeInTheDocument();
  });

  it("should execute custom callbacks when passed", async () => {
    props.defaultOpen = false;
    const newProps = { ...props, onOpenChange };

    const { user } = render(
      <ModalTrigger {...newProps}>
        {closeFn => (
          <button onClick={closeFn} type="button">
            Close Modal
          </button>
        )}
      </ModalTrigger>
    );
    const triggerButton = screen.getByText("Open Modal");

    expect(screen.queryByText("Close Modal")).not.toBeInTheDocument();
    await user.click(triggerButton);
    expect(onOpenChange).toHaveBeenCalled();

    expect(screen.getByText("Close Modal")).toBeInTheDocument();
  });

  it("should render Modal Header, Body and Footer elements and also check the actions", async () => {
    const handleTriggerBtn = jest.fn();
    const handleSubmit = jest.fn();

    function ModalShowcase(close: () => void) {
      return (
        <div>
          <ModalWithSection.Header
            closeHandler={close}
            description="Description"
            title="Title"
          />
          <ModalWithSection.Body>Modal Body</ModalWithSection.Body>
          <ModalWithSection.Footer
            actions={[
              {
                buttonVariant: "primary",
                buttonLabel: "Submit",
                clickHandler: handleSubmit,
              },
              {
                buttonVariant: "secondary",
                buttonLabel: "Cancel",
                clickHandler: close,
              },
            ]}
          />
        </div>
      );
    }

    const { user } = render(
      <ModalTrigger
        defaultOpen={false}
        label="Open Modal"
        onOpenChange={handleTriggerBtn}
        variant="primary"
      >
        {closeFn => ModalShowcase(closeFn)}
      </ModalTrigger>
    );

    expect(screen.queryByText("Title")).not.toBeInTheDocument();

    const openModalButton = screen.getByText("Open Modal");
    await user.click(openModalButton);

    expect(handleTriggerBtn).toHaveBeenCalledTimes(1);

    expect(screen.getByText("Title")).toBeInTheDocument();
    expect(screen.getByText("Description")).toBeInTheDocument();
    expect(screen.getByText("Modal Body")).toBeInTheDocument();

    const submitButton = screen.getByRole("button", { name: "Submit" });
    expect(submitButton).toBeInTheDocument();
    await user.click(submitButton);
    expect(handleSubmit).toHaveBeenCalledTimes(1);

    const cancelButton = screen.getByRole("button", { name: "Cancel" });
    expect(cancelButton).toBeInTheDocument();
    await user.click(cancelButton);

    expect(screen.queryByText("Title")).not.toBeInTheDocument();
  });

  /* Commented out until trigger component is re-implemented
  it("should execute a clickable trigger component", async () => {
    function MyNewComponent() {
      return <p>Trigger</p>;
    }

    const { user } = render(
      <ModalTrigger containerComponent={MyNewComponent}>
        {closeFn => (
          <button onClick={closeFn} type="button">
            Close Modal
          </button>
        )}
      </ModalTrigger>
    );
    const triggerButton = screen.getByText("Trigger");


    expect(screen.queryByText("Close Modal")).not.toBeInTheDocument();
    await user.click(triggerButton);

    expect(screen.getByText("Close Modal")).toBeInTheDocument();
  }); */

  it("should render button disabled if buttonDisabled is true", () => {
    const handleTriggerBtn = jest.fn();
    const handleSubmit = jest.fn();

    function ModalShowcase(close: () => void) {
      return (
        <div>
          <ModalWithSection.Header
            closeHandler={close}
            description="Description"
            title="Title"
          />
          <ModalWithSection.Body>Modal Body</ModalWithSection.Body>
          <ModalWithSection.Footer
            actions={[
              {
                buttonDisabled: true,
                buttonLabel: "Submit",
                buttonVariant: "primary",
                clickHandler: handleSubmit,
              },
              {
                buttonVariant: "secondary",
                buttonLabel: "Cancel",
                clickHandler: close,
              },
            ]}
          />
        </div>
      );
    }

    render(
      <ModalTrigger
        defaultOpen
        label="Open Modal"
        onOpenChange={handleTriggerBtn}
        variant="primary"
      >
        {closeFn => ModalShowcase(closeFn)}
      </ModalTrigger>
    );

    const submitButton = screen.getByRole("button", { name: "Submit" });
    expect(submitButton).toBeInTheDocument();
    expect(submitButton).toBeDisabled();
  });

  it("should render button type sumbit if buttonType is submit", () => {
    const handleTriggerBtn = jest.fn();
    const handleSubmit = jest.fn();

    function ModalShowcase(close: () => void) {
      return (
        <div>
          <ModalWithSection.Header
            closeHandler={close}
            description="Description"
            title="Title"
          />
          <ModalWithSection.Body>Modal Body</ModalWithSection.Body>
          <ModalWithSection.Footer
            actions={[
              {
                buttonLabel: "Submit",
                buttonType: "submit",
                buttonVariant: "primary",
                clickHandler: handleSubmit,
              },
              {
                buttonVariant: "secondary",
                buttonLabel: "Cancel",
                clickHandler: close,
              },
            ]}
          />
        </div>
      );
    }

    render(
      <ModalTrigger
        defaultOpen
        label="Open Modal"
        onOpenChange={handleTriggerBtn}
        variant="primary"
      >
        {closeFn => ModalShowcase(closeFn)}
      </ModalTrigger>
    );

    const submitButton = screen.getByRole("button", { name: "Submit" });
    expect(submitButton).toBeInTheDocument();
    expect(submitButton.getAttribute("type")).toEqual("submit");
  });
});
