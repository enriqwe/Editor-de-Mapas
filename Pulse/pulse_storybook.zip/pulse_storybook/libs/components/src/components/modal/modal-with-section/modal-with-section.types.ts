import type { ButtonProps } from "@components/button";

export type HeaderProps = {
  title: string;
  closeHandler?: () => void;
  description?: string;
};

type FooterButtonProps = {
  buttonDisabled?: boolean;
  buttonLabel: string;
  buttonType?: ButtonProps["type"];
  buttonVariant: ButtonProps["variant"];
  clickHandler: () => void;
};

export type FooterProps = {
  actions: FooterButtonProps[];
};

export type BodyProps = {
  children: React.ReactNode;
};
