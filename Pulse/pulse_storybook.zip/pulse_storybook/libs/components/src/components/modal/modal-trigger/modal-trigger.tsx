import type { JSX, ReactElement, ReactNode } from "react";
import { useRef, cloneElement } from "react";
import type { AriaModalOverlayProps, AriaButtonProps } from "react-aria";
import { useOverlayTrigger } from "react-aria";
import type { OverlayTriggerProps } from "react-stately";
import { useOverlayTriggerState } from "react-stately";

import type { ModalProps } from "../modal";
import { Modal } from "../modal";

import type { ButtonProps } from "@components/button";
import { Button } from "@components/button";
// import { automationClass } from "@utils/automation-class";

export type ModalTriggerProps = {
  label?: ReactNode;
  variant?: ButtonProps["variant"];
  children: (close: () => void) => ReactElement;
  automationContext?: string;
  /** @deprecated use isOpen instead */
  isShowing?: boolean;
  toggle?: () => void;
  // containerComponent?: () => ReactElement;
  requiredComponent?: boolean;
  type?: ModalProps["type"];
} & OverlayTriggerProps;

export function ModalTrigger(props: ModalTriggerProps & AriaModalOverlayProps) {
  const {
    label,
    variant,
    children,
    // toggle,
    // containerComponent,
    type = "short",
    automationContext,
    requiredComponent = true,
  } = props;

  const overlayTriggerStateProps = {
    ...props,
    isOpen: props.isOpen ?? props.isShowing,
  };

  const state = useOverlayTriggerState(overlayTriggerStateProps);

  const triggerRef = useRef(null);
  const { triggerProps, overlayProps } = useOverlayTrigger(
    { type: "dialog" },
    state,
    triggerRef
  );

  return (
    <>
      {requiredComponent && (
        <TriggerContainer
          automationContext={automationContext}
          // containerComponent={containerComponent}
          label={label}
          triggerProps={triggerProps}
          variant={variant}
        />
      )}
      {state.isOpen && (
        <Modal {...props} state={state} type={type}>
          {cloneElement(
            children(() => {
              state.close();
            }),
            overlayProps
          )}
        </Modal>
      )}
    </>
  );
}

type TriggerContainerProps = {
  triggerProps: AriaButtonProps;
  label: ReactNode;
  variant: ButtonProps["variant"];
  automationContext?: string;

  containerComponent?: () => JSX.Element;
};

function TriggerContainer(props: TriggerContainerProps) {
  const {
    triggerProps,
    label,
    variant,
    // toggle,
    // containerComponent: ContainerComponent,
    automationContext,
  } = props;

  // const automationClasses = automationClass("modal-trigger", automationContext);

  // if (ContainerComponent) {
  //   return (
  //     <S.Trigger  tabIndex={0} {...triggerProps} onClick={triggerProps.onPress}>
  //       <ContainerComponent className={automationClasses}  />
  //     </S.Trigger>
  //   );
  // }

  return (
    <Button
      automationContext={automationContext}
      type="button"
      variant={variant}
      {...triggerProps}
    >
      {label}
    </Button>
  );
}
