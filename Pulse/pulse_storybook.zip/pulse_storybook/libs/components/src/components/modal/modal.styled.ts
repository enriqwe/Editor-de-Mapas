import { styled } from "@linaria/react";
import { cssVars, helpers } from "@pulse/foundations";

import type { ModalProps } from "./modal";

export const Underlay = styled.div`
  position: fixed;
  z-index: ${cssVars.zIndex.modal};
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(
    0,
    0,
    0,
    0.6
  ); // opacity[60] color token not mentioned in default theme
  align-items: center;
  justify-content: center;
  display: flex;
`;

export const Modal = styled.div<{ type: ModalProps["type"] }>`
  background: ${cssVars.color.surfacePrimary};
  border-radius: ${cssVars.border.radiusM};
  box-shadow: ${cssVars.shadow.break};
  padding: ${cssVars.spacing.x32} ${cssVars.spacing.x24};
  max-height: ${({ type }) => (type === "short" ? "48dvh" : "72dvh")};
  display: flex;
  flex-direction: column;
  box-sizing: border-box;

  width: 100%;
  margin-left: ${cssVars.spacing.x16};
  margin-right: ${cssVars.spacing.x16};

  ${helpers.media.up("tablet")} {
    width: ${({ type }) => {
      if (type === "short") {
        return "45%";
      }
      if (type === "large") {
        return "68%";
      }
      return "42%";
    }};
  }

  ${helpers.media.up("desktop")} {
    width: ${({ type }) => {
      if (type === "short") {
        return "30%";
      }
      if (type === "large") {
        return "45%";
      }
      return "36%";
    }};
  }
`;

export const ModalTitle = styled.h1`
  font: ${cssVars.text.heading6Bold};
  color: ${cssVars.color.textHeading};
  margin-top: 0;
`;

export const ModalFooter = styled.footer`
  margin-top: auto;
  padding: ${cssVars.spacing.x24} 0 ${cssVars.spacing.x4};
  display: flex;
  justify-content: flex-end;
  gap: ${cssVars.spacing.x4};
`;

export const StyledTrigger = styled.div`
  display: flex;
  width: 100%;
  cursor: pointer;
`;
