import { screen, within } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import type { TopbarProps } from "./topbar.types";
import { Topbar } from "./topbar";

import { render } from "@test-utils";
import {useUp} from "@hooks/use-media";

jest.mock("@hooks/use-media");

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment -- stop copmlaining please
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

describe("topbar", () => {
  expect.extend(toHaveNoViolations);

  const mockProps: TopbarProps = {
    logo: {
      href: "https://example.com",
      src: {
        mobile: "/images/sportian_isotype.png",
        desktop: "/images/sportian_positive.png",
      },
    },
    organizations: {
      current: {
        id: "1",
        label: "Organization 1",
        logoSrc: "/public/images/sportian_isotype.png",
      },
      items: [
        {
          id: "1",
          label: "Organization 1",
          logoSrc: "/public/images/sportian_isotype.png",
        },
        {
          id: "2",
          label: "Org 2",
          logoSrc: "/public/images/sportian_isotype.png",
        },
        {
          id: "3",
          label: "Client 3",
          logoSrc: "/public/images/sportian_isotype.png",
        },
      ],
      onChange: jest.fn(),
    },
    userProfile: {
      name: "John Doe",
      items: [
        {
          id: "1",
          label: "User Action",
          onPress: jest.fn(),
        },
        {
          id: "2",
          label: "Log Out",
          onPress: jest.fn(),
        },
      ],
    },
    onHamburguerPress: jest.fn(),
    languages: {
      current: "es-ES",
      items: ["es-ES", "en-US", "fr-FR", "de-DE"],
      onChange: jest.fn(),
    },
  };

  beforeEach(() => {
    jest.mocked(useUp).mockImplementation(() => true)
  })

  it("renders the component without accesibility issues", async () => {
    const { container } = render(<Topbar {...mockProps} />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();
  });

  it("renders the logo", () => {
    render(<Topbar {...mockProps} />);
    const topbar = screen.getByTestId("topbar");
    const logoElement = within(topbar).getByTestId("logo");

    expect(logoElement).toBeInTheDocument();
    expect(logoElement).toHaveAttribute("src", mockProps.logo.src!.desktop);
  });

  it("renders the organization selector", () => {
    render(<Topbar {...mockProps} />);
    const organizationItem = screen.getByText("Organization 1");
    expect(organizationItem).toBeInTheDocument();
  });

  it("renders the user profile name", () => {
    render(<Topbar {...mockProps} />);
    const usernameElement = screen.getByText(mockProps.userProfile.name);
    expect(usernameElement).toBeInTheDocument();
  });

  it("renders the profile menu", () => {
    render(<Topbar {...mockProps} />);
    const topbar = screen.getByTestId("topbar");
    const userTrigger = within(topbar).getByTestId("user-trigger");
    expect(userTrigger).toBeInTheDocument();
  });

  it("calls logout menu item's callback", async () => {
    const { user } = render(<Topbar {...mockProps} />);
    const topbar = screen.getByTestId("topbar");
    const userTrigger = within(topbar).getByTestId("user-trigger");
    await user.click(userTrigger);

    const logoutOption = screen.getByText("Log Out");
    await user.click(logoutOption);

    expect(mockProps.userProfile.items[1]?.onPress).toHaveBeenCalled();
  });

  it("moves language selector to user menu on mobile", async () => {
    jest.mocked(useUp).mockImplementation(() => false)
    const { user } = render(<Topbar {...mockProps} />);
    const topbar = screen.getByTestId("topbar");
    const langTrigger = within(topbar).queryByTestId("lang-trigger");

    const userTrigger = within(topbar).getByTestId("user-trigger");
    await user.click(userTrigger);

    const userMenu = screen.getByTestId("user-menu");
    const languagesOption = within(userMenu).getByTestId("user-lang-trigger");
    await user.click(languagesOption);

    const langForm = screen.getByTestId("lang-form")

    expect(langTrigger).not.toBeInTheDocument();
    expect(langForm).toBeInTheDocument();
  });
});
