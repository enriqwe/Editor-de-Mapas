import { styled } from "@linaria/react";
import { cssVars, helpers } from "@pulse/foundations";

export const Header = styled.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  z-index: ${cssVars.zIndex.stickied};

  --vertical-padding: ${cssVars.spacing.x6};

  padding: var(--vertical-padding) ${cssVars.spacing.x16};
  background-color: ${cssVars.color.bgPrimary};
`;

export const LeftMenu = styled.div`
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
  min-width: 0;

  ${helpers.media.up("tablet")} {
    gap: ${cssVars.spacing.x16};
  }
`;

export const RightMenu = styled.div`
  display: flex;
  align-items: center;
`;

export const Separator = styled.div`
  width: 1px;
  align-self: stretch;
  background-color: ${cssVars.color.borderDivider};

  margin-block: calc(var(--vertical-padding) * -1);
  margin-inline: ${cssVars.spacing.x8};

  ${helpers.media.up("tablet")} {
    margin-inline: ${cssVars.spacing.x24};
  }
`

export const ButtonBar = styled.div`
  display: flex;
  align-items: center;
  gap: ${cssVars.spacing.x8};
`

export const LogoLink = styled.a`
  display: flex;
`

export const Logo = styled.img`
  height: 32px;
  width: auto;

  max-width: 96px;
  ${helpers.media.up("tablet")} {
    max-width: 216px;
  }

  object-fit: contain;
  object-position: center;
`
