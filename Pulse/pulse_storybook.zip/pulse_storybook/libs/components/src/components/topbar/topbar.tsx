import * as S from "./topbar.styled";
import type { TopbarProps } from "./topbar.types";
import { UserProfile } from "./sub-components/user-profile";
import { OrganizationsSelector } from "./sub-components/organizations-selector";
import { LanguagesSelector } from "./sub-components/languages-selector";

import { TranslationProvider, useTranslation, type Locale } from "@providers/translation";
import { IconButton } from "@components/icon-button";
import { useUp } from "@hooks/use-media";
import { useLocale } from "@providers/locale";

export function TopbarComponent(props: TopbarProps & { locale: Locale }) {
  const {
    onHamburguerPress,
    logo,
    userProfile,
    organizations,
    languages,
    locale,
  } = props;

  const t = useTranslation();
  const isTablet = useUp("tablet");

  const Logo =
    logo.src ?
      <S.Logo
        alt={t("topbar.a11y.logo.img.alt")}
        data-testid="logo"
        src={isTablet ? logo.src.desktop : logo.src.mobile}
      />
    : logo.element;

  return (
    <S.Header data-testid="topbar">
      <S.LeftMenu>
        <IconButton
          aria-label={t("topbar.a11y.toggle.label")}
          data-testid="hamburguer"
          iconName="menu"
          onPress={onHamburguerPress}
          size="default"
        />
        {logo.href ?
          <S.LogoLink
            aria-label={t("topbar.a11y.logo.link.label")}
            href={logo.href}
          >
            {Logo}
          </S.LogoLink>
        : Logo}
        {organizations && (
          <OrganizationsSelector organizations={organizations} />
        )}
      </S.LeftMenu>
      <S.RightMenu>
        {isTablet && languages && (
          <LanguagesSelector languages={languages} locale={locale} />
        )}
        <S.Separator />
        <UserProfile
          languages={!isTablet ? languages : undefined}
          locale={locale}
          userProfile={userProfile}
        />
      </S.RightMenu>
    </S.Header>
  );
}

export function Topbar(props: TopbarProps) {
  const localeContext = useLocale()
  const locale = props.locale || localeContext
  return (
    <TranslationProvider locale={locale}>
      <TopbarComponent {...props} locale={locale} />
    </TranslationProvider>
  );
}
