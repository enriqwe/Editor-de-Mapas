import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";

import { Button } from "./button";

import { render } from "@test-utils";

describe("button", () => {
  const IconSvg = (
    <svg
      fill="none"
      height="22"
      viewBox="0 0 26 25"
      width="22"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M11.9592 18.7519H13.8836V13.6203H19.0152V11.6959H13.8836V6.56432H11.9592V11.6959H6.82757V13.6203H11.9592V18.7519ZM12.9214 24.8457C11.2322 24.8457 9.64483 24.525 8.15922 23.8836C6.67276 23.2421 5.3843 22.3761 4.29383 21.2857C3.20336 20.1952 2.3374 18.9067 1.69594 17.4203C1.05449 15.9347 0.733765 14.3473 0.733765 12.6581C0.733765 10.969 1.05449 9.38116 1.69594 7.8947C2.3374 6.40909 3.20336 5.12105 4.29383 4.03058C5.3843 2.94011 6.67276 2.07415 8.15922 1.4327C9.64483 0.791247 11.2322 0.47052 12.9214 0.47052C14.6105 0.47052 16.1983 0.791247 17.6848 1.4327C19.1704 2.07415 20.4584 2.94011 21.5489 4.03058C22.6394 5.12105 23.5053 6.40909 24.1468 7.8947C24.7883 9.38116 25.109 10.969 25.109 12.6581C25.109 14.3473 24.7883 15.9347 24.1468 17.4203C23.5053 18.9067 22.6394 20.1952 21.5489 21.2857C20.4584 22.3761 19.1704 23.2421 17.6848 23.8836C16.1983 24.525 14.6105 24.8457 12.9214 24.8457ZM12.9214 22.9214C15.7651 22.9214 18.1868 21.922 20.1865 19.9232C22.1852 17.9236 23.1846 15.5019 23.1846 12.6581C23.1846 9.81435 22.1852 7.39265 20.1865 5.39303C18.1868 3.39426 15.7651 2.39488 12.9214 2.39488C10.0776 2.39488 7.65632 3.39426 5.65756 5.39303C3.65793 7.39265 2.65812 9.81435 2.65812 12.6581C2.65812 15.5019 3.65793 17.9236 5.65756 19.9232C7.65632 21.922 10.0776 22.9214 12.9214 22.9214Z"
        fill="white"
      />
    </svg>
  );
  expect.extend(toHaveNoViolations);
  it("should render successfully and onclick works", async () => {
    const onClickMock = jest.fn();
    const { container, user } = render(
      <Button onPress={onClickMock}>Confirm</Button>
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeInTheDocument();
    await user.click(button);
    expect(onClickMock).toHaveBeenCalledTimes(1);
  });

  it("renders successfully with icon", () => {
    const onClickMock = jest.fn();
    render(
      <Button IconLeft={IconSvg} onPress={onClickMock}>
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeInTheDocument();
    expect(button).toContainElement(document.querySelector("svg"));
  });
  it("should not call onClick function if button is disabled", async () => {
    const onClickMock = jest.fn();
    const { user } = render(
      <Button isDisabled onPress={onClickMock} variant="destructive">
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeDisabled();
    await user.click(button);
    expect(onClickMock).not.toHaveBeenCalled();
  });

  /*    Skipped until tooltip is re-enabled in button
  it("should render properly the tooltip when hover event is active for button", () => {
    const { user} = render(
      <Button tooltipContent="tooltip Text" variant="secondary">
        Label
      </Button>
    );
    const button = screen.getByRole("button");
    user.hover(button);
    expect(screen.getByText(/Tooltip text/i)).toBeInTheDocument();
  }); */

  it("renders successfully with right icon", () => {
    const onClickMock = jest.fn();
    render(
      <Button IconRight={IconSvg} onPress={onClickMock} variant="secondary">
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeInTheDocument();
    expect(button).toContainElement(document.querySelector("svg"));
  });

  it("should render ghost variant button type", async () => {
    const onClickMock = jest.fn();
    const { user } = render(
      <Button IconRight={IconSvg} onPress={onClickMock} variant="ghost">
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeInTheDocument();
    await user.click(button);
    expect(onClickMock).toHaveBeenCalledTimes(1);
  });

  it("should render button with right icon destructive variant in disabled state", () => {
    const onClickMock = jest.fn();
    render(
      <Button
        IconRight={IconSvg}
        isDisabled
        onPress={onClickMock}
        variant="destructive"
      >
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    expect(button).toBeInTheDocument();
    expect(button).toContainElement(document.querySelector("svg"));
    expect(onClickMock).toHaveBeenCalledTimes(0);
    expect(button).toHaveAttribute("disabled");
  });

  it("should render button with right icon tertiary variant", async () => {
    const onClickMock = jest.fn();
    const { user } = render(
      <Button IconRight={IconSvg} onPress={onClickMock} variant="tertiary">
        Confirm
      </Button>
    );
    const button = screen.getByRole("button", { name: "Confirm" });
    await user.click(button);
    expect(button).toBeInTheDocument();
    expect(onClickMock).toHaveBeenCalledTimes(1);
  });

  it("should render button incase of loading", async () => {
    const mockOnClick = jest.fn();
    const { user } = render(
      <Button isLoading onPress={mockOnClick} variant="primary">
        Button Label
      </Button>
    );
    const button = screen.getByRole("button");
    await user.click(button);
    expect(mockOnClick).toHaveBeenCalledTimes(0);
    expect(screen.getByText("Button Label")).toBeTruthy();
  });

  it("should render button incase of loading with loading text", async () => {
    const mockOnClick = jest.fn();
    const { user } = render(
      <Button
        isLoading
        loadingText="Loading Text"
        onPress={mockOnClick}
        variant="destructive"
      >
        Button Label
      </Button>
    );
    const button = screen.getByRole("button");
    await user.click(button);
    expect(mockOnClick).toHaveBeenCalledTimes(0);
    expect(screen.getByText("Loading Text")).toBeTruthy();
    expect(screen.queryByText("Button Label")).toBeFalsy();
  });
});
