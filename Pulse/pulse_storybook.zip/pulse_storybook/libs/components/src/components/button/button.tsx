import { isValidElement, useRef } from "react";
import {
  /* mergeProps, */ useButton /* , useTooltipTrigger */,
} from "react-aria";
// import { useTooltipTriggerState } from "react-stately";
// import { TooltipTrigger } from "@components/tooltip";

// import classNames from "classnames";

import type { ButtonProps } from "./button.types";
import * as S from "./button.styled";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";
import { Spinner } from "@components/spinner";

const allowedVariantsForLoading = ["primary", "destructive"];

export function Button(props: ButtonProps) {
  const {
    variant = "primary",
    type = "button",
    children,
    IconLeft,
    IconRight,
    automationContext,
    isDisabled,
    // tooltipContent,
    ...restProps
  } = props;
  let isLoading = false;
  let loadingText = "";

  if (props.variant === "primary" || props.variant === "destructive") {
    isLoading = Boolean(props.isLoading);
    loadingText = props.loadingText ?? "";
  }

  const automationClasses = automationClass("button", automationContext);
  // const tooltipAutomationClasses = automationClass(
  //   "tooltip-button",
  //   automationContext
  // );

  const ref = useRef<HTMLButtonElement | null>(null);

  const { buttonProps } = useButton(
    {
      ...restProps,
      type,
      onPress: evt => {
        if (isLoading) {
          return;
        }
        if (props.onPress) {
          props.onPress(evt);
        }
      },
      isDisabled,
    },
    ref
  );

  const displayIcon = (icon: string | React.ReactNode) => {
    let showIcon;
    if (isValidElement(icon)) {
      showIcon = icon;
    } else {
      showIcon = <Icon icon={String(icon)} state="normal" />;
    }

    return (
      <S.IconContainer $disabled={Boolean(isDisabled)} $variant={variant}>
        {showIcon}
      </S.IconContainer>
    );
  };

  const isLoadingState =
    isLoading && allowedVariantsForLoading.includes(variant);

  // const tooltipInitialProps = {
  //   delay: 0,
  //   isDisabled: props.isDisabled || props.disabled,
  // };

  // const state = useTooltipTriggerState(tooltipInitialProps);

  // const { triggerProps, tooltipProps } = useTooltipTrigger(
  //   tooltipInitialProps,
  //   state,
  //   ref
  // );

  const getButton = () => {
    const InternalButton = S.getButton(variant, isLoading);
    return (
      <InternalButton
        {...buttonProps}
        $isLoading={isLoading}
        $variant={variant}
        className={automationClasses}
        ref={ref}
      >
        {isLoadingState ?
          <div>
            <Spinner size="md" variant="light" />
          </div>
        : IconLeft && displayIcon(IconLeft)}

        {isLoadingState && loadingText ?
          <S.ButtonText>{loadingText}</S.ButtonText>
        : children && <S.ButtonText>{children}</S.ButtonText>}

        {IconRight && displayIcon(IconRight)}
      </InternalButton>
    );
  };
  // {tooltipContent && state.isOpen && (
  //   <Tooltip
  //     {...tooltipProps}
  //     automationContext={tooltipAutomationClasses}
  //     state={{
  //       ...state,
  //       setOpen: isOpen => {
  //         isOpen ? state.open() : state.close();
  //       },
  //       toggle: () => {
  //         state.isOpen ? state.close() : state.open();
  //       },
  //     }}
  //     // triggerRef={ref}
  //   >
  //     {tooltipContent}
  //   </Tooltip>
  // )}
  return getButton();
  /* return (
    <>
      {tooltipContent ?
        <TooltipTrigger
          automationContext={tooltipAutomationClasses}
          tooltipContent={tooltipContent}
          triggerElement={getButton()}
        />
      : getButton()}
    </>
  ); */
}
