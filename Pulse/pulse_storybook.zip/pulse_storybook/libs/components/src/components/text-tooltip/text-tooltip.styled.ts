import styled from "styled-components";

export const toolTipWrapper = styled.div`
  position: relative;
`;

export const tableText = styled.div<{ $capitalize?: boolean }>`
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  &:first-letter {
    text-transform: ${({ $capitalize }) =>
      $capitalize ? "capitalize" : "none"};
  }
`;

export const tooltipText = styled.div<{ $capitalize?: boolean }>`
  &:first-letter {
    text-transform: ${({ $capitalize }) =>
      $capitalize ? "capitalize" : "none"};
  }
`;
