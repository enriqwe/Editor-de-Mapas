import type { ReactNode } from "react";
import { useRef, useState } from "react";
import { useTooltipTriggerState } from "react-stately";
import type { TooltipTriggerProps } from "react-aria";
import { useTooltipTrigger } from "react-aria";

import * as S from "./text-tooltip.styled";

import { Tooltip } from "@components/tooltip";
import { automationClass } from "@utils/automation-class";

export type TextToolTipProps = {
  children: ReactNode;
  automationContext?: string;
  tooltipText?: string;
  alwaysShow?: boolean;
  capitalize?: boolean;
} & TooltipTriggerProps;

export function TextTooltip({
  children,
  automationContext,
  tooltipText,
  alwaysShow = false,
  capitalize = true,
}: TextToolTipProps) {
  const [isOpen, setIsOpen] = useState(false);
  const tooltipState = useTooltipTriggerState({
    delay: 0,
    onOpenChange: setIsOpen,
    isOpen,
  });
  const triggerRef = useRef<HTMLDivElement>(null);
  const { triggerProps, tooltipProps } = useTooltipTrigger(
    { delay: 0 },
    tooltipState,
    triggerRef
  );
  const { onPointerEnter, onPointerLeave, onFocus, onMouseEnter } =
    triggerProps;
  const tooltipAutomationClasses = automationClass(
    "tooltip",
    automationContext
  );

  /* Check if tooltip needs to display for text content */
  const handleMouseOver = (event: { target: EventTarget }) => {
    if (alwaysShow) {
      setIsOpen(true);
    } else {
      const element = event.target;
      if (element instanceof HTMLDivElement) {
        const style = window.getComputedStyle(element);
        const whiteSpace = style.getPropertyValue("white-space");
        const textOverflow = style.getPropertyValue("text-overflow");
        if (whiteSpace === "nowrap" && textOverflow === "ellipsis") {
          if (element.offsetWidth < element.scrollWidth) {
            setIsOpen(true);
          } else {
            setIsOpen(false);
          }
        }
      }
    }
  };

  const handleMouseLeave = () => {
    setIsOpen(false);
  };

  return (
    <S.toolTipWrapper>
      <S.tableText
        $capitalize={capitalize}
        aria-describedby={triggerProps["aria-describedby"]}
        onFocus={onFocus}
        onMouseEnter={onMouseEnter}
        onMouseLeave={handleMouseLeave}
        onMouseOver={handleMouseOver}
        onPointerEnter={onPointerEnter}
        onPointerLeave={onPointerLeave}
        ref={triggerRef}
      >
        {children}
      </S.tableText>
      {tooltipState.isOpen && (
        <Tooltip
          automationContext={tooltipAutomationClasses}
          state={{
            isOpen: tooltipState.isOpen,
            open: () => {
              tooltipState.open();
            },
            close: () => {
              tooltipState.close();
            },
            setOpen: () => {},
            toggle: () => {},
          }}
          triggerRef={triggerRef}
          {...(tooltipProps.id && { id: tooltipProps.id })}
        >
          <S.tooltipText $capitalize={capitalize}>
            {tooltipText ? tooltipText : children}
          </S.tooltipText>
        </Tooltip>
      )}
    </S.toolTipWrapper>
  );
}
