import { screen } from "@testing-library/react";

import { Textarea } from "./textarea";

import { render } from "@test-utils";

describe("textarea", () => {
  it("should render text tooltip on mouse over if set", async () => {
    const { container, user } = render(
      <Textarea
        label="Text Area Label"
        labelTooltipContent="Text Tooltip"
        value="Textarea value"
      />
    );

    const button = screen.getByText("info");
    await user.hover(button);

    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });

  it("should display an error icon when isError is true", () => {
    render(
      <Textarea
        isError
        label="Text Area Label"
        labelTooltipContent="Text Tooltip"
        subText="Error message"
        value="Textarea value"
      />
    );

    const message = screen.getByText("Error message");
    expect(message).toBeInTheDocument();
    const icon = screen.getByText("cancel");
    expect(icon).toBeInTheDocument();
  });
});
