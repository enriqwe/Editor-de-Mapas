import type { ReactNode } from "react";
import { useRef } from "react";
import type { AriaTextFieldProps } from "react-aria";
import { useTextField } from "react-aria";
import { useTheme } from "styled-components";

import * as S from "./textarea.styled";
import { RequiredIcon } from "./icons/required.icon";

import { automationClass } from "@utils/automation-class";
import { Icon } from "@components/icon";

export type TextareaProps = {
  disabled?: boolean;
  isError?: boolean;
  required?: boolean;
  subText?: string;
  width?: string;
  height?: string;
  automationContext?: string;
  labelTooltipContent?: ReactNode;
} & AriaTextFieldProps<HTMLTextAreaElement>;

export function Textarea(props: TextareaProps) {
  const textareaRef = useRef(null);
  const theme = useTheme();

  const {
    automationContext,
    isError = false,
    disabled = false,
    label,
    required = false,
    subText,
    width = "300px",
    height = "88px",
    maxLength = 100,
    labelTooltipContent,
  } = props;

  const { labelProps, inputProps } = useTextField(
    {
      ...props,
      isRequired: required,
      isDisabled: disabled,
      inputElementType: "textarea",
    },
    textareaRef
  );

  const { disabled: inputDisabled = false, value = "" } = inputProps;
  const automationClasses = automationClass("textarea", automationContext);
  return (
    <S.TextareaRoot $width={width}>
      <S.LabelContainer>
        <S.MandatoryLabel>
          <S.TextboxLabel $disabled={inputDisabled} {...labelProps}>
            {label}
          </S.TextboxLabel>
          {required && <RequiredIcon />}
          {Boolean(labelTooltipContent) && (
            <Icon
              color={theme.color.icon.informative}
              fill
              icon="info"
              size="s"
              tooltipContent={labelTooltipContent}
            />
          )}
        </S.MandatoryLabel>
        {maxLength > 0 && typeof value === "string" && (
          <S.LabelCounter>
            {value.length}/{maxLength}
          </S.LabelCounter>
        )}
      </S.LabelContainer>
      <S.Textarea
        {...inputProps}
        $height={height}
        $isError={isError}
        $width={width}
        className={automationClasses}
        disabled={inputDisabled}
        ref={textareaRef}
      />
      {subText && (
        <S.TextareaText $isError={isError}>
          {isError && <Icon fill icon="cancel" size="xs" state="error" />}
          {subText}
        </S.TextareaText>
      )}
    </S.TextareaRoot>
  );
}
