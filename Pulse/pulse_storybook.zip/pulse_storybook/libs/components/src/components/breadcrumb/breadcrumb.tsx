import { Fragment } from "react";
import { useTheme } from "styled-components";

import * as S from "./breadcrumb.styled";

import { Icon } from "@components/icon";
// import { InternalLink as Link } from '../Link/InternalLink/InternalLink';
import { Link } from "@components/link/link";
import { automationClass } from "@utils/automation-class";

type Breadcrumb = {
  label: string;
  to: string;
  isDisabled?: boolean;
  onPress?: () => void;
};

export type BreadcrumbProps = {
  to: Breadcrumb[];
  automationContext?: string;
  // routerLink: React.ElementType;
};

export function Breadcrumb({
  to,
  // routerLink,
  automationContext,
}: BreadcrumbProps) {
  const theme = useTheme();
  const automationClasses = automationClass("breadcrumb", automationContext);

  return (
    <S.Breadcrumb className={automationClasses}>
      {to.map((breadcrumbs, index) => {
        const lastItem = index !== to.length - 1;
        if (lastItem) {
          return (
            <Fragment key={breadcrumbs.label + breadcrumbs.to}>
              <Link
                isDisabled={breadcrumbs.isDisabled}
                onPress={breadcrumbs.onPress}
                // routerLink={routerLink}
                size="sm"
                to={`/${breadcrumbs.to}`}
                variant="inline"
              >
                {breadcrumbs.label}
              </Link>
              <S.ContainerIcon>
                <Icon
                  color={theme.color.text.link.visited}
                  fill
                  icon="chevron_right"
                  size="xs"
                />
              </S.ContainerIcon>
            </Fragment>
          );
        }
        return <S.LastItem key="last">{breadcrumbs.label}</S.LastItem>;
      })}
    </S.Breadcrumb>
  );
}
