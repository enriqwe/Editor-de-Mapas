import type { ButtonProps } from "@components/button";

type IllustrationName =
  | "Bank"
  | "Beach"
  | "BillBoard"
  | "Calendar"
  | "Computer"
  | "Crane"
  | "Date"
  | "Document"
  | "Dollar"
  | "Drink"
  | "Home"
  | "Home2"
  | "Image"
  | "Mountain"
  | "NoResultsFound"
  | "NothingHere"
  | "PiggyBank"
  | "PlayVideo"
  | "Search"
  | "SearchError"
  | "Shopping"
  | "Stadium"
  | "Stand"
  | "Tags"
  | "ToDo"
  | "Welcome";

type WithAction = {
  actionLabel: string;
  actionHandler: () => void;
  actionType?: Extract<
    ButtonProps["variant"],
    "primary" | "secondary" | "tertiary"
  >;
};

type WithoutAction = {
  actionLabel?: never;
  actionHandler?: never;
  actionType?: never;
};

export type EmptyStateProps = (WithAction | WithoutAction) & {
  title: string;
  subTitle?: string;
  illustrationName?: IllustrationName;
  automationContext?: string;
  size?: "s" | "m" | "l";
};
