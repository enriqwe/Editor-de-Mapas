import styled, { css } from "styled-components";

import type { EmptyStateProps } from "./empty-state.types";

type Size = EmptyStateProps["size"];

export const EmptyState = styled.div<{ $size: Size }>`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  ${({ $size, theme }) => {
    if ($size === "s") {
      return {
        paddingTop: theme.spacing.x16,
        paddingBottom: theme.spacing.x24,
      };
    }

    return {
      paddingTop: theme.spacing.x40,
      paddingBottom: theme.spacing.x64,
    };
  }}
`;

export const ImageWrapper = styled.div<{ $size: Size }>`
  height: ${({ $size }) => {
    if ($size === "s") {
      return "72px";
    } else if ($size === "m") {
      return "120px";
    }
    return "150px";
  }};
`;

export const IllustrationWrapper = styled.div<{ $size: Size }>`
  svg {
    ${({ $size }) => {
      let dimension = "136px"; // Default to "l"
      if ($size === "s") {
        dimension = "56px";
      } else if ($size === "m") {
        dimension = "96px";
      }
      return css`
        width: ${dimension};
        height: ${dimension};
      `;
    }}
  }
`;

export const TitleWrapper = styled.div<{ $size: Size }>`
  display: flex;
  flex-direction: column;
  gap: ${({ $size, theme }) => {
    if ($size === "s" || $size === "m") {
      return theme.spacing.x8;
    }
    return theme.spacing.x16;
  }};
`;

export const Title = styled.h2<{ $size: Size }>`
  ${({ $size, theme }) => {
    if ($size === "s") {
      return theme.text.bodyLeadSemiBold;
    } else if ($size === "m") {
      return theme.text.heading6SemiBold;
    }
    return theme.text.heading4SemiBold;
  }}
  margin: 0;
  color: ${({ theme }) => theme.color.textHeading};
`;
export const SubTitle = styled.p<{ $size: Size }>`
  ${({ $size, theme }) => {
    if ($size === "s") {
      return theme.text.bodyMediumRegular;
    } else if ($size === "m") {
      return theme.text.bodyBaseRegular;
    }
    return theme.text.bodyLeadRegular;
  }}
  margin: 0;
  color: ${({ theme }) => theme.color.textSubheading};
  white-space: break-spaces;
`;

export const ActionButtonWrapper = styled.div<{ $size: Size }>`
  margin-top: ${({ $size, theme }) => {
    if ($size === "s") {
      return theme.spacing.x16;
    }
    return theme.spacing.x40;
  }};
`;
