import { useRef } from "react";
import type { FC, PropsWithChildren } from "react";
import { useTabListState, Item } from "react-stately";
import { useFocusRing, useTabList, mergeProps } from "react-aria";

import { Step } from "./step";
import { StepContentPanel } from "./step-content-panel";
import * as S from "./stepper.styled";
import type { StepperContainerProps } from "./stepper.types";

import { automationClass } from "@utils/automation-class";

export function Group(props: StepperContainerProps) {
  const { orientation = "horizontal", selectedKey } = props;
  const stepListState = useTabListState(props);
  const ref = useRef<HTMLDivElement>(null);

  let selectedStepIndex = -1;
  if (selectedKey) {
    selectedStepIndex = [...stepListState.collection].findIndex(
      item => item.key === selectedKey
    );
  }

  const { tabListProps } = useTabList(props, stepListState, ref);
  const automationClasses = automationClass("stepper", props.automationContext);
  const { focusProps } = useFocusRing({
    within: true,
  });

  return (
    <S.StepperContainer
      className={automationClasses}
      orientation={props.orientation}
    >
      <S.StepList
        {...mergeProps(tabListProps, focusProps)}
        orientation={props.orientation}
        ref={ref}
      >
        {[...stepListState.collection].map((item, index) => (
          <Step
            completed={selectedStepIndex > index}
            editable={item.props?.editable}
            error={item.props?.error}
            helperText={item.props?.helperText}
            indicator={index + 1}
            isLastItem={index === [...stepListState.collection].length - 1}
            item={item}
            key={item.key}
            orientation={orientation}
            selected={stepListState.selectedItem?.key === item.key}
            stepListState={stepListState}
          />
        ))}
      </S.StepList>
      {props.orientation === "horizontal" && (
        <StepContentPanel
          key={stepListState.selectedItem?.key}
          stepListState={stepListState}
        />
      )}
    </S.StepperContainer>
  );
}

type CustomItemProps = PropsWithChildren<{
  error?: boolean;
  editable?: boolean;
  helperText?: string;
  title: string;
  key: string;
}>;

export const Stepper = {
  Container: Group,
  Step: Item as unknown as FC<CustomItemProps>,
};
