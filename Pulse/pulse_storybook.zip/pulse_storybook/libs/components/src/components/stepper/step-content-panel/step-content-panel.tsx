import { useTabPanel } from "react-aria";
import { useRef } from "react";

import type { StepListStateProps } from "../stepper.types";

import * as S from "./step-content-panel.styled";

export function StepContentPanel({
  stepListState,
  ...props
}: StepListStateProps) {
  const ref = useRef(null);
  const { tabPanelProps } = useTabPanel(props, stepListState, ref);
  return (
    <S.StepPanel
      aria-selected={tabPanelProps["aria-selected"]}
      id={tabPanelProps.id}
      ref={ref}
      role={tabPanelProps.role}
      tabIndex={tabPanelProps.tabIndex}
    >
      {stepListState.selectedItem?.props.children}
    </S.StepPanel>
  );
}
