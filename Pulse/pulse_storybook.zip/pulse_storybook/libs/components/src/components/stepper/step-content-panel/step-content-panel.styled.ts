import styled from "styled-components";

export const StepPanel = styled.div`
  padding: ${({ theme }) => theme.spacing.x4};
`;
