import { useContext } from "react";
import { DisclosureStateContext } from "react-aria-components";

import { useSideNavContext } from "../side-nav-context";

import * as S from "./disclosure-trigger.styled";

import { Icon, type IconProps } from "@components/icon";

type DisclosureTriggerComponentsProps = {
  icon?: IconProps["icon"];
  label: string;
  isHighlighted: boolean;
  testId: string;
  inner?: boolean;
};

function TriggerIcon() {
  const context = useContext(DisclosureStateContext);
  return (
    <Icon
      color="inherit"
      icon={context?.isExpanded ? "keyboard_arrow_up" : "keyboard_arrow_down"}
      size="m"
    />
  );
}

export function DisclosureTrigger(props: DisclosureTriggerComponentsProps) {
  const { icon, label, inner, isHighlighted, testId } = props;

  const { isExpanded } = useSideNavContext();

  const DefaultIcon = inner ? <S.DefaultIconInner /> : <S.DefaultIcon />;

  return (
    <S.DisclosureTrigger
      data-highlighted={isHighlighted ? true : undefined}
      data-testid={`nav-trigger-${testId}`}
      slot="trigger"
    >
      {icon ?
        <S.IconWrapper>
          <Icon color="inherit" icon={icon} size="m" />
        </S.IconWrapper>
      : DefaultIcon}
      {isExpanded && (
        <>
          <span>{label}</span>
          <TriggerIcon />
        </>
      )}
    </S.DisclosureTrigger>
  );
}
