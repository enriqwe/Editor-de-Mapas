import type { TreeItem } from "./side-nav.types";

export function subtreeContains(
  item: TreeItem,
  id: string,
  matchKey?: string
): boolean {
  if (id === matchKey) {
    return true;
  }
  return (
    item.items?.some(subitem => subtreeContains(subitem, id, subitem.id)) ??
    false
  );
}

export function getTreeLevelAt(tree: TreeItem[], id: string, level = 1) {
  const item = tree.find(subitem => subtreeContains(subitem, id));
  if (item?.items) {
    return getTreeLevelAt(item.items, id, level + 1);
  }
  return level;
}

export function getItemParents(tree: TreeItem[], id: string): TreeItem[] {
  const item = tree.find(subitem => subtreeContains(subitem, id));

  if (!item) {
    return []
  }

  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion --  If item is found, it is guaranteed to have items
  return [item, ...getItemParents(item.items!, id)]
}