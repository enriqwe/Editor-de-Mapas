import { createContext, useContext, useMemo } from "react";

import type { TreeItem } from "../side-nav.types";

type SideNavContextValue = {
  activeItemId: string;
  expandedKeys: Set<string | number>;
  isExpanded: boolean;
  onExpandedChange: (key: string | undefined, treeLevelItems: TreeItem[]) => void;
  tree: TreeItem[];
}

const SideNavContext = createContext<SideNavContextValue | null>(null);

type SideNavContextProviderProps = {
  activeItemId: string;
  expandedKeys: Set<string | number>;
  isExpanded: boolean;
  onExpandedChange: (key: string | undefined, treeLevelItems: TreeItem[]) => void;
  tree: TreeItem[];
  children: React.ReactNode;
};

export function SideNavContextProvider(props: SideNavContextProviderProps) {
  const { activeItemId, expandedKeys, isExpanded, onExpandedChange, tree, children } = props;

  const contextValue = useMemo(() => {
    return {
      activeItemId,
      expandedKeys,
      isExpanded,
      onExpandedChange,
      tree,
    };
  }, [activeItemId, expandedKeys, isExpanded, onExpandedChange, tree]);

  return (
    <SideNavContext.Provider value={contextValue}>
      {children}
    </SideNavContext.Provider>
  );
}

export function useSideNavContext() {
  const context = useContext(SideNavContext);
  if (!context) {
    throw new Error("useSideNavContext must be used within a SideNavContextProvider");
  }
  return context;
}