import {
  Collection,
  Disclosure,
  DisclosurePanel,
  DisclosureGroup,
} from "react-aria-components";

import { useSideNavContext } from "../side-nav-context";
import { SubNavItem } from "../subnav-item";
import { DisclosureTrigger } from "../disclosure-trigger";
import { LinkItem } from "../link-item";

import * as S from "./nav-item.styled";

import type { NavItem, TreeItem } from "@components/side-nav/side-nav.types";
import { subtreeContains } from "@components/side-nav/side-nav.utils";

type NavItemComponentProps = {
  item: NavItem;
  treeLevelItems: TreeItem[];
}

export function NavItem(props: NavItemComponentProps) {
  const {
    item,
    treeLevelItems,
  } = props

  const {
    activeItemId,
    expandedKeys,
    onExpandedChange,
  } = useSideNavContext()

  if (item.items) {
    return (
      <S.ListItem>
        <Disclosure
          data-testid={`nav-disclosure-${item.id}`}
          id={item.id}
          onExpandedChange={isExpanded => {
            onExpandedChange(
              isExpanded ? item.id : undefined,
              treeLevelItems,
            );
          }}
        >
          <DisclosureTrigger
            icon={item.icon}
            isHighlighted={subtreeContains(item, activeItemId)}
            label={item.label}
            testId={item.id}
          />
          <DisclosurePanel>
            <DisclosureGroup
              expandedKeys={expandedKeys}
            >
              <S.List>
                <Collection items={item.items}>
                  {(subItem) => {
                    return (
                      <SubNavItem
                        item={subItem}
                        treeLevelItems={item.items}
                      />
                    )
                  }}
                </Collection>
              </S.List>
            </DisclosureGroup>
          </DisclosurePanel>
        </Disclosure>
      </S.ListItem>
    );
  }

  return (
    <S.ListItem>
      <LinkItem
        href={item.link.href}
        icon={item.icon}
        isActive={activeItemId === item.id}
        label={item.label}
        testId={item.id}
      />
    </S.ListItem>
  );
}