import type { FocusEvent, ReactElement } from "react";
import { useEffect, useState } from "react";
import { useField, useFocus } from "react-aria";
import type { ActionMeta, MultiValueRemoveProps } from "react-select";
import { createFilter, components } from "react-select";

import { Label } from "../sub-components/label/label";
import { Option } from "../sub-components/dropdown-option/dropdown-option";

import * as S from "./base-dropdown.styled";
import type {
  BaseDropdownProps,
  GroupedOption,
  Option as IOptionTypes,
  OptionMultiLevel,
} from "./base-dropdown.types";

import { Icon } from "@components/icon";
import { TextTooltip } from "@components/text-tooltip";
import { automationClass } from "@utils/automation-class";

const orderOptions = (values: IOptionTypes[]) => {
  return values.filter(v => v.isFixed).concat(values.filter(v => !v.isFixed));
};

const prepareMultiValueProp = ({
  value,
  fixedOptions,
}: {
  value: BaseDropdownProps["value"];
  fixedOptions: IOptionTypes[];
}) => {
  let updatedValue: IOptionTypes[];

  if (value) {
    if (Array.isArray(value)) {
      updatedValue = value;
    } else {
      updatedValue = [value];
    }
  } else {
    updatedValue = [];
  }

  const newData = [...fixedOptions, ...updatedValue];

  return newData.length ?
      orderOptions(
        newData.filter(
          (item, index) =>
            newData.findIndex(
              currentOption => currentOption.value === item.value
            ) === index
        )
      )
    : [];
};

const getValueProp = ({
  value,
  fixedOptions = [],
  multi = false,
}: {
  value: BaseDropdownProps["value"];
  fixedOptions: IOptionTypes[];
  multi: boolean;
}) => {
  if (!value) {
    return { value };
  }

  if (multi) {
    return {
      value: prepareMultiValueProp({ value, fixedOptions }),
    };
  }

  return { value };
};

const getDefaultValueProp = ({
  selectedOption,
  fixedOptions,
  multi,
}: {
  selectedOption: BaseDropdownProps["selectedOption"];
  fixedOptions: IOptionTypes[];
  multi: BaseDropdownProps["multi"];
}) => {
  if (multi) {
    return {
      defaultValue: prepareMultiValueProp({
        value: selectedOption,
        fixedOptions,
      }),
    };
  }

  return selectedOption ? { defaultValue: selectedOption } : undefined;
};

const isOptionType = (
  obj: IOptionTypes | GroupedOption
): obj is IOptionTypes => {
  return "value" in obj && "label" in obj;
};

const flattenOptions = (
  options: IOptionTypes[] | GroupedOption[],
  level = 0
): OptionMultiLevel[] =>
  options.flatMap(option => {
    const newOption: OptionMultiLevel = {
      value: isOptionType(option) ? option.value : "",
      label: option.label,
      isFixed: isOptionType(option) ? Boolean(option.isFixed) : false,
      isDisabled: isOptionType(option) ? Boolean(option.isDisabled) : true,
      level,
    };

    if ("options" in option) {
      const subOptions = flattenOptions(
        option.options as OptionMultiLevel[],
        level + 1
      );
      return [newOption, ...subOptions];
    }
    return [newOption];
  });

const filterOptions = (
  options: OptionMultiLevel[]
): {
  dropdownOptions: OptionMultiLevel[];
  fixedOptions: OptionMultiLevel[];
} => {
  const dropdownOptions: OptionMultiLevel[] = [];
  const fixedOptions: OptionMultiLevel[] = [];
  options.forEach(option => {
    if (option.isFixed) {
      fixedOptions.push(option);
    } else {
      dropdownOptions.push(option);
    }
  });

  return { dropdownOptions, fixedOptions };
};

export function BaseDropdown(props: BaseDropdownProps) {
  const {
    label,
    Component,
    required = false,
    multi = false,
    disabled = false,
    additionalText,
    options,
    type,
    selectedOption,
    onSelectedOption,
    onFocus,
    onBlur,
    error = false,
    placeholder = "",
    noOptionsMessage,
    closeMenuOnSelect = true,
    hideSelectedOptions = false,
    value,
    automationContext,
    dropdownIndicatorIcon,
    searchable = true,
    transparent = false,
    dropdownInline = false,
    menuPlacement = "auto",
    isClearable = false,
    labelTooltipContent,
    maxLength,
  } = props;

  const automationClasses = automationClass("dropdown", automationContext);
  const handleFocus = (e: FocusEvent) => onFocus?.(e);
  const handleOnBlur = (e: FocusEvent) => onBlur?.(e);

  useFocus({
    onFocus: handleFocus,
    onBlur: handleOnBlur,
  });

  const { labelProps, fieldProps, descriptionProps, errorMessageProps } =
    useField(props);

  const flattenedOptions = flattenOptions(options);

  const { dropdownOptions, fixedOptions } = filterOptions(flattenedOptions);

  const [valueProp, setValueProp] = useState(value);

  const defaultValueProp = getDefaultValueProp({
    selectedOption,
    fixedOptions,
    multi,
  });

  function DropdownIndicatorFunction(
    icon: ReactElement | null | undefined,
    menuIsOpen?: boolean
  ) {
    return (
      icon || (
        <Icon
          icon={menuIsOpen ? "expand_less" : "expand_more"}
          size="m"
          state={disabled ? "disabled" : "default"}
        />
      )
    );
  }

  const onChange = (newValue: unknown, actionMeta: ActionMeta<unknown>) => {
    const finalValue = actionMeta.action === "clear" ? fixedOptions : newValue;

    const updatedValues =
      Array.isArray(finalValue) ? orderOptions(finalValue) : finalValue;

    setValueProp(updatedValues as IOptionTypes);

    onSelectedOption(updatedValues as IOptionTypes);
  };

  const getNoOptionsMessage = (obj: { inputValue: string }) => {
    return typeof noOptionsMessage === "function" ?
        noOptionsMessage(obj) // Call the function if it's a function
      : noOptionsMessage; // Default message as a string or node
  };

  useEffect(() => {
    setValueProp(value);
  }, [value]);

  return (
    <S.Wrapper
      $dropdownInline={dropdownInline}
      className={automationClasses}
      onBlur={onBlur}
      onFocus={onFocus}
    >
      {label && (
        <Label
          disabled={disabled}
          dropdownInline={dropdownInline}
          labelProps={labelProps}
          labelTooltipContent={labelTooltipContent}
          name={label}
          required={required}
        />
      )}
      <S.DropdownWrapper $dropdownInline={dropdownInline}>
        <Component
          {...getValueProp({
            value: valueProp,
            fixedOptions,
            multi,
          })}
          {...defaultValueProp}
          closeMenuOnSelect={closeMenuOnSelect}
          components={{
            IndicatorSeparator: null,
            ClearIndicator: props => (
              <Icon
                icon="close"
                onClick={props.clearValue}
                size="m"
                state={disabled ? "disabled" : "default"}
              />
            ),
            MultiValueRemove: (props: MultiValueRemoveProps) =>
              !(props.data as IOptionTypes).isFixed ?
                <components.MultiValueRemove {...props}>
                  <Icon
                    color="inherit"
                    icon="close"
                    size="xs"
                    state={disabled ? "disabled" : "default"}
                  />
                </components.MultiValueRemove>
              : null,
            Option,
            DropdownIndicator: props =>
              DropdownIndicatorFunction(
                dropdownIndicatorIcon,
                props.selectProps.menuIsOpen
              ),
            MultiValueLabel: props => (
              <TextTooltip tooltipText={props.data.label}>
                <S.MultiValueLabel $isFixed={props.data.isFixed}>
                  {props.data.label}
                </S.MultiValueLabel>
              </TextTooltip>
            ),
            Input: props => (
              <components.Input
                {...props}
                {...(type === "creatable" && maxLength && { maxLength })}
              />
            ),
          }}
          createOptionPosition="first"
          filterOption={createFilter({
            stringify: option => option.label,
          })}
          formatGroupLabel={data => <S.GroupLabel>{data.label}</S.GroupLabel>}
          hideSelectedOptions={hideSelectedOptions}
          isClearable={isClearable}
          isDisabled={disabled}
          isMulti={multi}
          isSearchable={searchable}
          menuPlacement={menuPlacement}
          menuPosition="fixed"
          menuShouldScrollIntoView={false}
          noOptionsMessage={getNoOptionsMessage}
          onChange={onChange}
          options={dropdownOptions}
          placeholder={placeholder}
          styles={S.Dropdown(error, transparent, disabled)}
          {...(type === "creatable" &&
            props.isValidNewOption && {
              isValidNewOption: props.isValidNewOption,
            })}
          {...(type === "creatable" &&
            props.formatCreateLabel && {
              formatCreateLabel: props.formatCreateLabel,
            })}
          {...fieldProps}
        />
      </S.DropdownWrapper>
      {additionalText &&
        (error ?
          <S.AdditionalText {...errorMessageProps} className="dropdown-error">
            {additionalText}
          </S.AdditionalText>
        : <S.AdditionalText
            {...descriptionProps}
            className={disabled ? "dropdown-disabled" : ""}
          >
            {additionalText}
          </S.AdditionalText>)}
    </S.Wrapper>
  );
}
