import type { DropdownProps as baseDropdownProps } from "./base/base-dropdown.types";

export type DropdownProps = Omit<baseDropdownProps, "Component" | "type">;
