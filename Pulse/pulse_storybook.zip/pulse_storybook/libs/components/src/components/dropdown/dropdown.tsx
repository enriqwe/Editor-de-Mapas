import Select from "react-select";

import type { DropdownProps } from "./dropdown.types";
import { BaseDropdown } from "./base/base-dropdown";

export function Dropdown(props: DropdownProps) {
  return <BaseDropdown Component={Select} type="regular" {...props} />;
}
