import styled, { css } from "styled-components";

export const Label = styled.label`
  display: flex;
  font-weight: ${({ theme }) => theme.font.weights.semibold};
  font-size: ${({ theme }) => theme.font.sizes.sm.fontSize};
  line-height: ${({ theme }) => theme.font.sizes.sm.lineHeight};
  color: ${({ theme }) => theme.color.text.body};
  align-items: center;
  padding-right: ${({ theme }) => theme.spacing.x6};

  &.dropdown-disabled {
    color: ${({ theme }) => theme.color.text.disabled};
  }
`;

export const RequiredField = styled.span<{ disabled: boolean }>`
  color: ${({ theme, disabled }) =>
    disabled ? theme.color.icon.disabled : theme.color.icon.error};
  margin-left: ${({ theme }) => theme.spacing.x4};
  &::before {
    content: "*";
  }
`;

export const LabelWrapper = styled.div<{
  $dropdownInline: boolean | undefined;
}>`
  display: flex;
  align-items: center;
  padding: 0px ${({ theme }) => theme.spacing.x6}
    ${({ theme }) => theme.spacing.x8} 0;
  ${props => {
    if (props.$dropdownInline) {
      return css`
        flex: 1;
        padding: 0;
      `;
    }
  }};
`;
