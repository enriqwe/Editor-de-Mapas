import CreatableSelect from "react-select/creatable";

import { BaseDropdown } from "../base/base-dropdown";

import type { CreatableDropdownProps } from "./creatable-dropdown.types";

export function CreatableDropdown(props: CreatableDropdownProps) {
  return (
    <BaseDropdown Component={CreatableSelect} type="creatable" {...props} />
  );
}
