import type { ReactNode } from "react";
import { useTheme } from "styled-components";
import type { FieldAria } from "react-aria";

import * as s from "./label.styled";

import { Icon } from "@components/icon";

type LabelProps = {
  dropdownInline: boolean;
  labelProps: FieldAria["labelProps"];
  disabled: boolean;
  name: string;
  required: boolean;
  labelTooltipContent: ReactNode;
};

export function Label({
  dropdownInline,
  labelProps,
  disabled,
  name,
  required,
  labelTooltipContent,
}: LabelProps) {
  const theme = useTheme();

  return (
    <s.LabelWrapper $dropdownInline={dropdownInline}>
      <s.Label {...labelProps} className={disabled ? "dropdown-disabled" : ""}>
        {name}
        {required && <s.RequiredField disabled={disabled} />}
      </s.Label>
      {Boolean(labelTooltipContent) && (
        <Icon
          color={theme.color.icon.informative}
          fill
          icon="info"
          size="s"
          tooltipContent={labelTooltipContent}
        />
      )}
    </s.LabelWrapper>
  );
}
