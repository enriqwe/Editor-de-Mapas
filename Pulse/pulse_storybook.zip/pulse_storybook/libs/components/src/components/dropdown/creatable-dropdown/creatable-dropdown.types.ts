import type { CreatableDropdownProps as baseCreatableDropdownProps } from "../base/base-dropdown.types";

export type CreatableDropdownProps = Omit<
  baseCreatableDropdownProps,
  "Component" | "type"
>;
