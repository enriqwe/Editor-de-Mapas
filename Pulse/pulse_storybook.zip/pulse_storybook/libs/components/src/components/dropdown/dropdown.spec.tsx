import { screen } from "@testing-library/react";
import { axe, toHaveNoViolations } from "jest-axe";
import type { ComponentProps } from "react";

import { Dropdown } from "./dropdown";

import { render } from "@test-utils";

let options = [
  { value: "option one", label: "Option one" },
  { value: "option two", label: "Option two" },
  { value: "option three", label: "Option three", isDisabled: true },
];

let colors = [
  { value: "blue", label: "Blue" },
  { value: "red", label: "Red" },
  { value: "blue", label: "Blue" },
];

const groupedOptions = [
  { label: "Numbers", options },
  { label: "Colors", options: colors },
];

const fixedOptions = [
  { value: "fixed-option-one", label: "Fixed option one", isFixed: true },
  ...options,
  { value: "fixed-option-two", label: "Fixed option two", isFixed: true },
];
const onSelect = jest.fn();
function DefaultDropdown(props: Partial<ComponentProps<typeof Dropdown>>) {
  return (
    <Dropdown
      additionalText="Additional text"
      closeMenuOnSelect
      disabled={false}
      error={false}
      hideSelectedOptions={false}
      label="Label Dropdown"
      multi={false}
      noOptionsMessage="No options"
      onSelectedOption={onSelect}
      options={options}
      placeholder="Placeholder"
      required
      selectedOption={{ value: "option one", label: "Option one" }}
      {...props}
    />
  );
}

describe("dropdown", () => {
  beforeEach(() => jest.resetAllMocks());

  expect.extend(toHaveNoViolations);

  it("should render properly with single select", async () => {
    const { container, user } = render(<DefaultDropdown />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();

    expect(screen.getByText(/option one/i)).toBeTruthy();

    const inputDropdown = screen.getByRole("combobox");
    await user.type(inputDropdown, "Option");

    await user.click(screen.getByText(/option two/i));
    expect(onSelect).toHaveBeenCalledTimes(1);

    expect(screen.queryByText(/option one/i)).not.toBeInTheDocument();
    expect(screen.getByText(/option two/i)).toBeInTheDocument();
  });

  it("should render properly with multi select", async () => {
    const { user } = render(<DefaultDropdown multi />);

    expect(screen.getByText(/option one/i)).toBeTruthy();

    const inputDropdown = screen.getByRole("combobox");
    await user.type(inputDropdown, "Option");

    await user.click(screen.getByText(/option two/i));
    expect(onSelect).toHaveBeenCalledTimes(1);

    expect(screen.getByText(/option one/i)).toBeInTheDocument();
    expect(screen.getByText(/option two/i)).toBeInTheDocument();
  });

  it("should render properly with grouped options", async () => {
    const { user } = render(<DefaultDropdown options={groupedOptions} />);

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText(/numbers/i)).toBeTruthy();
    expect(screen.getByText(/colors/i)).toBeTruthy();
  });

  it("should render properly with a multiple level options", async () => {
    const colors5 = [
      { value: "gray2", label: "gray2" },
      { value: "white2", label: "white2" },
    ];

    const colors4 = [
      { value: "1", label: "1" },
      { value: "2", label: "2" },
      { value: "colors5", label: "colors5", options: colors5 },
    ];

    const colors3 = [
      { value: "gray", label: "gray" },
      { value: "white", label: "white" },
    ];

    const colors2 = [
      { value: "blue", label: "Blue" },
      { value: "red", label: "Red" },
      { value: "Colors", label: "Colors", options: colors3 },
      { value: "colors4", label: "colors4", options: colors4 },
    ];

    const otherGroupedOptions = [
      { label: "Numbers", options, value: "numbers" },
      { label: "colors2", options: colors2, value: "colors2" },
    ];

    const { user } = render(
      <DefaultDropdown multiLevel options={otherGroupedOptions} />
    );

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText(/numbers/i)).toBeTruthy();
    expect(screen.getByText(/gray2/i)).toBeTruthy();
  });

  it("should render a multilevel dropdown properly", async () => {
    options = [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ];

    colors = [
      { label: "Red", value: "red" },
      { label: "Blue", value: "blue" },
      { label: "Green", value: "green" },
    ];

    const fruits = [
      { label: "Apple", value: "apple" },
      { label: "Banana", value: "banana" },
      { label: "Orange", value: "orange" },
    ];

    const vehicles = [
      { label: "Car", value: "car" },
      { label: "Truck", value: "truck" },
      { label: "Bike", value: "bike" },
    ];

    const otherGroupedOptions = [
      { label: "Numbers", options, value: "numbers" },
      {
        label: "AllColors",
        value: "colors",
        options: [
          {
            label: "Primary Colors",
            value: "primary",
            options: colors,
          },
          {
            label: "Secondary Colors",
            value: "secondary",
            options: [
              { label: "Yellow", value: "yellow" },
              { label: "Purple", value: "purple" },
            ],
          },
        ],
      },
      {
        label: "Fruits",
        value: "fruits",
        options: fruits,
      },
      {
        label: "Vehicles",
        value: "vehicles",
        options: [
          {
            label: "Cars",
            value: "cars",
            options: vehicles,
          },
          {
            label: "Bikes",
            value: "bikes",
            options: [
              { label: "Mountain Bike", value: "mountainBike" },
              { label: "Road Bike", value: "roadBike" },
            ],
          },
        ],
      },
    ];
    const { user } = render(
      <DefaultDropdown multiLevel options={otherGroupedOptions} />
    );

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    // Check if the options are displayed
    expect(screen.getByText("Option 1")).toBeInTheDocument();
    expect(screen.getByText("Option 2")).toBeInTheDocument();
    expect(screen.getByText("AllColors")).toBeInTheDocument();
    expect(screen.getByText("Fruits")).toBeInTheDocument();
    expect(screen.getByText("Vehicles")).toBeInTheDocument();

    // Check if Blue option is displayed
    expect(screen.getByText("Blue")).toBeInTheDocument();

    // Click on the Blue option
    await user.click(screen.getByText("Blue"));

    // Check if the onSelect function was called with the selected option
    expect(onSelect).toHaveBeenCalledTimes(1);

    // Check if the dropdown closes after an option is selected
    expect(screen.queryByText("Option 1")).toBeNull();
    expect(screen.queryByText("Option 2")).toBeNull();
    expect(screen.queryByText("Fruits")).toBeNull();
    expect(screen.queryByText("Vehicles")).toBeNull();
    expect(screen.queryByText("Primary Colors")).toBeNull();
    expect(screen.queryByText("Secondary Colors")).toBeNull();
    expect(screen.queryByText("Red")).toBeNull();
    expect(screen.queryByText("Green")).toBeNull();
    expect(screen.queryByText("Purple")).toBeNull();
  });

  it("should render a disabled dropdown properly", async () => {
    const { container } = render(<DefaultDropdown disabled value={null} />);
    const results = await axe(container);

    expect(results).toHaveNoViolations();

    const inputDropdown = screen.getByRole("combobox", { hidden: true });

    expect(inputDropdown).toBeDisabled();
  });

  it("should render no options message if the options list is empty", async () => {
    const { user } = render(<DefaultDropdown options={[]} />);

    const inputDropdown = screen.getByRole("combobox");
    await user.click(inputDropdown);

    expect(screen.getByText(/No options/i)).toBeInTheDocument();
  });

  it("should render additional text with error message", async () => {
    const { container } = render(
      <DefaultDropdown additionalText="dropdown error message text" error />
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();
    expect(
      screen.getByText(/dropdown error message text/i)
    ).toBeInTheDocument();
  });

  it("should render text tooltip on mouse over if set", async () => {
    const { container, user } = render(
      <DefaultDropdown
        additionalText="dropdown error message text"
        error
        labelTooltipContent="Tooltip Text"
      />
    );

    const button = screen.getByText("info");
    await user.hover(button);

    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });

  it("should render text tooltip on mouse over if set when dropdown is disabled", async () => {
    const { container, user } = render(
      <DefaultDropdown
        additionalText="dropdown error message text"
        disabled
        error
        labelTooltipContent="Tooltip Text"
      />
    );

    const button = screen.getByText("info");
    await user.hover(button);

    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });

  describe("should render properly a multi dropdown with fixed options", () => {
    it("should automatically select the fixed options from the dropdown list", () => {
      render(
        <Dropdown
          label="Label Dropdown"
          multi
          noOptionsMessage="No options"
          onSelectedOption={onSelect}
          options={fixedOptions}
          placeholder="Placeholder"
        />
      );

      expect(screen.getByText("Fixed option one")).toBeInTheDocument();
      expect(screen.getByText("Fixed option two")).toBeInTheDocument();
    });

    it("should not display the remove icon for the selected fixed options", () => {
      render(<DefaultDropdown multi options={fixedOptions} />);

      expect(screen.getAllByText("close")).toHaveLength(1);
    });

    describe("should keep the selected option in the teh selected option list", () => {
      it("if the selected option is a single option", () => {
        render(<DefaultDropdown multi options={fixedOptions} />);

        expect(screen.getByText("Option one")).toBeInTheDocument();
      });

      it("if the selected option is a option list", () => {
        render(
          <DefaultDropdown
            multi
            options={fixedOptions}
            selectedOption={[
              { value: "option one", label: "Option one" },
              { value: "option two", label: "Option two" },
            ]}
          />
        );

        expect(screen.getByText("Option one")).toBeInTheDocument();
        expect(screen.getByText("Option two")).toBeInTheDocument();
      });
    });

    it("should display first the fixed options in the selected option list", () => {
      render(
        <DefaultDropdown
          automationContext="fixedDropdown"
          multi
          options={fixedOptions}
        />
      );

      expect(
        document
          .getElementsByClassName("dropdown--fixedDropdown")[0]
          ?.textContent?.match(
            /.*Fixed option one.*Fixed option two.*Option one.*/
          )
      ).not.toBeNull();
    });

    describe("should remove the fixed options from the dropdown list", () => {
      it("if the dropdown is simple", async () => {
        const { user } = render(
          <DefaultDropdown multi options={fixedOptions} />
        );

        const inputDropdown = screen.getByRole("combobox");
        await user.click(inputDropdown);

        expect(screen.getAllByText("Fixed option one")).toHaveLength(1);
        expect(screen.getAllByText("Fixed option two")).toHaveLength(1);
      });

      it("if the dropdown is grouped", async () => {
        const { user } = render(
          <DefaultDropdown
            multi
            options={[
              {
                label: "First fixed label",
                options: [
                  { value: "first-option-one", label: "Option one" },
                  {
                    value: "fixed-option-one",
                    label: "Fixed option one",
                    isFixed: true,
                  },
                ],
              },
              {
                label: "Second fixed label",
                options: [
                  { value: "option-one", label: "Option one" },
                  {
                    value: "fixed-option-two",
                    label: "Fixed option two",
                    isFixed: true,
                  },
                ],
              },
            ]}
          />
        );

        const inputDropdown = screen.getByRole("combobox");
        await user.click(inputDropdown);

        expect(screen.getAllByText("Fixed option one")).toHaveLength(1);
        expect(screen.getAllByText("Fixed option two")).toHaveLength(1);
      });

      it("if the dropdown is multilevel", async () => {
        const { user } = render(
          <DefaultDropdown
            multi
            multiLevel
            options={[
              {
                label: "First fixed label",
                value: "first-fixed-label",
                options: [
                  { value: "first-option-one", label: "Option one" },
                  {
                    value: "fixed-option-one",
                    label: "Fixed option one",
                    isFixed: true,
                  },
                ],
              },
              {
                label: "Second fixed label",
                value: "second-fixed-label",
                options: [
                  { value: "option-one", label: "Option one" },
                  {
                    value: "fixed-option-two",
                    label: "Fixed option two",
                    isFixed: true,
                  },
                ],
              },
            ]}
          />
        );

        const inputDropdown = screen.getByRole("combobox");
        await user.click(inputDropdown);

        expect(screen.getAllByText("Fixed option one")).toHaveLength(1);
        expect(screen.getAllByText("Fixed option two")).toHaveLength(1);
      });
    });

    it("should not render twice the selected option if the option is also fixed", () => {
      render(
        <DefaultDropdown
          multi
          options={fixedOptions}
          selectedOption={{
            value: "fixed-option-two",
            label: "Fixed option two",
            isFixed: true,
          }}
        />
      );

      expect(screen.getAllByText("Fixed option two")).toHaveLength(1);
    });

    it("should not call the onSelect if the fixed option is clicked", async () => {
      const { user } = render(<DefaultDropdown multi options={fixedOptions} />);

      await user.click(screen.getByText("Fixed option one"));

      expect(onSelect).not.toHaveBeenCalled();
    });

    describe("should add also the fixed options in the selected option list payload for onSelect", () => {
      it("if another option is selected", async () => {
        const { user } = render(
          <DefaultDropdown multi options={fixedOptions} />
        );

        const inputDropdown = screen.getByRole("combobox");
        await user.click(inputDropdown);

        await user.click(screen.getByText("Option two"));

        expect(onSelect).toHaveBeenCalledWith([
          {
            isFixed: true,
            isDisabled: false,
            level: 0,
            label: "Fixed option one",
            value: "fixed-option-one",
          },
          {
            isFixed: true,
            isDisabled: false,
            level: 0,
            label: "Fixed option two",
            value: "fixed-option-two",
          },
          { label: "Option one", value: "option one" },
          {
            isFixed: false,
            isDisabled: false,
            level: 0,
            label: "Option two",
            value: "option two",
          },
        ]);
      });

      it("if another option is removed", async () => {
        const { user } = render(
          <DefaultDropdown multi options={fixedOptions} />
        );

        await user.click(screen.getByText("close"));

        expect(onSelect).toHaveBeenCalledWith([
          {
            isFixed: true,
            isDisabled: false,
            level: 0,
            label: "Fixed option one",
            value: "fixed-option-one",
          },
          {
            isFixed: true,
            isDisabled: false,
            level: 0,
            label: "Fixed option two",
            value: "fixed-option-two",
          },
        ]);
      });
    });

    it("should not remove the fixed selected option from the list if the dropdown is cleared", async () => {
      const { user } = render(
        <DefaultDropdown isClearable multi options={fixedOptions} />
      );

      const inputDropdown = screen.getByRole("combobox");
      await user.click(inputDropdown);

      await user.click(screen.getByText("Option two"));

      const closeButtons = screen.getAllByText("close");
      expect(closeButtons).toHaveLength(3);

      const thirdCloseButton = closeButtons[2]!;
      await user.click(thirdCloseButton);

      expect(screen.getByText("Fixed option one")).toBeInTheDocument();
      expect(screen.getByText("Fixed option two")).toBeInTheDocument();
    });
  });
});
