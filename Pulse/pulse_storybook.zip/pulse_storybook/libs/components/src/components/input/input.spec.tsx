import { screen } from "@testing-library/react";

import { Input } from "./input";

import { render } from "@test-utils";

describe("input", () => {
  it("should have htmlFor property", async () => {
    const onChange = jest.fn();
    const expectedId = "testId";
    render(
      <Input
        id={expectedId}
        label="testLabel"
        onChange={onChange}
        value="testValue"
      />
    );
    const inputLabel = await screen.findByTestId("label");
    expect(inputLabel.getAttribute("for")).toEqual(expectedId);
  });

  it("should render text tooltip on mouse over if set", async () => {
    const onChange = jest.fn();
    const onBlur = jest.fn();
    const onFocus = jest.fn();
    const labelTooltipContent = "Tooltip Text";
    const { container, user } = render(
      <Input
        label="Text Label"
        labelTooltipContent={labelTooltipContent}
        onBlur={onBlur}
        onChange={onChange}
        onFocus={onFocus}
        value="Text Value"
      />
    );

    const button = screen.getByText("info");
    await user.hover(button);

    expect(container.getElementsByClassName("tooltip-trigger").length).toBe(1);
  });
});
