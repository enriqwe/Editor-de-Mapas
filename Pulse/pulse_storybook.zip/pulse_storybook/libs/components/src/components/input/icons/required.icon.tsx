export function RequiredIcon() {
  return (
    <svg
      fill="none"
      height="7"
      viewBox="0 0 7 7"
      width="7"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4.692 3.104L6.596 4.176L6.1 5.056L4.164 3.92L4.18 6.096H3.22L3.236 3.92L1.3 5.056L0.804 4.176L2.724 3.104L0.804 2.048L1.3 1.152L3.236 2.288L3.22 0.127999H4.18L4.164 2.288L6.1 1.152L6.596 2.048L4.692 3.104Z"
        fill="#DF320C"
      />
    </svg>
  );
}
