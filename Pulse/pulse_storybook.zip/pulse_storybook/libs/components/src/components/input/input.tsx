import type { HTMLInputTypeAttribute, FocusEvent, ReactNode } from "react";
import { useState, useRef } from "react";
import type { AriaTextFieldProps } from "react-aria";
import { useFocus, useTextField } from "react-aria";

import * as S from "./input.styled";

import { automationClass } from "@utils/automation-class";
import { IconButton } from "@components/icon-button";
import { Label } from "@components/internal";

export type InputProps = {
  label: string;
  required?: boolean;
  type?: HTMLInputTypeAttribute;
  value: string;
  placeholder?: string;
  disabled?: boolean;
  isError?: boolean;
  subText?: string;
  errorMessage?: string;
  inputSize?: number;
  automationContext?: string;
  labelTooltipContent?: ReactNode;
} & AriaTextFieldProps;

export function Input(props: InputProps) {
  const {
    type = "text",
    value,
    onChange,
    onFocus,
    onBlur,
    placeholder = "",
    isError = false,
    required = false,
    subText = "",
    automationContext,
    errorMessage = "",
    inputSize,
    labelTooltipContent,
  } = props;
  const [showPassword, setShowPassword] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  const finalType = type === "password" && showPassword ? "text" : type;

  const isDisabled = props.isDisabled ?? props.disabled ?? false;

  const { labelProps, inputProps, descriptionProps, errorMessageProps } =
    useTextField(
      {
        ...props,
        isDisabled,
      },
      ref
    );

  const handleFocus = (e: FocusEvent<HTMLInputElement>) => {
    onFocus && onFocus(e);
  };
  const handleOnBlur = (e: FocusEvent<HTMLInputElement>) => {
    onBlur && onBlur(e);
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange && onChange(e.currentTarget.value);

    if (!e.currentTarget.value && showPassword) {
      setShowPassword(false);
    }
  };

  useFocus({
    onFocus: handleFocus,
    onBlur: handleOnBlur,
  });

  const automationClasses = automationClass("input", automationContext);
  return (
    <S.Root>
      {props.label && (
        <Label
          {...labelProps}
          infoTooltipContent={labelTooltipContent}
          isDisabled={isDisabled}
          isRequired={required}
          label={props.label}
        />
      )}
      <S.InputContainer>
        <S.Input
          {...inputProps}
          $isError={isError}
          className={automationClasses}
          onBlur={onBlur}
          onChange={handleChange}
          onClick={() => ref.current?.focus()}
          onFocus={onFocus}
          placeholder={placeholder}
          ref={ref}
          size={inputSize}
          type={finalType}
          value={value}
        />
        {type === "password" && (
          <S.InputIconContainer>
            <IconButton
              iconName={showPassword ? "visibility_off" : "visibility"}
              isDisabled={isDisabled}
              onPress={() => {
                setShowPassword(!showPassword);
              }}
            />
          </S.InputIconContainer>
        )}
      </S.InputContainer>
      {subText && (!isError || !errorMessage) && (
        <S.HelperText
          $disabled={isDisabled}
          $isError={isError}
          {...descriptionProps}
        >
          {subText}
        </S.HelperText>
      )}
      {errorMessage && isError && (
        <S.HelperText
          $disabled={isDisabled}
          $isError={isError}
          {...errorMessageProps}
        >
          {errorMessage}
        </S.HelperText>
      )}
    </S.Root>
  );
}
