import { useRef } from "react";
import { useTabListState, Item } from "react-stately";
import { useTab, useTabPanel, useTabList } from "react-aria";

import * as S from "./tab.styled";
import type {
  TabGroupProps,
  TabListStateProps,
  TabItemProps,
} from "./tab.types";

import { automationClass } from "@utils/automation-class";

function Group(props: TabGroupProps) {
  const state = useTabListState(props);
  const ref = useRef<HTMLDivElement>(null);
  const { tabListProps } = useTabList(props, state, ref);
  const automationClasses = automationClass(
    "tabGroup",
    props.automationContext
  );

  return (
    <S.TabsContainer className={automationClasses}>
      <S.TabList ref={ref} {...tabListProps}>
        {[...state.collection].map(item => (
          <TabItem item={item} key={item.key} state={state} />
        ))}
      </S.TabList>
      <TabContentPanel key={state.selectedItem?.key} state={state} />
    </S.TabsContainer>
  );
}

function TabItem({ item, state }: TabItemProps) {
  const { key, rendered } = item;
  const ref = useRef(null);
  const { tabProps } = useTab({ key }, state, ref);

  return (
    <S.TabCell
      {...tabProps}
      $disabled={state.isDisabled}
      $selected={state.selectedKey === key}
      ref={ref}
    >
      {rendered}
    </S.TabCell>
  );
}

function TabContentPanel({ state, ...props }: TabListStateProps) {
  const ref = useRef(null);
  const { tabPanelProps } = useTabPanel(props, state, ref);
  return (
    <S.TabPanel {...tabPanelProps} ref={ref}>
      {state.selectedItem?.props.children}
    </S.TabPanel>
  );
}

export const Tab = {
  Group,
  Item,
};
