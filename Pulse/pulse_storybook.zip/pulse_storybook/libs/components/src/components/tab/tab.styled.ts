import styled, { css } from "styled-components";

export const TabsContainer = styled.div`
  font-family: ${({ theme }) => theme.font.fontFamily};
`;

export const TabList = styled.div`
  border-bottom: ${({ theme }) =>
    `${theme.border.widthXS} solid ${theme.color.border.tabGroup.default}`};
  display: flex;
`;

export const TabPanel = styled.div`
  padding: ${({ theme }) => theme.spacing.x16};
`;

export const TabCell = styled.div<{
  $selected?: boolean;
  $disabled?: boolean;
}>`
  border: none;
  cursor: pointer;
  width: fit-content;
  color: ${({ theme }) => theme.color.text.tab.default};
  padding: ${({ theme }) => theme.spacing.x16};
  font-family: ${({ theme }) => theme.font.fontFamily};
  ${({ theme }) =>
    theme.font.resolve(theme.font.sizes.m, theme.font.weights.semibold)};

  ${({ theme, $selected }) =>
    $selected &&
    css`
      color: ${theme.color.text.tab.active};
      border-bottom: ${theme.border.widthS} solid
        ${theme.color.border.tab.active};
    `}

  ${({ theme, $disabled }) =>
    $disabled &&
    css`
      color: ${theme.color.text.disabled};
      cursor: unset;
    `}

  &:hover {
    color: ${({ theme, $disabled }) =>
      !$disabled && theme.color.text.tab.hover};
  }
`;
