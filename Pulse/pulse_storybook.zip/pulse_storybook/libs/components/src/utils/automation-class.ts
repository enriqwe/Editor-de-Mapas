import classNames from "classnames";

export const automationClass = (baseClass: string, identifier?: string) => {
  return classNames(baseClass, {
    [`${baseClass}--${identifier}`]: Boolean(identifier),
  });
};
