import { ThemeProvider } from "styled-components";
import { render as originalRender } from "@testing-library/react";
import { themes } from "@pulse/foundations";
import type { RenderOptions, RenderResult } from "@testing-library/react";
import type { ReactElement } from "react";
import userEvent from "@testing-library/user-event";
import type { UserEvent } from "@testing-library/user-event";

function AllProviders({ children }: React.PropsWithChildren) {
  return <ThemeProvider theme={themes.default}>{children}</ThemeProvider>;
}

export function render(
  ui: ReactElement,
  options?: RenderOptions
): RenderResult & { user: UserEvent } {
  return {
    ...originalRender(ui, { wrapper: AllProviders, ...options }),
    user: userEvent.setup(),
  };
}
