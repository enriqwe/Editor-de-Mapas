import path from "node:path";

import { libInjectCss } from "vite-plugin-lib-inject-css";
import { defineConfig } from "vite";
import wyw from "@wyw-in-js/vite";
import react from "@vitejs/plugin-react";
import dts from "vite-plugin-dts";

const components = {
  "accordion": "src/components/accordion/index.ts",
  "avatar": "src/components/avatar/public.ts",
  "breadcrumb": "src/components/breadcrumb/index.ts",
  "modal": "src/components/modal/index.ts",
  "box": "src/components/box/index.ts",
  "button-menu": "src/components/button-menu/index.ts",
  "button": "src/components/button/index.ts",
  "card": "src/components/card/index.ts",
  "checkbox": "src/components/checkbox/index.ts",
  "action-chip": "src/components/chips/action-chip/index.ts",
  "choice-chip": "src/components/chips/choice-chip/index.ts",
  // "calendar": "src/components/date-pickers/calendar/index.ts",
  "date-picker": "src/components/date-pickers/date-picker/index.ts",
  "date-range-picker": "src/components/date-pickers/date-range-picker/index.ts",
  "date-utils": "src/utils/date.ts",
  "drawer": "src/components/drawer/index.ts",
  "dropdown": "src/components/dropdown/index.ts",
  "empty-state": "src/components/empty-state/index.ts",
  "icon-button": "src/components/icon-button/index.ts",
  "icon": "src/components/icon/index.ts",
  "input": "src/components/input/index.ts",
  "legend": "src/components/legend/index.ts",
  "link": "src/components/link/index.ts",
  "overflow-menu": "src/components/overflow-menu/index.ts",
  "overlay-spinner": "src/components/overlay-spinner/index.ts",
  "pagination-bar": "src/components/pagination-bar/index.ts",
  "progress-bar": "src/components/progress-bar/index.ts",
  "radio": "src/components/radio/index.ts",
  // "range-calendar": "src/components/date-pickers/calendar/index.ts",
  "select-with-pagination": "src/components/select-with-pagination/index.ts",
  "side-nav": "src/components/side-nav/index.ts",
  "spinner": "src/components/spinner/index.ts",
  "stepper": "src/components/stepper/index.ts",
  "tab": "src/components/tab/index.ts",
  "table": "src/components/table/index.ts",
  "table-v2": "src/components/table-v2/index.ts",
  "tag": "src/components/tag/index.ts",
  "text-popover": "src/components/text-popover/index.ts",
  "text-tooltip": "src/components/text-tooltip/index.ts",
  "textarea": "src/components/textarea/index.ts",
  "time-picker": "src/components/time-picker/index.ts",
  "toggle": "src/components/toggle/index.ts",
  "topbar": "src/components/topbar/index.ts",
  "context": "src/providers/public.ts",
  "hooks": "src/hooks/public.ts",
};

export default defineConfig({
  resolve: {
    alias: {
      "@components": path.resolve(__dirname, "./src/components"),
      "@utils": path.resolve(__dirname, "./src/utils"),
      "@hooks": path.resolve(__dirname, "./src/hooks"),
      "@providers": path.resolve(__dirname, "./src/providers"),
    },
  },
  build: {
    minify: false,
    terserOptions: {
      compress: false,
      mangle: false,
      keep_fnames: true,
      keep_classnames: true,
    },
    // cssCodeSplit: true,
    sourcemap: true,
    lib: {
      formats: ["es"],
      entry: {
        index: "src/index.ts",
        // add all components to the entry
        ...components,
      },
      // name: "index",
      // fileName: "index",
    },
    rollupOptions: {
      external: [
        "react",
        "react-dom",
        "styled-components",
        // "@pulse/foundations",
      ],
    },
  },
  plugins: [
    react(),
    wyw({
      displayName: true,
      include: ["**/*.{ts,tsx}"],
      babelOptions: {
        presets: ["@babel/preset-typescript", "@babel/preset-react"],
      },
    }),
    libInjectCss(),
    process.env.NODE_ENV === "production" &&
      dts({
        rollupTypes: true,
        // root: resolve(__dirname, `src`),
        // tsconfigPath: resolve(__dirname, "tsconfig.json"),
      }),
  ],
});
