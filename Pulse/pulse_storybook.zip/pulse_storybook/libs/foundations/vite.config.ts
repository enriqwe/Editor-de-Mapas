import { libInjectCss } from "vite-plugin-lib-inject-css";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import dts from "vite-plugin-dts";

export default defineConfig({
  build: {
    sourcemap: true,
    lib: {
      formats: ["es"],
      entry: {
        "index": "src/index.ts",
        "default.theme.css": "src/themes/default.theme.css",
      },
    },
    rollupOptions: {
      external: ["react", "react-dom"],
    },
  },
  plugins: [
    react(),
    libInjectCss(),
    process.env.NODE_ENV === "production" &&
      dts({
        rollupTypes: true,
      }),
  ],
});
