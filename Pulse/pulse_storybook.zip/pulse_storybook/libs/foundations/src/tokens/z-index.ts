export const zIndex = {
  /* @deprecated use 'deepdive' instead*/
  negative: -1,
  /* @deprecated use 'default' instead*/
  auto: 0,
  int1: 1,
  int2: 2,
  int3: 3,
  /* @deprecated use 'stickied' instead*/
  x100: 100,
  /* @deprecated use 'popup' instead*/
  x200: 200,
  /* @deprecated use 'dropdown' instead*/
  x300: 300,
  /* @deprecated use 'overlay' instead*/
  x400: 400,
  /* @deprecated use 'modal' instead*/
  x500: 500,
  /* @deprecated use 'toast' instead*/
  x99999: 99999,
  deepdive: -1,
  default: 0,
  stickied: 100,
  popup: 200,
  dropdown: 300,
  overlay: 400,
  modal: 500,
  spinner: 600,
  toast: 99999,
};

export type ZIndex = typeof zIndex;
