export type FontSizeProp = {
  fontSize: string;
  lineHeight: string;
};

export type FontWeightProp = {
  regular: number;
  semibold: number;
  bold: number;
};

export type TypographyProp = {
  fontFamily: string;
  sizes: {
    xs: FontSizeProp;
    sm: FontSizeProp;
    m: FontSizeProp;
    l: FontSizeProp;
    xl: FontSizeProp;
    xxl: FontSizeProp;
    xxxl: FontSizeProp;
    h: FontSizeProp;
  };
  weights: FontWeightProp;
};

export type TypographyMethods = {
  resolve: (size: FontSizeProp, weight?: number) => string;
};

export const typographyApi: TypographyMethods = {
  resolve: (size, weight = 400): string => `
  font-size: ${size.fontSize};
  line-height: ${size.lineHeight};
  font-weight: ${weight};
  `,
};

export const typography: TypographyProp = {
  fontFamily: '"Nunito Sans", sans-serif',
  sizes: {
    xs: {
      fontSize: "0.75rem",
      lineHeight: "1.125rem",
    },
    sm: {
      fontSize: "0.875rem",
      lineHeight: "1.25rem",
    },
    m: {
      fontSize: "1rem",
      lineHeight: "1.5rem",
    },
    l: {
      fontSize: "1.125rem",
      lineHeight: "1.5rem",
    },
    xl: {
      fontSize: "1.25rem",
      lineHeight: "1.625rem",
    },
    xxl: {
      fontSize: "1.5rem",
      lineHeight: "2.125rem",
    },
    xxxl: {
      fontSize: "1.75rem",
      lineHeight: "2.25rem",
    },
    h: {
      fontSize: "2rem",
      lineHeight: "2.5rem",
    },
  },
  weights: {
    regular: 400,
    semibold: 600,
    bold: 700,
  },
};
