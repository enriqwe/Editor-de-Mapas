import * as mobileFontTypes from "./fonts.mobile";
import * as desktopFontTypes from "./fonts.desktop-tablet";

export const overlineRegular = `
  ${mobileFontTypes.overlineRegularCSS}
  ${desktopFontTypes.overlineRegularCSS}
`;
export const overlineSemiBold = `
  ${mobileFontTypes.overlineSemiBoldCSS}
  ${desktopFontTypes.overlineSemiBoldCSS}
`;
export const overlineBold = `
  ${mobileFontTypes.overlineBoldCSS}
  ${desktopFontTypes.overlineBoldCSS}
`;
export const overlineBlack = `
  ${mobileFontTypes.overlineBlackCSS}
  ${desktopFontTypes.overlineBlackCSS}
`;
export const display4Regular = `
  ${mobileFontTypes.display4RegularCSS}
  ${desktopFontTypes.display4RegularCSS}
`;
export const display4SemiBold = `
  ${mobileFontTypes.display4SemiBoldCSS}
  ${desktopFontTypes.display4SemiBoldCSS}
`;
export const display4Bold = `
  ${mobileFontTypes.display4BoldCSS}
  ${desktopFontTypes.display4BoldCSS}
`;
export const display4Black = `
  ${mobileFontTypes.display4BlackCSS}
  ${desktopFontTypes.display4BlackCSS}
`;
export const display3Regular = `
  ${mobileFontTypes.display3RegularCSS}
  ${desktopFontTypes.display3RegularCSS}
`;
export const display3SemiBold = `
  ${mobileFontTypes.display3SemiBoldCSS}
  ${desktopFontTypes.display3SemiBoldCSS}
`;
export const display3Bold = `
  ${mobileFontTypes.display3BoldCSS}
  ${desktopFontTypes.display3BoldCSS}
`;
export const display3Black = `
  ${mobileFontTypes.display3BlackCSS}
  ${desktopFontTypes.display3BlackCSS}
`;
export const display2Regular = `
  ${mobileFontTypes.display2RegularCSS}
  ${desktopFontTypes.display2RegularCSS}
`;
export const display2SemiBold = `
  ${mobileFontTypes.display2SemiBoldCSS}
  ${desktopFontTypes.display2SemiBoldCSS}
`;
export const display2Bold = `
  ${mobileFontTypes.display2BoldCSS}
  ${desktopFontTypes.display2BoldCSS}
`;
export const display2Black = `
  ${mobileFontTypes.display2BlackCSS}
  ${desktopFontTypes.display2BlackCSS}
`;
export const display1Regular = `
  ${mobileFontTypes.display1RegularCSS}
  ${desktopFontTypes.display1RegularCSS}
`;
export const display1SemiBold = `
  ${mobileFontTypes.display1SemiBoldCSS}
  ${desktopFontTypes.display1SemiBoldCSS}
`;
export const display1Bold = `
  ${mobileFontTypes.display1BoldCSS}
  ${desktopFontTypes.display1BoldCSS}
`;
export const display1Black = `
  ${mobileFontTypes.display1BlackCSS}
  ${desktopFontTypes.display1BlackCSS}
`;
export const heading1Regular = `
  ${mobileFontTypes.heading1RegularCSS}
  ${desktopFontTypes.heading1RegularCSS}
`;
export const heading1SemiBold = `
  ${mobileFontTypes.heading1SemiBoldCSS}
  ${desktopFontTypes.heading1SemiBoldCSS}
`;
export const heading1Bold = `
  ${mobileFontTypes.heading1BoldCSS}
  ${desktopFontTypes.heading1BoldCSS}
`;
export const heading1Black = `
  ${mobileFontTypes.heading1BlackCSS}
  ${desktopFontTypes.heading1BlackCSS}
`;
export const heading2Regular = `
  ${mobileFontTypes.heading2RegularCSS}
  ${desktopFontTypes.heading2RegularCSS}
`;
export const heading2SemiBold = `
  ${mobileFontTypes.heading2SemiBoldCSS}
  ${desktopFontTypes.heading2SemiBoldCSS}
`;
export const heading2Bold = `
  ${mobileFontTypes.heading2BoldCSS}
  ${desktopFontTypes.heading2BoldCSS}
`;
export const heading2Black = `
  ${mobileFontTypes.heading2BlackCSS}
  ${desktopFontTypes.heading2BlackCSS}
`;
export const heading3Regular = `
  ${mobileFontTypes.heading3RegularCSS}
  ${desktopFontTypes.heading3RegularCSS}
`;
export const heading3SemiBold = `
  ${mobileFontTypes.heading3SemiBoldCSS}
  ${desktopFontTypes.heading3SemiBoldCSS}
`;
export const heading3Bold = `
  ${mobileFontTypes.heading3BoldCSS}
  ${desktopFontTypes.heading3BoldCSS}
`;
export const heading3Black = `
  ${mobileFontTypes.heading3BlackCSS}
  ${desktopFontTypes.heading3BlackCSS}
`;
export const heading4Regular = `
  ${mobileFontTypes.heading4RegularCSS}
  ${desktopFontTypes.heading4RegularCSS}
`;
export const heading4SemiBold = `
  ${mobileFontTypes.heading4SemiBoldCSS}
  ${desktopFontTypes.heading4SemiBoldCSS}
`;
export const heading4Bold = `
  ${mobileFontTypes.heading4BoldCSS}
  ${desktopFontTypes.heading4BoldCSS}
`;
export const heading4Black = `
  ${mobileFontTypes.heading4BlackCSS}
  ${desktopFontTypes.heading4BlackCSS}
`;
export const heading5Regular = `
  ${mobileFontTypes.heading5RegularCSS}
  ${desktopFontTypes.heading5RegularCSS}
`;
export const heading5SemiBold = `
  ${mobileFontTypes.heading5SemiBoldCSS}
  ${desktopFontTypes.heading5SemiBoldCSS}
`;
export const heading5Bold = `
  ${mobileFontTypes.heading5BoldCSS}
  ${desktopFontTypes.heading5BoldCSS}
`;
export const heading5Black = `
  ${mobileFontTypes.heading5BlackCSS}
  ${desktopFontTypes.heading5BlackCSS}
`;
export const heading6Regular = `
  ${mobileFontTypes.heading6RegularCSS}
  ${desktopFontTypes.heading6RegularCSS}
`;
export const heading6SemiBold = `
  ${mobileFontTypes.heading6SemiBoldCSS}
  ${desktopFontTypes.heading6SemiBoldCSS}
`;
export const heading6Bold = `
  ${mobileFontTypes.heading6BoldCSS}
  ${desktopFontTypes.heading6BoldCSS}
`;
export const heading6Black = `
  ${mobileFontTypes.heading6BlackCSS}
  ${desktopFontTypes.heading6BlackCSS}
`;
export const bodyLeadRegular = `
  ${mobileFontTypes.bodyLeadRegularCSS}
  ${desktopFontTypes.bodyLeadRegularCSS}
`;
export const bodyLeadSemiBold = `
  ${mobileFontTypes.bodyLeadSemiBoldCSS}
  ${desktopFontTypes.bodyLeadSemiBoldCSS}
`;
export const bodyLeadBold = `
  ${mobileFontTypes.bodyLeadBoldCSS}
  ${desktopFontTypes.bodyLeadBoldCSS}
`;
export const bodyLeadBlack = `
  ${mobileFontTypes.bodyLeadBlackCSS}
  ${desktopFontTypes.bodyLeadBlackCSS}
`;
export const bodyBaseRegular = `
  ${mobileFontTypes.bodyBaseRegularCSS}
  ${desktopFontTypes.bodyBaseRegularCSS}
`;
export const bodyBaseSemiBold = `
  ${mobileFontTypes.bodyBaseSemiBoldCSS}
  ${desktopFontTypes.bodyBaseSemiBoldCSS}
`;
export const bodyBaseBold = `
  ${mobileFontTypes.bodyBaseBoldCSS}
  ${desktopFontTypes.bodyBaseBoldCSS}
`;
export const bodyBaseBlack = `
  ${mobileFontTypes.bodyBaseBlackCSS}
  ${desktopFontTypes.bodyBaseBlackCSS}
`;
export const bodyMediumRegular = `
  ${mobileFontTypes.bodyMediumRegularCSS}
  ${desktopFontTypes.bodyMediumRegularCSS}
`;
export const bodyMediumSemiBold = `
  ${mobileFontTypes.bodyMediumSemiBoldCSS}
  ${desktopFontTypes.bodyMediumSemiBoldCSS}
`;
export const bodyMediumBold = `
  ${mobileFontTypes.bodyMediumBoldCSS}
  ${desktopFontTypes.bodyMediumBoldCSS}
`;
export const bodyMediumBlack = `
  ${mobileFontTypes.bodyMediumBlackCSS}
  ${desktopFontTypes.bodyMediumBlackCSS}
`;
export const bodySmallRegular = `
  ${mobileFontTypes.bodySmallRegularCSS}
  ${desktopFontTypes.bodySmallRegularCSS}
`;
export const bodySmallSemiBold = `
  ${mobileFontTypes.bodySmallSemiBoldCSS}
  ${desktopFontTypes.bodySmallSemiBoldCSS}
`;
export const bodySmallBold = `
  ${mobileFontTypes.bodySmallBoldCSS}
  ${desktopFontTypes.bodySmallBoldCSS}
`;
export const bodySmallBlack = `
  ${mobileFontTypes.bodySmallBlackCSS}
  ${desktopFontTypes.bodySmallBlackCSS}
`;