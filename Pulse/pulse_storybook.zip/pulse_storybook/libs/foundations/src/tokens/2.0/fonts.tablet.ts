import { mMin } from './breakpoint';

export const display4Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "6rem",
  "fontWeight": 400,
  "lineHeight": "7.5rem"
}
export const display4SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "6rem",
  "fontWeight": 600,
  "lineHeight": "7.5rem"
}
export const display4Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "6rem",
  "fontWeight": 700,
  "lineHeight": "7.5rem"
}
export const display4Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "6rem",
  "fontWeight": 900,
  "lineHeight": "7.5rem"
}
export const display3Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4.5rem",
  "fontWeight": 400,
  "lineHeight": "6rem"
}
export const display3SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4.5rem",
  "fontWeight": 600,
  "lineHeight": "6rem"
}
export const display3Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4.5rem",
  "fontWeight": 700,
  "lineHeight": "6rem"
}
export const display3Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4.5rem",
  "fontWeight": 900,
  "lineHeight": "6rem"
}
export const display2Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4rem",
  "fontWeight": 400,
  "lineHeight": "5rem"
}
export const display2SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4rem",
  "fontWeight": 600,
  "lineHeight": "5rem"
}
export const display2Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4rem",
  "fontWeight": 700,
  "lineHeight": "5rem"
}
export const display2Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "4rem",
  "fontWeight": 900,
  "lineHeight": "5rem"
}
export const display1Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3.5rem",
  "fontWeight": 400,
  "lineHeight": "4.5rem"
}
export const display1SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3.5rem",
  "fontWeight": 600,
  "lineHeight": "4.5rem"
}
export const display1Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3.5rem",
  "fontWeight": 700,
  "lineHeight": "4.5rem"
}
export const display1Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3.5rem",
  "fontWeight": 900,
  "lineHeight": "4.5rem"
}
export const heading1Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3rem",
  "fontWeight": 400,
  "lineHeight": "4rem"
}
export const heading1SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3rem",
  "fontWeight": 600,
  "lineHeight": "4rem"
}
export const heading1Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3rem",
  "fontWeight": 700,
  "lineHeight": "4rem"
}
export const heading1Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "3rem",
  "fontWeight": 900,
  "lineHeight": "4rem"
}
export const heading2Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2.5rem",
  "fontWeight": 400,
  "lineHeight": "3rem"
}
export const heading2SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2.5rem",
  "fontWeight": 600,
  "lineHeight": "3rem"
}
export const heading2Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2.5rem",
  "fontWeight": 700,
  "lineHeight": "3rem"
}
export const heading2Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2.5rem",
  "fontWeight": 900,
  "lineHeight": "3rem"
}
export const heading3Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2rem",
  "fontWeight": 400,
  "lineHeight": "2.5rem"
}
export const heading3SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2rem",
  "fontWeight": 600,
  "lineHeight": "2.5rem"
}
export const heading3Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2rem",
  "fontWeight": 700,
  "lineHeight": "2.5rem"
}
export const heading3Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "2rem",
  "fontWeight": 900,
  "lineHeight": "2.5rem"
}
export const heading4Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.75rem",
  "fontWeight": 400,
  "lineHeight": "2.25rem"
}
export const heading4SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.75rem",
  "fontWeight": 600,
  "lineHeight": "2.25rem"
}
export const heading4Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.75rem",
  "fontWeight": 700,
  "lineHeight": "2.25rem"
}
export const heading4Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.75rem",
  "fontWeight": 900,
  "lineHeight": "2.25rem"
}
export const heading5Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.5rem",
  "fontWeight": 400,
  "lineHeight": "2rem"
}
export const heading5SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.5rem",
  "fontWeight": 600,
  "lineHeight": "2rem"
}
export const heading5Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.5rem",
  "fontWeight": 700,
  "lineHeight": "2rem"
}
export const heading5Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.5rem",
  "fontWeight": 900,
  "lineHeight": "2rem"
}
export const heading6Regular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.25rem",
  "fontWeight": 400,
  "lineHeight": "1.75rem"
}
export const heading6SemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.25rem",
  "fontWeight": 600,
  "lineHeight": "1.75rem"
}
export const heading6Bold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.25rem",
  "fontWeight": 700,
  "lineHeight": "1.75rem"
}
export const heading6Black = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.25rem",
  "fontWeight": 900,
  "lineHeight": "1.75rem"
}
export const bodyLeadRegular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.125rem",
  "fontWeight": 400,
  "lineHeight": "1.75rem"
}
export const bodyLeadSemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.125rem",
  "fontWeight": 600,
  "lineHeight": "1.75rem"
}
export const bodyLeadBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.125rem",
  "fontWeight": 700,
  "lineHeight": "1.75rem"
}
export const bodyLeadBlack = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1.125rem",
  "fontWeight": 900,
  "lineHeight": "1.75rem"
}
export const bodyBaseRegular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1rem",
  "fontWeight": 400,
  "lineHeight": "1.5rem"
}
export const bodyBaseSemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1rem",
  "fontWeight": 600,
  "lineHeight": "1.5rem"
}
export const bodyBaseBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1rem",
  "fontWeight": 700,
  "lineHeight": "1.5rem"
}
export const bodyBaseBlack = {
  "fontFamily": "Nunito Sans",
  "fontSize": "1rem",
  "fontWeight": 900,
  "lineHeight": "1.5rem"
}
export const bodyMediumRegular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.875rem",
  "fontWeight": 400,
  "lineHeight": "1.25rem"
}
export const bodyMediumSemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.875rem",
  "fontWeight": 600,
  "lineHeight": "1.25rem"
}
export const bodyMediumBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.875rem",
  "fontWeight": 700,
  "lineHeight": "1.25rem"
}
export const bodyMediumBlack = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.875rem",
  "fontWeight": 900,
  "lineHeight": "1.25rem"
}
export const bodySmallRegular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 400,
  "lineHeight": "1.125rem"
}
export const bodySmallSemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 600,
  "lineHeight": "1.125rem"
}
export const bodySmallBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 700,
  "lineHeight": "1.125rem"
}
export const bodySmallBlack = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 900,
  "lineHeight": "1.125rem"
}
export const overlineRegular = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 400,
  "lineHeight": "1.125rem"
}
export const overlineSemiBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 600,
  "lineHeight": "1.125rem"
}
export const overlineBold = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 700,
  "lineHeight": "1.125rem"
}
export const overlineBlack = {
  "fontFamily": "Nunito Sans",
  "fontSize": "0.75rem",
  "fontWeight": 900,
  "lineHeight": "1.125rem"
}

export const display4RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 6rem;
  font-weight: 400;
  line-height: 7.5rem;
}`
export const display4SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 6rem;
  font-weight: 600;
  line-height: 7.5rem;
}`
export const display4BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 6rem;
  font-weight: 700;
  line-height: 7.5rem;
}`
export const display4BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 6rem;
  font-weight: 900;
  line-height: 7.5rem;
}`
export const display3RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4.5rem;
  font-weight: 400;
  line-height: 6rem;
}`
export const display3SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4.5rem;
  font-weight: 600;
  line-height: 6rem;
}`
export const display3BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4.5rem;
  font-weight: 700;
  line-height: 6rem;
}`
export const display3BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4.5rem;
  font-weight: 900;
  line-height: 6rem;
}`
export const display2RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4rem;
  font-weight: 400;
  line-height: 5rem;
}`
export const display2SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4rem;
  font-weight: 600;
  line-height: 5rem;
}`
export const display2BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4rem;
  font-weight: 700;
  line-height: 5rem;
}`
export const display2BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 4rem;
  font-weight: 900;
  line-height: 5rem;
}`
export const display1RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3.5rem;
  font-weight: 400;
  line-height: 4.5rem;
}`
export const display1SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3.5rem;
  font-weight: 600;
  line-height: 4.5rem;
}`
export const display1BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3.5rem;
  font-weight: 700;
  line-height: 4.5rem;
}`
export const display1BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3.5rem;
  font-weight: 900;
  line-height: 4.5rem;
}`
export const heading1RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3rem;
  font-weight: 400;
  line-height: 4rem;
}`
export const heading1SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3rem;
  font-weight: 600;
  line-height: 4rem;
}`
export const heading1BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3rem;
  font-weight: 700;
  line-height: 4rem;
}`
export const heading1BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 3rem;
  font-weight: 900;
  line-height: 4rem;
}`
export const heading2RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2.5rem;
  font-weight: 400;
  line-height: 3rem;
}`
export const heading2SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2.5rem;
  font-weight: 600;
  line-height: 3rem;
}`
export const heading2BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2.5rem;
  font-weight: 700;
  line-height: 3rem;
}`
export const heading2BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2.5rem;
  font-weight: 900;
  line-height: 3rem;
}`
export const heading3RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2rem;
  font-weight: 400;
  line-height: 2.5rem;
}`
export const heading3SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2rem;
  font-weight: 600;
  line-height: 2.5rem;
}`
export const heading3BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2rem;
  font-weight: 700;
  line-height: 2.5rem;
}`
export const heading3BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 2rem;
  font-weight: 900;
  line-height: 2.5rem;
}`
export const heading4RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.75rem;
  font-weight: 400;
  line-height: 2.25rem;
}`
export const heading4SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.75rem;
  font-weight: 600;
  line-height: 2.25rem;
}`
export const heading4BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.75rem;
  font-weight: 700;
  line-height: 2.25rem;
}`
export const heading4BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.75rem;
  font-weight: 900;
  line-height: 2.25rem;
}`
export const heading5RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.5rem;
  font-weight: 400;
  line-height: 2rem;
}`
export const heading5SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.5rem;
  font-weight: 600;
  line-height: 2rem;
}`
export const heading5BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.5rem;
  font-weight: 700;
  line-height: 2rem;
}`
export const heading5BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.5rem;
  font-weight: 900;
  line-height: 2rem;
}`
export const heading6RegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.25rem;
  font-weight: 400;
  line-height: 1.75rem;
}`
export const heading6SemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.25rem;
  font-weight: 600;
  line-height: 1.75rem;
}`
export const heading6BoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.25rem;
  font-weight: 700;
  line-height: 1.75rem;
}`
export const heading6BlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.25rem;
  font-weight: 900;
  line-height: 1.75rem;
}`
export const bodyLeadRegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.125rem;
  font-weight: 400;
  line-height: 1.75rem;
}`
export const bodyLeadSemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.125rem;
  font-weight: 600;
  line-height: 1.75rem;
}`
export const bodyLeadBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.125rem;
  font-weight: 700;
  line-height: 1.75rem;
}`
export const bodyLeadBlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1.125rem;
  font-weight: 900;
  line-height: 1.75rem;
}`
export const bodyBaseRegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5rem;
}`
export const bodyBaseSemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1rem;
  font-weight: 600;
  line-height: 1.5rem;
}`
export const bodyBaseBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1rem;
  font-weight: 700;
  line-height: 1.5rem;
}`
export const bodyBaseBlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 1rem;
  font-weight: 900;
  line-height: 1.5rem;
}`
export const bodyMediumRegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.875rem;
  font-weight: 400;
  line-height: 1.25rem;
}`
export const bodyMediumSemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.875rem;
  font-weight: 600;
  line-height: 1.25rem;
}`
export const bodyMediumBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.875rem;
  font-weight: 700;
  line-height: 1.25rem;
}`
export const bodyMediumBlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.875rem;
  font-weight: 900;
  line-height: 1.25rem;
}`
export const bodySmallRegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 400;
  line-height: 1.125rem;
}`
export const bodySmallSemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 600;
  line-height: 1.125rem;
}`
export const bodySmallBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 700;
  line-height: 1.125rem;
}`
export const bodySmallBlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 900;
  line-height: 1.125rem;
}`
export const overlineRegularCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 400;
  line-height: 1.125rem;
}`
export const overlineSemiBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 600;
  line-height: 1.125rem;
}`
export const overlineBoldCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 700;
  line-height: 1.125rem;
}`
export const overlineBlackCSS = `@media screen and (min-width: ${mMin}px) {
  font-family: Nunito Sans;
  font-size: 0.75rem;
  font-weight: 900;
  line-height: 1.125rem;
}`