export const shadow = {
  default: "0px 2px 8px 0px #5c5c5c1a",
  hover: "0px 8px 16px 0px #5c5c5c26",
  break: "0px 16px 32px 0px #5c5c5c40",
  top: "0px -8px 8px 0px #5c5c5c14",
  right: "4px 4px 8px 0px #5c5c5c1a",
  left: "4px 4px 8px 0px #5c5c5c1a"
}

export type Shadow = typeof shadow