import * as fontsCore from "./fonts.core";
import * as mobileFontTypes from "./fonts.mobile";
import * as desktopFontTypes from "./fonts.desktop-tablet";
import * as fontTypes from "./fonts.base";

export const text = {
  core: {
    ...fontsCore,
  },
  mobile: {
    ...mobileFontTypes,
  },
  desktop: {
    ...desktopFontTypes,
  },
  ...fontTypes,
};

export type Text = typeof text;
