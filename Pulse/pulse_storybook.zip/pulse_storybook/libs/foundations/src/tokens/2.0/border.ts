const borderWidth = {
  widthXS: "1px",
  widthS: "2px",
  widthM: "3px",
  widthL: "4px",
  widthXL: "8px",
} as const;

const borderRadius = {
  radiusXS: "4px",
  radiusS: "8px",
  radiusM: "12px",
  radiusL: "16px",
  radiusXL: "24px",
  radius2XL: "32px",
  radiusCircle: "50%",
} as const;

export const border = {
  ...borderWidth,
  ...borderRadius,
};

export type Border = typeof border;
