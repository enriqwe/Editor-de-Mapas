import { sMax } from './breakpoint';

export const overlineRegular = {
  "font": "400 0.75rem/1.125rem 'Nunito Sans'"
}
export const overlineSemiBold = {
  "font": "600 0.75rem/1.125rem 'Nunito Sans'"
}
export const overlineBold = {
  "font": "700 0.75rem/1.125rem 'Nunito Sans'"
}
export const overlineBlack = {
  "font": "900 0.75rem/1.125rem 'Nunito Sans'"
}
export const display4Regular = {
  "font": "400 4rem/5rem 'Nunito Sans'"
}
export const display4SemiBold = {
  "font": "600 4rem/5rem 'Nunito Sans'"
}
export const display4Bold = {
  "font": "700 4rem/5rem 'Nunito Sans'"
}
export const display4Black = {
  "font": "900 4rem/5rem 'Nunito Sans'"
}
export const display3Regular = {
  "font": "400 3.25rem/4rem 'Nunito Sans'"
}
export const display3SemiBold = {
  "font": "600 3.25rem/4rem 'Nunito Sans'"
}
export const display3Bold = {
  "font": "700 3.25rem/4rem 'Nunito Sans'"
}
export const display3Black = {
  "font": "900 3.25rem/4rem 'Nunito Sans'"
}
export const display2Regular = {
  "font": "400 2.625rem/3.75rem 'Nunito Sans'"
}
export const display2SemiBold = {
  "font": "600 2.625rem/3.75rem 'Nunito Sans'"
}
export const display2Bold = {
  "font": "700 2.625rem/3.75rem 'Nunito Sans'"
}
export const display2Black = {
  "font": "900 2.625rem/3.75rem 'Nunito Sans'"
}
export const display1Regular = {
  "font": "400 2.375rem/3rem 'Nunito Sans'"
}
export const display1SemiBold = {
  "font": "600 2.375rem/3rem 'Nunito Sans'"
}
export const display1Bold = {
  "font": "700 2.375rem/3rem 'Nunito Sans'"
}
export const display1Black = {
  "font": "900 2.375rem/3rem 'Nunito Sans'"
}
export const heading1Regular = {
  "font": "400 2.125rem/2.75rem 'Nunito Sans'"
}
export const heading1SemiBold = {
  "font": "600 2.125rem/2.75rem 'Nunito Sans'"
}
export const heading1Bold = {
  "font": "700 2.125rem/2.75rem 'Nunito Sans'"
}
export const heading1Black = {
  "font": "900 2.125rem/2.75rem 'Nunito Sans'"
}
export const heading2Regular = {
  "font": "400 1.875rem/2.5rem 'Nunito Sans'"
}
export const heading2SemiBold = {
  "font": "600 1.875rem/2.5rem 'Nunito Sans'"
}
export const heading2Bold = {
  "font": "700 1.875rem/2.5rem 'Nunito Sans'"
}
export const heading2Black = {
  "font": "900 1.875rem/2.5rem 'Nunito Sans'"
}
export const heading3Regular = {
  "font": "400 1.625rem/2.25rem 'Nunito Sans'"
}
export const heading3SemiBold = {
  "font": "600 1.625rem/2.25rem 'Nunito Sans'"
}
export const heading3Bold = {
  "font": "700 1.625rem/2.25rem 'Nunito Sans'"
}
export const heading3Black = {
  "font": "900 1.625rem/2.25rem 'Nunito Sans'"
}
export const heading4Regular = {
  "font": "400 1.5rem/1.75rem 'Nunito Sans'"
}
export const heading4SemiBold = {
  "font": "600 1.5rem/1.75rem 'Nunito Sans'"
}
export const heading4Bold = {
  "font": "700 1.5rem/1.75rem 'Nunito Sans'"
}
export const heading4Black = {
  "font": "900 1.5rem/1.75rem 'Nunito Sans'"
}
export const heading5Regular = {
  "font": "400 1.25rem/1.5rem 'Nunito Sans'"
}
export const heading5SemiBold = {
  "font": "600 1.25rem/1.5rem 'Nunito Sans'"
}
export const heading5Bold = {
  "font": "700 1.25rem/1.5rem 'Nunito Sans'"
}
export const heading5Black = {
  "font": "900 1.25rem/1.5rem 'Nunito Sans'"
}
export const heading6Regular = {
  "font": "400 1.125rem/1.5rem 'Nunito Sans'"
}
export const heading6SemiBold = {
  "font": "600 1.125rem/1.5rem 'Nunito Sans'"
}
export const heading6Bold = {
  "font": "700 1.125rem/1.5rem 'Nunito Sans'"
}
export const heading6Black = {
  "font": "900 1.125rem/1.5rem 'Nunito Sans'"
}
export const bodyLeadRegular = {
  "font": "400 1.125rem/1.75rem 'Nunito Sans'"
}
export const bodyLeadSemiBold = {
  "font": "600 1.125rem/1.75rem 'Nunito Sans'"
}
export const bodyLeadBold = {
  "font": "700 1.125rem/1.75rem 'Nunito Sans'"
}
export const bodyLeadBlack = {
  "font": "900 1.125rem/1.75rem 'Nunito Sans'"
}
export const bodyBaseRegular = {
  "font": "400 1rem/1.5rem 'Nunito Sans'"
}
export const bodyBaseSemiBold = {
  "font": "600 1rem/1.5rem 'Nunito Sans'"
}
export const bodyBaseBold = {
  "font": "700 1rem/1.5rem 'Nunito Sans'"
}
export const bodyBaseBlack = {
  "font": "900 1rem/1.5rem 'Nunito Sans'"
}
export const bodyMediumRegular = {
  "font": "400 0.875rem/1.25rem 'Nunito Sans'"
}
export const bodyMediumSemiBold = {
  "font": "600 0.875rem/1.25rem 'Nunito Sans'"
}
export const bodyMediumBold = {
  "font": "700 0.875rem/1.25rem 'Nunito Sans'"
}
export const bodyMediumBlack = {
  "font": "900 0.875rem/1.25rem 'Nunito Sans'"
}
export const bodySmallRegular = {
  "font": "400 0.75rem/1.125rem 'Nunito Sans'"
}
export const bodySmallSemiBold = {
  "font": "600 0.75rem/1.125rem 'Nunito Sans'"
}
export const bodySmallBold = {
  "font": "700 0.75rem/1.125rem 'Nunito Sans'"
}
export const bodySmallBlack = {
  "font": "900 0.75rem/1.125rem 'Nunito Sans'"
}

export const overlineRegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 0.75rem/1.125rem 'Nunito Sans';
}`
export const overlineSemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 0.75rem/1.125rem 'Nunito Sans';
}`
export const overlineBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 0.75rem/1.125rem 'Nunito Sans';
}`
export const overlineBlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 0.75rem/1.125rem 'Nunito Sans';
}`
export const display4RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 4rem/5rem 'Nunito Sans';
}`
export const display4SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 4rem/5rem 'Nunito Sans';
}`
export const display4BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 4rem/5rem 'Nunito Sans';
}`
export const display4BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 4rem/5rem 'Nunito Sans';
}`
export const display3RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 3.25rem/4rem 'Nunito Sans';
}`
export const display3SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 3.25rem/4rem 'Nunito Sans';
}`
export const display3BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 3.25rem/4rem 'Nunito Sans';
}`
export const display3BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 3.25rem/4rem 'Nunito Sans';
}`
export const display2RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 2.625rem/3.75rem 'Nunito Sans';
}`
export const display2SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 2.625rem/3.75rem 'Nunito Sans';
}`
export const display2BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 2.625rem/3.75rem 'Nunito Sans';
}`
export const display2BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 2.625rem/3.75rem 'Nunito Sans';
}`
export const display1RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 2.375rem/3rem 'Nunito Sans';
}`
export const display1SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 2.375rem/3rem 'Nunito Sans';
}`
export const display1BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 2.375rem/3rem 'Nunito Sans';
}`
export const display1BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 2.375rem/3rem 'Nunito Sans';
}`
export const heading1RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 2.125rem/2.75rem 'Nunito Sans';
}`
export const heading1SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 2.125rem/2.75rem 'Nunito Sans';
}`
export const heading1BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 2.125rem/2.75rem 'Nunito Sans';
}`
export const heading1BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 2.125rem/2.75rem 'Nunito Sans';
}`
export const heading2RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.875rem/2.5rem 'Nunito Sans';
}`
export const heading2SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.875rem/2.5rem 'Nunito Sans';
}`
export const heading2BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.875rem/2.5rem 'Nunito Sans';
}`
export const heading2BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.875rem/2.5rem 'Nunito Sans';
}`
export const heading3RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.625rem/2.25rem 'Nunito Sans';
}`
export const heading3SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.625rem/2.25rem 'Nunito Sans';
}`
export const heading3BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.625rem/2.25rem 'Nunito Sans';
}`
export const heading3BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.625rem/2.25rem 'Nunito Sans';
}`
export const heading4RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.5rem/1.75rem 'Nunito Sans';
}`
export const heading4SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.5rem/1.75rem 'Nunito Sans';
}`
export const heading4BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.5rem/1.75rem 'Nunito Sans';
}`
export const heading4BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.5rem/1.75rem 'Nunito Sans';
}`
export const heading5RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.25rem/1.5rem 'Nunito Sans';
}`
export const heading5SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.25rem/1.5rem 'Nunito Sans';
}`
export const heading5BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.25rem/1.5rem 'Nunito Sans';
}`
export const heading5BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.25rem/1.5rem 'Nunito Sans';
}`
export const heading6RegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.125rem/1.5rem 'Nunito Sans';
}`
export const heading6SemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.125rem/1.5rem 'Nunito Sans';
}`
export const heading6BoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.125rem/1.5rem 'Nunito Sans';
}`
export const heading6BlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.125rem/1.5rem 'Nunito Sans';
}`
export const bodyLeadRegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1.125rem/1.75rem 'Nunito Sans';
}`
export const bodyLeadSemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1.125rem/1.75rem 'Nunito Sans';
}`
export const bodyLeadBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1.125rem/1.75rem 'Nunito Sans';
}`
export const bodyLeadBlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1.125rem/1.75rem 'Nunito Sans';
}`
export const bodyBaseRegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 1rem/1.5rem 'Nunito Sans';
}`
export const bodyBaseSemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 1rem/1.5rem 'Nunito Sans';
}`
export const bodyBaseBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 1rem/1.5rem 'Nunito Sans';
}`
export const bodyBaseBlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 1rem/1.5rem 'Nunito Sans';
}`
export const bodyMediumRegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 0.875rem/1.25rem 'Nunito Sans';
}`
export const bodyMediumSemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 0.875rem/1.25rem 'Nunito Sans';
}`
export const bodyMediumBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 0.875rem/1.25rem 'Nunito Sans';
}`
export const bodyMediumBlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 0.875rem/1.25rem 'Nunito Sans';
}`
export const bodySmallRegularCSS = `@media screen and (max-width: ${sMax}px) {
  font: 400 0.75rem/1.125rem 'Nunito Sans';
}`
export const bodySmallSemiBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 600 0.75rem/1.125rem 'Nunito Sans';
}`
export const bodySmallBoldCSS = `@media screen and (max-width: ${sMax}px) {
  font: 700 0.75rem/1.125rem 'Nunito Sans';
}`
export const bodySmallBlackCSS = `@media screen and (max-width: ${sMax}px) {
  font: 900 0.75rem/1.125rem 'Nunito Sans';
}`