export const sMax = 767;

export const mMin = 768;
export const mMax = 1199;

export const lMin = 1200;

type CSSObject = Record<string, string | number>;

const CSSObjectToString = (props: CSSObject): string =>
  Object.keys(props)
    .map(key => {
      return `${key}: ${props[key]};`;
    })
    .join("\n");

// This only applies to target one specific range
const sOnly = (props: CSSObject) =>
  `@media screen and (max-width: ${sMax}px) {
    ${CSSObjectToString(props)}
}`;

const mOnly = (props: CSSObject) =>
  `@media screen and (min-width: ${mMin}px) and (max-width: ${mMax}px) {
    ${CSSObjectToString(props)}
}`;

// This applies to the selected range and above
const m = (props: CSSObject) =>
  `@media screen and (min-width: ${mMin}px) {
    ${CSSObjectToString(props)}
}`;

const l = (props: CSSObject) =>
  `@media screen and (min-width: ${lMin}px) {
    ${CSSObjectToString(props)}
}`;

const generate = (
  smallBreakpointProps?: CSSObject,
  mediumBreakpointProps?: CSSObject,
  largeBreakpointProps?: CSSObject
): string => {
  const sContent = smallBreakpointProps ? sOnly(smallBreakpointProps) : "";
  const mContent = mediumBreakpointProps ? mOnly(mediumBreakpointProps) : "";
  const lContent = largeBreakpointProps ? l(largeBreakpointProps) : "";

  return `${sContent}\n${mContent}\n${lContent}`;
};

export const breakpoint: Breakpoint = {
  sMax,
  mMin,
  mMax,
  lMin,
  m,
  l,
  sOnly,
  mOnly,
  tablet: m,
  tabletOnly: mOnly,
  desktop: l,
  generate,
};

export type Breakpoint = {
  /** Max resolution for mobile, in pxs.  */
  sMax: number;
  /** Min resolution for tablet, in pxs.  */
  mMin: number;
  /** Max resolution for tablet, in pxs.  */
  mMax: number;
  /** Min resolution for desktop, in pxs.  */
  lMin: number;
  /** Apply styles for tablets and above (768+).  */
  m: (props: CSSObject) => string;
  /** Apply styles for desktops and above (1200+).  */
  l: (props: CSSObject) => string;
  /** Apply styles for mobiles only (360-767).  */
  sOnly: (props: CSSObject) => string;
  /** Apply styles for tablets only (768-1199).  */
  mOnly: (props: CSSObject) => string;
  /** Apply styles for tablets only (768-1199).  */
  tablet: (props: CSSObject) => string;
  /** Apply styles for tablets only (768-1199).  */
  tabletOnly: (props: CSSObject) => string;
  /** Apply styles for desktops only (1200+).  */
  desktop: (props: CSSObject) => string;
  /** Generate styles for all breakpoints */
  generate: typeof generate;
};
