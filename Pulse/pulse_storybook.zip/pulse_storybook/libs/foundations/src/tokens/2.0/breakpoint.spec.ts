import { breakpoint } from "./breakpoint";

describe("breakpoint", () => {
  it("should have the correct values", () => {
    expect(breakpoint.sMax).toBe(767);
    expect(breakpoint.mMin).toBe(768);
    expect(breakpoint.mMax).toBe(1199);
    expect(breakpoint.lMin).toBe(1200);
  });

  it("should generate the correct media queries", () => {
    const sProps = { color: "red" };
    const mProps = { color: "blue" };
    const lProps = { color: "green" };

    const expected = `@media screen and (max-width: 767px) {
    color: red;
  }
  @media screen and (min-width: 768px) and (max-width: 1199px) {
    color: blue;
  }
  @media screen and (min-width: 1200px) {
    color: green;
  }`;

    expect(breakpoint.generate(sProps, mProps, lProps).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });

  it("should generate the correct media queries even if some props are undefined", () => {
    const sProps = undefined;
    const mProps = { color: "blue" };
    const lProps = undefined;

    const expected = `@media screen and (min-width: 768px) and (max-width: 1199px) {
    color: blue;
  }`;

    expect(breakpoint.generate(sProps, mProps, lProps).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });

  it("should generate the correct media queries with only small and large props", () => {
    const sProps = { color: "red" };
    const lProps = { color: "green" };

    const expected = `@media screen and (max-width: 767px) {
      color: red;
    }
    @media screen and (min-width: 1200px) {
      color: green;
    }`;

    expect(
      breakpoint.generate(sProps, undefined, lProps).replace(/\s/g, "")
    ).toBe(expected.replace(/\s/g, ""));
  });

  // create tests for the s, m, and l functions
  it("should generate the correct media query for sOnly", () => {
    const props = { color: "red" };

    const expected = `@media screen and (max-width: 767px) {
      color: red;
    }`;

    expect(breakpoint.sOnly(props).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });

  it("should generate the correct media query for mOnly", () => {
    const props = { color: "blue" };

    const expected = `@media screen and (min-width: 768px) and (max-width: 1199px) {
      color: blue;
    }`;

    expect(breakpoint.mOnly(props).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });

  it("should generate the correct media query for m", () => {
    const props = { color: "blue" };

    const expected = `@media screen and (min-width: 768px) {
      color: blue;
    }`;

    expect(breakpoint.m(props).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });

  it("should generate the correct media query for l", () => {
    const props = { color: "green" };

    const expected = `@media screen and (min-width: 1200px) {
      color: green;
    }`;

    expect(breakpoint.l(props).replace(/\s/g, "")).toBe(
      expected.replace(/\s/g, "")
    );
  });
});
