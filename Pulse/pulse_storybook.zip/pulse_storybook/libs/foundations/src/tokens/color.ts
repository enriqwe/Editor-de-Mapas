type ColorShades = 10 | 20 | 30 | 40 | 50 | 60 | 70 | 80 | 90;

export type IColor = Record<ColorShades, string>;

export const blue: IColor = {
  10: "#EAF1FB",
  20: "#ADC9F4",
  30: "#6FA1EC",
  40: "#4F88E2",
  50: "#2E6ED6",
  60: "#2B58BF",
  70: "#2843A8",
  80: "#1F3A9C",
  90: "#0D2887",
};

export const green: IColor = {
  10: "#DDFDED",
  20: "#0AC295",
  30: "#09A57F",
  40: "#078364",
  50: "#027357",
  60: "#02624A",
  70: "#01523E",
  80: "#014232",
  90: "#013427",
};

export const orange: IColor = {
  10: "#FEF7B9",
  20: "#FFDA6C",
  30: "#FFB400",
  40: "#E07C02",
  50: "#C33E01",
  60: "#A63501",
  70: "#8A2C01",
  80: "#6F2301",
  90: "#581C00",
};

export const red: IColor = {
  10: "#FCD2CF",
  20: "#F45532",
  30: "#DF320C",
  40: "#C61A0B",
  50: "#AE0A0A",
  60: "#940909",
  70: "#7C0707",
  80: "#630606",
  90: "#4E0505",
};

export const purple: IColor = {
  10: "#F5F0FF",
  20: "#D2BEFA",
  30: "#A88AE6",
  40: "#8660D1",
  50: "#6345A1",
  60: "#543B89",
  70: "#463172",
  80: "#38275C",
  90: "#2D1F48",
};

export const neutral: IColor = {
  10: "#F9F9F9",
  20: "#F3F3F3",
  30: "#E1E1E1",
  40: "#B8B8B8",
  50: "#858585",
  60: "#707070",
  70: "#5C5C5C",
  80: "#303030",
  90: "#1E1E1E",
};

export const fiord: IColor = {
  10: "#F8F9FB",
  20: "#EEF1F6",
  30: "#E4E8EE",
  40: "#CDD3DD",
  50: "#A8B1BD",
  60: "#818A95",
  70: "#5C6470",
  80: "#3A414C",
  90: "#1A212B",
};

export const opacity: IColor = {
  10: "rgba(0, 0, 0, 0.1)",
  20: "rgba(0, 0, 0, 0.2)",
  30: "rgba(0, 0, 0, 0.3)",
  40: "rgba(0, 0, 0, 0.4)",
  50: "rgba(0, 0, 0, 0.5)",
  60: "rgba(0, 0, 0, 0.6)",
  70: "rgba(0, 0, 0, 0.7)",
  80: "rgba(0, 0, 0, 0.8)",
  90: "rgba(0, 0, 0, 0.9)",
};

export const black = "#000000";

// TODO : challenge
/*export const chart: IColor = {
  green: '#74E4DA',
  yellow: '#F3DC46',
  blue: '#60A9FF',
  darkgrey: '#585E67',
  pink: '#ED64A4',
  lightgray: '#BABFC5',
  purple: '#C8BAEE',
  10: '#C3EAFF',
  20: '#8ED7FF',
  30: '#60A9FF',
  40: '#2F73DA',
  50: '#034AB3',
  60: '#002966',
};*/
