export type BorderClasses = "x4" | "x8" | "x12" | "x16" | "x50" | "circle";
export type Border = Record<BorderClasses, string>;

export const border: Border = {
  x4: "4px",
  x8: "8px",
  x12: "12px",
  x16: "16px",
  x50: "50px",
  circle: "50%",
};
