export type SpacingClasses =
  | "x2"
  | "x4"
  | "x6"
  | "x8"
  | "x12"
  | "x16"
  | "x20"
  | "x24"
  | "x26"
  | "x28"
  | "x32"
  | "x40"
  | "x48"
  | "x56"
  | "x64"
  | "x72"
  | "x80";

export type Spacing = Record<SpacingClasses, string>;

export const spacing: Spacing = {
  x2: "2px",
  x4: "4px",
  x6: "6px",
  x8: "8px",
  x12: "12px",
  x16: "16px",
  x20: "20px",
  x24: "24px",
  x26: "26px",
  x28: "28px",
  x32: "32px",
  x40: "40px",
  x48: "48px",
  x56: "48px",
  x64: "64px",
  x72: "72px",
  x80: "80px",
};
