export type ShadowTypes =
  | "low"
  | "med"
  | "high"
  | "medTop"
  | "medLeft"
  | "medRight";

export type ShadowProp = Record<ShadowTypes, string>;

export const shadow: ShadowProp = {
  low: "0px 2px 8px rgba(106, 115, 129, 0.12)",
  med: "0px 6px 12px rgba(106, 115, 129, 0.16)",
  high: "0px 12px 30px rgba(106, 115, 129, 0.22)",
  medTop: "0px -2px 8px rgba(106, 115, 129, 0.22)",
  medLeft: "-1px 2px 8px rgba(106, 115, 129, 0.22)",
  medRight: "1px 0px 8px rgba(106, 115, 129, 0.22)",
};
