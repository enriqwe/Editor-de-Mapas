import { breakpoint } from "../tokens/2.0/breakpoint"

const screenSizes = {
  tablet: breakpoint.mMin,
  desktop: breakpoint.lMin
}

export type ScreenSize = keyof typeof screenSizes
export type MediaValue = ScreenSize | number

function getSize(screenSize: ScreenSize) {
  return screenSizes[screenSize]
}

function up(mediaValue: MediaValue) {
  const value = typeof mediaValue === 'number' ? mediaValue : screenSizes[mediaValue]
  return `@media (min-width: ${value}px)`
}

function down(mediaValue: MediaValue) {
  const value = typeof mediaValue === 'number' ? mediaValue : screenSizes[mediaValue]
  return `@media (max-width: ${value}px)`
}

export const media = {
  getSize,
  up,
  down,
}
