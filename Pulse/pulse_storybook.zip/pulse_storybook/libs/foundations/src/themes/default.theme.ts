import "./default.theme.css";
import {
  blue,
  fiord,
  green,
  neutral,
  opacity,
  orange,
  purple,
  red,
  black,
} from "../tokens/color";
import { border } from "../tokens/border";
import { shadow } from "../tokens/shadow";
import { spacing } from "../tokens/spacing";
import { typography, typographyApi } from "../tokens/typography";
import { zIndex } from "../tokens/z-index";
import { text } from "../tokens/2.0/text";
import { breakpoint } from "../tokens/2.0/breakpoint";
// new tokens
import { createTokensFromCoreColors } from "../tokens/2.0/tokens-colors";
import { border as newBorder } from "../tokens/2.0/border";
import { shadow as newShadow } from "../tokens/2.0/shadow";

import type { ThemeType } from "./theme.type";

export const theme: ThemeType = {
  color: {
    ...createTokensFromCoreColors(),
    // everything below is to be deprecated
    background: {
      accordion: {
        focus: blue[40],
        hover: blue[10],
      },
      avatar: {
        default: neutral[30],
        textIcon: {
          hover: blue[30],
        },
      },
      box: "white",
      breadcrumb: "white",
      button: {
        destructive: red[30],
        destructiveHover: red[40],
        destructiveDisabled: neutral[20],
        destructiveClick: red[60],
        primary: blue[50],
        primaryHover: blue[60],
        primaryDisabled: neutral[20],
        secondary: "white",
        secondaryHover: blue[10],
        secondaryDisabled: "white",
        tertiary: "transparent",
        tertiaryHover: blue[10],
        tertiaryDisabled: "white",
      },
      buttonMenu: {
        default: blue[10],
      },
      calendar: {
        default: "transparent",
        defaultHover: blue[10],
        daySelected: blue[10],
        daySelectedHover: "#EAF1FF", //TODO: background color in hover is #EAF1FF in figma design, but it doesn't exist in our const, Review with design team
        daySelectedCorners: "#2E6ED6", //blue[30] TODO
        today: "#2E6ED6", //blue[30] TODO,
        hover: neutral[20],
      },
      cell: {
        active: blue[10],
        hover: "white",
      },
      chip: {
        active: blue[10],
        default: fiord[10],
        hover: "white",
        selected: blue[50],
      },
      drawer: {
        underlay: opacity[60],
      },
      default: neutral[10],
      disabled: neutral[20],
      dropdown: {
        active: blue[10],
        disabled: neutral[10],
        hover: neutral[20],
        titleGroupOption: neutral[10],
      },
      error: red[10],
      form: "white",
      iconButton: {
        hover: blue[10],
      },
      informative: blue[10],
      inverted: neutral[80],
      layout: {
        header: "white",
        body: fiord[10],
      },
      paginationBar: neutral[10],
      pressed: blue[70],
      searchBar: {
        disabled: neutral[10],
        default: "white",
      },
      sidemenu: {
        active: neutral[70],
      },
      stepper: {
        dividingLine: {
          completed: green[40],
          default: neutral[40],
          error: red[30],
        },
        hover: blue[10],
        indicator: {
          active: blue[50],
          completed: green[40],
          error: red[30],
          inactive: neutral[30],
        },
      },
      success: green[10],
      tag: {
        success: green[10],
        error: red[10],
        informative: blue[10],
        pending: neutral[20],
        warning: orange[10],
        tip: purple[10],
      },
      tagDynamic: {
        default: blue[10],
        deleted: red[10],
      },
      tips: purple[10],
      toggleSwitch: {
        active: blue[50],
        default: neutral[50],
        disabled: neutral[30],
        hover: blue[10],
        thumb: "white",
      },
      tooltip: neutral[80],
      transparent: opacity[10],
      warning: orange[10],
    },
    border: {
      accordion: {
        default: neutral[40],
        focus: blue[40],
      },
      avatar: {
        img: {
          hover: blue[20],
        },
      },
      box: neutral[30],
      button: {
        secondary: blue[50],
        secondaryHover: blue[50],
        focus: blue[60],
      },
      chip: {
        default: neutral[60],
        hover: blue[30],
        active: blue[60],
      },
      disabled: neutral[40],
      layout: {
        header: neutral[30],
      },
      divider: {
        default: neutral[40],
        active: blue[40],
      },
      dropdown: {
        default: neutral[60],
        disabled: neutral[40],
        error: red[30],
        focus: blue[40],
        hover: blue[30],
      },
      toggleSwitch: {
        active: blue[50],
        default: neutral[50],
        disabled: neutral[30],
        focus: blue[60],
      },
      error: red[20],
      expandedGroup: neutral[70],
      form: {
        default: neutral[50],
        error: red[30],
        focus: blue[40],
        hover: blue[30],
      },
      informative: blue[20],
      pending: neutral[40],
      pressed: blue[70],
      searchBar: {
        default: neutral[50],
        hover: neutral[60],
        focus: blue[40],
      },
      success: green[20],
      tab: {
        active: blue[60],
      },
      tabGroup: {
        default: neutral[40],
      },
      tag: {
        success: green[20],
        error: red[20],
        informative: blue[20],
        pending: fiord[40],
        warning: orange[20],
        tip: purple[30],
      },
      tagDynamic: {
        default: blue[20],
        deleted: red[20],
        deletedHover: red[30],
        hover: blue[30],
      },
      warning: orange[20],
      checkbox: {
        default: neutral[60],
        hover: blue[10],
        focus: blue[30],
      },
    },
    icon: {
      default: neutral[80],
      disabled: neutral[50],
      error: red[30],
      hover: blue[40],
      informative: blue[50],
      success: green[30],
      tagDynamic: {
        default: blue[30],
        deleted: red[30],
        deletedHover: red[40],
        hover: blue[40],
      },
      linkVisited: purple[60],
      tips: purple[50],
      warning: orange[30],
    },
    text: {
      body: neutral[80],
      accordion: {
        subLabel: neutral[80],
        avatar: neutral[80],
      },
      breadcrumb: {
        default: neutral[30],
      },
      button: {
        destructive: "white",
        destructiveHover: "white",
        primary: "white",
        primaryHover: "white",
        primaryClick: blue[70],
        secondary: blue[50],
        secondaryHover: blue[60],
        secondaryClick: blue[70],
        tertiary: blue[50],
        tertiaryHover: blue[60],
        tertiaryClick: blue[70],
        ghost: blue[50],
        ghostHover: blue[60],
        ghostActive: blue[70],
      },
      buttonMenu: {
        filled: blue[50],
        hover: blue[60],
      },
      card: {
        subHeader: neutral[60],
      },
      chip: {
        active: blue[60],
        default: neutral[80],
        hover: blue[50],
      },
      disabled: neutral[50],
      dropdown: {
        additionalText: neutral[70],
        additionalTextError: red[50],
        default: neutral[90],
        disabled: neutral[50],
        label: neutral[80],
        titleGroupOption: neutral[90],
      },
      dropdownItem: {
        active: neutral[80],
      },
      error: red[40],
      heading: neutral[90],
      helperText: neutral[70],
      helperTextError: red[50],
      informative: blue[40],
      inverted: "white",
      label: neutral[80],
      link: {
        active: blue["80"],
        destructive: blue["30"],
        destructiveActive: blue[40],
        destructiveHover: blue[40],
        primary: blue[60],
        primaryActive: blue[40],
        primaryHover: blue[70],
        secondary: neutral[70],
        secondaryActive: neutral[70],
        secondaryHover: neutral[70],
        visited: purple[60],
      },
      notifications: neutral[90],
      pending: neutral[70],
      pressed: blue[70],
      radio: {
        default: neutral[70],
        disabled: neutral[50],
      },
      searchBar: {
        default: neutral[90],
        placeholder: neutral[60],
      },
      sidemenu: {
        default: neutral[50],
      },
      stepper: {
        active: neutral[90],
        completed: neutral[90],
        error: red[50],
        inactive: neutral[60],
        editable: blue[60],
        helperText: {
          active: neutral[70],
          completed: neutral[70],
          error: red[40],
          inactive: neutral[50],
        },
        indicator: {
          active: "white",
          completed: "white",
          error: "white",
          inactive: neutral[60],
        },
      },
      subheading: neutral[80],
      success: green[40],
      tab: {
        default: neutral[70],
        hover: blue[60],
        active: blue[60],
      },
      tag: {
        success: green[60],
        error: red[50],
        informative: "#2B58BF", // Todo: New to add to color.ts
        pending: neutral[80],
        warning: orange[50],
        tip: purple[50],
      },
      toggleSwitch: {
        default: neutral[70],
        disabled: neutral[50],
      },
      input: {
        default: neutral[60],
      },
      warning: orange[40],
      checkbox: {
        default: neutral[70],
      },
      calendar: {
        active: "#2B58BF", // Todo: New to add to color.ts blue[60]
        default: neutral[90],
      },
    },
  },
  spacing,
  shadow: {
    high: shadow.high, // to be deprecated
    low: shadow.low, // to be deprecated
    med: shadow.med, // to be deprecated
    drawer: {
      left: shadow.medLeft, // to be deprecated
      right: shadow.medRight, // to be deprecated
      top: shadow.medTop, // to be deprecated
    },
    ...newShadow,
  },
  overlay: {
    light: neutral[20], // to be deprecated
    dark: black, // to be deprecated
  },
  zIndex,
  font: {
    ...typography, // to be deprecated
    ...typographyApi, // to be deprecated
  },
  text,
  breakpoint,
  border: {
    ...border, // to be deprecated
    ...newBorder,
  },
};
