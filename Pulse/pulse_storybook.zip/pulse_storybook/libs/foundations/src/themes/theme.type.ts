import type { Border } from "../tokens/border";
import type { Spacing } from "../tokens/spacing";
import type { TypographyMethods, TypographyProp } from "../tokens/typography";
import type { ZIndex } from "../tokens/z-index";
// New tokens
import type { Text } from "../tokens/2.0/text";
import type { Border as NewBorder } from "../tokens/2.0/border";
import type { TokenColors } from "../tokens/2.0/tokens-colors";
import type { Breakpoint as NewBreakpoint } from "../tokens/2.0/breakpoint";
import type { Shadow as NewShadow } from "../tokens/2.0/shadow";

export type SemanticColors = {
  background: {
    accordion: {
      focus: string;
      hover: string;
    };
    avatar: {
      default: string;
      textIcon: {
        hover: string;
      };
    };
    box: string;
    breadcrumb: string;
    button: {
      destructive: string;
      destructiveHover: string;
      destructiveDisabled: string;
      destructiveClick: string;
      primary: string;
      primaryHover: string;
      primaryDisabled: string;
      secondary: string;
      secondaryHover: string;
      secondaryDisabled: string;
      tertiary: string;
      tertiaryHover: string;
      tertiaryDisabled: string;
    };
    buttonMenu: {
      default: string;
    };
    calendar: {
      default: string;
      defaultHover: string;
      daySelected: string;
      daySelectedHover: string;
      daySelectedCorners: string;
      today: string;
      hover: string;
    };
    cell: {
      active: string;
      hover: string;
    };
    chip: {
      active: string;
      default: string;
      hover: string;
      selected: string;
    };
    drawer: {
      underlay: string;
    };
    default: string;
    disabled: string;
    dropdown: {
      active: string;
      disabled: string;
      hover: string;
      titleGroupOption: string;
    };
    error: string;
    form: string;
    iconButton: {
      hover: string;
    };
    informative: string;
    inverted: string;
    layout: {
      header: string;
      body: string;
    };
    paginationBar: string;
    pressed: string;
    searchBar: {
      disabled: string;
      default: string;
    };
    sidemenu: {
      active: string;
    };
    stepper: {
      hover: string;
      indicator: {
        active: string;
        completed: string;
        error: string;
        inactive: string;
      };
      dividingLine: {
        completed: string;
        default: string;
        error: string;
      };
    };
    success: string;
    tag: {
      success: string;
      error: string;
      informative: string;
      pending: string;
      warning: string;
      tip: string;
    };
    tagDynamic: {
      default: string;
      deleted: string;
    };
    tips: string;
    toggleSwitch: {
      active: string;
      default: string;
      disabled: string;
      hover: string;
      thumb: string;
    };
    tooltip: string;
    transparent: string;
    warning: string;
  };
  border: {
    accordion: {
      default: string;
      focus: string;
    };
    avatar: {
      img: {
        hover: string;
      };
    };
    box: string;
    button: {
      secondary: string;
      secondaryHover: string;
      focus: string;
    };
    chip: {
      default: string;
      hover: string;
      active: string;
    };
    toggleSwitch: {
      active: string;
      default: string;
      disabled: string;
      focus: string;
    };
    disabled: string;
    divider: {
      default: string;
      active: string;
    };
    dropdown: {
      default: string;
      disabled: string;
      error: string;
      focus: string;
      hover: string;
    };
    layout: {
      header: string;
    };
    error: string;
    expandedGroup: string;
    form: {
      default: string;
      error: string;
      focus: string;
      hover: string;
    };
    informative: string;
    pending: string;
    pressed: string;
    searchBar: {
      default: string;
      hover: string;
      focus: string;
    };
    success: string;
    tab: {
      active: string;
    };
    tabGroup: {
      default: string;
    };
    tag: {
      success: string; //TODO: This name is in spanish in the figma's file
      error: string;
      informative: string; //TODO: This name is in spanish in the figma's file
      pending: string;
      warning: string;
      tip: string;
    };
    tagDynamic: {
      default: string;
      deleted: string;
      deletedHover: string;
      hover: string;
    };
    warning: string;
    checkbox: {
      default: string;
      hover: string;
      focus: string;
    };
  };
  icon: {
    default: string;
    disabled: string;
    error: string;
    hover: string;
    informative: string;
    linkVisited: string;
    success: string;
    tagDynamic: {
      default: string;
      deleted: string;
      deletedHover: string;
      hover: string;
    };
    tips: string;
    warning: string;
  };
  text: {
    body: string;
    accordion: {
      subLabel: string;
      avatar: string;
    };
    breadcrumb: {
      default: string;
    };
    button: {
      destructive: string;
      destructiveHover: string;
      primary: string;
      primaryHover: string;
      primaryClick: string;
      secondary: string;
      secondaryHover: string;
      secondaryClick: string;
      tertiary: string;
      tertiaryHover: string;
      tertiaryClick: string;
      ghost: string;
      ghostHover: string;
      ghostActive: string;
    };
    buttonMenu: {
      filled: string;
      hover: string;
    };
    card: {
      subHeader: string;
    };
    chip: {
      default: string;
      active: string;
      hover: string;
    };
    disabled: string;
    dropdown: {
      additionalText: string;
      additionalTextError: string;
      default: string;
      disabled: string;
      label: string;
      titleGroupOption: string;
    };
    dropdownItem: {
      active: string;
    };
    error: string;
    heading: string;
    helperText: string;
    helperTextError: string;
    informative: string;
    inverted: string;
    label: string;
    link: {
      active: string;
      destructive: string;
      destructiveActive: string;
      destructiveHover: string;
      primary: string;
      primaryActive: string;
      primaryHover: string;
      secondary: string;
      secondaryActive: string;
      secondaryHover: string;
      visited: string;
    };
    notifications: string;
    pending: string;
    pressed: string;
    radio: {
      default: string;
      disabled: string;
    };
    searchBar: {
      default: string;
      placeholder: string;
    };
    sidemenu: {
      default: string;
    };
    stepper: {
      active: string;
      completed: string;
      error: string;
      inactive: string;
      editable: string;
      helperText: {
        active: string;
        completed: string;
        error: string;
        inactive: string;
      };
      indicator: {
        active: string;
        completed: string;
        error: string;
        inactive: string;
      };
    };
    subheading: string;
    success: string;
    tab: {
      default: string;
      hover: string;
      active: string;
    };
    tag: {
      success: string; //TODO: This name is in spanish in the figma's file
      error: string;
      informative: string; //TODO: This name is in spanish in the figma's file
      pending: string;
      warning: string;
      tip: string;
    };
    toggleSwitch: {
      default: string;
      disabled: string;
    };
    input: {
      default: string;
    };
    warning: string;
    checkbox: {
      default: string;
    };
    calendar: {
      active: string;
      default: string;
    };
  };
};

export type SemanticShadows = {
  high: string;
  low: string;
  med: string;
  drawer: {
    left: string;
    right: string;
    top: string;
  };
};

export type SemanticOverlays = {
  light: unknown;
  dark: unknown;
};

export type ThemeType = {
  color: TokenColors & SemanticColors;
  shadow: SemanticShadows & NewShadow;
  overlay: SemanticOverlays;
  zIndex: ZIndex;
  font: TypographyProp & TypographyMethods;
  spacing: Spacing;
  breakpoint: NewBreakpoint;
  border: Border & NewBorder;
  text: Text;
};

export type ThemeType2 = {
  color: TokenColors;
  spacing: Spacing;
  shadow: NewShadow;
  text: Text;
  breakpoint: NewBreakpoint;
  border: NewBorder;
  zIndex: ZIndex;
  // zIndex pending
};
