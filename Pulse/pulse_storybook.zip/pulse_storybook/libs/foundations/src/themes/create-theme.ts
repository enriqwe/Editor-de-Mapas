import type { CoreColors } from "../tokens/2.0/core-colors";
import { createTokensFromCoreColors } from "../tokens/2.0/tokens-colors";
import { text } from "../tokens/2.0/text";
import { border } from "../tokens/2.0/border";
import { spacing } from "../tokens/spacing";
import { shadow } from "../tokens/2.0/shadow";
import { breakpoint } from "../tokens/2.0/breakpoint";
import { zIndex } from "../tokens/z-index";

import type { ThemeType2 } from "./theme.type";

export const createTheme = ({
  coreColors,
}: {
  coreColors: Partial<CoreColors>;
}): ThemeType2 => {
  return {
    color: createTokensFromCoreColors(coreColors),
    spacing,
    shadow,
    border,
    text,
    breakpoint,
    zIndex,
  };
};
