import { theme as defaultTheme } from "./default.theme";
import { theme as cssVars } from "./css-vars.theme";
// import { theme as sportianTheme } from './sportian.theme';

export const themes = {
  default: defaultTheme,
  cssVars,
  // sportian: sportianTheme,
};

export { theme as cssVars } from "./css-vars.theme";

export { createTheme } from "./create-theme";

export type { ThemeType } from "./theme.type";
