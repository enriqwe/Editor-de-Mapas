# Tokens builder

This tool generates TS and CSS files from Figma Tokens

## Steps to generate files

### 1 - Export tokens from Figma

- Go to Foundations project in Figma: https://www.figma.com/design/ZQ9TpDQA00Nt8soG92ryWj/Foundation-Pulse?node-id=2-243&p=f&t=GLFrCen5AAVoJn2v-0
- Go to plugins/manage plugins
- Search for Design Tokens Manager and run it
- You should see a screen like this:

![alt text](image.png)

- Click on export tokens, and then download option should enable in "Export Tokens to JSON" line

![alt text](image-1.png)

- Download zip, unzip it and copy following files to `libs/tokens-builder/tokens` folder:
  - Color - 1 - Foundation.Value.tokens.json
  - Color - 2 - Theme.Theme Base.tokens.json
  - Color - 3 - Specific.Sportian.tokens.json
  - effect.styles.tokens.json
  - text.styles.tokens.json
  - Typography.Desktop.tokens.json
  - Typography.Mobile.tokens.json

> Use git diff to make sure changes are somewhat expected: a change of color in one tokens, some new tokens added. If you are seeing big json changes, you'll need to adjust scripts (check [Tunning](#tunning))

- Proceed to `building` section

### 2 - Build TS and CSS files

- run `pnpm i` (this just needs to be done once for the whole repo)
- run `pnpm run build-tokens`

This will read token files from `/tokens` (copied on previous step) and re-create files in `/build`

- `build/ts` will contain all ts files
- `build/css` will contain all css files

> Once again, use git diff to make sure changes are somewhat expected

- If everything looks good, commit changes on `/tokens` and `/build`, so next person can compare changes too.

### 3 - Syncing to foundations

- run `pnpm run copy-tokens-to-foundations`

This will sync generated files on `libs/tokens-builder/build` to `libs/foundations/src/tokens`

## Tunning

- Main file is `build.js`
- `/formatters` folders includes custom formatters

### build.js Structure

The build.js file serves as the core configuration for transforming design tokens into platform-specific assets. Here's a detailed breakdown of its structure:

1. Core Functionality:

- Configures StyleDictionary to transform design tokens into platform-specific assets
- Processes Figma-exported tokens with custom handling for colors, typography, and shadows

2. Main Components:

- Token Source Files:
  - Color tokens (theme base and specific)
  - Typography tokens (desktop and mobile)
  - Shadow and text style tokens
  - Processed core color foundation file
- Custom Transforms:
  - Device name cleanup (noDeviceInName transform)
  - Color formatting utilities
  - Typography responsive handling
  - Shadow formatting

3. Output Generation:

- TypeScript:
  - Color definitions and token exports
  - Font definitions with responsive support
  - Shadow token exports
- CSS:
  - Variables for colors, z-index, borders, shadows
  - Device-specific responsive typography

4. Build Architecture:

- Multiple StyleDictionary instances handle different token groups
- Separate configurations for mobile and desktop typography
- Parallel platform builds for complete asset generation

The file ensures consistent styling across the application while maintaining responsive design principles through its systematic token transformation process.
